# WebAssembly SoA Read/Adjust Balance Reproduction

This package reproduces the final checkpoint-frequency balance experiment from the linked-list traversal study.

## What it measures

For each projection size (`10k`, `100k`, `1M`) and checkpoint frequency (`128`, `160`, `192`, `200`, `224`, `256`), it measures:

- **Serial read latency** using one dependent `uint32_t next[]` chain.
- **Adjustment latency** using **16 interleaved independent walkers**.
- **Combined estimated average read + measured average adjustment cost** for an edit length of **1**.

The assumptions used by the final balance sweep are:

- SoA traversal storage: `uint32_t next[]`.
- Read target is uniformly distributed within a checkpoint interval, so average read distance is `(frequency - 1) / 2` steps.
- Edit position is approximately uniform in the projection, so the benchmark adjusts approximately 50% of checkpoints.
- Edit length is 1.
- Adjustment uses 16 independent walkers.
- The linked structure is a deterministic random permutation, avoiding a simple sequential-memory walk.

## Requirements

- Node.js
- Clang with WebAssembly target support (`clang --target=wasm32`)

The build does not require Emscripten or libc.

## Run

```bash
./run.sh
```

Or separately:

```bash
./build.sh
node run.mjs
```

Results are printed as JSON and saved to:

```text
results/latest.json
```

## Benchmark implementation

`src/balance.c` exports two relevant WebAssembly functions:

```c
serial_chain(...)
adjust16(...)
```

`serial_chain` deliberately contains one dependent chain:

```c
p = next[p];
```

This measures **single-read latency**, not aggregate multi-walker throughput.

`adjust16` keeps 16 independent current positions live and advances them in an interleaved loop. An inline compiler barrier keeps the chain states observable to the optimizer and helps preserve the intended interleaved structure.

## Output fields

Each JSON row contains:

- `N`: projection node count.
- `F`: checkpoint frequency.
- `stepNs`: measured serial linked traversal latency per step.
- `avgSteps`: average checkpoint-to-target read distance `(F - 1) / 2`.
- `readNs`: `stepNs * avgSteps`.
- `adjustNs`: measured 16-walker adjustment latency with edit length 1 and ~50% affected checkpoints.
- `totalNs`: `readNs + adjustNs`.

## Intended reference targets

The frequency-selection study used these approximate combined budgets:

| Projection | Target |
|---:|---:|
| 10k | < 500 ns |
| 100k | < 1,000 ns |
| 1M | < 10,000 ns |

The experiment identified **frequency 128** as a strong common-case choice when most projection instances are expected to be substantially below 10k entries, while still remaining inside the selected 100k and 1M scale targets in the reference environment.

## Important reproducibility note

Absolute timings are CPU- and JIT-dependent. Run the benchmark on the actual target hardware/browser environment before treating a frequency as final. The experiment is designed to reproduce the methodology and relative tradeoff, not to guarantee identical nanosecond values on another machine.
