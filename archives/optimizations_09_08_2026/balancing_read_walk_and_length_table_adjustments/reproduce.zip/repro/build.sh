#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

CLANG="${CLANG:-clang}"
"$CLANG" --target=wasm32 -O3 -msimd128 -nostdlib \
  -Wl,--no-entry \
  -Wl,--export-memory \
  -Wl,--initial-memory=134217728 \
  -Wl,--max-memory=134217728 \
  -Wl,--export=serial_chain \
  -Wl,--export=adjust16 \
  src/balance.c -o balance.wasm

echo "Built $ROOT/balance.wasm"
