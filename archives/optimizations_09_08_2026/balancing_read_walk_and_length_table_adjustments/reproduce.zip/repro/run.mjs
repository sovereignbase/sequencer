import fs from 'node:fs';
import { performance } from 'node:perf_hooks';
const bytes=fs.readFileSync(new URL('./balance.wasm', import.meta.url));
const {instance}=await WebAssembly.instantiate(bytes,{});
const {memory,serial_chain,adjust16}=instance.exports;
const u32=new Uint32Array(memory.buffer);
let seed=0x12345678;
function rnd(){seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return seed>>>0;}
function median(a){a=[...a].sort((x,y)=>x-y);return a[a.length>>1];}
function buildOrder(N){const o=new Uint32Array(N);for(let i=0;i<N;i++)o[i]=i;for(let i=N-1;i>0;i--){const j=rnd()%(i+1);[o[i],o[j]]=[o[j],o[i]];}return o;}
function benchStep(start,totalSteps){serial_chain(0,start,10000);let reps=1;while(true){let t=performance.now();let p=start;for(let r=0;r<reps;r++)p=serial_chain(0,p,totalSteps);let dt=performance.now()-t;if(dt>=15||reps>=1<<16){const ts=[];for(let q=0;q<9;q++){t=performance.now();p=start;for(let r=0;r<reps;r++)p=serial_chain(0,p,totalSteps);ts.push(performance.now()-t);}return median(ts)*1e6/(reps*totalSteps);}reps*=2;}}
function benchAdjust(cpPtr,cpInit,count,L){u32.set(cpInit,cpPtr>>2);adjust16(0,cpPtr,count,L,4);let reps=1;while(true){u32.set(cpInit,cpPtr>>2);let t=performance.now();adjust16(0,cpPtr,count,L,reps);let dt=performance.now()-t;if(dt>=10||reps>=1<<18){const ts=[];for(let q=0;q<9;q++){u32.set(cpInit,cpPtr>>2);t=performance.now();adjust16(0,cpPtr,count,L,reps);ts.push(performance.now()-t);}return median(ts)*1e6/reps;}reps*=2;}}
const freqs=[128,160,192,200,224,256];
const sizes=[10000,100000,1000000];
const rows=[];
for(const N of sizes){seed=0x12345678^N;const order=buildOrder(N);for(let i=0;i<N-1;i++)u32[order[i]]=order[i+1];u32[order[N-1]]=order[0];const stepNs=benchStep(order[0], Math.max(100000,N));const cpPtr=((N*4+63)&~63);for(const F of freqs){const totalCp=Math.floor(N/F);const affected=Math.max(1,Math.floor(totalCp/2));const startCp=totalCp-affected;const cpInit=new Uint32Array(affected);for(let j=0;j<affected;j++)cpInit[j]=order[((startCp+j)*F)%N];const adjustNs=benchAdjust(cpPtr,cpInit,affected,1);const avgSteps=(F-1)/2;const readNs=stepNs*avgSteps;rows.push({N,F,stepNs,avgSteps,readNs,adjustNs,totalNs:readNs+adjustNs});console.error(`N=${N} F=${F} step=${stepNs.toFixed(3)} read=${readNs.toFixed(1)} adjust=${adjustNs.toFixed(1)} total=${(readNs+adjustNs).toFixed(1)}`);}}
console.log(JSON.stringify(rows,null,2));
