#include <stdint.h>
#include <stddef.h>

__attribute__((export_name("serial_reads")))
uint32_t serial_reads(const uint32_t *next, const uint32_t *starts, const uint16_t *offsets,
                      uint32_t count, uint32_t repeats) {
    uint32_t sink = 0;
    for (uint32_t r = 0; r < repeats; ++r) {
        for (uint32_t i = 0; i < count; ++i) {
            uint32_t p = starts[i];
            uint32_t n = offsets[i];
            for (uint32_t s = 0; s < n; ++s) p = next[p];
            sink ^= p + 0x9e3779b9u * (i + 1u);
        }
    }
    return sink;
}

#define STEP(p) p = next[p]

__attribute__((export_name("adjust16")))
uint32_t adjust16(const uint32_t *next, uint32_t *cp, uint32_t count,
                  uint32_t edit_len, uint32_t repeats) {
    uint32_t sink = 0;
    for (uint32_t r = 0; r < repeats; ++r) {
        uint32_t k = 0;
        for (; k + 16 <= count; k += 16) {
            uint32_t a0=cp[k+0], a1=cp[k+1], a2=cp[k+2], a3=cp[k+3];
            uint32_t a4=cp[k+4], a5=cp[k+5], a6=cp[k+6], a7=cp[k+7];
            uint32_t a8=cp[k+8], a9=cp[k+9], a10=cp[k+10], a11=cp[k+11];
            uint32_t a12=cp[k+12], a13=cp[k+13], a14=cp[k+14], a15=cp[k+15];
            for (uint32_t s=0; s<edit_len; ++s) {
                STEP(a0); STEP(a1); STEP(a2); STEP(a3);
                STEP(a4); STEP(a5); STEP(a6); STEP(a7);
                STEP(a8); STEP(a9); STEP(a10); STEP(a11);
                STEP(a12); STEP(a13); STEP(a14); STEP(a15);
                __asm__ __volatile__("" : "+r"(a0), "+r"(a1), "+r"(a2), "+r"(a3),
                                           "+r"(a4), "+r"(a5), "+r"(a6), "+r"(a7),
                                           "+r"(a8), "+r"(a9), "+r"(a10), "+r"(a11),
                                           "+r"(a12), "+r"(a13), "+r"(a14), "+r"(a15));
            }
            cp[k+0]=a0; cp[k+1]=a1; cp[k+2]=a2; cp[k+3]=a3;
            cp[k+4]=a4; cp[k+5]=a5; cp[k+6]=a6; cp[k+7]=a7;
            cp[k+8]=a8; cp[k+9]=a9; cp[k+10]=a10; cp[k+11]=a11;
            cp[k+12]=a12; cp[k+13]=a13; cp[k+14]=a14; cp[k+15]=a15;
            sink ^= a0 ^ a5 ^ a10 ^ a15;
        }
        // Tail: independent active walkers are handled in a small scalar loop here.
        // For average-size cases this is at most 15 entries and negligible.
        for (; k<count; ++k) {
            uint32_t p=cp[k];
            for (uint32_t s=0; s<edit_len; ++s) p=next[p];
            cp[k]=p; sink ^= p;
        }
    }
    return sink;
}

__attribute__((export_name("serial_chain")))
uint32_t serial_chain(const uint32_t *next, uint32_t start, uint32_t total_steps) {
    uint32_t p=start;
    for(uint32_t s=0;s<total_steps;++s) p=next[p];
    return p;
}
