# Frequency-Bounded Adjust Reproduction

This package reproduces the A/B benchmark comparing:

- **Baseline**: always adjust all affected checkpoints by the full edit length using 16 interleaved walkers.
- **Proposed**:
  - Remove: erase complete 128-strip checkpoint intervals, compact the length table, then 16-way adjust only `edit_length % 128`.
  - Insert: linearly walk complete 128-strip intervals to emit new checkpoints, insert them into the length table, then 16-way adjust only `edit_length % 128`.

## Requirements

- Node.js 20+
- clang with `wasm32` target support
- POSIX shell

## Run

```bash
./run.sh
```

Outputs:

- `results/latest.json`
- `results/latest.csv`
- Markdown tables printed to stdout

## Benchmark matrix

Projection sizes:

- 10,000
- 100,000
- 1,000,000

Edit lengths:

- 1
- 16
- 64
- 127
- 128
- 129
- 256
- 512
- 1000
- 10000

Checkpoint frequency: 128
Walker width: 16

The harness uses a deterministic random permutation for `next[]` and `prev[]` so pointer chasing is reproducible.
