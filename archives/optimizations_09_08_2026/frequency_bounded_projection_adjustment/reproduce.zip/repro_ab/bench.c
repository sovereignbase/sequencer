#include <stdint.h>
#include <stddef.h>

#define FREQ 128u
#define LANES 16u

static inline uint32_t walk_forward(const uint32_t* next, uint32_t p, uint32_t steps) {
  for (uint32_t s = 0; s < steps; ++s) p = next[p];
  return p;
}

static inline uint32_t walk_backward(const uint32_t* prev, uint32_t p, uint32_t steps) {
  for (uint32_t s = 0; s < steps; ++s) p = prev[p];
  return p;
}

__attribute__((export_name("baseline_insert")))
uint32_t baseline_insert(const uint32_t* next, uint32_t* table, uint32_t table_count, uint32_t edit_len) {
  uint32_t checksum = 0;
  uint32_t i = 0;
  for (; i + LANES <= table_count; i += LANES) {
    uint32_t p[LANES];
    for (uint32_t l = 0; l < LANES; ++l) p[l] = table[i + l];
    for (uint32_t s = 0; s < edit_len; ++s)
      for (uint32_t l = 0; l < LANES; ++l) p[l] = next[p[l]];
    for (uint32_t l = 0; l < LANES; ++l) { table[i + l] = p[l]; checksum ^= p[l]; }
  }
  for (; i < table_count; ++i) { table[i] = walk_forward(next, table[i], edit_len); checksum ^= table[i]; }
  return checksum;
}

__attribute__((export_name("baseline_remove")))
uint32_t baseline_remove(const uint32_t* prev, uint32_t* table, uint32_t table_count, uint32_t edit_len) {
  uint32_t checksum = 0;
  uint32_t i = 0;
  for (; i + LANES <= table_count; i += LANES) {
    uint32_t p[LANES];
    for (uint32_t l = 0; l < LANES; ++l) p[l] = table[i + l];
    for (uint32_t s = 0; s < edit_len; ++s)
      for (uint32_t l = 0; l < LANES; ++l) p[l] = prev[p[l]];
    for (uint32_t l = 0; l < LANES; ++l) { table[i + l] = p[l]; checksum ^= p[l]; }
  }
  for (; i < table_count; ++i) { table[i] = walk_backward(prev, table[i], edit_len); checksum ^= table[i]; }
  return checksum;
}

static inline void memmove_u32(uint32_t* dst, const uint32_t* src, uint32_t count) {
  if (dst < src) {
    for (uint32_t i = 0; i < count; ++i) dst[i] = src[i];
  } else if (dst > src) {
    for (uint32_t i = count; i-- > 0;) dst[i] = src[i];
  }
}

__attribute__((export_name("proposed_remove")))
uint32_t proposed_remove(const uint32_t* prev, uint32_t* table, uint32_t table_count, uint32_t edit_len) {
  uint32_t whole = edit_len >> 7;
  uint32_t rem = edit_len & 127u;
  if (whole > table_count) whole = table_count;
  if (whole) {
    memmove_u32(table, table + whole, table_count - whole);
    table_count -= whole;
  }
  if (!rem) return table_count;
  return baseline_remove(prev, table, table_count, rem) ^ table_count;
}

__attribute__((export_name("proposed_insert")))
uint32_t proposed_insert(const uint32_t* next, uint32_t* table, uint32_t table_count, uint32_t table_capacity, uint32_t edit_len, uint32_t start) {
  uint32_t whole = edit_len >> 7;
  uint32_t rem = edit_len & 127u;
  if (table_count + whole > table_capacity) whole = table_capacity - table_count;

  // Make room for new checkpoint entries at the front of this benchmark suffix.
  if (whole) memmove_u32(table + whole, table, table_count);

  uint32_t p = start;
  for (uint32_t q = 0; q < whole; ++q) {
    p = walk_forward(next, p, FREQ);
    table[q] = p;
  }

  uint32_t new_count = table_count + whole;
  if (rem) {
    // Adjust only the pre-existing suffix, not the newly generated checkpoints.
    baseline_insert(next, table + whole, table_count, rem);
  }

  uint32_t checksum = new_count ^ p;
  for (uint32_t i = 0; i < new_count; ++i) checksum ^= table[i];
  return checksum;
}
