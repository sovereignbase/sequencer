import fs from 'node:fs';
import { performance } from 'node:perf_hooks';

const wasm = fs.readFileSync(new URL('./bench.wasm', import.meta.url));
const { instance } = await WebAssembly.instantiate(wasm, {});
const e = instance.exports;
const mem = new Uint32Array(e.memory.buffer);

const sizes = [10_000, 100_000, 1_000_000];
const edits = [1,16,64,127,128,129,256,512,1000,10000];
const REPEATS = Number(process.env.REPEATS || 7);
const INNER = Number(process.env.INNER || 8);

function xorshift32(x){ x ^= x<<13; x ^= x>>>17; x ^= x<<5; return x>>>0; }
function makePermutation(n, seed=0x12345678){
  const a = new Uint32Array(n);
  for(let i=0;i<n;i++) a[i]=i;
  let x=seed>>>0;
  for(let i=n-1;i>0;i--){ x=xorshift32(x); const j=x%(i+1); const t=a[i]; a[i]=a[j]; a[j]=t; }
  const next = new Uint32Array(n), prev = new Uint32Array(n);
  for(let i=0;i<n;i++){ const cur=a[i], nx=a[(i+1)%n]; next[cur]=nx; prev[nx]=cur; }
  return {next,prev};
}
function median(a){ const b=[...a].sort((x,y)=>x-y); return b[Math.floor(b.length/2)]; }
function nsPerCall(fn){
  for(let i=0;i<3;i++) fn();
  const samples=[];
  for(let r=0;r<REPEATS;r++){
    const t0=performance.now();
    for(let i=0;i<INNER;i++) fn();
    const t1=performance.now();
    samples.push((t1-t0)*1e6/INNER);
  }
  return median(samples);
}

const results=[];
let ptrWords = 1024;
for(const n of sizes){
  const {next,prev}=makePermutation(n, 0x9e3779b9 ^ n);
  const nextPtr=ptrWords; mem.set(next,nextPtr); ptrWords += n + 64;
  const prevPtr=ptrWords; mem.set(prev,prevPtr); ptrWords += n + 64;
  const tableCount=Math.max(1,Math.floor(n/128/2)); // average edit at midpoint
  const capacity=tableCount + Math.ceil(Math.max(...edits)/128) + 64;
  const tablePtr=ptrWords; ptrWords += capacity + 64;
  const template=new Uint32Array(capacity);
  let p=0;
  for(let i=0;i<tableCount;i++){
    for(let s=0;s<128;s++) p=next[p];
    template[i]=p;
  }

  for(const L of edits){
    const whole=L>>7;
    const run=(kind)=>{
      mem.set(template,tablePtr);
      if(kind==='bi') return e.baseline_insert(nextPtr*4, tablePtr*4, tableCount, L);
      if(kind==='br') return e.baseline_remove(prevPtr*4, tablePtr*4, tableCount, L);
      if(kind==='pi') return e.proposed_insert(nextPtr*4, tablePtr*4, tableCount, capacity, L, template[0]||0);
      return e.proposed_remove(prevPtr*4, tablePtr*4, tableCount, L);
    };
    const bi=nsPerCall(()=>run('bi'));
    const pi=nsPerCall(()=>run('pi'));
    const br=nsPerCall(()=>run('br'));
    const pr=nsPerCall(()=>run('pr'));
    results.push({projection:n,edit:L,baseline_insert_ns:bi,proposed_insert_ns:pi,insert_speedup:bi/pi,baseline_remove_ns:br,proposed_remove_ns:pr,remove_speedup:br/pr});
  }
}

fs.mkdirSync(new URL('./results/', import.meta.url), {recursive:true});
fs.writeFileSync(new URL('./results/latest.json', import.meta.url), JSON.stringify({meta:{frequency:128,walkers:16,repeats:REPEATS,inner:INNER,node:process.version,v8:process.versions.v8},results},null,2));
const header='projection,edit,baseline_insert_ns,proposed_insert_ns,insert_speedup,baseline_remove_ns,proposed_remove_ns,remove_speedup\n';
const csv=header+results.map(r=>[r.projection,r.edit,r.baseline_insert_ns,r.proposed_insert_ns,r.insert_speedup,r.baseline_remove_ns,r.proposed_remove_ns,r.remove_speedup].join(',')).join('\n')+'\n';
fs.writeFileSync(new URL('./results/latest.csv', import.meta.url),csv);

for(const n of sizes){
  console.log(`\n## Projection ${n}`);
  console.log('| Edit | Insert A ns | Insert B ns | Speedup | Remove A ns | Remove B ns | Speedup |');
  console.log('|---:|---:|---:|---:|---:|---:|---:|');
  for(const r of results.filter(x=>x.projection===n)){
    console.log(`| ${r.edit} | ${r.baseline_insert_ns.toFixed(1)} | ${r.proposed_insert_ns.toFixed(1)} | ${r.insert_speedup.toFixed(2)}x | ${r.baseline_remove_ns.toFixed(1)} | ${r.proposed_remove_ns.toFixed(1)} | ${r.remove_speedup.toFixed(2)}x |`);
  }
}
