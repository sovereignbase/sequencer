#!/usr/bin/env bash
set -euo pipefail
clang --target=wasm32 -O3 -msimd128 -nostdlib \
  -Wl,--no-entry \
  -Wl,--export-memory \
  -Wl,--initial-memory=134217728 \
  -Wl,--max-memory=134217728 \
  -Wl,--allow-undefined \
  -o bench.wasm bench.c
