# WebAssembly Indexed Linked-List Benchmark

Reproducible benchmark suite for the linked-list traversal experiments discussed for Sequencer projection adjustment.

## What it measures

1. **Walker-width scaling:** 1, 2, 4, 8, 16, 32 and 64 independent checkpoint walkers.
2. **Working-set scaling:** 64 B through 64 MiB of SoA `uint32_t next[]` data.
3. **AoS vs SoA:** 48-byte AoS nodes versus a 4-byte SoA `next[]` hot set.
4. **Scalar vs SIMD output store:** eight-walker traversal followed by scalar stores versus two explicit `v128.store` operations.

Each checkpoint update performs **20 dependent indexed `next[]` loads**. Independent walkers are interleaved one load at a time to expose instruction-level and memory-level parallelism.

## Important compiler detail

`next` is intentionally declared `volatile` in the benchmark traversal functions. This makes the order of observable `next[]` loads explicit and prevents LLVM from legally regrouping the source into long per-walker dependency chains. This is deliberate: the benchmark is measuring the performance of an explicitly interleaved traversal schedule.

For production code, inspect the generated WASM/native code rather than assuming source-level interleaving survives optimization.

## Requirements

- Python 3
- Clang with the `wasm32` target and `wasm-ld`
- Node.js with WebAssembly SIMD support

Tested package generation environment:

- Clang 17
- Node.js 22

## Run

```bash
./scripts/build.sh
node bench.mjs
```

Results are written to:

```text
results/walkers.csv
results/walkers.md
results/metadata.json
results/extra.json
```

## Optional benchmark controls

```bash
REPEATS=15 WARMUPS=8 CHECKPOINTS=65536 CALLS=32 node bench.mjs
```

All tests use a deterministic xorshift32-generated random permutation cycle. `SEED` can be changed:

```bash
SEED=12345 node bench.mjs
```

## Interpretation

Throughput is reported as **completed checkpoint updates per microsecond**. One checkpoint update contains 20 linked-list steps, so traversal step throughput is `updates/µs × 20`.

Exact numbers are hardware-, runtime- and JIT-dependent. Reproduction should focus on the scaling behavior on the machine under test, not byte-for-byte equality with another CPU.

## AoS layout

The AoS comparison uses an exact 48-byte synthetic node:

```c
struct Node48 {
    uint32_t next;
    uint32_t prev;
    uint32_t length;
    uint32_t stable;
    uint32_t flags;
    uint32_t payload[7];
};
```

Only `next` is consumed during traversal. The SoA test uses a contiguous `uint32_t next[]` array.

## Inspecting the generated WASM

If `wasm2wat` or `wasm-tools` is installed, inspect `walkers.wasm` and verify the eight-walker SIMD-store function contains `v128.store`. The traversal loads are intentionally volatile at the source level to retain interleaving.
