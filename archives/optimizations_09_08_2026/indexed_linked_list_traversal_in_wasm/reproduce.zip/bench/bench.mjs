import fs from 'node:fs';
import os from 'node:os';
import process from 'node:process';

const ROOT = new URL('.', import.meta.url);
const widths = [1,2,4,8,16,32,64];
const sizes = [64,256,512,4<<10,16<<10,64<<10,256<<10,1<<20,4<<20,16<<20,64<<20];
const repeats = Number(process.env.REPEATS ?? 11);
const warmups = Number(process.env.WARMUPS ?? 5);
const checkpoints = Number(process.env.CHECKPOINTS ?? 65536);
const callsPerSample = Number(process.env.CALLS ?? 16);
const seed = Number(process.env.SEED ?? 0x12345678) >>> 0;

function median(a){ const b=[...a].sort((x,y)=>x-y); return b[Math.floor(b.length/2)]; }
function fmtBytes(n){ if(n>=1<<20)return `${n/(1<<20)} MiB`; if(n>=1<<10)return `${n/(1<<10)} KiB`; return `${n} B`; }
function xorshift32(x){ x^=x<<13; x^=x>>>17; x^=x<<5; return x>>>0; }
function makeCycle(n, s){
  const p = new Uint32Array(n); for(let i=0;i<n;i++)p[i]=i;
  let x=s>>>0;
  for(let i=n-1;i>0;i--){ x=xorshift32(x); const j=x%(i+1); const t=p[i];p[i]=p[j];p[j]=t; }
  const next=new Uint32Array(n);
  for(let i=0;i<n;i++) next[p[i]]=p[(i+1)%n];
  return {next, permutation:p};
}
function pages(bytes){ return Math.ceil(bytes/65536); }

async function loadWasm(path, memory){
  const bytes=fs.readFileSync(new URL(path, ROOT));
  const {instance}=await WebAssembly.instantiate(bytes,{env:{memory}});
  return instance.exports;
}

async function benchWalkers(){
  const rows=[];
  for(const bytes of sizes){
    const nodeCount=Math.max(2, bytes>>>2);
    const nextBytes=nodeCount*4;
    const lengthOffset=(nextBytes+63)&~63;
    const lengthBytes=checkpoints*4;
    const total=lengthOffset+lengthBytes+65536;
    const memory=new WebAssembly.Memory({initial:pages(total)});
    const exp=await loadWasm('walkers.wasm',memory);
    const {next, permutation}=makeCycle(nodeCount,seed^nodeCount);
    new Uint32Array(memory.buffer,0,nodeCount).set(next);
    const length=new Uint32Array(memory.buffer,lengthOffset,checkpoints);

    const row={bytes,label:fmtBytes(bytes)};
    for(const w of widths){
      for(let i=0;i<checkpoints;i++) length[i]=permutation[(i*20)%nodeCount];
      const fn=exp[`walk_${w}`];
      for(let i=0;i<warmups;i++) fn(0,lengthOffset,checkpoints);
      const samples=[];
      for(let r=0;r<repeats;r++){
        const t0=process.hrtime.bigint();
        for(let c=0;c<callsPerSample;c++) fn(0,lengthOffset,checkpoints);
        const us=Number(process.hrtime.bigint()-t0)/1000;
        samples.push((checkpoints*callsPerSample)/us);
      }
      row[w]=median(samples);
    }
    rows.push(row);
    console.log(row.label, Object.fromEntries(widths.map(w=>[w,row[w].toFixed(2)])));
  }
  return rows;
}

async function benchStores(){
  const bytes=1<<20, nodeCount=bytes>>>2, lengthOffset=bytes, total=lengthOffset+checkpoints*4+65536;
  const memory=new WebAssembly.Memory({initial:pages(total)});
  const exp=await loadWasm('walkers.wasm',memory);
  const {next,permutation}=makeCycle(nodeCount,seed^0xa5a5a5a5);
  new Uint32Array(memory.buffer,0,nodeCount).set(next);
  const length=new Uint32Array(memory.buffer,lengthOffset,checkpoints);
  const result={};
  for(const name of ['walk_8','walk_8_simd_store']){
    for(let i=0;i<checkpoints;i++) length[i]=permutation[(i*20)%nodeCount];
    const fn=exp[name]; for(let i=0;i<warmups;i++)fn(0,lengthOffset,checkpoints);
    const samples=[];
    for(let r=0;r<repeats;r++){
      const t0=process.hrtime.bigint();
      for(let c=0;c<callsPerSample;c++)fn(0,lengthOffset,checkpoints);
      const us=Number(process.hrtime.bigint()-t0)/1000;
      samples.push((checkpoints*callsPerSample)/us);
    }
    result[name]=median(samples);
  }
  return result;
}

async function benchLayout(){
  const nodeCount=1<<20;
  const soaBytes=nodeCount*4;
  const aosBytes=nodeCount*48;
  const stateOffset=((Math.max(soaBytes,aosBytes)+63)&~63);
  const total=stateOffset+65536;
  const memory=new WebAssembly.Memory({initial:pages(total)});
  const exp=await loadWasm('layout.wasm',memory);
  const {next,permutation}=makeCycle(nodeCount,seed^0x55aa55aa);
  const state=new Uint32Array(memory.buffer,stateOffset,4);
  const iterations=200000;
  const layout={};

  new Uint32Array(memory.buffer,0,nodeCount).set(next);
  state.set([permutation[0],permutation[20],permutation[40],permutation[60]]);
  for(let i=0;i<warmups;i++)exp.soa_walk4(0,stateOffset,iterations);
  let samples=[];
  for(let r=0;r<repeats;r++){
    const t0=process.hrtime.bigint(); exp.soa_walk4(0,stateOffset,iterations); const us=Number(process.hrtime.bigint()-t0)/1000;
    samples.push((iterations*4)/us);
  }
  layout.soa_steps_per_us=median(samples);

  const dv=new DataView(memory.buffer);
  for(let i=0;i<nodeCount;i++)dv.setUint32(i*48,next[i],true);
  state.set([permutation[0],permutation[20],permutation[40],permutation[60]]);
  for(let i=0;i<warmups;i++)exp.aos_walk4(0,stateOffset,iterations);
  samples=[];
  for(let r=0;r<repeats;r++){
    const t0=process.hrtime.bigint(); exp.aos_walk4(0,stateOffset,iterations); const us=Number(process.hrtime.bigint()-t0)/1000;
    samples.push((iterations*4)/us);
  }
  layout.aos_steps_per_us=median(samples);
  return layout;
}

function csv(rows){
  const head=['working_set_bytes','working_set',...widths.map(String)].join(',');
  return [head,...rows.map(r=>[r.bytes,r.label,...widths.map(w=>r[w].toFixed(6))].join(','))].join('\n')+'\n';
}
function markdown(rows){
  const head=`| Working set | ${widths.map(w=>`${w} walker${w===1?'':'s'}`).join(' | ')} |`;
  const sep=`|---:|${widths.map(()=> '---:').join('|')}|`;
  const lines=rows.map(r=>`| ${r.label} | ${widths.map(w=>r[w].toFixed(2)).join(' | ')} |`);
  return [head,sep,...lines].join('\n')+'\n';
}

const rows=await benchWalkers();
const stores=await benchStores();
const layout=await benchLayout();
const meta={date:new Date().toISOString(),node:process.version,v8:process.versions.v8,platform:process.platform,arch:process.arch,cpu:os.cpus()[0]?.model,repeats,warmups,checkpoints,callsPerSample,seed};
fs.mkdirSync(new URL('results/',ROOT),{recursive:true});
fs.writeFileSync(new URL('results/walkers.csv',ROOT),csv(rows));
fs.writeFileSync(new URL('results/walkers.md',ROOT),markdown(rows));
fs.writeFileSync(new URL('results/metadata.json',ROOT),JSON.stringify(meta,null,2)+'\n');
fs.writeFileSync(new URL('results/extra.json',ROOT),JSON.stringify({stores,layout},null,2)+'\n');
console.log('\n8 scalar vs SIMD store @ 1 MiB:',stores);
console.log('AoS vs SoA, 4 walkers, 1,048,576 nodes:',layout);
console.log('\nWrote results/');
