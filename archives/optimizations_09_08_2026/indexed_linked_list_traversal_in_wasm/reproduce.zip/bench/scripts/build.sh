#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PYTHON="${PYTHON:-python3}"
CLANG="${CLANG:-clang}"
"$PYTHON" "$ROOT/scripts/generate_walkers.py"
COMMON=(--target=wasm32 -O3 -msimd128 -nostdlib -Wl,--no-entry -Wl,--import-memory -Wl,--allow-undefined -Wl,--strip-all)
"$CLANG" "${COMMON[@]}" -Wl,--export=walk_1 -Wl,--export=walk_2 -Wl,--export=walk_4 -Wl,--export=walk_8 -Wl,--export=walk_16 -Wl,--export=walk_32 -Wl,--export=walk_64 -Wl,--export=walk_8_simd_store "$ROOT/src/walkers.c" -o "$ROOT/walkers.wasm"
"$CLANG" "${COMMON[@]}" -Wl,--export=soa_walk4 -Wl,--export=aos_walk4 "$ROOT/src/layout.c" -o "$ROOT/layout.wasm"
echo "Built walkers.wasm and layout.wasm"
