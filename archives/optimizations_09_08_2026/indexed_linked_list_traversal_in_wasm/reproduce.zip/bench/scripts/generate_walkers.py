#!/usr/bin/env python3
from pathlib import Path
WIDTHS = [1,2,4,8,16,32,64]
STEPS = 20
out = []
out.append('#include <stdint.h>\n')
out.append('#if defined(__wasm_simd128__)\n#include <wasm_simd128.h>\n#endif\n\n')
out.append('static inline uint32_t scalar_walk(const volatile uint32_t *next, uint32_t node) {\n')
out.append(f'  for (uint32_t s = 0; s < {STEPS}; ++s) node = next[node];\n')
out.append('  return node;\n}\n\n')
for w in WIDTHS:
    out.append(f'__attribute__((export_name("walk_{w}")))\n')
    out.append(f'void walk_{w}(const volatile uint32_t *next, uint32_t *length, uint32_t count) {{\n')
    out.append(f'  const uint32_t limit = count - (count % {w}u);\n')
    out.append(f'  for (uint32_t base = 0; base < limit; base += {w}u) {{\n')
    for i in range(w): out.append(f'    uint32_t a{i} = length[base + {i}u];\n')
    for s in range(STEPS):
        for i in range(w): out.append(f'    a{i} = next[a{i}];\n')
    for i in range(w): out.append(f'    length[base + {i}u] = a{i};\n')
    out.append('  }\n')
    out.append('  for (uint32_t i = limit; i < count; ++i) length[i] = scalar_walk(next, length[i]);\n')
    out.append('}\n\n')

# 8-walker scalar vs explicit SIMD stores.
out.append('__attribute__((export_name("walk_8_simd_store")))\n')
out.append('void walk_8_simd_store(const volatile uint32_t *next, uint32_t *length, uint32_t count) {\n')
out.append('  const uint32_t limit = count - (count % 8u);\n')
out.append('  for (uint32_t base = 0; base < limit; base += 8u) {\n')
for i in range(8): out.append(f'    uint32_t a{i} = length[base + {i}u];\n')
for s in range(STEPS):
    for i in range(8): out.append(f'    a{i} = next[a{i}];\n')
out.append('#if defined(__wasm_simd128__)\n')
out.append('    v128_t lo = wasm_i32x4_make(a0,a1,a2,a3);\n')
out.append('    v128_t hi = wasm_i32x4_make(a4,a5,a6,a7);\n')
out.append('    wasm_v128_store(length + base, lo);\n')
out.append('    wasm_v128_store(length + base + 4u, hi);\n')
out.append('#else\n')
for i in range(8): out.append(f'    length[base + {i}u] = a{i};\n')
out.append('#endif\n')
out.append('  }\n')
out.append('  for (uint32_t i = limit; i < count; ++i) length[i] = scalar_walk(next, length[i]);\n')
out.append('}\n\n')

Path(__file__).resolve().parents[1].joinpath('src/walkers.c').write_text(''.join(out))
