#include <stdint.h>

typedef struct {
  uint32_t next;
  uint32_t prev;
  uint32_t length;
  uint32_t stable;
  uint32_t flags;
  uint32_t payload[7]; /* 48 bytes total */
} Node48;

__attribute__((export_name("soa_walk4")))
void soa_walk4(const volatile uint32_t *next, uint32_t *state, uint32_t iterations) {
  uint32_t a=state[0], b=state[1], c=state[2], d=state[3];
  for (uint32_t i=0;i<iterations;++i) {
    a=next[a]; b=next[b]; c=next[c]; d=next[d];
  }
  state[0]=a; state[1]=b; state[2]=c; state[3]=d;
}

__attribute__((export_name("aos_walk4")))
void aos_walk4(const volatile Node48 *nodes, uint32_t *state, uint32_t iterations) {
  uint32_t a=state[0], b=state[1], c=state[2], d=state[3];
  for (uint32_t i=0;i<iterations;++i) {
    a=nodes[a].next; b=nodes[b].next; c=nodes[c].next; d=nodes[d].next;
  }
  state[0]=a; state[1]=b; state[2]=c; state[3]=d;
}
