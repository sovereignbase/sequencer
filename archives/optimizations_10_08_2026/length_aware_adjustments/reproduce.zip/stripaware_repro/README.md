# Strip-aware 16-walker + SIMD benchmark

Reproduces the benchmark for a checkpoint frequency of 128 projection Frames.

## Model
- SoA `next[]` and `length[]` arrays.
- Physical Strip IDs are randomized while logical projection order is linked through `next[]`.
- Checkpoint table contains one entry every 128 projection Frames.
- Read benchmark resolves an average 64-Frame displacement from a checkpoint.
- Adjust starts at the midpoint of the checkpoint table (average affected suffix).
- 16 independent walker states are processed together.
- Each walker consumes Frame distance using the current Strip length and follows `next[]` only when a Strip boundary is crossed.
- Results are written as four groups of four `uint32_t` values using `v128.store`.
- Strip-length profiles: mean 32, 128, and 512 Frames (randomized approximately 0.5x-1.5x mean).
- Edit/remainder lengths: 1, 4, 16, 32, 64, 127 Frames.
- Projection sizes: 10k, 100k, 1M Frames.

## Requirements
- Node.js with WebAssembly SIMD support.
- Clang with the wasm32 target and `wasm_simd128.h`.

## Run
```sh
./run.sh
```

Output is written to `results/latest.csv`. `results/reference.csv` contains the captured reference run.

Times are medians of seven timed samples after automatic repetition calibration. Absolute timings depend on CPU/runtime; compare trends and rerun on the target machine for production decisions.
