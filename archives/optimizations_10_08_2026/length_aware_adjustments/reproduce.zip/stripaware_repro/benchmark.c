#include <stdint.h>
#include <wasm_simd128.h>

#define MAX_FRAMES 1000000u
#define MAX_STRIPS 1000000u
#define MAX_CK ((MAX_FRAMES+127u)/128u + 16u)
#define FREQ 128u

static uint32_t next_arr[MAX_STRIPS];
static uint32_t len_arr[MAX_STRIPS];
static uint32_t order_arr[MAX_STRIPS];
static uint32_t logical_len[MAX_STRIPS];
static uint32_t ck_strip[MAX_CK];
static uint32_t ck_off[MAX_CK];
static uint32_t out_arr[MAX_CK];
static uint32_t strip_count_g, ck_count_g, frames_g;
static volatile uint32_t sink_g;
static uint32_t rng_state;

static inline uint32_t rng32(void){uint32_t x=rng_state; x^=x<<13; x^=x>>17; x^=x<<5; return rng_state=x;}

__attribute__((export_name("init_model")))
uint32_t init_model(uint32_t frames, uint32_t mean_len){
  if(frames>MAX_FRAMES) frames=MAX_FRAMES;
  if(mean_len<1) mean_len=1;
  frames_g=frames; rng_state=0x9e3779b9u ^ frames ^ (mean_len*0x85ebca6bu);
  uint32_t total=0,n=0;
  while(total<frames && n<MAX_STRIPS){
    uint32_t l;
    if(mean_len==1) l=1;
    else {uint32_t half=mean_len>>1, span=mean_len; l=half+(rng32()%(span+1u)); if(l<1)l=1;}
    if(l>frames-total) l=frames-total;
    logical_len[n]=l; order_arr[n]=n; total+=l; n++;
  }
  for(uint32_t i=n;i>1;--i){uint32_t j=rng32()%i,t=order_arr[i-1];order_arr[i-1]=order_arr[j];order_arr[j]=t;}
  for(uint32_t i=0;i<n;++i) len_arr[order_arr[i]]=logical_len[i];
  for(uint32_t i=0;i+1<n;++i) next_arr[order_arr[i]]=order_arr[i+1];
  next_arr[order_arr[n-1]]=order_arr[n-1]; strip_count_g=n;
  uint32_t ck=0,target=0,start=0;
  for(uint32_t i=0;i<n && target<frames;++i){
    uint32_t sid=order_arr[i],l=logical_len[i],end=start+l;
    while(target<end && target<frames){ck_strip[ck]=sid; ck_off[ck]=target-start; out_arr[ck]=sid; ck++; target+=FREQ;}
    start=end;
  }
  ck_count_g=ck; return ck;
}

#define DECL(L) uint32_t s##L=ck_strip[i+L]; uint32_t r##L=ck_off[i+L]+delta
#define STEP(L) do{ uint32_t ll=len_arr[s##L]; if(r##L>=ll){r##L-=ll; s##L=next_arr[s##L]; active=1;} }while(0)

__attribute__((export_name("adjust_delta")))
uint32_t adjust_delta(uint32_t reps, uint32_t delta){
  uint32_t start=ck_count_g>>1,sum=0;
  for(uint32_t rep=0;rep<reps;++rep){
    uint32_t i=start;
    for(;i+15<ck_count_g;i+=16){
      DECL(0);DECL(1);DECL(2);DECL(3);DECL(4);DECL(5);DECL(6);DECL(7);DECL(8);DECL(9);DECL(10);DECL(11);DECL(12);DECL(13);DECL(14);DECL(15);
      uint32_t active;
      do{
        active=0;
        STEP(0);STEP(1);STEP(2);STEP(3);STEP(4);STEP(5);STEP(6);STEP(7);
        STEP(8);STEP(9);STEP(10);STEP(11);STEP(12);STEP(13);STEP(14);STEP(15);
      }while(active);
      wasm_v128_store(out_arr+i+0,wasm_i32x4_make(s0,s1,s2,s3));
      wasm_v128_store(out_arr+i+4,wasm_i32x4_make(s4,s5,s6,s7));
      wasm_v128_store(out_arr+i+8,wasm_i32x4_make(s8,s9,s10,s11));
      wasm_v128_store(out_arr+i+12,wasm_i32x4_make(s12,s13,s14,s15));
      sum^=s0^s5^s10^s15;
    }
    for(;i<ck_count_g;++i){
      uint32_t s=ck_strip[i],rem=ck_off[i]+delta;
      while(rem>=len_arr[s]){rem-=len_arr[s];s=next_arr[s];}
      out_arr[i]=s; sum^=s;
    }
  }
  sink_g=sum; return sum;
}

__attribute__((export_name("read64_serial")))
uint32_t read64_serial(uint32_t reps){
  uint32_t limit=ck_count_g>>1; if(limit<2) limit=ck_count_g;
  uint32_t idx=0,sum=0,sid=0;
  for(uint32_t r=0;r<reps;++r){
    sid=ck_strip[idx]; uint32_t rem=ck_off[idx]+64u;
    while(rem>=len_arr[sid]){rem-=len_arr[sid];sid=next_arr[sid];}
    sum^=sid+rem; idx += (sid&63u)+1u; while(idx>=limit)idx-=limit;
  }
  sink_g=sum; return sum;
}

__attribute__((export_name("checkpoint_count"))) uint32_t checkpoint_count(void){return ck_count_g;}
__attribute__((export_name("strip_count"))) uint32_t strip_count(void){return strip_count_g;}
