import fs from 'node:fs';
import {performance} from 'node:perf_hooks';
const bytes=fs.readFileSync('./benchmark.wasm');
const {instance}=await WebAssembly.instantiate(bytes,{}); const e=instance.exports;
function med(a){a=[...a].sort((x,y)=>x-y);return a[a.length>>1];}
function measure1(fn,targetMs=18){fn(2);let reps=1;for(;;){const t0=performance.now();fn(reps);const dt=performance.now()-t0;if(dt>=targetMs||reps>=1<<22)break;const mul=Math.max(2,Math.min(16,Math.ceil(targetMs/Math.max(dt,.001))));reps=Math.min(1<<22,reps*mul);}const vals=[];for(let k=0;k<7;k++){const t0=performance.now();fn(reps);vals.push((performance.now()-t0)*1e6/reps);}return med(vals);}
const framesList=[10000,100000,1000000];
const means=[32,128,512];
const deltas=[1,4,16,32,64,127];
console.log('frames,mean_strip,strips,checkpoints,read64_ns,delta,adjust_ns,total_ns');
for(const frames of framesList){
 for(const mean of means){
  e.init_model(frames,mean);
  const read=measure1(r=>e.read64_serial(r));
  for(const d of deltas){
   const adj=measure1(r=>e.adjust_delta(r,d));
   console.log([frames,mean,e.strip_count(),e.checkpoint_count(),read.toFixed(2),d,adj.toFixed(2),(read+adj).toFixed(2)].join(','));
  }
 }
}
