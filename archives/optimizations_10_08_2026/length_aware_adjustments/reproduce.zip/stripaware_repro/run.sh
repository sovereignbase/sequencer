#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
CLANG="${CLANG:-clang}"
"$CLANG" --target=wasm32 -O3 -msimd128 -nostdlib benchmark.c -Wl,--no-entry -Wl,--export-memory -Wl,--initial-memory=33554432 -Wl,--max-memory=33554432 -o benchmark.wasm
node benchmark.mjs | tee results/latest.csv
