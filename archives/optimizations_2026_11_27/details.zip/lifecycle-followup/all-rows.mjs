import fs from 'node:fs'
const root='temp/optimization_2026_11_27_lifecycle/'
const rows=JSON.parse(fs.readFileSync(root+'final-full-base-to-indices.json'))
const aa=JSON.parse(fs.readFileSync(root+'final-full-base-to-control.json'))
const l=['# Complete final comparison','','Five observations per build; negative time changes are faster. The identical baseline-copy change is a separate control. Raw observations remain in the matching JSON files.','']
for(const kind of ['timing','space']){
  const unit=kind==='timing'?'µs':'bytes',scale=kind==='timing'?1000:1
  l.push('## '+kind,'',`| Row | Baseline ${unit} | Candidate ${unit} | Change | Baseline IQR ${unit} | Candidate IQR ${unit} | Paired change | Paired IQR, pp | Identical control change | Slower every pair |`,'| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |')
  for(const r of rows.filter(x=>x.kind===kind)){
    const control=aa.find(x=>x.key===r.key)
    const pct=x=>(x>0?'+':'')+x.toFixed(2)+'%'
    l.push(`| ${r.key} | ${(r.baselineMedian/scale).toFixed(3)} | ${(r.candidateMedian/scale).toFixed(3)} | ${pct(r.percentage)} | ${(r.baselineIQR/scale).toFixed(3)} | ${(r.candidateIQR/scale).toFixed(3)} | ${pct(r.pairedPercentage)} | ${r.pairedIQR.toFixed(2)} | ${pct(control.percentage)} | ${r.slowerEveryPair?'yes':'no'} |`)
  }
  l.push('')
}
fs.writeFileSync(root+'all-rows.md',l.join('\n'))
