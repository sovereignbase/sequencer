[![npm version](https://img.shields.io/npm/v/@sovereignbase/sequencer)](https://www.npmjs.com/package/@sovereignbase/sequencer)
[![JSR](https://jsr.io/badges/@sovereignbase/sequencer)](https://jsr.io/@sovereignbase/sequencer)
[![CI](https://github.com/sovereignbase/sequencer/actions/workflows/ci.yaml/badge.svg?branch=master)](https://github.com/sovereignbase/sequencer/actions/workflows/ci.yaml)
[![codecov](https://codecov.io/gh/sovereignbase/sequencer/branch/master/graph/badge.svg)](https://codecov.io/gh/sovereignbase/sequencer)
[![license](https://img.shields.io/npm/l/@sovereignbase/sequencer)](https://github.com/sovereignbase/sequencer/blob/master/LICENSE)

# Sequencer

Sequencer provides a total order guarantee for distributed editing. It allows independently operating actors to make concurrent edits and eventually converge on the same state without relying on network arrival order or perfectly synchronized clocks.

## Contents

- [Projection](#projection) · [Usage](#projection-usage) · [Benchmarks](#projection-benchmarks)
- [Tuple mode](#tuple-mode) · [Usage](#tuple-usage) · [Benchmarks](#tuple-benchmarks)
- [Text mode](#text-mode) · [Usage](#text-usage) · [Benchmarks](#text-benchmarks)
- [Packed words](#packed-words) · [Usage](#packed-words-usage) · [Benchmarks](#packed-words-benchmarks)
- [Batch](#batch) · [Usage](#batch-usage) · [Benchmarks](#batch-benchmarks)
- [Errors](#errors) · [Tests](#tests)
- [Credits](#credits) · [License](#license)

## Projection

<a id="projection-usage"></a>

### Usage

```ts
import { Projection } from '@sovereignbase/sequencer'

const projectionA = new Projection<string>(1)

const projectionB = new Projection<string>(2)

const insertDelta = projectionA.insert(['Hello World'], 0)
console.log(projectionA.value(0)) // "Hello World"

projectionB.apply(insertDelta)
console.log(projectionB.value(0)) // "Hello World"

const replaceDelta = projectionA.replace(['Hello Dude'], 0, 0)
console.log(projectionA.value(0)) // "Hello Dude"

const replaceAcknowledgement = projectionB.apply(replaceDelta)
console.log(projectionB.value(0)) // "Hello Dude"

projectionA.apply(replaceAcknowledgement?.[1])

const removeDelta = projectionA.remove(0, 0)
console.log(projectionA.value(0)) // undefined

const removeAcknowledgement = projectionB.apply(removeDelta)
console.log(projectionB.value(0)) // undefined

projectionA.apply(removeAcknowledgement?.[1])

const serializable = projectionA.sequence()

const acknowledgements = projectionB.merge(serializable)
projectionA.apply(acknowledgements?.[1])

projectionA.destroy()
projectionB.destroy()
```

<a id="projection-benchmarks"></a>

### Benchmarks

<!-- BEGIN GENERATED:projection:benchmarks -->

2026-11-27T21:29:46.151Z · local run

#### Moderate bundle size

| Format   | Raw (KiB) | Minified (KiB) | Minified + gzip (KiB) |
| -------- | --------: | -------------: | --------------------: |
| ESM      |    199.23 |         162.89 |                 56.49 |
| CommonJS |    199.41 |         164.51 |                 56.69 |

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

#### Average throughput during editing to checkpoint

Arithmetic means of 1 runs, in ops/s, from each phase's start to checkpoint.
Strips contain 1–100 Frames (visible entries). Headers show Strip counts and mean Frame counts.

**↑ Scale up (0 → 25,000 Strips)**

| Method / case  | 1,000 Strips<br>50,671 Frames | 5,000 Strips<br>252,715 Frames | 10,000 Strips<br>501,654 Frames | 15,000 Strips<br>750,657 Frames | 20,000 Strips<br>1,008,112 Frames | 25,000 Strips<br>1,257,856 Frames |
| -------------- | ----------------------------: | -----------------------------: | ------------------------------: | ------------------------------: | --------------------------------: | --------------------------------: |
| apply.random   |                       274,944 |                        283,447 |                         303,195 |                         319,273 |                           319,753 |                           320,763 |
| insert.head    |                       989,120 |                      1,173,599 |                       1,308,695 |                       1,357,343 |                         1,345,587 |                         1,361,374 |
| insert.random  |                       513,954 |                        629,644 |                         592,905 |                         615,465 |                           599,195 |                           575,472 |
| insert.tail    |                       602,773 |                      1,107,812 |                       1,320,795 |                       1,401,895 |                         1,432,480 |                         1,406,818 |
| remove.head    |                             — |                              — |                               — |                               — |                                 — |                                 — |
| remove.random  |                       437,924 |                        532,822 |                         514,089 |                         528,998 |                           517,798 |                           516,561 |
| remove.tail    |                             — |                              — |                               — |                               — |                                 — |                                 — |
| replace.head   |                       419,059 |                        486,135 |                         534,945 |                         528,467 |                           542,382 |                           542,542 |
| replace.random |                       389,332 |                        396,841 |                         394,630 |                         385,345 |                           381,153 |                           377,777 |
| replace.tail   |                       471,921 |                        448,467 |                         501,160 |                         523,149 |                           509,874 |                           521,304 |
| value.head     |                     1,200,624 |                      2,422,363 |                       2,912,226 |                       3,116,236 |                         3,225,390 |                         3,287,052 |
| value.random   |                     1,357,220 |                      1,121,831 |                       1,035,786 |                       1,014,981 |                           980,286 |                           961,254 |
| value.tail     |                     5,608,525 |                      5,773,672 |                       6,133,464 |                       6,509,287 |                         6,614,413 |                         6,744,908 |

**↓ Scale down (25,000 → 0 Strips)**

| Method / case  | 20,000 Strips<br>1,007,326 Frames | 15,000 Strips<br>756,010 Frames | 10,000 Strips<br>503,964 Frames | 5,000 Strips<br>252,028 Frames | 1,000 Strips<br>49,568 Frames | 0 Strips<br>0 Frames |
| -------------- | --------------------------------: | ------------------------------: | ------------------------------: | -----------------------------: | ----------------------------: | -------------------: |
| apply.random   |                           323,382 |                         303,458 |                         312,986 |                        322,745 |                       333,289 |              335,841 |
| insert.head    |                                 — |                               — |                               — |                              — |                             — |                    — |
| insert.random  |                           532,283 |                         533,966 |                         551,491 |                        571,860 |                       594,008 |              603,925 |
| insert.tail    |                                 — |                               — |                               — |                              — |                             — |                    — |
| remove.head    |                           701,400 |                         722,063 |                         676,273 |                        703,195 |                       722,535 |              727,078 |
| remove.random  |                           474,190 |                         493,991 |                         491,143 |                        506,200 |                       521,729 |              529,778 |
| remove.tail    |                           718,019 |                         760,526 |                         773,810 |                        781,201 |                       797,183 |              802,542 |
| replace.head   |                           510,803 |                         513,503 |                         518,026 |                        511,190 |                       518,660 |              522,659 |
| replace.random |                           346,344 |                         351,770 |                         364,196 |                        371,179 |                       386,000 |              391,869 |
| replace.tail   |                            27,568 |                          32,593 |                          41,854 |                         47,709 |                        53,541 |               55,417 |
| value.head     |                         2,312,353 |                       2,381,463 |                       2,407,589 |                      2,425,360 |                     2,434,546 |            2,454,614 |
| value.random   |                           929,040 |                         936,049 |                         954,381 |                        958,823 |                       991,965 |            1,009,730 |
| value.tail     |                         4,418,522 |                       4,333,507 |                       4,317,914 |                      4,287,889 |                     4,268,792 |            4,303,370 |

#### API throughput at checkpoint

Checkpoint calls, in ops/s, averaged across runs.

**↑ Scale up (0 → 25,000 Strips)**

| Method                            | 1,000 Strips<br>50,671 Frames | 5,000 Strips<br>252,715 Frames | 10,000 Strips<br>501,654 Frames | 15,000 Strips<br>750,657 Frames | 20,000 Strips<br>1,008,112 Frames | 25,000 Strips<br>1,257,856 Frames |
| --------------------------------- | ----------------------------: | -----------------------------: | ------------------------------: | ------------------------------: | --------------------------------: | --------------------------------: |
| new Projection(actorID, sequence) |                         2,036 |                            832 |                             589 |                             418 |                               295 |                               235 |
| sequence()                        |                           391 |                            128 |                              91 |                              71 |                                53 |                                42 |
| values()                          |                           536 |                            243 |                             184 |                             138 |                                95 |                                93 |

**↓ Scale down (25,000 → 0 Strips)**

| Method                            | 20,000 Strips<br>1,007,326 Frames | 15,000 Strips<br>756,010 Frames | 10,000 Strips<br>503,964 Frames | 5,000 Strips<br>252,028 Frames | 1,000 Strips<br>49,568 Frames | 0 Strips<br>0 Frames |
| --------------------------------- | --------------------------------: | ------------------------------: | ------------------------------: | -----------------------------: | ----------------------------: | -------------------: |
| new Projection(actorID, sequence) |                               286 |                             349 |                             562 |                          1,185 |                         5,862 |               78,740 |
| sequence()                        |                                52 |                              56 |                              82 |                            111 |                           145 |                  823 |
| values()                          |                               100 |                             146 |                             193 |                            368 |                         1,964 |              105,263 |

#### Sequence disk size at checkpoint

Complete exported Sequences, including Footage and acknowledgements. Sizes are in KiB.

**↑ Scale up (0 → 25,000 Strips)**

| Encoding           | 1,000 Strips<br>50,671 Frames | 5,000 Strips<br>252,715 Frames | 10,000 Strips<br>501,654 Frames | 15,000 Strips<br>750,657 Frames | 20,000 Strips<br>1,008,112 Frames | 25,000 Strips<br>1,257,856 Frames |
| ------------------ | ----------------------------: | -----------------------------: | ------------------------------: | ------------------------------: | --------------------------------: | --------------------------------: |
| JSON               |                        275.58 |                       1,623.80 |                        3,239.34 |                        4,881.17 |                          7,089.99 |                          9,217.18 |
| JSON + gzip        |                         14.63 |                          73.27 |                          148.63 |                          225.50 |                            311.06 |                            392.27 |
| MessagePack        |                        164.19 |                         820.20 |                        1,636.95 |                        3,511.78 |                          5,113.11 |                          6,522.62 |
| MessagePack + gzip |                         12.39 |                          61.64 |                          124.60 |                          199.90 |                            263.47 |                            334.88 |

**↓ Scale down (25,000 → 0 Strips)**

| Encoding           | 20,000 Strips<br>1,007,326 Frames | 15,000 Strips<br>756,010 Frames | 10,000 Strips<br>503,964 Frames | 5,000 Strips<br>252,028 Frames | 1,000 Strips<br>49,568 Frames | 0 Strips<br>0 Frames |
| ------------------ | --------------------------------: | ------------------------------: | ------------------------------: | -----------------------------: | ----------------------------: | -------------------: |
| JSON               |                          7,537.44 |                        5,701.64 |                        3,809.23 |                       1,894.53 |                        370.09 |                 0.02 |
| JSON + gzip        |                            326.42 |                          247.04 |                          164.74 |                          79.81 |                         15.92 |                 0.03 |
| MessagePack        |                          5,290.22 |                        3,986.59 |                        2,657.43 |                       1,324.48 |                        259.39 |                 0.01 |
| MessagePack + gzip |                            278.28 |                          209.82 |                          139.77 |                          67.85 |                         13.57 |                 0.03 |

#### Memory usage at checkpoint

One instance after checkpoint compaction and recreation: live native allocation plus retained JS array slots and string code units, in MiB (1,048,576 bytes). Unused WASM capacity is excluded.

**↑ Scale up (0 → 25,000 Strips)**

| Measurement            | 1,000 Strips<br>50,671 Frames | 5,000 Strips<br>252,715 Frames | 10,000 Strips<br>501,654 Frames | 15,000 Strips<br>750,657 Frames | 20,000 Strips<br>1,008,112 Frames | 25,000 Strips<br>1,257,856 Frames |
| ---------------------- | ----------------------------: | -----------------------------: | ------------------------------: | ------------------------------: | --------------------------------: | --------------------------------: |
| Estimated memory (MiB) |                          0.62 |                           3.09 |                            6.17 |                            9.37 |                             12.80 |                             16.23 |

**↓ Scale down (25,000 → 0 Strips)**

| Measurement            | 20,000 Strips<br>1,007,326 Frames | 15,000 Strips<br>756,010 Frames | 10,000 Strips<br>503,964 Frames | 5,000 Strips<br>252,028 Frames | 1,000 Strips<br>49,568 Frames | 0 Strips<br>0 Frames |
| ---------------------- | --------------------------------: | ------------------------------: | ------------------------------: | -----------------------------: | ----------------------------: | -------------------: |
| Estimated memory (MiB) |                             13.30 |                            9.90 |                            7.14 |                           4.08 |                          1.80 |                 1.23 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49,
win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.
Peer synchronization, encoding and explicit JS process garbage collection are outside API timings.
[Full lifecycle results](../final-full-base-4-lifecycle.md) · [Throughput results](benchmark/.results/throughput.md).

<!-- END GENERATED:projection:benchmarks -->

## Tuple mode

<a id="tuple-usage"></a>

### Usage

Each index represents an independent slot. Adding or removing values
never shifts other values. Empty slots return `undefined`.

Omit `maxLength` to allow dynamic growth.

```ts
const tuple = new Projection<string>(1, undefined, { enabled: 1, maxLength: 4 })
tuple.insert(['hello'], 2)
tuple.replace(['world'], 2, 2)
tuple.remove(2, 2)
```

<a id="tuple-benchmarks"></a>

### Benchmarks

<!-- BEGIN GENERATED:tuple:benchmarks -->

2026-11-27T21:37:12.436Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

#### Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ------: | ------------- | ---------: | -----------: | -----------------: |
|       2 | apply.replace |    641,441 |      872,220 |              1.36× |

#### Memory and encoded size

| Indices | Mode         | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ------: | ------------ | -------------------------------: | ----------------: | -----------------------: |
|       2 | Projection   |                           0.0006 |              0.03 |                     0.04 |
|       2 | Static tuple |                           0.0007 |              0.04 |                     0.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.

[Full tuple results](../residual-base-4-tuple.md).

<!-- END GENERATED:tuple:benchmarks -->

## Text mode

<a id="text-usage"></a>

### Usage

String inputs retain UTF-16 code units without creating character arrays.
Array results remain the default; `true` requests string Footage.

```ts
const text = new Projection<string>(1)
const gossip = text.insert('Hello', 0)
const replica = new Projection<string>(2)
replica.apply(gossip, true)
const visibleText = replica.values(undefined, undefined, true)
const snapshot = replica.sequence(true)
const restored = new Projection<string>(3, snapshot, undefined, true)
text.destroy()
replica.destroy()
restored.destroy()
```

<a id="text-benchmarks"></a>

### Benchmarks

<!-- BEGIN GENERATED:text:benchmarks -->

2026-11-27T21:39:31.709Z · local run

1 runs; median throughput in ops/s. Sizes are UTF-16 code units.

| Operation      | 1,048,576 string |
| -------------- | ---------------: |
| values.range   |        5,951,839 |
| replace.middle |          565,402 |
| sequence.text  |        4,702,214 |

Encoded snapshots use string Footage in both representations.

#### Memory and encoded size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ----------------: | -------------- | ------------: | -----------------------: | ----------------: | ---------------------: | --------------: |
|           1048576 | string         |        2.0004 |                  1024.02 |              1.05 |                1024.02 |            1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.

[Full text results](../guard-target-base-4-text.md).

<!-- END GENERATED:text:benchmarks -->

## Packed words

<a id="packed-words-usage"></a>

### Usage

Unpacked words remain the default. The optional final `binaryEncode` argument
returns `Uint8Array` metadata for binary serializers such as MessagePack.
Footage keeps its existing array or string representation.

```ts
const projection = new Projection<string>(1)
const gossip = projection.insert('Hello', 0, true)
const snapshot = projection.sequence(true, true)
const replica = new Projection<string>(2, snapshot, undefined, true)
replica.apply(projection.remove(0, 0, true), true, true)
projection.destroy()
replica.destroy()
```

<a id="packed-words-benchmarks"></a>

### Benchmarks

<!-- BEGIN GENERATED:words:benchmarks -->

2026-11-27T21:31:09.162Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload   | Words    | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| ---------- | -------- | -----------: | ----------------: | ------------: | -----------: | ---------: | ----------------: |
| append     | unpacked |         5.90 |              3.61 |         22.88 |       25,219 |    122,861 |               129 |
| append     | packed   |         5.90 |              3.61 |         13.98 |       23,424 |    158,090 |               285 |
| prepend    | unpacked |        40.07 |             18.06 |         22.94 |        1,639 |        789 |               218 |
| prepend    | packed   |         5.90 |              3.62 |         13.99 |       30,382 |      1,569 |               204 |
| random     | unpacked |       138.05 |             57.31 |         39.88 |          414 |        256 |                85 |
| random     | packed   |        49.58 |             35.38 |         23.45 |       14,839 |        545 |               127 |
| concurrent | unpacked |        92.24 |             42.76 |         32.34 |          657 |        198 |                94 |
| concurrent | packed   |        38.94 |             28.15 |         20.71 |       15,675 |        411 |               136 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.

[Full words results](../final-full-base-4-words.md).

<!-- END GENERATED:words:benchmarks -->

## Batch

Collect local edits into one packed Gossip. Edits are immediately visible;
Footage stays in JavaScript.

<a id="batch-usage"></a>

### Usage

```ts
const projection = new Projection<string>(1)
const peer = new Projection<string>(2)
projection.apply([[1], [2]])
peer.apply([[1], [2]])
const gossip = projection.batch((edit) => {
  edit.insert('hello', 0)
  edit.replace('H', 0, 0)
})
const result = peer.apply(gossip, true, true)
projection.apply(result?.[1] ?? [])
projection.destroy()
peer.destroy()
```

<a id="batch-benchmarks"></a>

### Benchmarks

<!-- BEGIN GENERATED:batch:benchmarks -->

2026-11-27T21:31:16.297Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload              | Mode       | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --------------------- | ---------- | -------------: | ------------: | --------------: | ----------------: | -----------: | ---------: |
| append                | individual |      1,787,630 |     1,094,551 |         562,577 |             76.05 |         5.99 |      0.012 |
| append                | batch      |      2,580,090 |   222,222,222 |     195,439,739 |              5.88 |         5.99 |      0.012 |
| prepend               | individual |      1,527,689 |     1,487,394 |         861,252 |             76.11 |         5.99 |      0.896 |
| prepend               | batch      |      1,563,559 |     1,884,185 |       1,645,323 |              5.89 |         5.99 |      0.896 |
| random.characters     | individual |        674,241 |       988,794 |         842,247 |             82.09 |        28.31 |      0.917 |
| random.characters     | batch      |      1,231,148 |     1,574,059 |       1,395,089 |             22.95 |        28.31 |      0.917 |
| random.words          | individual |      1,037,775 |     1,179,431 |         739,864 |            125.68 |        73.88 |      0.991 |
| random.words          | batch      |        965,282 |     1,737,217 |       1,562,378 |             59.71 |        73.88 |      0.991 |
| concurrent.characters | individual |      1,304,631 |     1,203,575 |         826,071 |             82.04 |        56.41 |      1.834 |
| concurrent.characters | batch      |      1,436,094 |     1,690,808 |       1,685,867 |             22.92 |        56.41 |      1.834 |
| concurrent.words      | individual |      1,271,941 |     1,345,533 |         915,108 |            125.74 |       147.81 |      1.981 |
| concurrent.words      | batch      |      1,501,351 |     1,733,277 |       1,531,785 |             59.79 |       147.81 |      1.981 |
| concurrent.mixed      | individual |        661,110 |       975,118 |         709,723 |            154.61 |        97.82 |      1.505 |
| concurrent.mixed      | batch      |        877,379 |     1,133,262 |       1,168,748 |             56.88 |        97.82 |      1.505 |
| causal.characters     | individual |      1,195,398 |     1,407,113 |       1,029,628 |             88.96 |        63.81 |      1.842 |
| causal.characters     | batch      |      1,232,805 |     1,835,031 |       1,656,726 |             23.18 |        63.81 |      1.842 |
| causal.words          | individual |      1,199,916 |     1,365,825 |         925,555 |            135.13 |       156.41 |      1.989 |
| causal.words          | batch      |      1,299,011 |     1,625,708 |       1,621,885 |             60.68 |       156.41 |      1.989 |
| causal.mixed          | individual |        735,560 |       992,548 |         721,288 |            161.05 |       103.75 |      1.509 |
| causal.mixed          | batch      |        862,484 |     1,239,618 |       1,137,527 |             57.34 |       103.75 |      1.509 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.

[Full batch results](../final-full-base-4-batch.md).

<!-- END GENERATED:batch:benchmarks -->

## Errors

| Code                      | Meaning                                                             |
| ------------------------- | ------------------------------------------------------------------- |
| `PROJECTION_DESTROYED`    | An operation was called after the Projection was destroyed.         |
| `BATCH_CLOSED`            | An editor was used after its batch callback finished.               |
| `NATIVE_OPERATION_FAILED` | The native runtime reported an initialization or operation failure. |
| `STRING_ENCODING_FAILED`  | Footage concatenation as text failed.                               |
| `UNKNOWN_ERROR`           | All other errors.                                                   |

Invalid input to `apply()` or `merge()` returns `undefined` instead of throwing.

## Tests

### Behaviour guaranteed by excessive tests

2026-11-27T16:45:59.798Z · [CI run](https://github.com/sovereignbase/sequencer/actions/runs/46035866481)

The latest verification passed 403 Vitest tests and 153 compatibility checks.
The configured 100% coverage threshold is met (100% statements, 100% branches, 100% functions, 100% lines).
See the [test suites](test/README.md) and
[automated test report](https://sovereignbase.dev/sequencer/tests/).

### Works everywhere where JavaScript and Wasm works

2026-11-27T16:45:59.804Z · [CI run](https://github.com/sovereignbase/sequencer/actions/runs/46035866481)

Runtimes covered by the latest compatibility verification:

- Node.js, ESM: passed
- Node.js, CommonJS: passed
- Deno: passed
- Bun: passed
- Edge Runtime: passed
- Cloudflare Workers through workerd: passed
- Chromium browser windows: passed
- Firefox browser windows: passed
- WebKit browser windows: passed

### Tested realtime and offline text editing behaviour examples

- [Online and offline editors](test/convergence/delivery/offline_realtime_editing/README.md): six editors converge through delayed, reversed and shuffled delivery, including offline changes arriving during online editing.
- [Concurrent replacements](test/convergence/delivery/concurrent_replacement_delivery/README.md): independent replacement histories retain the same surviving content across delivery orders.
- [Restart and redelivery](test/convergence/persistence/restart_redelivery/README.md): stored Sequences preserve visible content through hydration, duplicate delivery and further edits.
- [Peer-to-peer fanout](test/integration/fanout_peer_to_peer/README.md): independently editing browser peers synchronize through BroadcastChannel.
- [WebSocket fanout](test/integration/fanout_websocket/README.md): three browser peers converge through a stateless JSON Gossip relay.

## Credits

This could not have been made without years of work from many great engineers of many great projects, to mention a few:

- [AUTOMERGE](https://github.com/automerge)

- [YJS](https://github.com/yjs)

- [DIAMOND TYPES](https://github.com/josephg/diamond-types)

## License

Licensed under the Apache License, Version 2.0.

Copyright © 2026 Sovereignbase.
