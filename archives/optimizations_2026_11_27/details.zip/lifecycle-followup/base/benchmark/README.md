# Sequencer benchmarks

- [Lifecycle](lifecycle/README.md) measures scaling through continuous growth,
  mutation, immediate gossip and shrinkage.
- [Throughput](throughput/README.md) measures repeated API calls in independent
  bursts at configured checkpoints from 100 to 25,000 Strips.
- [Tuple](tuple/README.md) compares small static tuples with ordinary Projections;
  run it separately with `npm run bench:tuple`.
- [Large strings](text/README.md) measures bulk text, partial edits, replication,
  hydration and reads with array and string Footage; use `npm run bench:text`.
- [Words](words/README.md) compares numeric and byte metadata, transport sizes,
  encoding and complete loading; use `npm run bench:words`.
- [Batch](batch/README.md) compares individual binary outputs with batched editing,
  transport and compact checkpoints; use `npm run bench:batch`.

```powershell
npm run bench
npm run bench:lifecycle
npm run bench:throughput
```

Both default to three runs and produce JSON and Markdown reports under
`benchmark/.results`. `npm run bench` runs lifecycle followed by throughput;
the suite-specific commands run only the selected suite. When both suites use
`--output <path>`, filenames receive `.lifecycle` and `.throughput` suffixes.
Both report calls per second and average latency, with separate memory usage
and disk usage tables. Run `npm run bench -- --help` for shared options.

Lifecycle report writes also refresh the README's bundle and checkpoint tables.
Tuple and text runs refresh their own benchmark blocks without replacing other
results. Reports identify local runs or link to their producing CI run.
Those tables average independent runs at each growth and shrinkage checkpoint
and show JSON/MessagePack transport sizes with gzip in KiB. Memory estimates
are shown in MiB and cover one instance's live native allocation and retained JS Footage, excluding
unused WASM capacity. At lifecycle checkpoints both peers are destroyed and
recreated from the same compacted Sequence before measuring memory and continuing
edits. The peer uses a separate runtime. `--no-output` preserves existing reports
and README.

Default settings are collected at the top of `index.ts`. Command-line options
override them. Shared measurement helpers and types live in `.shared`;
each benchmark keeps its reporting code alongside its workload.

The benchmark builds its public API and memory diagnostics into an in-memory
bundle. Fresh factories release prior runtime references without accumulating
WASM instances in Node's module cache. The published package exposes the same
public API.
