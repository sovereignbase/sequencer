# Sequencer lifecycle benchmark

This benchmark drives one measured Replica and one continuously synchronized
peer through a complete dynamic lifecycle:

```text
0 → 1,000 → 5,000 → 10,000 → 15,000 → 20,000 → 25,000 → 20,000 → 15,000 → 10,000 → 5,000 → 1,000 → 0
```

The maximum is configurable. Checkpoints use the scales configured in
`../index.ts`, together with zero and the exact maximum. Strip lengths default to 1–100
Frames, and all random choices are deterministic from the run seed.

## Continuous workload

Every scale-up step grows the visible Strip count by exactly one and every
scale-down step shrinks it by exactly one. The timed operations are:

```text
apply.random
insert.head
insert.random
insert.tail
remove.head
remove.random
remove.tail
replace.head
replace.random
replace.tail
value.head
value.random
value.tail
```

The benchmark calls `Projection.insert`, `Projection.remove`, and
`Projection.replace` directly. Their Gossip updates are immediately sent to the other
peer with `apply`. If `apply` returns acknowledgements, those acknowledgements
are immediately gossiped back to the sender with another `apply` call.

Results use `method.case` names and alphabetical method/case order, matching
throughput. Console and Markdown tables separate `method` and `case` columns.

Each step reads the first, a random, and the last visible Frame, and replaces
the first, a random, and the last Strip with an equal-length Strip.

For `apply.random`, the peer performs an equal-length replacement outside the
timed region. The measured Projection then applies the remote Gossip inside the
timed region, after which any acknowledgements are sent back outside it. The
final scale-down step has no `apply.random` sample because no visible Strip
remains to replace.

## Checkpoints

At each checkpoint the benchmark validates the public Frame count and measures:

```text
create(sequence)
sequence
values
```

The measured Projection exports one compacted Sequence. Both peers are then
destroyed and recreated from that same Sequence, with the original Actor IDs.
The measured constructor creates the next active Projection. Both restored
views are checked against the pre-checkpoint values before editing continues.
Acknowledgements travel as part of the ordinary two-way gossip after every update.

The report includes visible Strip and Frame counts, retained Sequence insertion
count, serialized Sequence size, and one instance's estimated library memory.
The measured Projection and its peer have separate WASM runtimes. Memory is
sampled after checkpoint recreation, so discarded history does not contribute
to the active Projection's retained allocation.

Each complete run starts with fresh runtimes and its own warmup. The library
estimate uses live native allocator bytes plus eight bytes per retained
JavaScript array slot. Shared Footage arrays are counted once. Exercised runtime
buffers are included; unused WASM capacity is excluded. The shared WASM instance
remains in use across checkpoints, as it does in the library.

JS array headers, hidden backing capacity, application value objects, compiled
code and JS engine bookkeeping are outside the estimate. Benchmark inputs and
exported snapshots are counted only when retained by the measured runtime.

The raw report also preserves a separate exported Sequence estimate:

```text
4 bytes × Sequence frontier and insertion metadata words
+
8 bytes × JavaScript Footage slots
```

Storage measurements include V8 serialization, JSON, MessagePack, and level-nine
gzip of JSON and MessagePack. Both transport encodings use numeric arrays.
Encoding is kept outside timed API regions.
Checkpoint logging never resets cumulative operation metrics.

The final aggregate includes checkpoint `create`, `sequence`, and `values`
calls; `create` also includes initial creation. Throughput uses total calls
divided by total measured time. Separate memory and disk aggregates combine
nonempty checkpoints across runs; bytes per unit use total bytes divided by
total Strips or Frames.

## Timing and warmup

Only the selected public API call is inside each timed region. Random
generation, target selection, peer synchronization, serialization, metric
calculation, and logging are excluded. Latency is calculated as total measured
nanoseconds divided by call count.

Warmup exercises only the continuous operation paths. It does not run hidden
checkpoints, Sequences, restarts, serialization, or forced JS process garbage collection.

## Running

```powershell
npm run bench:lifecycle
```

A short development run:

```powershell
npm run bench -- --runs 1 --max-strips 100 --warmup-cycles 8 --no-output
```

Useful options are documented by:

```powershell
npm run bench -- --help
```

Memory usage and disk usage are reported in separate tables. Library memory
describes the measured instance's isolated runtime; process RSS and heap in the
raw report include the entire benchmark.
Disk usage measures serialized Sequence bytes, excluding filesystem metadata.

The default run count is three and the default maximum is 25,000 visible
Strips. JSON and Markdown reports are written to
`benchmark/.results/lifecycle.{json,md}` unless `--no-output` is supplied.

Writing the lifecycle report also updates the README's raw and minified bundle sizes,
checkpoint throughput, encoded Sequence sizes, and memory tables. Those tables
use growth and shrinkage checkpoints and arithmetic means of independent run observations.
Shrinkage rates exclude growth-phase calls and timings.
Checkpoint headers show Strip counts and the mean visible Frame count across runs.
Bundle sizes include WASM and use Terser with three compression passes.
Bundle and encoded sizes use KiB (1,024 bytes); memory uses MiB (1,048,576 bytes).
The memory tables show only the
isolated instance's library estimate. The full report retains individual runs
and distinguishes runtime memory from the exported Sequence representation.
`--no-output` leaves the README untouched.

The npm entry point exposes JS process garbage collection for checkpoint memory readings.
Memory observations and runtime initialization are outside API timings.
