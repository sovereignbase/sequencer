# Native runtime

`class.hpp` owns one Projection's native state. Strips allocate an indexed arena
when history first materializes; links remain valid when it grows. Insertion
coordinates occupy exactly six uint32 words, with signed Frame effects interpreted
in C++.

- `algorithms/` contains individual public operations.
- `auxiliary/` contains anchoring, fragmentation and position helpers.
- `components/Traversal/` indexes visible positions with weights in the Strip arena.
- `components/ContainmentTable/` indexes canonical Insertion identities.
- `components/PendingTable/` retains Insertions awaiting their parent identity or extent.
- `components/FrontierTable/` tracks Acknowledgements and retired Actors.
- `components/Tuple/` stores stable indices and active competing versions without Strip links.
- `components/Batch/` collects local replication coordinates and their shared byte encoding.
- `types/type.hpp` defines coordinates, strips, spans and operation results.
- `bindings.cpp` exposes scalar calls and contiguous numeric result buffers.

One synchronous WASM instance owns native allocation and algorithm execution.
Deferred Footage changes use shared queues cleared before each operation.
JavaScript reads borrowed numeric result views and retains generic Footage.
Native spans address opaque Footage tokens and Frame offsets. Structural Strip
indices, original Frame coordinates and visible Projection positions are distinct.
Fragments retain their canonical identity; only their runtime materialization changes.

Tuple placement runs through the same Projection algorithms and ACK tables.
Its `anchor_diff` is a stable index; each positive Insertion owns one Frame.
