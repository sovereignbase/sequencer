/**
 * @file
 * Integrates canonical history while preserving local traversal and consumer Splice
 * order.
 */
#include "../class.hpp"
#include <algorithm>

namespace sequencer {
void Projection::apply(const Insertion &entry, Result &result, bool binary) {
  // The first operation needs no queued allocation; released dependencies share
  // this stack and are pushed in reverse to retain arrival order.
  std::vector<Insertion> queue;
  bool first = true;
  while (first || !queue.empty()) {
    auto insertion = first ? entry : queue.back();
    // Remote history ends the local consecutive-edit chain, even for a duplicate.
    last_insert = none;
    if (first)
      first = false;
    else
      queue.pop_back();
    const auto c = insertion.coordinates;
    // Acknowledgement precedes duplicate and dependency checks; it does not prove
    // a gap-free received removal Session prefix.
    if (c.diff < 0) {
      if (insertion.content) {
        released.push_back({insertion.content, 0, 0});
        insertion.content = 0;
      }
      const std::array a{actor, c.session, c.start - c.diff};
      frontier.observe(a);
      // Preserve the final report, including lower frontiers; zero reports remain ordered.
      if (binary && !result.gossip.empty() && result.gossip.back().frontier[1] == c.session &&
          result.gossip.back().frontier[2] && a[2])
        result.gossip.back().frontier[2] = a[2];
      else
        result.gossip.push_back(Entry::acknowledge(a));
    }
    const auto extension = !tuple && c.extension();
    const auto existing = extension ? none : containment.get(c.session, c.start);
    // A snapshot may carry a longer known positive root. Suffix Gossip instead
    // continues its parent's logical time without a new zero reservation.
    const auto growing = !tuple && existing && c.diff > 0 &&
                         strips.identity[existing].coordinates.diff > 0 &&
                         c.diff > strips.identity[existing].coordinates.diff;
    // Duplicate detection and Acknowledgements are shared by both placement modes.
    if (existing && !growing) {
      if (insertion.content)
        released.push_back({insertion.content, 0, 0});
      continue;
    }
    const auto origin = c.birth() || (tuple && c.diff > 0)
                            ? none
                            : containment.get(c.anchor_session, c.anchor_start);
    if (tuple) {
      const auto before = tuple->winner(c.anchor_diff);
      const auto incoming = tuple->add(insertion);
      containment.set(c, incoming);
      if (c.diff > 0) {
        frame_count = std::max(frame_count, c.anchor_diff + 1);
        // An earlier removal may already target this previously missing version.
        for (const auto &mask : pending.take(c))
          if (mask.coordinates.anchor_diff == c.anchor_diff)
            tuple->erase(incoming, released, copied);
      } else if (origin)
        tuple->erase(origin, released, copied);
      else
        pending.set(insertion);
      if (before != tuple->winner(c.anchor_diff))
        result.changes.push_back({c.anchor_diff, c.anchor_diff + 1, tuple->value(c.anchor_diff)});
      continue;
    }
    if (extension || growing) {
      const auto parent = growing ? existing : origin;
      // A known parent identity can still lack the required extension prefix.
      if (!parent || (!growing && c.anchor_diff > Word(strips.identity[parent].coordinates.diff))) {
        pending.set(insertion);
        continue;
      }
      const auto known = Word(strips.identity[parent].coordinates.diff);
      const auto end = growing ? Word(c.diff) : c.anchor_diff + Word(c.diff);
      if (end > known && (growing || c.anchor_diff == known)) {
        // A longer snapshot includes the known prefix; replay only its unknown suffix.
        const auto source_start = growing ? known : known - c.anchor_diff;
        const auto at = extend(parent, end - known, insertion.content,
                               insertion.content_start + source_start, insertion.string_content);
        result.changes.push_back(
            {at, at, Span{insertion.content, insertion.content_start + source_start, end - known}});
        auto released_pending = pending.take(strips.identity[parent].coordinates);
        for (auto it = released_pending.rbegin(); it != released_pending.rend(); ++it)
          queue.push_back(*it);
      } else if (insertion.content)
        released.push_back({insertion.content, 0, 0});
      continue;
    }
    // Stage before allocating so repeated out-of-order delivery cannot leak
    // unlinked arena nodes. A dependent retains coordinates and an opaque binding token.
    if (!c.birth() &&
        (!origin || (strips.identity[origin].coordinates.diff > 0 &&
                     std::uint64_t(c.anchor_diff) + (c.diff < 0 ? -std::int64_t(c.diff) : 0) >
                         Word(strips.identity[origin].coordinates.diff)))) {
      pending.set(insertion);
      continue;
    }
    const auto incoming = allocate(insertion);
    Word start = 0;
    auto diff = c.diff;
    if (c.birth() && !structural_count)
      insert_first(incoming);
    else {
      Word point = 0;
      Index anchor = none;
      if (!c.birth()) {
        const auto resolved = find_containing_fragment(origin, c, incoming);
        point = resolved.first;
        anchor = resolved.second;
      }
      // Restore a visible traversal boundary when local masking left gate hidden.
      if (!frame_count) {
        gate = none;
        gate_position = 0;
      } else if (gate && strips.fragment_diff[gate] <= 0)
        find_frame(std::min(gate_position, frame_count - 1));
      diff = anchor_strip(incoming, anchor, point);
      // A fragmented mask can consume Frames on both sides of surviving gate
      // content. Only its consumed prefix before the gate boundary shifts it.
      auto gate_diff = diff;
      if (diff < 0 && strips.fragment[incoming] && gate) {
        auto parent = gate;
        while (parent &&
               !(strips.identity[parent].coordinates.session == c.anchor_session &&
                 strips.identity[parent].coordinates.start == c.anchor_start) &&
               !(strips.identity[parent].coordinates.anchor_session == c.anchor_session &&
                 strips.identity[parent].coordinates.anchor_start == c.anchor_start))
          parent = containment.get(strips.identity[parent].coordinates.anchor_session,
                                   strips.identity[parent].coordinates.anchor_start);
        if (parent) {
          const auto boundary = strips.identity[parent].coordinates.session == c.anchor_session &&
                                        strips.identity[parent].coordinates.start == c.anchor_start
                                    ? strips.fragment_start[parent]
                                    : strips.identity[parent].coordinates.anchor_diff;
          gate_diff = 0;
          for (auto mask = incoming;
               mask && strips.identity[mask].coordinates.anchor_diff + strips.fragment_start[mask] <
                           boundary;
               mask = strips.fragment[mask])
            gate_diff -= std::min(
                -strips.fragment_diff[mask],
                std::max(0, std::int32_t(boundary - strips.identity[mask].coordinates.anchor_diff -
                                         strips.fragment_start[mask])));
        }
      }
      // Resolve the consumer position after linking, retaining gate's content identity.
      start = position_of(incoming, gate_diff);
      if (start <= gate_position)
        gate_position =
            Word(std::max<std::int64_t>(start, std::int64_t(gate_position) + gate_diff));
      // An emptied left fragment hands the gate and its distances to its surviving right
      // fragment.
      if (diff > 0 && gate && strips.identity[gate].fragmented && !strips.fragment_diff[gate]) {
        gate = strips.fragment[gate];
      }
    }
    containment.set(c, incoming);
    if (diff > 0) {
      if (!start)
        head = incoming;
      if (start + Word(diff) == frame_count)
        tail = incoming;
      result.changes.push_back(
          {start, start, Span{insertion.content, insertion.content_start, Word(c.diff)}});
    } else if (diff < 0) {
      // Separate Splices preserve concurrent content between mask fragments;
      // each later Splice uses the Projection left by preceding removals.
      auto position = start;
      for (auto mask = incoming; mask; mask = strips.fragment[mask]) {
        if (strips.fragment_diff[mask] < 0)
          result.changes.push_back({position, position - strips.fragment_diff[mask], {}});
        const auto next = strips.fragment[mask];
        if (next)
          for (auto i = strips.right[mask]; i && i != next; i = strips.right[i])
            position += std::max(0, strips.fragment_diff[i]);
      }
    }
    // Hidden history remains addressable even when no Frames are visible.
    if (!frame_count) {
      gate = none;
      gate_position = 0;
    } else if (!gate) {
      gate = head;
      gate_position = 0;
    } else if (strips.fragment_diff[gate] <= 0)
      find_frame(std::min(gate_position, frame_count - 1));
    // Materialization makes this canonical identity available to waiting descendants.
    auto released_pending = pending.take(c);
    for (auto it = released_pending.rbegin(); it != released_pending.rend(); ++it)
      queue.push_back(*it);
  }
}
} // namespace sequencer
