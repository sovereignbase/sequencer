/**
 * @file
 * Materializes a positive Insertion suffix under its existing canonical identity.
 */
#include "../class.hpp"
#include "containsAnchor.hpp"
#include <algorithm>

namespace sequencer {
Word Projection::extend(Index origin, Word count, Word content, Word source_start, bool text) {
  const auto original = strips.identity[origin];
  const auto end = Word(original.coordinates.diff);
  const auto target_content =
      original.shared_content || !original.content
          ? content && content != original.content ? content : next_content++
          : original.content;
  // A mixed suffix materializes an array; restore the text root's masked slots there.
  if (original.string_content && !text && original.fragmented) {
    Word start = 0;
    for (auto fragment = origin; fragment; fragment = strips.fragment[fragment]) {
      const auto point = strips.fragment_start[fragment];
      if (point > start)
        released.push_back({target_content, start, point - start});
      start = point + Word(std::max(0, strips.fragment_diff[fragment]));
    }
    if (end > start)
      released.push_back({target_content, start, end - start});
  }
  auto last = origin;
  while (strips.fragment[last])
    last = strips.fragment[last];
  // Native state retains one content token. JavaScript appends the new suffix
  // after public Splices have read it, then releases its temporary source binding.
  // An original positive extent fits 31 bits; its high bit requests a private JS copy.
  const auto target = end | (original.footage_state == FootageState::Private ? 0 : 0x80000000u);
  appended.push_back({target_content, content, source_start, count, target, original.content_start,
                      original.content});
  if (original.shared_content && !--shared_content_count)
    released.push_back({original.content, 0, 0});
  if (content && content != target_content)
    released.push_back({content, 0, 0});
  const auto next = strips.right[last];
  // An intact visible endpoint can grow in place. Existing children or interior
  // fragmentation require replay through the same anchor placement used for normal history.
  if ((last == tail || (!strips.identity[origin].fragmented &&
                        (!next || !contains_anchor(original.coordinates,
                                                   strips.identity[next].coordinates, 0, end)))) &&
      strips.fragment_diff[last] > 0 &&
      strips.fragment_start[last] + Word(strips.fragment_diff[last]) == end) {
    const auto at =
        last == tail ? frame_count : position_of(last) + Word(strips.fragment_diff[last]);
    gate = last;
    gate_position = at - Word(strips.fragment_diff[last]);
    strips.fragment_diff[last] += std::int32_t(count);
    traversal.update(strips, last, strips.fragment_diff[last] - std::int32_t(count));
    frame_count += count;
    for (auto fragment = origin; fragment; fragment = strips.fragment[fragment]) {
      strips.identity[fragment].content = target_content;
      strips.identity[fragment].shared_content = false;
      strips.identity[fragment].coordinates.diff += std::int32_t(count);
      strips.identity[fragment].content_start = 0;
      strips.identity[fragment].content_owned = true;
      strips.identity[fragment].footage_state = FootageState::Private;
      strips.identity[fragment].string_content = original.string_content && text;
    }
    return at;
  }

  // A suffix follows every existing descendant at the old endpoint. It extends
  // the same canonical root and never participates in sibling competition.
  const auto left = subtree_end(origin);
  const auto right = strips.right[left];
  auto grown = original;
  grown.content = target_content;
  grown.shared_content = false;
  grown.coordinates.diff += std::int32_t(count);
  grown.content_start = 0;
  grown.content_owned = true;
  grown.footage_state = FootageState::Private;
  grown.string_content = original.string_content && text;
  const auto incoming = allocate(grown);
  strips.fragment_start[incoming] = end;
  strips.fragment_diff[incoming] = std::int32_t(count);
  strips.identity[incoming].offset = strips.identity[incoming].fragmented = true;
  strips.left[incoming] = left;
  strips.right[incoming] = right;
  strips.right[left] = incoming;
  if (right)
    strips.left[right] = incoming;
  if (!head || right == head)
    head = incoming;
  if (!tail || !right || left == tail)
    tail = incoming;
  ++structural_count;
  traversal.insert(strips, structural_head, structural_count, incoming);
  frame_count += count;
  for (auto fragment = origin; fragment; fragment = strips.fragment[fragment]) {
    strips.identity[fragment].content = target_content;
    strips.identity[fragment].shared_content = false;
    strips.identity[fragment].coordinates.diff = grown.coordinates.diff;
    strips.identity[fragment].content_start = 0;
    strips.identity[fragment].content_owned = true;
    strips.identity[fragment].footage_state = FootageState::Private;
    strips.identity[fragment].string_content = grown.string_content;
    strips.identity[fragment].fragmented = true;
  }
  // All fragments share the grown original extent and the rebased private Footage array.
  strips.fragment[last] = incoming;
  const auto at = position_of(incoming, std::int32_t(count));
  if (gate && at <= gate_position)
    gate_position += count;
  if (at == 0)
    head = incoming;
  if (at + count == frame_count)
    tail = incoming;
  gate = incoming;
  gate_position = at;
  return at;
}
} // namespace sequencer
