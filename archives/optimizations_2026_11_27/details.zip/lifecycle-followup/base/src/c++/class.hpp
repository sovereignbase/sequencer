#pragma once
#include "components/ContainmentTable/class.hpp"
#include "components/FrontierTable/class.hpp"
#include "components/PendingTable/class.hpp"
#include "components/Traversal/class.hpp"
#include "components/Tuple/class.hpp"
#include <span>
#include <stdexcept>

namespace sequencer {
/** Visible Projection of a replicated Sequence. */
class Projection {
public:
  /** Actor identifier used in Acknowledgements. */
  const Word actor;
  /** Indexed Strip arena; index zero is the absent-link sentinel. */
  Strips strips;
  Index structural_head{} /**< First Strip in Structural Order, including hidden history. */,
      head{} /**< Strip owning the first visible Frame. */,
      tail{} /**< Strip owning the last visible Frame. */,
      gate{} /**< Retained local lookup Strip, possibly a hidden insertion boundary. */;
  Word structural_count{} /**< Linked Strip count, including fragments and masks. */,
      frame_count{} /**< Visible Frame count; tuple extent includes empty registers. */,
      gate_position{} /**< Visible position at the gate Strip's first Frame or boundary. */;
  /** Weighted view into the arena's traversal directory. */
  Traversal traversal;
  /** Last locally authored positive root eligible for an intact extension. */
  Index last_insert{};
  /** Positive roots retaining the constructor's shared Footage binding. */
  Word shared_content_count{};
  /** Independent positive and reducing clocks, each stored as [Session, next time]. */
  std::array<Word, 2> increase_clock, decrease_clock;
  /** Canonical Insertion identity to materialized root. */
  ContainmentTable containment;
  /** Unresolved Insertions grouped by their missing canonical parent. */
  PendingTable pending;
  /** Actor membership and Acknowledgements used only by export compaction. */
  FrontierTable frontier;
  /** Present only for stable-index register semantics. */
  std::unique_ptr<Tuple> tuple;

  /** Initializes empty history with independently supplied Session identities.
   * @param actor_id Acknowledging Actor.
   * @param increasing_session Session for locally authored positive Insertions.
   * @param decreasing_session Session for locally authored reducing Insertions.
   * @param tuple_enabled Whether indices identify stable registers.
   * @param tuple_capacity Fixed register count, or UINT32_MAX for dynamic growth.
   */
  Projection(Word actor_id, Word increasing_session, Word decreasing_session,
             bool tuple_enabled = false, Word tuple_capacity = UINT32_MAX)
      : actor(actor_id), increase_clock{increasing_session, 0},
        decrease_clock{decreasing_session, 0} {
    if (tuple_enabled) {
      tuple = std::make_unique<Tuple>(tuple_capacity);
      frame_count = tuple_capacity == UINT32_MAX ? 0 : tuple_capacity;
    }
  }
  /** Allocates an unlinked Strip; linking, counts and containment are separate.
   * @param i Canonical coordinates and JavaScript binding reference.
   * @return Stable arena index.
   */
  Index allocate(Insertion i) {
    if (strips.count == strips.capacity) {
      // Directory rows still refer to the previous allocation until grow rebases them.
      const auto previous = strips.reserve(std::max(Word(2), strips.capacity * 2));
      traversal.grow(strips);
    }
    return strips.append(i);
  }
  /** Reads visible length without structural traversal.
   * @return Maintained visible Frame count.
   */
  Word length() const { return frame_count; }
  /** Initializes structural and visible endpoints for the first root.
   * @param i Unlinked root Strip in an empty Structural Order.
   */
  void insert_first(Index i);
  /** Splits materialization without changing canonical Insertion coordinates.
   * @param anchor Strip containing the logical boundary.
   * @param point Original Frame boundary, relative to its canonical Insertion.
   * @param incoming_diff Incoming visible effect; negative values consume the right prefix.
   * @param indexed Whether the live traversal directory is maintained during this split.
   * @return Structural successor at the new boundary.
   */
  Index split_strip(Index anchor, Word point, std::int32_t incoming_diff, bool indexed = true);
  /** Finds a competitor's final descendant so sibling subtrees stay contiguous.
   * @param root First Strip of the causal subtree.
   * @return Last Strip belonging to that subtree.
   */
  Index subtree_end(Index root);
  /** Resolves a historical anchor through fragments and already consumed Frames.
   * @param origin Canonical parent root, or a known fragment from which to continue.
   * @param coordinates Canonical anchor and authored effect; positive queries resolve boundaries.
   * @param incoming Strip whose negative effect may be shortened by overlap; none for boundary
   * queries.
   * @return Resolved logical boundary and its current owning Strip.
   */
  std::pair<Word, Index> find_containing_fragment(Index origin, const Coordinates &coordinates,
                                                  Index incoming = none);
  /** Places a Strip in deterministic Structural Order and materializes mask continuations.
   * @param incoming Unlinked Strip to place.
   * @param anchor Current owner of the logical boundary; none for the virtual root.
   * @param point Boundary relative to the owning Insertion or mask.
   * @param index_fragments Whether to maintain the live traversal directory during placement.
   * @return Actual signed visible effect across all materialized fragments.
   */
  std::int32_t anchor_strip(Index incoming, Index anchor, Word point, bool index_fragments = true);
  /** Resolves a visible position and retains the owning Strip as gate.
   * @param position Visible Frame position, or insertion boundary when requested.
   * @param for_insertion Whether logical boundaries may resolve through hidden history.
   * @return Original Frame coordinate within the gate Insertion.
   */
  Word find_frame(Word position, bool for_insertion = false);
  /** Locates a linked Strip without moving the retained local gate.
   * @param strip Strip whose visible start is required.
   * @param gate_diff Effect already applied before the retained gate boundary.
   * @return Visible Projection position.
   */
  Word position_of(Index strip, std::int32_t gate_diff = 0);
  /** Translates a visible insertion boundary into a replayable logical anchor.
   * @param position Insertion boundary in 0..frame_count.
   * @return Logical point and its anchoring Strip.
   */
  std::pair<Word, Index> select_anchor(Word position);
  /** Authors positive Frames, extending only an eligible local Insertion.
   * @param count Positive Footage length; tuple mode accepts one Frame per Insertion.
   * @param content JavaScript binding token; native code never reads the values.
   * @param at Visible insertion boundary.
   * @param text Whether the binding retains immutable UTF-16 text.
   * @return Canonical Gossip operation, including only the suffix for an extension.
   */
  Insertion insert(Word count, Word content, Word at, bool text = false);
  /** Authors one Insertion per stable tuple index, or one contiguous sequence Insertion.
   * @param count Number of Frames to insert.
   * @param content JavaScript Footage binding token.
   * @param at First tuple index or visible insertion boundary.
   * @param text Whether the input retains UTF-16 text.
   * @return Authored Insertions in Frame order.
   */
  Gossip insert_batch(Word count, Word content, Word at, bool text = false);
  /** Appends a contiguous logical suffix while respecting remote fragmentation.
   * @param origin Existing positive canonical root.
   * @param count Number of newly visible Frames.
   * @param content Binding carrying the incoming suffix.
   * @param source_start Offset of that suffix in its source Footage.
   * @param text Whether the suffix binding retains UTF-16 text.
   * @return Visible start of the added suffix.
   */
  Word extend(Index origin, Word count, Word content, Word source_start = 0, bool text = false);
  /** Requests private Footage before clearing externally owned content slots.
   * @param fragment Any fragment of the positive canonical Insertion.
   * @param discard Releases an array root whose entire original extent is masked.
   */
  void own_content(Index fragment, bool discard);
  /** Authors masks for each original Insertion crossed by an inclusive visible range.
   * @param start First removed Projection position.
   * @param end Last removed position; start greater than end represents an empty range.
   * @return Reducing Insertions followed by the local removal Acknowledgement.
   */
  Gossip remove(Word start, std::int64_t end);
  /** Authors removal, then insertion against the resulting visible boundary.
   * @param count Replacement Frame count; zero means removal only.
   * @param content Replacement Footage binding.
   * @param start First replaced Projection position.
   * @param end Last replaced position, inclusive.
   * @param text Whether replacement Footage retains UTF-16 text.
   * @return Gossip preserving removal-before-insertion order.
   */
  [[gnu::always_inline]] Gossip replace(Word count, Word content, Word start, std::int64_t end,
                                        bool text = false);
  /** Integrates one Insertion and any dependencies released by it.
   * @param insertion Canonical Insertion already validated at the ABI.
   * @param result Output to append to.
   * @param binary Whether consecutive ACKs share a report for byte output.
   */
  void apply(const Insertion &insertion, Result &result, bool binary = false);
  /** Reconstructs trusted exported history and builds its traversal directory.
   * @param insertions Canonical Insertions in exported Structural Order.
   * @param frontiers Retained Actor Acknowledgements.
   */
  void hydrate(std::span<const Insertion> insertions,
               const std::vector<Acknowledgement> &frontiers);
  /** Integrates snapshot history and then observes its retained Acknowledgements.
   * @param insertions Canonical snapshot Insertions.
   * @param frontiers Snapshot Acknowledgements.
   * @param binary Whether consecutive ACKs share a report for byte output.
   * @return Visible Splices and Gossip containing Acknowledgements for newly integrated history.
   */
  Result merge(std::span<const Insertion> insertions, const std::vector<Acknowledgement> &frontiers,
               bool binary = false);
  /** Reuses output capacity while resolving an inclusive visible range.
   * @param start First included Projection position.
   * @param end Last included position.
   * @param output Span vector cleared and repopulated by this call.
   */
  void values(Word start, Word end, std::vector<Span> &output);
  /** Exports equivalent retained state without rewriting live history.
   * @param output Snapshot replaced with acknowledgement-gated removal compaction.
   * @param binary Whether metadata is written as bytes instead of numeric words.
   */
  void sequence(Sequence &output, bool binary = false) const;

private:
  template <bool Binary, typename Removed>
  void sequence_into(Sequence &output, const WordTable &compactable,
                     const ContainmentTable &removed, std::vector<Removed> &deletions) const;
};
} // namespace sequencer
