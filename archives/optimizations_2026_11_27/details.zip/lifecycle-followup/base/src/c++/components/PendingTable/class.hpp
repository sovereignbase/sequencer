#pragma once
#include "../../types/type.hpp"
#include <unordered_map>
#include <utility>

namespace sequencer {
/** Holds canonical operations until their parent's required logical extent exists. */
class PendingTable {
  // A bucket uses the missing parent identity, not the incoming operation identity.
  using Buckets = std::unordered_map<std::uint64_t, std::vector<Insertion>>;
  std::unique_ptr<Buckets> buckets;

public:
  /** Retains an operation without allocating a linked Strip.
   * @param i Unresolved Insertion; Footage is retained through its numeric binding token.
   */
  void set(Insertion i) {
    if (!buckets)
      buckets = std::make_unique<Buckets>();
    (*buckets)[identity(i.coordinates.anchor_session, i.coordinates.anchor_start)].push_back(i);
  }
  /** Removes the waiters for a materialized or extended parent.
   * @param c Parent coordinates whose Session/start key has become available.
   * @return Waiters in arrival order; apply preserves that order with a reversed stack push.
   */
  std::vector<Insertion> take(const Coordinates &c) {
    if (!buckets)
      return {};
    auto it = buckets->find(identity(c.session, c.start));
    if (it == buckets->end())
      return {};
    auto entries = std::move(it->second);
    buckets->erase(it);
    if (buckets->empty())
      buckets.reset();
    return entries;
  }
  /** Counts unresolved canonical parent identities.
   * @return Dependency bucket count, not waiting operation count.
   */
  std::size_t size() const { return buckets ? buckets->size() : 0; }
};
} // namespace sequencer
