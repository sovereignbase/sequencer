#pragma once
#include "../components/Traversal/layout.hpp"
#include <algorithm>
#include <array>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <limits>
#include <memory>
#include <vector>

namespace sequencer {
/** Unsigned wasm32 lane used for coordinates, lengths, tokens and addresses. */
using Word = std::uint32_t;
/** Stable Strip arena index; distinct from a Projection position or logical time. */
using Index = Word;
/** Absent Strip link, backed by a zero-initialized sentinel arena entry. */
constexpr Index none = 0;

/** Canonical six-word Insertion coordinates; runtime fragmentation leaves these intact. */
struct Coordinates {
  Word anchor_session{} /**< Session of the canonical anchoring Insertion. */,
      anchor_start{} /**< Start identifying the canonical anchoring Insertion. */,
      anchor_diff{} /**< Logical boundary within that Insertion, not a visible index. */,
      session{} /**< Session that authored this Insertion. */,
      start{} /**< Start identifying this Insertion within its Session. */;
  /** Positive authored Frame length, or negative original removal length. */
  std::int32_t diff{};
  /** Tests for the virtual root.
   * @return Whether the anchor triple is (0, 0, 0).
   */
  bool birth() const { return !(anchor_session | anchor_start | anchor_diff); }
  /** Recognizes positive logical continuation without a new zero reservation.
   * @return Whether same-Session identity begins at the parent's anchored endpoint.
   */
  bool extension() const {
    return diff > 0 && session == anchor_session && start == anchor_start + anchor_diff;
  }
};
static_assert(sizeof(Coordinates) == 6 * sizeof(Word));
/** Packs a canonical identity without hashing or truncating either coordinate.
 * @param session Authoring Session.
 * @param start Logical start within that Session.
 * @return Exact identity key; the anchor is deliberately excluded.
 */
inline std::uint64_t identity(Word session, Word start) {
  return (std::uint64_t(session) << 32) | start;
}
/** Ownership of one JavaScript Footage binding. */
enum class FootageState : std::uint8_t { Caller = 0, Private = 1, Retained = 2, Snapshot = 3 };
/** Native Insertion plus an opaque JavaScript Footage reference. */
struct Insertion {
  /** Historical anchor, canonical identity and original Frame effect. */
  Coordinates coordinates;
  /** JavaScript binding token; zero means no content binding. */
  Word content{};
  /** Origin of this Insertion's original Frame coordinates in the bound Footage. */
  Word content_start{};
  /** Binding state in the low byte of an aligned word shared with native flags. */
  FootageState footage_state{};
  /** Whether array Footage is privately writable before masking. */
  bool content_owned : 1 {};
  /** Immutable UTF-16 Footage; masked ranges are emitted as missing snapshot spans. */
  bool string_content : 1 {};
  /** Shares the hydrated Footage binding with other canonical Insertions. */
  bool shared_content : 1 {};
  /** Whether materialization has diverged from one intact Strip. */
  bool fragmented{};
  /** Whether this Strip represents an offset fragment or consumed mask prefix. */
  bool offset{};
};
static_assert(sizeof(Insertion) == 36 && offsetof(Insertion, footage_state) % sizeof(Word) == 0);
/** Actor ID followed by removal Session/frontier pairs. */
using Acknowledgement = std::vector<Word>;
/** Discriminated Gossip entry; only the selected Insertion or frontier is meaningful. */
struct Entry {
#ifndef DOXYGEN
  // Document the anonymous union's fields directly on Entry.
  union {
#endif
    /** Canonical operation when acknowledgement_count is zero. */
    Insertion insertion;
    /** Locally reported Actor, removal Session and frontier. */
    std::array<Word, 3> frontier;
#ifndef DOXYGEN
  };
#endif
  /** Zero selects Insertion; one or three selects the reported frontier words. */
  Word acknowledgement_count{};
  /** Creates an operation entry.
   * @param i Canonical Insertion and its binding reference.
   * @return Insertion-tagged entry.
   */
  static Entry insert(Insertion i) { return {.insertion = i, .acknowledgement_count = 0}; }
  /** Creates an Acknowledgement entry without dynamic payload storage.
   * @param a Actor ID and the reported removal Session/frontier.
   * @param count Number of reported words; one admits only the Actor.
   * @return Acknowledgement-tagged entry.
   */
  static Entry acknowledge(std::array<Word, 3> a, Word count = 3) {
    return {.frontier = a, .acknowledgement_count = count};
  }
};
static_assert(sizeof(Entry) == 40);
/** Ordered operations and Acknowledgements transported between replicas. */
using Gossip = std::vector<Entry>;
/** JavaScript Footage slice; no application values enter WASM. */
struct Span {
  Word content{} /**< Per-Projection JavaScript binding token. */,
      start{} /**< First content-array slot. */,
      count{} /**< Frame count; zero in a release request means the whole binding. */;
};
/** Deferred content concatenation accompanying an Insertion extension. */
struct ContentAppend {
  Word target{} /**< Existing Insertion's content binding. */,
      source{} /**< Incoming suffix binding. */, start{} /**< First suffix slot in source. */,
      count{} /**< Suffix Frame count. */,
      at{} /**< Original positive extent; the high bit requests a private Footage copy. */,
      base{} /**< Target Insertion's content-array origin before copy-on-write. */,
      prefix{} /**< Binding supplying the original extent before concatenation. */;
};
/** Copies one original extent into its private Footage binding. */
struct ContentCopy {
  Word target{}, source{}, start{}, count{};
};
/** Deferred Footage changes for the current synchronous ABI call. */
extern std::vector<Span> released;
extern std::vector<ContentCopy> copied;
extern std::vector<ContentAppend> appended;
/** First unused JavaScript binding token for the current synchronous call. */
extern Word next_content;
/** Consumer-visible mutation; the removal end is exclusive. */
struct Splice {
  Word start{} /**< First affected Projection position. */,
      end{} /**< Exclusive removal boundary, equal to start for insertion. */;
  /** Inserted Footage span; zero count denotes a removal-only Splice. */
  Span values;
};
/** Output of applying operations against a live Projection. */
struct Result {
  /** Splices applied in order; each uses the Projection left by preceding Splices. */
  std::vector<Splice> changes;
  /** Acknowledgements generated for this Projection's Actor while integrating masks. */
  Gossip gossip;
};
/** Retained numeric history and ordered Footage spans for snapshot export. */
struct Sequence {
  /** Plain or compact metadata, including retained Acknowledgements. */
  std::vector<Word> words;
  /** Optional byte metadata; ordinary exports retain numeric words. */
  std::vector<std::uint8_t> bytes;
  /** Positive original Frame spans in exported Insertion order. */
  std::vector<Span> footage;
  /** Candidate root for sharing one complete Footage span; never serialized. */
  Index shared_root{};
};

/**
 * Strip materialization in one arena with separate traversal lanes (SoA).
 * Canonical coordinates and binding references remain grouped as Insertions;
 * hot fragment/link fields use indexed lanes. Growth preserves indices, not pointers.
 */
struct Strips {
  static constexpr Word lanes = 8;
  /** One allocation for identities, node lanes and the traversal directory. */
  std::unique_ptr<std::byte[]> memory;
  Word count{} /**< Allocated slots, including the absent-link sentinel. */,
      capacity{} /**< Slots available in each lane. */;
  /** Canonical coordinates and binding references, repeated across an Insertion's fragments. */
  Insertion *identity{};
  /** First original Frame coordinate represented by each Strip. */
  Word *fragment_start{};
  /** Current signed effect; overlaps can leave a mask with zero visible effect. */
  std::int32_t *fragment_diff{};
  Index *left{} /**< Previous Strip in Structural Order. */,
      *right{} /**< Next Strip in Structural Order. */,
      *competitor{} /**< Next smaller sibling using the exact same anchor triple. */,
      *fragment{} /**< Next materialized fragment of the same canonical Insertion. */,
      *block_root{} /**< Stable directory identity shared by the nodes in one block. */;
  /** Last proven endpoint of each positive Strip's causal subtree. */
  Index *subtree_tail{};

  /** Grows every lane together, preserving initialized slots and stable indices.
   * @param next Required arena capacity; existing capacity is retained when sufficient.
   * @return Former arena, kept alive until borrowed traversal views are rebound.
   */
  std::unique_ptr<std::byte[]> reserve(Word next) {
    if (next <= capacity)
      return {};
    const auto bytes =
        std::uint64_t(sizeof(Insertion) + lanes * sizeof(Word)) * next +
        std::uint64_t(TraversalLayout::words(TraversalLayout::capacity(next))) * sizeof(Word);
    if (bytes > std::numeric_limits<std::size_t>::max())
      throw std::bad_alloc();
    auto grown = std::make_unique_for_overwrite<std::byte[]>(std::size_t(bytes));
    auto *identities = reinterpret_cast<Insertion *>(grown.get());
    auto *fields = reinterpret_cast<Word *>(identities + next);
    // Copy only constructed slots. Lane spacing changes with capacity, so one
    // whole-allocation memcpy would place every traversal field incorrectly.
    if (count) {
      std::memcpy(identities, identity, count * sizeof(Insertion));
      auto *old = reinterpret_cast<Word *>(identity + capacity);
      for (Word field = 0; field < lanes; ++field)
        std::memcpy(fields + field * next, old + field * capacity, count * sizeof(Word));
    }
    // Every cached lane pointer belongs to the new allocation after this commit.
    auto previous = std::move(memory);
    memory = std::move(grown);
    capacity = next;
    identity = identities;
    fragment_start = fields;
    fragment_diff = reinterpret_cast<std::int32_t *>(fields + next);
    left = fields + 2 * next;
    right = fields + 3 * next;
    competitor = fields + 4 * next;
    fragment = fields + 5 * next;
    block_root = fields + 6 * next;
    subtree_tail = fields + 7 * next;
    // Slot zero is needed only once history exists; empty Projections own no arena.
    if (!count)
      append({});
    return previous;
  }
  /** Adds an unlinked Strip to a reserved slot with its original signed Frame effect.
   * @param insertion Canonical Insertion and binding reference.
   * @return Stable arena index, unaffected by subsequent growth.
   */
  Index append(Insertion insertion) {
    const auto index = count++;
    insertion.fragmented = insertion.offset = false;
    std::construct_at(identity + index, insertion);
    auto *fields = reinterpret_cast<Word *>(identity + capacity);
    for (Word field = 0; field < lanes; ++field)
      std::construct_at(fields + field * capacity + index, Word(0));
    fragment_diff[index] = insertion.coordinates.diff;
    return index;
  }
};
} // namespace sequencer
