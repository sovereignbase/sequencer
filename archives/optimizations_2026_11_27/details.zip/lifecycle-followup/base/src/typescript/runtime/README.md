# Runtime

Every `Projection` calls one synchronous WASM instance loaded with the package.
The native runtime owns Structural Order, traversal, Session clocks, containment,
pending dependencies, removal frontiers and compaction. TypeScript retains generic Footage and
attaches it to public results without cloning its values.

Local operations trust their caller. `length`, `value` and `insert` use direct WASM
exports; other operations expose native coordinates, frontiers and spans through
pointers and counts. No worker, RPC, Promise or shared memory is involved.

Insertion coordinates contain exactly six uint32 words. Numeric arrays remain
the default, including JSON transport; signed effects use their 32-bit bit pattern.
The optional final `binaryEncode` argument returns owned `Uint8Array` metadata
for binary transport. Both forms enter a reusable native input region. Byte
packing, bounds checks and coordinate reconstruction execute in WASM.
Snapshots keep `[words, footage]`; neither metadata form serializes Footage.
With `sequence(true)`, TypeScript concatenates the native Footage spans with
`+=` into a string instead. No intermediate Footage array is built. Text Frames
must be UTF-16 code units; absent slots use NUL to retain their coordinates.
Hydration and merge split string Footage by default; their existing text options
retain the string instead.
Footage remains in canonical Insertion order, reconstructed by the words.
`batch()` uses the same native editing algorithms and returns one encoded Gossip
packet. Its callback editor has no per-edit Gossip result. Native coordinates
share local Session identities and clocks and retain eligible extension runs before encoding;
JavaScript combines the original Footage. Remote packet records receive separate
binding slots, so releasing one root cannot release another root's content.
Single-Frame text packets retain individual code units rather than the full
packet string in each binding. The editor closes when its callback returns;
completed edits remain if that callback throws.
From 64 retained insertions onward, WASM omits predictable coordinate fields
during export. Compact words remain JSON-compatible uint32 numbers; the reader
also accepts the plain six-word snapshot layout. Footage is never packed in WASM.

`npm run build` builds C++/WASM and bundles the synchronous TS package. WASM
starts with 1 MiB of ordinary memory and grows as needed. `destroy()` releases
native state and retained content; subsequent calls throw, and repeated
destruction is safe. Finalization releases unreachable instances.

Library-reported failures use the exported `SequencerError`:
`BATCH_CLOSED` identifies an editor used outside its callback scope.
`PROJECTION_DESTROYED` identifies a released instance and
`NATIVE_OPERATION_FAILED` identifies a failure reported by native dispatch.
`STRING_ENCODING_FAILED` identifies a failed Footage concatenation and preserves
its original `cause`. Operation-failure messages name the public method. Invalid remote input still
returns `undefined`. Unexpected errors use `UNKNOWN_ERROR`, name the public call
and retain the original error as `cause`. Existing Sequencer errors pass through unchanged. Error creation
and method-name lookup run only on failure.
