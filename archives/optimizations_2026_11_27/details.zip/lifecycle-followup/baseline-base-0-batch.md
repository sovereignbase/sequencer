# Batch benchmarks

2026-11-27T17:03:04.237Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 1,221,722 | 1,182,662 | 495,475 | 76.05 | 5.99 | 0.012 |
| append | batch | 2,245,425 | 230,769,231 | 216,606,498 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,398,601 | 1,588,394 | 890,115 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 1,674,902 | 2,103,713 | 1,982,947 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 1,132,717 | 1,113,606 | 792,665 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 1,143,794 | 1,547,070 | 1,481,079 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 1,116,258 | 1,110,782 | 859,550 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 753,485 | 1,655,492 | 1,580,320 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,266,451 | 1,171,749 | 742,152 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,309,372 | 1,623,201 | 1,592,885 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,308,159 | 1,315,761 | 911,612 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,227,961 | 1,754,668 | 1,368,894 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 691,419 | 934,616 | 697,857 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 828,907 | 1,195,791 | 1,103,611 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,132,086 | 1,321,324 | 870,979 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 981,065 | 1,761,287 | 1,646,633 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,116,248 | 1,298,997 | 850,792 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 976,507 | 1,651,278 | 1,413,161 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 777,469 | 1,023,376 | 744,597 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 953,100 | 1,226,016 | 1,156,036 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 4.911 | 0.000 |
| append | individual | apply | 5.073 | 0.000 |
| append | individual | receive | 12.110 | 0.000 |
| append | individual | encode | 7.742 | 0.000 |
| append | individual | decode | 8.130 | 0.000 |
| append | batch | author | 2.672 | 0.000 |
| append | batch | apply | 0.026 | 0.000 |
| append | batch | receive | 0.028 | 0.000 |
| append | batch | encode | 0.216 | 0.000 |
| append | batch | decode | 0.091 | 0.000 |
| prepend | individual | author | 4.290 | 0.000 |
| prepend | individual | apply | 3.777 | 0.000 |
| prepend | individual | receive | 6.741 | 0.000 |
| prepend | individual | encode | 5.842 | 0.000 |
| prepend | individual | decode | 7.071 | 0.000 |
| prepend | batch | author | 3.582 | 0.000 |
| prepend | batch | apply | 2.852 | 0.000 |
| prepend | batch | receive | 3.026 | 0.000 |
| prepend | batch | encode | 0.223 | 0.000 |
| prepend | batch | decode | 0.101 | 0.000 |
| random.characters | individual | author | 5.297 | 0.000 |
| random.characters | individual | apply | 5.388 | 0.000 |
| random.characters | individual | receive | 7.569 | 0.000 |
| random.characters | individual | encode | 5.639 | 0.000 |
| random.characters | individual | decode | 7.276 | 0.000 |
| random.characters | batch | author | 5.246 | 0.000 |
| random.characters | batch | apply | 3.878 | 0.000 |
| random.characters | batch | receive | 4.051 | 0.000 |
| random.characters | batch | encode | 0.252 | 0.000 |
| random.characters | batch | decode | 0.102 | 0.000 |
| random.words | individual | author | 5.375 | 0.000 |
| random.words | individual | apply | 5.402 | 0.000 |
| random.words | individual | receive | 6.980 | 0.000 |
| random.words | individual | encode | 4.484 | 0.000 |
| random.words | individual | decode | 6.017 | 0.000 |
| random.words | batch | author | 7.963 | 0.000 |
| random.words | batch | apply | 3.624 | 0.000 |
| random.words | batch | receive | 3.797 | 0.000 |
| random.words | batch | encode | 0.502 | 0.000 |
| random.words | batch | decode | 0.109 | 0.000 |
| concurrent.characters | individual | author | 9.475 | 0.000 |
| concurrent.characters | individual | apply | 10.241 | 0.000 |
| concurrent.characters | individual | receive | 16.169 | 0.000 |
| concurrent.characters | individual | encode | 7.793 | 0.000 |
| concurrent.characters | individual | decode | 12.874 | 0.000 |
| concurrent.characters | batch | author | 9.165 | 0.000 |
| concurrent.characters | batch | apply | 7.393 | 0.000 |
| concurrent.characters | batch | receive | 7.534 | 0.000 |
| concurrent.characters | batch | encode | 0.399 | 0.000 |
| concurrent.characters | batch | decode | 0.133 | 0.000 |
| concurrent.words | individual | author | 9.173 | 0.000 |
| concurrent.words | individual | apply | 9.120 | 0.000 |
| concurrent.words | individual | receive | 13.163 | 0.000 |
| concurrent.words | individual | encode | 8.269 | 0.000 |
| concurrent.words | individual | decode | 11.098 | 0.000 |
| concurrent.words | batch | author | 9.772 | 0.000 |
| concurrent.words | batch | apply | 6.839 | 0.000 |
| concurrent.words | batch | receive | 8.766 | 0.000 |
| concurrent.words | batch | encode | 0.724 | 0.000 |
| concurrent.words | batch | decode | 0.121 | 0.000 |
| concurrent.mixed | individual | author | 17.356 | 0.000 |
| concurrent.mixed | individual | apply | 12.840 | 0.000 |
| concurrent.mixed | individual | receive | 17.196 | 0.000 |
| concurrent.mixed | individual | encode | 9.081 | 0.000 |
| concurrent.mixed | individual | decode | 8.772 | 0.000 |
| concurrent.mixed | batch | author | 14.477 | 0.000 |
| concurrent.mixed | batch | apply | 10.035 | 0.000 |
| concurrent.mixed | batch | receive | 10.873 | 0.000 |
| concurrent.mixed | batch | encode | 0.603 | 0.000 |
| concurrent.mixed | batch | decode | 0.183 | 0.000 |
| causal.characters | individual | author | 10.600 | 0.000 |
| causal.characters | individual | apply | 9.082 | 0.000 |
| causal.characters | individual | receive | 13.778 | 0.000 |
| causal.characters | individual | encode | 5.910 | 0.000 |
| causal.characters | individual | decode | 13.539 | 0.000 |
| causal.characters | batch | author | 12.232 | 0.000 |
| causal.characters | batch | apply | 6.813 | 0.000 |
| causal.characters | batch | receive | 7.288 | 0.000 |
| causal.characters | batch | encode | 0.499 | 0.000 |
| causal.characters | batch | decode | 0.155 | 0.000 |
| causal.words | individual | author | 10.750 | 0.000 |
| causal.words | individual | apply | 9.238 | 0.000 |
| causal.words | individual | receive | 14.104 | 0.000 |
| causal.words | individual | encode | 8.898 | 0.000 |
| causal.words | individual | decode | 11.694 | 0.000 |
| causal.words | batch | author | 12.289 | 0.000 |
| causal.words | batch | apply | 7.267 | 0.000 |
| causal.words | batch | receive | 8.492 | 0.000 |
| causal.words | batch | encode | 0.580 | 0.000 |
| causal.words | batch | decode | 0.146 | 0.000 |
| causal.mixed | individual | author | 15.435 | 0.000 |
| causal.mixed | individual | apply | 11.726 | 0.000 |
| causal.mixed | individual | receive | 16.116 | 0.000 |
| causal.mixed | individual | encode | 9.454 | 0.000 |
| causal.mixed | individual | decode | 10.957 | 0.000 |
| causal.mixed | batch | author | 12.591 | 0.000 |
| causal.mixed | batch | apply | 9.788 | 0.000 |
| causal.mixed | batch | receive | 10.380 | 0.000 |
| causal.mixed | batch | encode | 0.441 | 0.000 |
| causal.mixed | batch | decode | 0.111 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
