# Sequencer dynamic lifecycle benchmark

2026-11-27T17:01:32.229Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.23 | 162.89 | 56.49 |
| CommonJS | 199.41 | 164.51 | 56.69 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 313,266 | 3.192 | 3.192 | 3.192 | 0.000 | 0: 3.192 | 0: 3.192 |
| apply | random | A | scaleDown | 24,999 | 341,762 | 2.926 | 2.926 | 2.926 | 0.000 | 0: 2.926 | 0: 2.926 |
| apply | random | A | fullLifecycle | 49,999 | 326,894 | 3.059 | 3.059 | 3.059 | 0.000 | 0: 3.059 | 0: 3.059 |
| create | — | A | scaleUp | 7 | 525 | 1904.200 | 1904.200 | 1904.200 | 0.000 | 0: 1904.200 | 0: 1904.200 |
| create | — | A | scaleDown | 6 | 657 | 1522.467 | 1522.467 | 1522.467 | 0.000 | 0: 1522.467 | 0: 1522.467 |
| create | — | A | fullLifecycle | 13 | 579 | 1728.015 | 1728.015 | 1728.015 | 0.000 | 0: 1728.015 | 0: 1728.015 |
| insert | head | A | scaleUp | 12,500 | 1,333,049 | 0.750 | 0.750 | 0.750 | 0.000 | 0: 0.750 | 0: 0.750 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,333,049 | 0.750 | 0.750 | 0.750 | 0.000 | 0: 0.750 | 0: 0.750 |
| insert | random | A | scaleUp | 25,000 | 563,195 | 1.776 | 1.776 | 1.776 | 0.000 | 0: 1.776 | 0: 1.776 |
| insert | random | A | scaleDown | 25,000 | 595,546 | 1.679 | 1.679 | 1.679 | 0.000 | 0: 1.679 | 0: 1.679 |
| insert | random | A | fullLifecycle | 50,000 | 578,919 | 1.727 | 1.727 | 1.727 | 0.000 | 0: 1.727 | 0: 1.727 |
| insert | tail | A | scaleUp | 12,500 | 1,433,223 | 0.698 | 0.698 | 0.698 | 0.000 | 0: 0.698 | 0: 0.698 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,433,223 | 0.698 | 0.698 | 0.698 | 0.000 | 0: 0.698 | 0: 0.698 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 694,460 | 1.440 | 1.440 | 1.440 | 0.000 | 0: 1.440 | 0: 1.440 |
| remove | head | A | fullLifecycle | 12,500 | 694,460 | 1.440 | 1.440 | 1.440 | 0.000 | 0: 1.440 | 0: 1.440 |
| remove | random | A | scaleUp | 25,000 | 459,553 | 2.176 | 2.176 | 2.176 | 0.000 | 0: 2.176 | 0: 2.176 |
| remove | random | A | scaleDown | 25,000 | 492,585 | 2.030 | 2.030 | 2.030 | 0.000 | 0: 2.030 | 0: 2.030 |
| remove | random | A | fullLifecycle | 50,000 | 475,496 | 2.103 | 2.103 | 2.103 | 0.000 | 0: 2.103 | 0: 2.103 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 788,703 | 1.268 | 1.268 | 1.268 | 0.000 | 0: 1.268 | 0: 1.268 |
| remove | tail | A | fullLifecycle | 12,500 | 788,703 | 1.268 | 1.268 | 1.268 | 0.000 | 0: 1.268 | 0: 1.268 |
| replace | head | A | scaleUp | 25,000 | 509,270 | 1.964 | 1.964 | 1.964 | 0.000 | 0: 1.964 | 0: 1.964 |
| replace | head | A | scaleDown | 25,000 | 475,262 | 2.104 | 2.104 | 2.104 | 0.000 | 0: 2.104 | 0: 2.104 |
| replace | head | A | fullLifecycle | 50,000 | 491,678 | 2.034 | 2.034 | 2.034 | 0.000 | 0: 2.034 | 0: 2.034 |
| replace | random | A | scaleUp | 25,000 | 319,196 | 3.133 | 3.133 | 3.133 | 0.000 | 0: 3.133 | 0: 3.133 |
| replace | random | A | scaleDown | 25,000 | 382,214 | 2.616 | 2.616 | 2.616 | 0.000 | 0: 2.616 | 0: 2.616 |
| replace | random | A | fullLifecycle | 50,000 | 347,874 | 2.875 | 2.875 | 2.875 | 0.000 | 0: 2.875 | 0: 2.875 |
| replace | tail | A | scaleUp | 25,000 | 481,871 | 2.075 | 2.075 | 2.075 | 0.000 | 0: 2.075 | 0: 2.075 |
| replace | tail | A | scaleDown | 25,000 | 50,171 | 19.932 | 19.932 | 19.932 | 0.000 | 0: 19.932 | 0: 19.932 |
| replace | tail | A | fullLifecycle | 50,000 | 90,880 | 11.004 | 11.004 | 11.004 | 0.000 | 0: 11.004 | 0: 11.004 |
| sequence | — | A | scaleUp | 6 | 70 | 14279.583 | 14279.583 | 14279.583 | 0.000 | 0: 14279.583 | 0: 14279.583 |
| sequence | — | A | scaleDown | 6 | 95 | 10494.200 | 10494.200 | 10494.200 | 0.000 | 0: 10494.200 | 0: 10494.200 |
| sequence | — | A | fullLifecycle | 12 | 81 | 12386.892 | 12386.892 | 12386.892 | 0.000 | 0: 12386.892 | 0: 12386.892 |
| value | head | A | scaleUp | 25,000 | 3,097,586 | 0.323 | 0.323 | 0.323 | 0.000 | 0: 0.323 | 0: 0.323 |
| value | head | A | scaleDown | 25,000 | 2,300,225 | 0.435 | 0.435 | 0.435 | 0.000 | 0: 0.435 | 0: 0.435 |
| value | head | A | fullLifecycle | 50,000 | 2,640,013 | 0.379 | 0.379 | 0.379 | 0.000 | 0: 0.379 | 0: 0.379 |
| value | random | A | scaleUp | 25,000 | 858,511 | 1.165 | 1.165 | 1.165 | 0.000 | 0: 1.165 | 0: 1.165 |
| value | random | A | scaleDown | 25,000 | 945,051 | 1.058 | 1.058 | 1.058 | 0.000 | 0: 1.058 | 0: 1.058 |
| value | random | A | fullLifecycle | 50,000 | 899,705 | 1.111 | 1.111 | 1.111 | 0.000 | 0: 1.111 | 0: 1.111 |
| value | tail | A | scaleUp | 25,000 | 6,521,285 | 0.153 | 0.153 | 0.153 | 0.000 | 0: 0.153 | 0: 0.153 |
| value | tail | A | scaleDown | 25,000 | 4,165,486 | 0.240 | 0.240 | 0.240 | 0.000 | 0: 0.240 | 0: 0.240 |
| value | tail | A | fullLifecycle | 50,000 | 5,083,729 | 0.197 | 0.197 | 0.197 | 0.000 | 0: 0.197 | 0: 0.197 |
| values | — | A | scaleUp | 6 | 133 | 7522.150 | 7522.150 | 7522.150 | 0.000 | 0: 7522.150 | 0: 7522.150 |
| values | — | A | scaleDown | 6 | 252 | 3973.967 | 3973.967 | 3973.967 | 0.000 | 0: 3973.967 | 0: 3973.967 |
| values | — | A | fullLifecycle | 12 | 174 | 5748.058 | 5748.058 | 5748.058 | 0.000 | 0: 5748.058 | 0: 5748.058 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5448434.000 | 430.140 | 8.475 |
| A | scaleDown | 5 | 4404655.200 | 431.829 | 8.549 |
| A | fullLifecycle | 11 | 4973989.091 | 430.818 | 8.505 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3135629.000 | 247.550 | 4.877 |
| A | scaleDown | 5 | 2594145.800 | 254.328 | 5.035 |
| A | fullLifecycle | 11 | 2889500.273 | 250.272 | 4.940 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 246,027 | 4.065 | 1.700 | 329.400 |
| apply | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 319,144 | 3.133 | 1.400 | 329.400 |
| apply | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 309,932 | 3.227 | 1.400 | 1047.900 |
| apply | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 317,404 | 3.151 | 1.400 | 1047.900 |
| apply | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 312,888 | 3.196 | 1.400 | 1047.900 |
| apply | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 313,266 | 3.192 | 1.400 | 1047.900 |
| apply | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 315,283 | 3.172 | 1.400 | 1047.900 |
| apply | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 313,466 | 3.190 | 1.400 | 1047.900 |
| apply | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 314,772 | 3.177 | 1.400 | 1047.900 |
| apply | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 319,171 | 3.133 | 1.400 | 1047.900 |
| apply | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 324,695 | 3.080 | 1.400 | 1047.900 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 326,894 | 3.059 | 1.200 | 1047.900 |
| insert | head | 0 | up | 1,000 | 49,966 | A | 500 | 921,319 | 1.085 | 0.400 | 74.300 |
| insert | head | 0 | up | 5,000 | 254,523 | A | 2,500 | 1,220,822 | 0.819 | 0.300 | 74.300 |
| insert | head | 0 | up | 10,000 | 509,098 | A | 5,000 | 1,320,097 | 0.758 | 0.300 | 74.300 |
| insert | head | 0 | up | 15,000 | 765,837 | A | 7,500 | 1,348,339 | 0.742 | 0.300 | 74.300 |
| insert | head | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 1,327,070 | 0.754 | 0.300 | 74.300 |
| insert | head | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 1,333,049 | 0.750 | 0.300 | 74.300 |
| insert | head | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 1,333,049 | 0.750 | 0.300 | 74.300 |
| insert | head | 0 | down | 15,000 | 757,461 | A | 12,500 | 1,333,049 | 0.750 | 0.300 | 74.300 |
| insert | head | 0 | down | 10,000 | 505,565 | A | 12,500 | 1,333,049 | 0.750 | 0.300 | 74.300 |
| insert | head | 0 | down | 5,000 | 249,719 | A | 12,500 | 1,333,049 | 0.750 | 0.300 | 74.300 |
| insert | head | 0 | down | 1,000 | 50,567 | A | 12,500 | 1,333,049 | 0.750 | 0.300 | 74.300 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,333,049 | 0.750 | 0.300 | 74.300 |
| insert | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 483,115 | 2.070 | 0.500 | 607.600 |
| insert | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 564,908 | 1.770 | 0.500 | 607.600 |
| insert | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 584,215 | 1.712 | 0.500 | 607.600 |
| insert | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 596,910 | 1.675 | 0.500 | 607.600 |
| insert | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 560,350 | 1.785 | 0.500 | 754.700 |
| insert | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 563,195 | 1.776 | 0.500 | 754.700 |
| insert | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 558,002 | 1.792 | 0.500 | 754.700 |
| insert | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 548,319 | 1.824 | 0.500 | 754.700 |
| insert | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 553,309 | 1.807 | 0.500 | 754.700 |
| insert | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 562,845 | 1.777 | 0.500 | 754.700 |
| insert | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 573,787 | 1.743 | 0.500 | 754.700 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 578,919 | 1.727 | 0.300 | 754.700 |
| insert | tail | 0 | up | 1,000 | 49,966 | A | 500 | 1,197,892 | 0.835 | 0.400 | 11.000 |
| insert | tail | 0 | up | 5,000 | 254,523 | A | 2,500 | 1,353,326 | 0.739 | 0.300 | 69.100 |
| insert | tail | 0 | up | 10,000 | 509,098 | A | 5,000 | 1,456,410 | 0.687 | 0.300 | 75.000 |
| insert | tail | 0 | up | 15,000 | 765,837 | A | 7,500 | 1,481,686 | 0.675 | 0.200 | 150.000 |
| insert | tail | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 1,476,865 | 0.677 | 0.200 | 150.000 |
| insert | tail | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 1,433,223 | 0.698 | 0.200 | 315.600 |
| insert | tail | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 1,433,223 | 0.698 | 0.200 | 315.600 |
| insert | tail | 0 | down | 15,000 | 757,461 | A | 12,500 | 1,433,223 | 0.698 | 0.200 | 315.600 |
| insert | tail | 0 | down | 10,000 | 505,565 | A | 12,500 | 1,433,223 | 0.698 | 0.200 | 315.600 |
| insert | tail | 0 | down | 5,000 | 249,719 | A | 12,500 | 1,433,223 | 0.698 | 0.200 | 315.600 |
| insert | tail | 0 | down | 1,000 | 50,567 | A | 12,500 | 1,433,223 | 0.698 | 0.200 | 315.600 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,433,223 | 0.698 | 0.200 | 315.600 |
| remove | head | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 677,984 | 1.475 | 0.900 | 20.200 |
| remove | head | 0 | down | 15,000 | 757,461 | A | 5,000 | 652,375 | 1.533 | 0.900 | 37.100 |
| remove | head | 0 | down | 10,000 | 505,565 | A | 7,500 | 632,223 | 1.582 | 0.800 | 686.200 |
| remove | head | 0 | down | 5,000 | 249,719 | A | 10,000 | 665,744 | 1.502 | 0.800 | 686.200 |
| remove | head | 0 | down | 1,000 | 50,567 | A | 12,000 | 686,609 | 1.456 | 0.700 | 686.200 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 694,460 | 1.440 | 0.700 | 686.200 |
| remove | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 364,591 | 2.743 | 0.800 | 545.300 |
| remove | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 426,305 | 2.346 | 0.800 | 1393.900 |
| remove | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 449,355 | 2.225 | 0.800 | 1393.900 |
| remove | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 469,325 | 2.131 | 0.800 | 1393.900 |
| remove | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 455,077 | 2.197 | 0.800 | 1393.900 |
| remove | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 459,553 | 2.176 | 0.800 | 1393.900 |
| remove | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 457,694 | 2.185 | 0.800 | 1393.900 |
| remove | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 449,379 | 2.225 | 0.800 | 1393.900 |
| remove | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 453,051 | 2.207 | 0.800 | 1393.900 |
| remove | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 462,331 | 2.163 | 0.800 | 1393.900 |
| remove | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 471,314 | 2.122 | 0.800 | 1393.900 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 475,496 | 2.103 | 0.600 | 1393.900 |
| remove | tail | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 780,226 | 1.282 | 0.800 | 50.900 |
| remove | tail | 0 | down | 15,000 | 757,461 | A | 5,000 | 712,393 | 1.404 | 0.800 | 393.900 |
| remove | tail | 0 | down | 10,000 | 505,565 | A | 7,500 | 739,652 | 1.352 | 0.700 | 393.900 |
| remove | tail | 0 | down | 5,000 | 249,719 | A | 10,000 | 763,779 | 1.309 | 0.700 | 393.900 |
| remove | tail | 0 | down | 1,000 | 50,567 | A | 12,000 | 780,493 | 1.281 | 0.600 | 393.900 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 788,703 | 1.268 | 0.600 | 393.900 |
| replace | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 422,476 | 2.367 | 1.200 | 53.800 |
| replace | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 489,366 | 2.043 | 1.100 | 224.000 |
| replace | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 530,217 | 1.886 | 1.000 | 224.000 |
| replace | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 540,782 | 1.849 | 1.000 | 364.300 |
| replace | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 508,100 | 1.968 | 1.000 | 2126.200 |
| replace | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 509,270 | 1.964 | 1.000 | 2126.200 |
| replace | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 505,093 | 1.980 | 1.000 | 2126.200 |
| replace | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 480,498 | 2.081 | 1.000 | 2126.200 |
| replace | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 478,773 | 2.089 | 1.000 | 2126.200 |
| replace | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 483,057 | 2.070 | 1.000 | 2126.200 |
| replace | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 488,568 | 2.047 | 1.000 | 2126.200 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 491,678 | 2.034 | 1.000 | 2126.200 |
| replace | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 368,406 | 2.714 | 1.100 | 102.800 |
| replace | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 311,486 | 3.210 | 1.100 | 1138.000 |
| replace | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 337,456 | 2.963 | 1.100 | 1138.000 |
| replace | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 341,644 | 2.927 | 1.100 | 1138.000 |
| replace | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 313,505 | 3.190 | 1.100 | 4038.100 |
| replace | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 319,196 | 3.133 | 1.100 | 4038.100 |
| replace | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 325,878 | 3.069 | 1.100 | 4038.100 |
| replace | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 324,923 | 3.078 | 1.100 | 4038.100 |
| replace | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 330,251 | 3.028 | 1.100 | 4038.100 |
| replace | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 336,984 | 2.967 | 1.100 | 4038.100 |
| replace | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 344,716 | 2.901 | 1.000 | 4038.100 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 347,874 | 2.875 | 0.800 | 4038.100 |
| replace | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 450,288 | 2.221 | 1.000 | 126.600 |
| replace | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 521,534 | 1.917 | 1.000 | 126.600 |
| replace | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 539,951 | 1.852 | 1.000 | 230.600 |
| replace | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 513,226 | 1.948 | 1.000 | 1664.100 |
| replace | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 503,535 | 1.986 | 1.000 | 1664.100 |
| replace | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 481,871 | 2.075 | 1.000 | 1664.100 |
| replace | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 124,831 | 8.011 | 1.000 | 1754.400 |
| replace | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 86,459 | 11.566 | 1.000 | 1754.400 |
| replace | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 87,503 | 11.428 | 1.000 | 1754.400 |
| replace | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 86,672 | 11.538 | 1.000 | 1754.400 |
| replace | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 89,431 | 11.182 | 1.000 | 1754.400 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 90,880 | 11.004 | 0.800 | 1754.400 |
| value | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 1,282,545 | 0.780 | 0.100 | 243.900 |
| value | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 2,437,241 | 0.410 | 0.100 | 243.900 |
| value | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 2,876,539 | 0.348 | 0.100 | 243.900 |
| value | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 3,029,079 | 0.330 | 0.100 | 243.900 |
| value | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 3,047,665 | 0.328 | 0.100 | 243.900 |
| value | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 3,097,586 | 0.323 | 0.100 | 243.900 |
| value | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 2,903,769 | 0.344 | 0.100 | 243.900 |
| value | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 2,739,404 | 0.365 | 0.100 | 243.900 |
| value | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 2,678,290 | 0.373 | 0.100 | 243.900 |
| value | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 2,645,425 | 0.378 | 0.100 | 243.900 |
| value | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 2,636,109 | 0.379 | 0.100 | 243.900 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,640,013 | 0.379 | 0.100 | 243.900 |
| value | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 1,266,785 | 0.789 | 0.100 | 103.000 |
| value | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 1,025,157 | 0.975 | 0.100 | 103.000 |
| value | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 941,637 | 1.062 | 0.100 | 103.000 |
| value | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 918,144 | 1.089 | 0.100 | 103.000 |
| value | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 863,111 | 1.159 | 0.100 | 103.000 |
| value | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 858,511 | 1.165 | 0.100 | 103.000 |
| value | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 864,850 | 1.156 | 0.100 | 103.000 |
| value | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 850,214 | 1.176 | 0.100 | 103.000 |
| value | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 855,041 | 1.170 | 0.100 | 103.000 |
| value | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 871,011 | 1.148 | 0.100 | 103.000 |
| value | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 890,668 | 1.123 | 0.100 | 103.000 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 899,705 | 1.111 | 0.100 | 103.000 |
| value | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 5,847,953 | 0.171 | 0.100 | 3.900 |
| value | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 5,776,340 | 0.173 | 0.100 | 17.100 |
| value | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 5,933,662 | 0.169 | 0.100 | 39.600 |
| value | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 6,180,724 | 0.162 | 0.000 | 39.600 |
| value | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 6,336,935 | 0.158 | 0.000 | 39.600 |
| value | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 6,521,285 | 0.153 | 0.000 | 39.600 |
| value | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 5,974,548 | 0.167 | 0.000 | 39.600 |
| value | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 5,554,762 | 0.180 | 0.000 | 39.600 |
| value | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 5,335,610 | 0.187 | 0.000 | 39.600 |
| value | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 5,164,815 | 0.194 | 0.000 | 39.600 |
| value | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 5,077,247 | 0.197 | 0.000 | 39.600 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,083,729 | 0.197 | 0.000 | 39.600 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 3,058 | 327.000 |
| create | — | 0 | up | 5,000 | A | 1 | 883 | 1133.100 |
| create | — | 0 | up | 10,000 | A | 1 | 604 | 1655.600 |
| create | — | 0 | up | 15,000 | A | 1 | 390 | 2561.900 |
| create | — | 0 | up | 20,000 | A | 1 | 292 | 3420.200 |
| create | — | 0 | up | 25,000 | A | 1 | 247 | 4056.500 |
| create | — | 0 | down | 20,000 | A | 1 | 283 | 3533.700 |
| create | — | 0 | down | 15,000 | A | 1 | 348 | 2871.600 |
| create | — | 0 | down | 10,000 | A | 1 | 569 | 1756.200 |
| create | — | 0 | down | 5,000 | A | 1 | 1,238 | 807.800 |
| create | — | 0 | down | 1,000 | A | 1 | 6,618 | 151.100 |
| create | — | 0 | down | 0 | A | 1 | 69,444 | 14.400 |
| sequence | — | 0 | up | 1,000 | A | 1 | 441 | 2267.000 |
| sequence | — | 0 | up | 5,000 | A | 1 | 136 | 7340.400 |
| sequence | — | 0 | up | 10,000 | A | 1 | 85 | 11721.000 |
| sequence | — | 0 | up | 15,000 | A | 1 | 73 | 13681.600 |
| sequence | — | 0 | up | 20,000 | A | 1 | 36 | 27770.700 |
| sequence | — | 0 | up | 25,000 | A | 1 | 44 | 22896.800 |
| sequence | — | 0 | down | 20,000 | A | 1 | 53 | 18918.600 |
| sequence | — | 0 | down | 15,000 | A | 1 | 66 | 15216.100 |
| sequence | — | 0 | down | 10,000 | A | 1 | 84 | 11886.000 |
| sequence | — | 0 | down | 5,000 | A | 1 | 107 | 9304.900 |
| sequence | — | 0 | down | 1,000 | A | 1 | 161 | 6221.600 |
| sequence | — | 0 | down | 0 | A | 1 | 705 | 1418.000 |
| values | — | 0 | up | 1,000 | A | 1 | 551 | 1814.800 |
| values | — | 0 | up | 5,000 | A | 1 | 183 | 5451.900 |
| values | — | 0 | up | 10,000 | A | 1 | 176 | 5692.600 |
| values | — | 0 | up | 15,000 | A | 1 | 121 | 8255.600 |
| values | — | 0 | up | 20,000 | A | 1 | 89 | 11275.800 |
| values | — | 0 | up | 25,000 | A | 1 | 79 | 12642.200 |
| values | — | 0 | down | 20,000 | A | 1 | 113 | 8838.600 |
| values | — | 0 | down | 15,000 | A | 1 | 152 | 6573.700 |
| values | — | 0 | down | 10,000 | A | 1 | 184 | 5429.800 |
| values | — | 0 | down | 5,000 | A | 1 | 407 | 2458.200 |
| values | — | 0 | down | 1,000 | A | 1 | 1,881 | 531.600 |
| values | — | 0 | down | 0 | A | 1 | 84,034 | 11.900 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.613 | 0.232 | 0.381 |
| 0 | up | 5000 | 3.108 | 1.167 | 1.942 |
| 0 | up | 10000 | 6.228 | 2.343 | 3.884 |
| 0 | up | 15000 | 9.486 | 3.643 | 5.843 |
| 0 | up | 20000 | 12.852 | 5.113 | 7.739 |
| 0 | up | 25000 | 16.278 | 6.637 | 9.641 |
| 0 | down | 20000 | 13.340 | 5.613 | 7.727 |
| 0 | down | 15000 | 9.910 | 4.131 | 5.779 |
| 0 | down | 10000 | 7.153 | 3.295 | 3.857 |
| 0 | down | 5000 | 4.067 | 2.161 | 1.905 |
| 0 | down | 1000 | 1.807 | 1.421 | 0.386 |
| 0 | down | 0 | 1.231 | 1.231 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 49,966 | 0.402 | 421.140 | 8.429 | 115.699 | 15.524 |
| 0 | up | A | 5,000 | 5,000 | 254,523 | 2.043 | 428.454 | 8.417 | 149.293 | 19.640 |
| 0 | up | A | 10,000 | 10,000 | 509,098 | 4.098 | 429.682 | 8.440 | 188.504 | 24.533 |
| 0 | up | A | 15,000 | 15,000 | 765,837 | 6.183 | 432.249 | 8.466 | 203.238 | 29.443 |
| 0 | up | A | 20,000 | 20,000 | 1,014,350 | 8.209 | 430.368 | 8.486 | 274.176 | 34.233 |
| 0 | up | A | 25,000 | 25,000 | 1,263,607 | 10.242 | 429.572 | 8.499 | 288.859 | 39.002 |
| 0 | down | A | 20,000 | 20,000 | 1,012,792 | 8.267 | 433.443 | 8.559 | 289.922 | 34.236 |
| 0 | down | A | 15,000 | 15,000 | 757,461 | 6.185 | 432.337 | 8.562 | 292.879 | 29.390 |
| 0 | down | A | 10,000 | 10,000 | 505,565 | 4.118 | 431.804 | 8.541 | 290.668 | 24.615 |
| 0 | down | A | 5,000 | 5,000 | 249,719 | 2.025 | 424.661 | 8.503 | 289.824 | 19.779 |
| 0 | down | A | 1,000 | 1,000 | 50,567 | 0.408 | 428.020 | 8.464 | 287.777 | 15.983 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 286.832 | 14.908 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 49966 | 184228 | 184.228 | 3.687 | 271.76 | 14.53 | 161.92 | 12.35 |
| 0 | up | A | 5000 | 254523 | 1210131 | 242.026 | 4.755 | 1634.13 | 73.21 | 825.25 | 61.48 |
| 0 | up | A | 10000 | 509098 | 2448079 | 244.808 | 4.809 | 3283.48 | 149.01 | 1658.86 | 124.83 |
| 0 | up | A | 15000 | 765837 | 3734371 | 248.958 | 4.876 | 4974.88 | 226.26 | 3590.17 | 200.09 |
| 0 | up | A | 20000 | 1014350 | 4987172 | 249.359 | 4.917 | 7129.39 | 311.11 | 5143.68 | 263.60 |
| 0 | up | A | 25000 | 1263607 | 6249793 | 249.992 | 4.946 | 9254.82 | 392.21 | 6545.54 | 334.80 |
| 0 | down | A | 20000 | 1012792 | 5129580 | 256.479 | 5.065 | 7576.63 | 326.54 | 5319.60 | 278.20 |
| 0 | down | A | 15000 | 757461 | 3834350 | 255.623 | 5.062 | 5712.74 | 247.20 | 3993.54 | 209.87 |
| 0 | down | A | 10000 | 505565 | 2537356 | 253.736 | 5.019 | 3822.17 | 165.03 | 2665.76 | 139.77 |
| 0 | down | A | 5000 | 249719 | 1229097 | 245.819 | 4.922 | 1877.54 | 79.58 | 1312.05 | 67.88 |
| 0 | down | A | 1000 | 50567 | 240346 | 240.346 | 4.753 | 377.29 | 15.97 | 264.47 | 13.64 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 430.140 | 8.475 | 247.550 | 4.877 |
| 0 | A | scaleDown | 431.829 | 8.549 | 254.328 | 5.035 |
| 0 | A | fullLifecycle | 430.818 | 8.505 | 250.272 | 4.940 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
