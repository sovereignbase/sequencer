# Large string benchmarks

2026-11-27T17:02:34.481Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2245.89 | 0.00 |
| 1024 | insert.append | array | 13170.17 | 0.00 |
| 1024 | replace | array | 3305.39 | 0.00 |
| 1024 | remove | array | 1045.37 | 0.00 |
| 1024 | remove.middle | array | 2011.55 | 0.00 |
| 1024 | replace.middle | array | 2393.01 | 0.00 |
| 1024 | apply | array | 1059.03 | 0.00 |
| 1024 | apply.array | array | 542.64 | 0.00 |
| 1024 | concurrent.apply | array | 68022.28 | 0.00 |
| 1024 | merge | array | 3166.03 | 0.00 |
| 1024 | create | array | 3100.51 | 0.00 |
| 1024 | value.random | array | 45.66 | 0.00 |
| 1024 | values.range | array | 110.06 | 0.00 |
| 1024 | values.array | array | 1674.78 | 0.00 |
| 1024 | values.text | array | 14469.79 | 0.00 |
| 1024 | sequence.array | array | 1595.94 | 0.00 |
| 1024 | sequence.text | array | 9508.14 | 0.00 |
| 1024 | sequence.edited.text | array | 14139.47 | 0.00 |
| 1024 | sequence.masked.text | array | 11040.13 | 0.00 |
| 1024 | insert | string | 380.96 | 0.00 |
| 1024 | insert.append | string | 4239.25 | 0.00 |
| 1024 | replace | string | 1179.08 | 0.00 |
| 1024 | remove | string | 1002.51 | 0.00 |
| 1024 | remove.middle | string | 1003.17 | 0.00 |
| 1024 | replace.middle | string | 1319.74 | 0.00 |
| 1024 | apply | string | 805.87 | 0.00 |
| 1024 | apply.array | string | 2314.48 | 0.00 |
| 1024 | concurrent.apply | string | 4201.51 | 0.00 |
| 1024 | merge | string | 1311.19 | 0.00 |
| 1024 | create | string | 1030.40 | 0.00 |
| 1024 | value.random | string | 48.18 | 0.00 |
| 1024 | values.range | string | 175.80 | 0.00 |
| 1024 | values.array | string | 1717.82 | 0.00 |
| 1024 | values.text | string | 70.02 | 0.00 |
| 1024 | sequence.array | string | 2054.86 | 0.00 |
| 1024 | sequence.text | string | 203.92 | 0.00 |
| 1024 | sequence.edited.text | string | 2331.50 | 0.00 |
| 1024 | sequence.masked.text | string | 3700.57 | 0.00 |
| 65536 | insert | array | 269465.96 | 0.00 |
| 65536 | insert.append | array | 1079368.00 | 0.00 |
| 65536 | replace | array | 248646.53 | 0.00 |
| 65536 | remove | array | 2366.02 | 0.00 |
| 65536 | remove.middle | array | 238767.89 | 0.00 |
| 65536 | replace.middle | array | 208520.83 | 0.00 |
| 65536 | apply | array | 989.32 | 0.00 |
| 65536 | apply.array | array | 514.84 | 0.00 |
| 65536 | concurrent.apply | array | 4607833.33 | 0.00 |
| 65536 | merge | array | 223816.07 | 0.00 |
| 65536 | create | array | 208930.00 | 0.00 |
| 65536 | value.random | array | 60.66 | 0.00 |
| 65536 | values.range | array | 159.38 | 0.00 |
| 65536 | values.array | array | 202189.68 | 0.00 |
| 65536 | values.text | array | 803234.37 | 0.00 |
| 65536 | sequence.array | array | 203396.83 | 0.00 |
| 65536 | sequence.text | array | 709880.56 | 0.00 |
| 65536 | sequence.edited.text | array | 933881.48 | 0.00 |
| 65536 | sequence.masked.text | array | 720565.71 | 0.00 |
| 65536 | insert | string | 349.57 | 0.00 |
| 65536 | insert.append | string | 22088.96 | 0.00 |
| 65536 | replace | string | 1259.72 | 0.00 |
| 65536 | remove | string | 904.28 | 0.00 |
| 65536 | remove.middle | string | 908.59 | 0.00 |
| 65536 | replace.middle | string | 1315.56 | 0.00 |
| 65536 | apply | string | 782.26 | 0.00 |
| 65536 | apply.array | string | 249224.22 | 0.00 |
| 65536 | concurrent.apply | string | 162556.49 | 0.00 |
| 65536 | merge | string | 1172.64 | 0.00 |
| 65536 | create | string | 983.98 | 0.00 |
| 65536 | value.random | string | 46.84 | 0.00 |
| 65536 | values.range | string | 150.61 | 0.00 |
| 65536 | values.array | string | 275407.81 | 0.00 |
| 65536 | values.text | string | 78.97 | 0.00 |
| 65536 | sequence.array | string | 262484.38 | 0.00 |
| 65536 | sequence.text | string | 540.29 | 0.00 |
| 65536 | sequence.edited.text | string | 245280.39 | 0.00 |
| 65536 | sequence.masked.text | string | 4269.19 | 0.00 |
| 1048576 | insert | array | 3281212.50 | 0.00 |
| 1048576 | insert.append | array | 24359250.00 | 0.00 |
| 1048576 | replace | array | 3209400.00 | 0.00 |
| 1048576 | remove | array | 9882.13 | 0.00 |
| 1048576 | remove.middle | array | 3394000.00 | 0.00 |
| 1048576 | replace.middle | array | 2849966.67 | 0.00 |
| 1048576 | apply | array | 1001.35 | 0.00 |
| 1048576 | apply.array | array | 527.54 | 0.00 |
| 1048576 | concurrent.apply | array | 67795900.00 | 0.00 |
| 1048576 | merge | array | 2996433.33 | 0.00 |
| 1048576 | create | array | 2942322.22 | 0.00 |
| 1048576 | value.random | array | 52.94 | 0.00 |
| 1048576 | values.range | array | 137.92 | 0.00 |
| 1048576 | values.array | array | 2562270.00 | 0.00 |
| 1048576 | values.text | array | 13316050.00 | 0.00 |
| 1048576 | sequence.array | array | 2180175.00 | 0.00 |
| 1048576 | sequence.text | array | 42332450.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 49956400.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 45624850.00 | 0.00 |
| 1048576 | insert | string | 542.41 | 0.00 |
| 1048576 | insert.append | string | 515422.45 | 0.00 |
| 1048576 | replace | string | 1579.50 | 0.00 |
| 1048576 | remove | string | 1166.50 | 0.00 |
| 1048576 | remove.middle | string | 892.30 | 0.00 |
| 1048576 | replace.middle | string | 1457.64 | 0.00 |
| 1048576 | apply | string | 835.52 | 0.00 |
| 1048576 | apply.array | string | 3415800.00 | 0.00 |
| 1048576 | concurrent.apply | string | 1317810.53 | 0.00 |
| 1048576 | merge | string | 1319.75 | 0.00 |
| 1048576 | create | string | 1001.62 | 0.00 |
| 1048576 | value.random | string | 46.27 | 0.00 |
| 1048576 | values.range | string | 150.83 | 0.00 |
| 1048576 | values.array | string | 3396475.00 | 0.00 |
| 1048576 | values.text | string | 64.61 | 0.00 |
| 1048576 | sequence.array | string | 3664300.00 | 0.00 |
| 1048576 | sequence.text | string | 173.38 | 0.00 |
| 1048576 | sequence.edited.text | string | 1402416.67 | 0.00 |
| 1048576 | sequence.masked.text | string | 3179.99 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
