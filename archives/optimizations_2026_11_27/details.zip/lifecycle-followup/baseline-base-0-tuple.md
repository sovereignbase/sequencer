# Tuple benchmarks

2026-11-27T17:02:19.942Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 3,100,760 | 2,414,332 | 0.78× |
| 2 | create.sequence | 1,011,712 | 222,628 | 0.22× |
| 2 | replace.random | 1,100,028 | 1,315,298 | 1.20× |
| 2 | apply.replace | 650,509 | 953,173 | 1.47× |
| 2 | apply.duplicate | 1,772,445 | 900,330 | 0.51× |
| 2 | merge.duplicate | 1,652,838 | 1,752,098 | 1.06× |
| 2 | length | 136,800,589 | 137,497,274 | 1.01× |
| 2 | value.random | 31,934,210 | 52,841,061 | 1.65× |
| 2 | values | 10,292,155 | 10,282,435 | 1.00× |
| 2 | sequence | 2,960,983 | 2,994,614 | 1.01× |
| 4 | create.empty | 2,509,879 | 2,243,744 | 0.89× |
| 4 | create.sequence | 59,970 | 412,051 | 6.87× |
| 4 | replace.random | 665,904 | 1,256,160 | 1.89× |
| 4 | apply.replace | 596,034 | 936,698 | 1.57× |
| 4 | apply.duplicate | 1,735,928 | 1,729,969 | 1.00× |
| 4 | merge.duplicate | 1,320,922 | 1,303,105 | 0.99× |
| 4 | length | 38,802,194 | 37,596,665 | 0.97× |
| 4 | value.random | 25,146,383 | 58,228,230 | 2.32× |
| 4 | values | 6,011,487 | 7,226,807 | 1.20× |
| 4 | sequence | 2,731,717 | 2,792,664 | 1.02× |
| 8 | create.empty | 2,660,208 | 2,441,763 | 0.92× |
| 8 | create.sequence | 466,780 | 579,071 | 1.24× |
| 8 | replace.random | 1,055,227 | 1,710,590 | 1.62× |
| 8 | apply.replace | 614,403 | 1,046,434 | 1.70× |
| 8 | apply.duplicate | 1,792,036 | 1,732,913 | 0.97× |
| 8 | merge.duplicate | 981,305 | 900,475 | 0.92× |
| 8 | length | 39,103,170 | 36,011,971 | 0.92× |
| 8 | value.random | 19,683,953 | 55,720,676 | 2.83× |
| 8 | values | 4,642,107 | 5,210,181 | 1.12× |
| 8 | sequence | 1,791,416 | 1,627,645 | 0.91× |
| 100 | create.empty | 2,334,669 | 2,264,363 | 0.97× |
| 100 | create.sequence | 71,329 | 85,069 | 1.19× |
| 100 | replace.random | 1,031,468 | 1,658,169 | 1.61× |
| 100 | apply.replace | 652,109 | 926,482 | 1.42× |
| 100 | apply.duplicate | 1,760,344 | 1,773,293 | 1.01× |
| 100 | merge.duplicate | 116,896 | 75,648 | 0.65× |
| 100 | length | 35,426,369 | 40,884,539 | 1.15× |
| 100 | value.random | 12,380,677 | 51,289,857 | 4.14× |
| 100 | values | 534,836 | 690,117 | 1.29× |
| 100 | sequence | 74,391 | 185,350 | 2.49× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
