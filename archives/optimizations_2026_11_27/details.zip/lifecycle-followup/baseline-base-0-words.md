# Words benchmarks

2026-11-27T17:02:56.964Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 29,951 | 147,013 | 180 |
| append | packed | 5.90 | 3.61 | 13.98 | 32,296 | 205,182 | 292 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,640 | 842 | 245 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 26,334 | 1,176 | 240 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 325 | 174 | 75 |
| random | packed | 49.58 | 35.38 | 23.45 | 13,179 | 436 | 124 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 696 | 214 | 79 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 15,098 | 424 | 147 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 560.59 | 0.00 |
| append | numeric | encode | 33388.31 | 0.00 |
| append | numeric | decode | 2820.32 | 0.00 |
| append | numeric | create | 2246.48 | 0.00 |
| append | numeric | load | 6802.14 | 0.00 |
| append | numeric | apply | 3389373.33 | 0.00 |
| append | numeric | receive | 5566377.78 | 0.00 |
| append | binary | sequence | 479.84 | 0.00 |
| append | binary | encode | 30963.34 | 0.00 |
| append | binary | decode | 1730.38 | 0.00 |
| append | binary | create | 1898.81 | 0.00 |
| append | binary | load | 4873.73 | 0.00 |
| append | binary | apply | 1705820.00 | 0.00 |
| append | binary | receive | 3422986.67 | 0.00 |
| prepend | numeric | sequence | 581400.00 | 0.00 |
| prepend | numeric | encode | 609912.20 | 0.00 |
| prepend | numeric | decode | 259358.03 | 0.00 |
| prepend | numeric | create | 617990.12 | 0.00 |
| prepend | numeric | load | 1188181.40 | 0.00 |
| prepend | numeric | apply | 2338236.36 | 0.00 |
| prepend | numeric | receive | 4084784.62 | 0.00 |
| prepend | binary | sequence | 368504.41 | 0.00 |
| prepend | binary | encode | 37973.88 | 0.00 |
| prepend | binary | decode | 3319.21 | 0.00 |
| prepend | binary | create | 698993.06 | 0.00 |
| prepend | binary | load | 850210.00 | 0.00 |
| prepend | binary | apply | 3276325.00 | 0.00 |
| prepend | binary | receive | 4173725.00 | 0.00 |
| random | numeric | sequence | 3155793.75 | 0.00 |
| random | numeric | encode | 3081476.47 | 0.00 |
| random | numeric | decode | 1259525.00 | 0.00 |
| random | numeric | create | 2314245.45 | 0.00 |
| random | numeric | load | 5747611.11 | 0.00 |
| random | numeric | apply | 8733300.00 | 0.00 |
| random | numeric | receive | 13366925.00 | 0.00 |
| random | binary | sequence | 911078.18 | 0.00 |
| random | binary | encode | 75879.82 | 0.00 |
| random | binary | decode | 1639.34 | 0.00 |
| random | binary | create | 1907611.11 | 0.00 |
| random | binary | load | 2291239.13 | 0.00 |
| random | binary | apply | 7198300.00 | 0.00 |
| random | binary | receive | 8042642.86 | 0.00 |
| concurrent | numeric | sequence | 825145.90 | 0.00 |
| concurrent | numeric | encode | 1436205.71 | 0.00 |
| concurrent | numeric | decode | 810177.42 | 0.00 |
| concurrent | numeric | create | 2523530.00 | 0.00 |
| concurrent | numeric | load | 4663327.27 | 0.00 |
| concurrent | numeric | apply | 6014211.11 | 0.00 |
| concurrent | numeric | receive | 12599975.00 | 0.00 |
| concurrent | binary | sequence | 755998.51 | 0.00 |
| concurrent | binary | encode | 66233.11 | 0.00 |
| concurrent | binary | decode | 2863.34 | 0.00 |
| concurrent | binary | create | 2288336.36 | 0.00 |
| concurrent | binary | load | 2360072.73 | 0.00 |
| concurrent | binary | apply | 5312410.00 | 0.00 |
| concurrent | binary | receive | 6780450.00 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
