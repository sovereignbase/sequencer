# Batch benchmarks

2026-11-27T17:04:49.284Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 1,438,159 | 1,144,470 | 614,169 | 76.05 | 5.99 | 0.012 |
| append | batch | 2,729,506 | 243,902,439 | 222,222,222 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,766,368 | 1,582,571 | 898,688 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 1,291,684 | 1,210,312 | 1,312,882 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 1,001,803 | 1,096,551 | 858,516 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 1,283,313 | 1,613,337 | 1,434,652 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 1,051,764 | 1,100,150 | 805,023 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 1,147,491 | 1,831,278 | 1,626,413 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,271,698 | 1,153,802 | 767,710 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,100,756 | 1,460,796 | 1,252,557 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,325,147 | 810,904 | 718,455 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,238,339 | 1,748,201 | 1,534,507 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 557,935 | 928,570 | 693,638 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 954,601 | 1,241,979 | 1,211,057 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,015,684 | 1,413,111 | 952,638 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 1,310,158 | 1,809,136 | 1,659,109 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,150,748 | 1,338,300 | 896,774 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 1,288,535 | 1,621,687 | 1,436,231 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 501,408 | 791,860 | 551,744 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 481,903 | 903,213 | 724,130 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 4.172 | 0.000 |
| append | individual | apply | 5.243 | 0.000 |
| append | individual | receive | 9.769 | 0.000 |
| append | individual | encode | 8.108 | 0.000 |
| append | individual | decode | 7.276 | 0.000 |
| append | batch | author | 2.198 | 0.000 |
| append | batch | apply | 0.025 | 0.000 |
| append | batch | receive | 0.027 | 0.000 |
| append | batch | encode | 0.203 | 0.000 |
| append | batch | decode | 0.089 | 0.000 |
| prepend | individual | author | 3.397 | 0.000 |
| prepend | individual | apply | 3.791 | 0.000 |
| prepend | individual | receive | 6.676 | 0.000 |
| prepend | individual | encode | 5.317 | 0.000 |
| prepend | individual | decode | 6.808 | 0.000 |
| prepend | batch | author | 4.645 | 0.000 |
| prepend | batch | apply | 4.957 | 0.000 |
| prepend | batch | receive | 4.570 | 0.000 |
| prepend | batch | encode | 0.271 | 0.000 |
| prepend | batch | decode | 0.166 | 0.000 |
| random.characters | individual | author | 5.989 | 0.000 |
| random.characters | individual | apply | 5.472 | 0.000 |
| random.characters | individual | receive | 6.989 | 0.000 |
| random.characters | individual | encode | 5.202 | 0.000 |
| random.characters | individual | decode | 7.358 | 0.000 |
| random.characters | batch | author | 4.675 | 0.000 |
| random.characters | batch | apply | 3.719 | 0.000 |
| random.characters | batch | receive | 4.182 | 0.000 |
| random.characters | batch | encode | 0.188 | 0.000 |
| random.characters | batch | decode | 0.102 | 0.000 |
| random.words | individual | author | 5.705 | 0.000 |
| random.words | individual | apply | 5.454 | 0.000 |
| random.words | individual | receive | 7.453 | 0.000 |
| random.words | individual | encode | 4.514 | 0.000 |
| random.words | individual | decode | 6.686 | 0.000 |
| random.words | batch | author | 5.229 | 0.000 |
| random.words | batch | apply | 3.276 | 0.000 |
| random.words | batch | receive | 3.689 | 0.000 |
| random.words | batch | encode | 0.429 | 0.000 |
| random.words | batch | decode | 0.109 | 0.000 |
| concurrent.characters | individual | author | 9.436 | 0.000 |
| concurrent.characters | individual | apply | 10.400 | 0.000 |
| concurrent.characters | individual | receive | 15.631 | 0.000 |
| concurrent.characters | individual | encode | 8.431 | 0.000 |
| concurrent.characters | individual | decode | 10.577 | 0.000 |
| concurrent.characters | batch | author | 10.902 | 0.000 |
| concurrent.characters | batch | apply | 8.215 | 0.000 |
| concurrent.characters | batch | receive | 9.580 | 0.000 |
| concurrent.characters | batch | encode | 0.431 | 0.000 |
| concurrent.characters | batch | decode | 0.135 | 0.000 |
| concurrent.words | individual | author | 9.056 | 0.000 |
| concurrent.words | individual | apply | 14.798 | 0.000 |
| concurrent.words | individual | receive | 16.702 | 0.000 |
| concurrent.words | individual | encode | 12.398 | 0.000 |
| concurrent.words | individual | decode | 13.655 | 0.000 |
| concurrent.words | batch | author | 9.690 | 0.000 |
| concurrent.words | batch | apply | 6.864 | 0.000 |
| concurrent.words | batch | receive | 7.820 | 0.000 |
| concurrent.words | batch | encode | 0.784 | 0.000 |
| concurrent.words | batch | decode | 0.120 | 0.000 |
| concurrent.mixed | individual | author | 21.508 | 0.000 |
| concurrent.mixed | individual | apply | 12.923 | 0.000 |
| concurrent.mixed | individual | receive | 17.300 | 0.000 |
| concurrent.mixed | individual | encode | 8.754 | 0.000 |
| concurrent.mixed | individual | decode | 10.268 | 0.000 |
| concurrent.mixed | batch | author | 12.571 | 0.000 |
| concurrent.mixed | batch | apply | 9.662 | 0.000 |
| concurrent.mixed | batch | receive | 9.909 | 0.000 |
| concurrent.mixed | batch | encode | 0.531 | 0.000 |
| concurrent.mixed | batch | decode | 0.111 | 0.000 |
| causal.characters | individual | author | 11.815 | 0.000 |
| causal.characters | individual | apply | 8.492 | 0.000 |
| causal.characters | individual | receive | 12.597 | 0.000 |
| causal.characters | individual | encode | 7.534 | 0.000 |
| causal.characters | individual | decode | 10.166 | 0.000 |
| causal.characters | batch | author | 9.159 | 0.000 |
| causal.characters | batch | apply | 6.633 | 0.000 |
| causal.characters | batch | receive | 7.233 | 0.000 |
| causal.characters | batch | encode | 0.415 | 0.000 |
| causal.characters | batch | decode | 0.127 | 0.000 |
| causal.words | individual | author | 10.428 | 0.000 |
| causal.words | individual | apply | 8.967 | 0.000 |
| causal.words | individual | receive | 13.381 | 0.000 |
| causal.words | individual | encode | 8.853 | 0.000 |
| causal.words | individual | decode | 10.930 | 0.000 |
| causal.words | batch | author | 9.313 | 0.000 |
| causal.words | batch | apply | 7.400 | 0.000 |
| causal.words | batch | receive | 8.355 | 0.000 |
| causal.words | batch | encode | 0.594 | 0.000 |
| causal.words | batch | decode | 0.113 | 0.000 |
| causal.mixed | individual | author | 23.933 | 0.000 |
| causal.mixed | individual | apply | 15.154 | 0.000 |
| causal.mixed | individual | receive | 21.749 | 0.000 |
| causal.mixed | individual | encode | 11.006 | 0.000 |
| causal.mixed | individual | decode | 12.059 | 0.000 |
| causal.mixed | batch | author | 24.901 | 0.000 |
| causal.mixed | batch | apply | 13.286 | 0.000 |
| causal.mixed | batch | receive | 16.572 | 0.000 |
| causal.mixed | batch | encode | 0.728 | 0.000 |
| causal.mixed | batch | decode | 0.145 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
