# Sequencer dynamic lifecycle benchmark

2026-11-27T17:03:15.584Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.23 | 162.89 | 56.49 |
| CommonJS | 199.41 | 164.51 | 56.69 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 275,798 | 3.626 | 3.626 | 3.626 | 0.000 | 0: 3.626 | 0: 3.626 |
| apply | random | A | scaleDown | 24,999 | 356,402 | 2.806 | 2.806 | 2.806 | 0.000 | 0: 2.806 | 0: 2.806 |
| apply | random | A | fullLifecycle | 49,999 | 310,961 | 3.216 | 3.216 | 3.216 | 0.000 | 0: 3.216 | 0: 3.216 |
| create | — | A | scaleUp | 7 | 541 | 1847.300 | 1847.300 | 1847.300 | 0.000 | 0: 1847.300 | 0: 1847.300 |
| create | — | A | scaleDown | 6 | 669 | 1494.533 | 1494.533 | 1494.533 | 0.000 | 0: 1494.533 | 0: 1494.533 |
| create | — | A | fullLifecycle | 13 | 594 | 1684.485 | 1684.485 | 1684.485 | 0.000 | 0: 1684.485 | 0: 1684.485 |
| insert | head | A | scaleUp | 12,500 | 1,172,762 | 0.853 | 0.853 | 0.853 | 0.000 | 0: 0.853 | 0: 0.853 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,172,762 | 0.853 | 0.853 | 0.853 | 0.000 | 0: 0.853 | 0: 0.853 |
| insert | random | A | scaleUp | 25,000 | 500,096 | 2.000 | 2.000 | 2.000 | 0.000 | 0: 2.000 | 0: 2.000 |
| insert | random | A | scaleDown | 25,000 | 600,853 | 1.664 | 1.664 | 1.664 | 0.000 | 0: 1.664 | 0: 1.664 |
| insert | random | A | fullLifecycle | 50,000 | 545,864 | 1.832 | 1.832 | 1.832 | 0.000 | 0: 1.832 | 0: 1.832 |
| insert | tail | A | scaleUp | 12,500 | 1,182,525 | 0.846 | 0.846 | 0.846 | 0.000 | 0: 0.846 | 0: 0.846 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,182,525 | 0.846 | 0.846 | 0.846 | 0.000 | 0: 0.846 | 0: 0.846 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 703,698 | 1.421 | 1.421 | 1.421 | 0.000 | 0: 1.421 | 0: 1.421 |
| remove | head | A | fullLifecycle | 12,500 | 703,698 | 1.421 | 1.421 | 1.421 | 0.000 | 0: 1.421 | 0: 1.421 |
| remove | random | A | scaleUp | 25,000 | 397,158 | 2.518 | 2.518 | 2.518 | 0.000 | 0: 2.518 | 0: 2.518 |
| remove | random | A | scaleDown | 25,000 | 528,617 | 1.892 | 1.892 | 1.892 | 0.000 | 0: 1.892 | 0: 1.892 |
| remove | random | A | fullLifecycle | 50,000 | 453,554 | 2.205 | 2.205 | 2.205 | 0.000 | 0: 2.205 | 0: 2.205 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 846,608 | 1.181 | 1.181 | 1.181 | 0.000 | 0: 1.181 | 0: 1.181 |
| remove | tail | A | fullLifecycle | 12,500 | 846,608 | 1.181 | 1.181 | 1.181 | 0.000 | 0: 1.181 | 0: 1.181 |
| replace | head | A | scaleUp | 25,000 | 300,762 | 3.325 | 3.325 | 3.325 | 0.000 | 0: 3.325 | 0: 3.325 |
| replace | head | A | scaleDown | 25,000 | 522,898 | 1.912 | 1.912 | 1.912 | 0.000 | 0: 1.912 | 0: 1.912 |
| replace | head | A | fullLifecycle | 50,000 | 381,875 | 2.619 | 2.619 | 2.619 | 0.000 | 0: 2.619 | 0: 2.619 |
| replace | random | A | scaleUp | 25,000 | 297,673 | 3.359 | 3.359 | 3.359 | 0.000 | 0: 3.359 | 0: 3.359 |
| replace | random | A | scaleDown | 25,000 | 396,073 | 2.525 | 2.525 | 2.525 | 0.000 | 0: 2.525 | 0: 2.525 |
| replace | random | A | fullLifecycle | 50,000 | 339,894 | 2.942 | 2.942 | 2.942 | 0.000 | 0: 2.942 | 0: 2.942 |
| replace | tail | A | scaleUp | 25,000 | 470,961 | 2.123 | 2.123 | 2.123 | 0.000 | 0: 2.123 | 0: 2.123 |
| replace | tail | A | scaleDown | 25,000 | 58,027 | 17.233 | 17.233 | 17.233 | 0.000 | 0: 17.233 | 0: 17.233 |
| replace | tail | A | fullLifecycle | 50,000 | 103,323 | 9.678 | 9.678 | 9.678 | 0.000 | 0: 9.678 | 0: 9.678 |
| sequence | — | A | scaleUp | 6 | 74 | 13500.850 | 13500.850 | 13500.850 | 0.000 | 0: 13500.850 | 0: 13500.850 |
| sequence | — | A | scaleDown | 6 | 98 | 10193.817 | 10193.817 | 10193.817 | 0.000 | 0: 10193.817 | 0: 10193.817 |
| sequence | — | A | fullLifecycle | 12 | 84 | 11847.333 | 11847.333 | 11847.333 | 0.000 | 0: 11847.333 | 0: 11847.333 |
| value | head | A | scaleUp | 25,000 | 2,698,589 | 0.371 | 0.371 | 0.371 | 0.000 | 0: 0.371 | 0: 0.371 |
| value | head | A | scaleDown | 25,000 | 2,363,485 | 0.423 | 0.423 | 0.423 | 0.000 | 0: 0.423 | 0: 0.423 |
| value | head | A | fullLifecycle | 50,000 | 2,519,945 | 0.397 | 0.397 | 0.397 | 0.000 | 0: 0.397 | 0: 0.397 |
| value | random | A | scaleUp | 25,000 | 650,662 | 1.537 | 1.537 | 1.537 | 0.000 | 0: 1.537 | 0: 1.537 |
| value | random | A | scaleDown | 25,000 | 1,010,203 | 0.990 | 0.990 | 0.990 | 0.000 | 0: 0.990 | 0: 0.990 |
| value | random | A | fullLifecycle | 50,000 | 791,516 | 1.263 | 1.263 | 1.263 | 0.000 | 0: 1.263 | 0: 1.263 |
| value | tail | A | scaleUp | 25,000 | 5,836,349 | 0.171 | 0.171 | 0.171 | 0.000 | 0: 0.171 | 0: 0.171 |
| value | tail | A | scaleDown | 25,000 | 4,144,494 | 0.241 | 0.241 | 0.241 | 0.000 | 0: 0.241 | 0: 0.241 |
| value | tail | A | fullLifecycle | 50,000 | 4,847,028 | 0.206 | 0.206 | 0.206 | 0.000 | 0: 0.206 | 0: 0.206 |
| values | — | A | scaleUp | 6 | 140 | 7138.667 | 7138.667 | 7138.667 | 0.000 | 0: 7138.667 | 0: 7138.667 |
| values | — | A | scaleDown | 6 | 257 | 3896.900 | 3896.900 | 3896.900 | 0.000 | 0: 3896.900 | 0: 3896.900 |
| values | — | A | fullLifecycle | 12 | 181 | 5517.783 | 5517.783 | 5517.783 | 0.000 | 0: 5517.783 | 0: 5517.783 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5428540.000 | 428.569 | 8.477 |
| A | scaleDown | 5 | 4409840.000 | 432.337 | 8.548 |
| A | fullLifecycle | 11 | 4965494.545 | 430.082 | 8.506 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3126055.667 | 246.794 | 4.882 |
| A | scaleDown | 5 | 2596615.600 | 254.570 | 5.033 |
| A | fullLifecycle | 11 | 2885401.091 | 249.917 | 4.943 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 255,565 | 3.913 | 1.800 | 247.500 |
| apply | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 318,350 | 3.141 | 1.600 | 491.600 |
| apply | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 308,018 | 3.247 | 1.400 | 621.600 |
| apply | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 317,604 | 3.149 | 1.400 | 621.600 |
| apply | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 296,389 | 3.374 | 1.400 | 1582.200 |
| apply | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 275,798 | 3.626 | 1.400 | 1631.900 |
| apply | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 284,517 | 3.515 | 1.400 | 1631.900 |
| apply | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 293,263 | 3.410 | 1.400 | 1631.900 |
| apply | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 296,618 | 3.371 | 1.400 | 1631.900 |
| apply | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 301,837 | 3.313 | 1.400 | 1631.900 |
| apply | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 309,099 | 3.235 | 1.300 | 1631.900 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 310,961 | 3.216 | 1.200 | 1631.900 |
| insert | head | 0 | up | 1,000 | 51,204 | A | 500 | 1,092,896 | 0.915 | 0.400 | 14.500 |
| insert | head | 0 | up | 5,000 | 250,037 | A | 2,500 | 1,215,953 | 0.822 | 0.400 | 18.200 |
| insert | head | 0 | up | 10,000 | 506,154 | A | 5,000 | 1,259,256 | 0.794 | 0.300 | 21.200 |
| insert | head | 0 | up | 15,000 | 762,134 | A | 7,500 | 1,309,403 | 0.764 | 0.300 | 21.200 |
| insert | head | 0 | up | 20,000 | 1,012,964 | A | 10,000 | 1,231,315 | 0.812 | 0.300 | 123.500 |
| insert | head | 0 | up | 25,000 | 1,259,727 | A | 12,500 | 1,172,762 | 0.853 | 0.300 | 123.500 |
| insert | head | 0 | down | 20,000 | 1,009,630 | A | 12,500 | 1,172,762 | 0.853 | 0.300 | 123.500 |
| insert | head | 0 | down | 15,000 | 759,633 | A | 12,500 | 1,172,762 | 0.853 | 0.300 | 123.500 |
| insert | head | 0 | down | 10,000 | 507,941 | A | 12,500 | 1,172,762 | 0.853 | 0.300 | 123.500 |
| insert | head | 0 | down | 5,000 | 250,794 | A | 12,500 | 1,172,762 | 0.853 | 0.300 | 123.500 |
| insert | head | 0 | down | 1,000 | 51,447 | A | 12,500 | 1,172,762 | 0.853 | 0.300 | 123.500 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,172,762 | 0.853 | 0.300 | 123.500 |
| insert | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 542,476 | 1.843 | 0.500 | 347.600 |
| insert | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 565,170 | 1.769 | 0.500 | 1008.400 |
| insert | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 575,089 | 1.739 | 0.500 | 1008.400 |
| insert | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 574,488 | 1.741 | 0.500 | 1008.400 |
| insert | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 526,905 | 1.898 | 0.500 | 1008.400 |
| insert | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 500,096 | 2.000 | 0.500 | 1008.400 |
| insert | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 508,447 | 1.967 | 0.500 | 1008.400 |
| insert | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 509,601 | 1.962 | 0.500 | 1446.300 |
| insert | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 521,028 | 1.919 | 0.500 | 1446.300 |
| insert | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 528,582 | 1.892 | 0.500 | 1446.300 |
| insert | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 540,518 | 1.850 | 0.400 | 1446.300 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 545,864 | 1.832 | 0.400 | 1446.300 |
| insert | tail | 0 | up | 1,000 | 51,204 | A | 500 | 1,034,768 | 0.966 | 0.300 | 31.700 |
| insert | tail | 0 | up | 5,000 | 250,037 | A | 2,500 | 1,315,789 | 0.760 | 0.300 | 42.500 |
| insert | tail | 0 | up | 10,000 | 506,154 | A | 5,000 | 1,368,513 | 0.731 | 0.300 | 73.900 |
| insert | tail | 0 | up | 15,000 | 762,134 | A | 7,500 | 1,391,956 | 0.718 | 0.300 | 147.500 |
| insert | tail | 0 | up | 20,000 | 1,012,964 | A | 10,000 | 1,291,406 | 0.774 | 0.300 | 342.200 |
| insert | tail | 0 | up | 25,000 | 1,259,727 | A | 12,500 | 1,182,525 | 0.846 | 0.300 | 342.200 |
| insert | tail | 0 | down | 20,000 | 1,009,630 | A | 12,500 | 1,182,525 | 0.846 | 0.300 | 342.200 |
| insert | tail | 0 | down | 15,000 | 759,633 | A | 12,500 | 1,182,525 | 0.846 | 0.300 | 342.200 |
| insert | tail | 0 | down | 10,000 | 507,941 | A | 12,500 | 1,182,525 | 0.846 | 0.300 | 342.200 |
| insert | tail | 0 | down | 5,000 | 250,794 | A | 12,500 | 1,182,525 | 0.846 | 0.300 | 342.200 |
| insert | tail | 0 | down | 1,000 | 51,447 | A | 12,500 | 1,182,525 | 0.846 | 0.300 | 342.200 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,182,525 | 0.846 | 0.300 | 342.200 |
| remove | head | 0 | up | 1,000 | 51,204 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 250,037 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 506,154 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 762,134 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,012,964 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,259,727 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,009,630 | A | 2,500 | 690,322 | 1.449 | 0.900 | 26.500 |
| remove | head | 0 | down | 15,000 | 759,633 | A | 5,000 | 681,831 | 1.467 | 0.800 | 299.600 |
| remove | head | 0 | down | 10,000 | 507,941 | A | 7,500 | 661,913 | 1.511 | 0.800 | 580.400 |
| remove | head | 0 | down | 5,000 | 250,794 | A | 10,000 | 683,957 | 1.462 | 0.800 | 580.400 |
| remove | head | 0 | down | 1,000 | 51,447 | A | 12,000 | 707,130 | 1.414 | 0.700 | 580.400 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 703,698 | 1.421 | 0.700 | 580.400 |
| remove | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 449,236 | 2.226 | 1.000 | 476.300 |
| remove | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 523,412 | 1.911 | 0.900 | 476.300 |
| remove | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 438,285 | 2.282 | 0.900 | 1855.900 |
| remove | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 462,345 | 2.163 | 0.800 | 1855.900 |
| remove | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 433,651 | 2.306 | 0.800 | 1855.900 |
| remove | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 397,158 | 2.518 | 0.800 | 2080.300 |
| remove | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 407,690 | 2.453 | 0.800 | 2080.300 |
| remove | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 420,292 | 2.379 | 0.800 | 2080.300 |
| remove | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 428,809 | 2.332 | 0.800 | 2080.300 |
| remove | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 438,170 | 2.282 | 0.800 | 2080.300 |
| remove | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 449,242 | 2.226 | 0.800 | 2080.300 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 453,554 | 2.205 | 0.700 | 2080.300 |
| remove | tail | 0 | up | 1,000 | 51,204 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 250,037 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 506,154 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 762,134 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,012,964 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,259,727 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,009,630 | A | 2,500 | 801,359 | 1.248 | 0.800 | 15.100 |
| remove | tail | 0 | down | 15,000 | 759,633 | A | 5,000 | 821,423 | 1.217 | 0.800 | 15.100 |
| remove | tail | 0 | down | 10,000 | 507,941 | A | 7,500 | 822,639 | 1.216 | 0.800 | 17.400 |
| remove | tail | 0 | down | 5,000 | 250,794 | A | 10,000 | 826,932 | 1.209 | 0.700 | 17.400 |
| remove | tail | 0 | down | 1,000 | 51,447 | A | 12,000 | 841,243 | 1.189 | 0.600 | 17.400 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 846,608 | 1.181 | 0.600 | 22.200 |
| replace | head | 0 | up | 1,000 | 51,204 | A | 1,000 | 461,382 | 2.167 | 1.200 | 67.100 |
| replace | head | 0 | up | 5,000 | 250,037 | A | 5,000 | 528,737 | 1.891 | 1.100 | 178.800 |
| replace | head | 0 | up | 10,000 | 506,154 | A | 10,000 | 522,646 | 1.913 | 1.100 | 273.500 |
| replace | head | 0 | up | 15,000 | 762,134 | A | 15,000 | 256,561 | 3.898 | 1.000 | 30561.800 |
| replace | head | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 288,982 | 3.460 | 1.000 | 30561.800 |
| replace | head | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 300,762 | 3.325 | 1.000 | 30561.800 |
| replace | head | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 322,841 | 3.098 | 1.000 | 30561.800 |
| replace | head | 0 | down | 15,000 | 759,633 | A | 35,000 | 341,559 | 2.928 | 1.000 | 30561.800 |
| replace | head | 0 | down | 10,000 | 507,941 | A | 40,000 | 355,819 | 2.810 | 1.000 | 30561.800 |
| replace | head | 0 | down | 5,000 | 250,794 | A | 45,000 | 367,686 | 2.720 | 1.000 | 30561.800 |
| replace | head | 0 | down | 1,000 | 51,447 | A | 49,000 | 378,671 | 2.641 | 1.000 | 30561.800 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 381,875 | 2.619 | 0.900 | 30561.800 |
| replace | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 423,585 | 2.361 | 1.100 | 57.800 |
| replace | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 376,756 | 2.654 | 1.100 | 628.000 |
| replace | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 358,041 | 2.793 | 1.100 | 628.000 |
| replace | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 358,370 | 2.790 | 1.100 | 982.000 |
| replace | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 308,359 | 3.243 | 1.100 | 5875.100 |
| replace | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 297,673 | 3.359 | 1.100 | 5875.100 |
| replace | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 308,809 | 3.238 | 1.100 | 5875.100 |
| replace | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 317,564 | 3.149 | 1.100 | 5875.100 |
| replace | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 323,592 | 3.090 | 1.100 | 5875.100 |
| replace | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 327,963 | 3.049 | 1.100 | 5875.100 |
| replace | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 336,393 | 2.973 | 1.000 | 5875.100 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 339,894 | 2.942 | 0.900 | 5875.100 |
| replace | tail | 0 | up | 1,000 | 51,204 | A | 1,000 | 494,707 | 2.021 | 1.000 | 114.200 |
| replace | tail | 0 | up | 5,000 | 250,037 | A | 5,000 | 525,133 | 1.904 | 1.000 | 176.200 |
| replace | tail | 0 | up | 10,000 | 506,154 | A | 10,000 | 490,237 | 2.040 | 1.000 | 1447.100 |
| replace | tail | 0 | up | 15,000 | 762,134 | A | 15,000 | 524,421 | 1.907 | 1.000 | 1447.100 |
| replace | tail | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 503,511 | 1.986 | 1.000 | 1447.100 |
| replace | tail | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 470,961 | 2.123 | 1.000 | 1447.100 |
| replace | tail | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 132,977 | 7.520 | 1.000 | 1447.100 |
| replace | tail | 0 | down | 15,000 | 759,633 | A | 35,000 | 101,778 | 9.825 | 1.000 | 1447.100 |
| replace | tail | 0 | down | 10,000 | 507,941 | A | 40,000 | 102,364 | 9.769 | 1.000 | 1447.100 |
| replace | tail | 0 | down | 5,000 | 250,794 | A | 45,000 | 98,529 | 10.149 | 1.000 | 1447.100 |
| replace | tail | 0 | down | 1,000 | 51,447 | A | 49,000 | 101,746 | 9.828 | 0.900 | 1447.100 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 103,323 | 9.678 | 0.900 | 1447.100 |
| value | head | 0 | up | 1,000 | 51,204 | A | 1,000 | 1,599,232 | 0.625 | 0.100 | 251.200 |
| value | head | 0 | up | 5,000 | 250,037 | A | 5,000 | 2,683,699 | 0.373 | 0.100 | 251.200 |
| value | head | 0 | up | 10,000 | 506,154 | A | 10,000 | 2,859,185 | 0.350 | 0.100 | 251.200 |
| value | head | 0 | up | 15,000 | 762,134 | A | 15,000 | 3,028,957 | 0.330 | 0.100 | 251.200 |
| value | head | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 2,956,437 | 0.338 | 0.100 | 251.200 |
| value | head | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 2,698,589 | 0.371 | 0.100 | 251.200 |
| value | head | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 2,602,021 | 0.384 | 0.100 | 251.200 |
| value | head | 0 | down | 15,000 | 759,633 | A | 35,000 | 2,582,645 | 0.387 | 0.100 | 251.200 |
| value | head | 0 | down | 10,000 | 507,941 | A | 40,000 | 2,549,248 | 0.392 | 0.100 | 251.200 |
| value | head | 0 | down | 5,000 | 250,794 | A | 45,000 | 2,519,413 | 0.397 | 0.100 | 251.200 |
| value | head | 0 | down | 1,000 | 51,447 | A | 49,000 | 2,514,394 | 0.398 | 0.100 | 251.200 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,519,945 | 0.397 | 0.100 | 251.200 |
| value | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 1,359,804 | 0.735 | 0.100 | 20.600 |
| value | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 950,083 | 1.053 | 0.100 | 734.800 |
| value | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 870,815 | 1.148 | 0.100 | 734.800 |
| value | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 833,922 | 1.199 | 0.100 | 1058.200 |
| value | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 779,353 | 1.283 | 0.100 | 1058.200 |
| value | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 650,662 | 1.537 | 0.100 | 4637.000 |
| value | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 687,935 | 1.454 | 0.100 | 4637.000 |
| value | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 718,906 | 1.391 | 0.100 | 4637.000 |
| value | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 740,373 | 1.351 | 0.100 | 4637.000 |
| value | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 759,399 | 1.317 | 0.100 | 4637.000 |
| value | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 783,113 | 1.277 | 0.100 | 4637.000 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 791,516 | 1.263 | 0.100 | 4637.000 |
| value | tail | 0 | up | 1,000 | 51,204 | A | 1,000 | 5,685,048 | 0.176 | 0.100 | 5.300 |
| value | tail | 0 | up | 5,000 | 250,037 | A | 5,000 | 5,652,911 | 0.177 | 0.100 | 34.400 |
| value | tail | 0 | up | 10,000 | 506,154 | A | 10,000 | 5,787,037 | 0.173 | 0.100 | 34.400 |
| value | tail | 0 | up | 15,000 | 762,134 | A | 15,000 | 5,961,133 | 0.168 | 0.000 | 34.400 |
| value | tail | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 6,006,908 | 0.166 | 0.000 | 34.400 |
| value | tail | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 5,836,349 | 0.171 | 0.000 | 34.400 |
| value | tail | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 5,504,587 | 0.182 | 0.000 | 34.400 |
| value | tail | 0 | down | 15,000 | 759,633 | A | 35,000 | 5,221,776 | 0.192 | 0.000 | 50.100 |
| value | tail | 0 | down | 10,000 | 507,941 | A | 40,000 | 5,067,782 | 0.197 | 0.000 | 50.100 |
| value | tail | 0 | down | 5,000 | 250,794 | A | 45,000 | 4,880,112 | 0.205 | 0.000 | 65.400 |
| value | tail | 0 | down | 1,000 | 51,447 | A | 49,000 | 4,862,751 | 0.206 | 0.000 | 65.400 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 4,847,028 | 0.206 | 0.000 | 65.400 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,602 | 384.300 |
| create | — | 0 | up | 5,000 | A | 1 | 1,060 | 943.100 |
| create | — | 0 | up | 10,000 | A | 1 | 639 | 1565.200 |
| create | — | 0 | up | 15,000 | A | 1 | 416 | 2401.100 |
| create | — | 0 | up | 20,000 | A | 1 | 275 | 3630.900 |
| create | — | 0 | up | 25,000 | A | 1 | 256 | 3907.300 |
| create | — | 0 | down | 20,000 | A | 1 | 289 | 3465.300 |
| create | — | 0 | down | 15,000 | A | 1 | 383 | 2607.600 |
| create | — | 0 | down | 10,000 | A | 1 | 517 | 1934.100 |
| create | — | 0 | down | 5,000 | A | 1 | 1,238 | 808.000 |
| create | — | 0 | down | 1,000 | A | 1 | 7,153 | 139.800 |
| create | — | 0 | down | 0 | A | 1 | 80,645 | 12.400 |
| sequence | — | 0 | up | 1,000 | A | 1 | 371 | 2692.800 |
| sequence | — | 0 | up | 5,000 | A | 1 | 131 | 7643.100 |
| sequence | — | 0 | up | 10,000 | A | 1 | 83 | 12027.200 |
| sequence | — | 0 | up | 15,000 | A | 1 | 71 | 14036.800 |
| sequence | — | 0 | up | 20,000 | A | 1 | 44 | 22630.600 |
| sequence | — | 0 | up | 25,000 | A | 1 | 46 | 21974.600 |
| sequence | — | 0 | down | 20,000 | A | 1 | 56 | 17973.100 |
| sequence | — | 0 | down | 15,000 | A | 1 | 69 | 14592.200 |
| sequence | — | 0 | down | 10,000 | A | 1 | 85 | 11749.000 |
| sequence | — | 0 | down | 5,000 | A | 1 | 101 | 9941.900 |
| sequence | — | 0 | down | 1,000 | A | 1 | 176 | 5667.500 |
| sequence | — | 0 | down | 0 | A | 1 | 807 | 1239.200 |
| values | — | 0 | up | 1,000 | A | 1 | 538 | 1857.800 |
| values | — | 0 | up | 5,000 | A | 1 | 214 | 4666.200 |
| values | — | 0 | up | 10,000 | A | 1 | 168 | 5944.100 |
| values | — | 0 | up | 15,000 | A | 1 | 134 | 7440.300 |
| values | — | 0 | up | 20,000 | A | 1 | 96 | 10382.900 |
| values | — | 0 | up | 25,000 | A | 1 | 80 | 12540.700 |
| values | — | 0 | down | 20,000 | A | 1 | 109 | 9209.300 |
| values | — | 0 | down | 15,000 | A | 1 | 150 | 6673.900 |
| values | — | 0 | down | 10,000 | A | 1 | 224 | 4468.500 |
| values | — | 0 | down | 5,000 | A | 1 | 417 | 2398.200 |
| values | — | 0 | down | 1,000 | A | 1 | 1,606 | 622.600 |
| values | — | 0 | down | 0 | A | 1 | 112,360 | 8.900 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.622 | 0.232 | 0.391 |
| 0 | up | 5000 | 3.076 | 1.168 | 1.908 |
| 0 | up | 10000 | 6.205 | 2.343 | 3.862 |
| 0 | up | 15000 | 9.457 | 3.643 | 5.815 |
| 0 | up | 20000 | 12.841 | 5.112 | 7.728 |
| 0 | up | 25000 | 16.247 | 6.636 | 9.611 |
| 0 | down | 20000 | 13.315 | 5.612 | 7.703 |
| 0 | down | 15000 | 9.926 | 4.131 | 5.796 |
| 0 | down | 10000 | 7.170 | 3.295 | 3.875 |
| 0 | down | 5000 | 4.075 | 2.161 | 1.913 |
| 0 | down | 1000 | 1.812 | 1.420 | 0.393 |
| 0 | down | 0 | 1.230 | 1.230 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 51,204 | 0.411 | 430.756 | 8.413 | 114.805 | 15.543 |
| 0 | up | A | 5,000 | 5,000 | 250,037 | 2.010 | 421.606 | 8.431 | 147.898 | 19.574 |
| 0 | up | A | 10,000 | 10,000 | 506,154 | 4.075 | 427.300 | 8.442 | 190.141 | 24.488 |
| 0 | up | A | 15,000 | 15,000 | 762,134 | 6.154 | 430.176 | 8.467 | 203.047 | 29.387 |
| 0 | up | A | 20,000 | 20,000 | 1,012,964 | 8.198 | 429.835 | 8.487 | 273.742 | 34.212 |
| 0 | up | A | 25,000 | 25,000 | 1,259,727 | 10.214 | 428.405 | 8.502 | 287.887 | 38.942 |
| 0 | down | A | 20,000 | 20,000 | 1,009,630 | 8.241 | 432.089 | 8.559 | 291.637 | 34.188 |
| 0 | down | A | 15,000 | 15,000 | 759,633 | 6.201 | 433.508 | 8.560 | 296.332 | 29.423 |
| 0 | down | A | 10,000 | 10,000 | 507,941 | 4.136 | 433.718 | 8.539 | 294.777 | 24.651 |
| 0 | down | A | 5,000 | 5,000 | 250,794 | 2.034 | 426.570 | 8.504 | 293.035 | 19.796 |
| 0 | down | A | 1,000 | 1,000 | 51,447 | 0.415 | 434.772 | 8.451 | 291.727 | 15.997 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 292.883 | 14.906 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 51204 | 187497 | 187.497 | 3.662 | 277.53 | 14.54 | 165.41 | 12.36 |
| 0 | up | A | 5000 | 250037 | 1195941 | 239.188 | 4.783 | 1610.38 | 73.38 | 813.25 | 61.61 |
| 0 | up | A | 10000 | 506154 | 2435808 | 243.581 | 4.812 | 3265.74 | 148.71 | 1649.99 | 124.72 |
| 0 | up | A | 15000 | 762134 | 3716482 | 247.765 | 4.876 | 4950.79 | 226.25 | 3565.22 | 200.28 |
| 0 | up | A | 20000 | 1012964 | 4982573 | 249.129 | 4.919 | 7121.78 | 311.32 | 5144.59 | 263.55 |
| 0 | up | A | 25000 | 1259727 | 6238033 | 249.521 | 4.952 | 9237.87 | 392.58 | 6535.88 | 334.89 |
| 0 | down | A | 20000 | 1009630 | 5113545 | 255.677 | 5.065 | 7558.03 | 326.74 | 5304.48 | 278.22 |
| 0 | down | A | 15000 | 759633 | 3843527 | 256.235 | 5.060 | 5727.79 | 247.31 | 4004.31 | 209.86 |
| 0 | down | A | 10000 | 507941 | 2547329 | 254.733 | 5.015 | 3837.94 | 164.83 | 2677.99 | 139.88 |
| 0 | down | A | 5000 | 250794 | 1235293 | 247.059 | 4.926 | 1887.01 | 79.61 | 1318.78 | 67.84 |
| 0 | down | A | 1000 | 51447 | 243384 | 243.384 | 4.731 | 382.91 | 15.90 | 268.58 | 13.64 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 428.569 | 8.477 | 246.794 | 4.882 |
| 0 | A | scaleDown | 432.337 | 8.548 | 254.570 | 5.033 |
| 0 | A | fullLifecycle | 430.082 | 8.506 | 249.917 | 4.943 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
