# Large string benchmarks

2026-11-27T17:04:20.117Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2265.43 | 0.00 |
| 1024 | insert.append | array | 13416.85 | 0.00 |
| 1024 | replace | array | 3447.97 | 0.00 |
| 1024 | remove | array | 1047.60 | 0.00 |
| 1024 | remove.middle | array | 2010.67 | 0.00 |
| 1024 | replace.middle | array | 2322.18 | 0.00 |
| 1024 | apply | array | 830.51 | 0.00 |
| 1024 | apply.array | array | 641.54 | 0.00 |
| 1024 | concurrent.apply | array | 68607.95 | 0.00 |
| 1024 | merge | array | 2911.54 | 0.00 |
| 1024 | create | array | 3164.18 | 0.00 |
| 1024 | value.random | array | 76.53 | 0.00 |
| 1024 | values.range | array | 138.09 | 0.00 |
| 1024 | values.array | array | 1474.14 | 0.00 |
| 1024 | values.text | array | 14426.30 | 0.00 |
| 1024 | sequence.array | array | 1718.26 | 0.00 |
| 1024 | sequence.text | array | 10004.56 | 0.00 |
| 1024 | sequence.edited.text | array | 14695.24 | 0.00 |
| 1024 | sequence.masked.text | array | 11141.76 | 0.00 |
| 1024 | insert | string | 434.14 | 0.00 |
| 1024 | insert.append | string | 4517.96 | 0.00 |
| 1024 | replace | string | 1170.00 | 0.00 |
| 1024 | remove | string | 1044.79 | 0.00 |
| 1024 | remove.middle | string | 1024.78 | 0.00 |
| 1024 | replace.middle | string | 1306.87 | 0.00 |
| 1024 | apply | string | 791.26 | 0.00 |
| 1024 | apply.array | string | 2436.30 | 0.00 |
| 1024 | concurrent.apply | string | 3561.62 | 0.00 |
| 1024 | merge | string | 1435.14 | 0.00 |
| 1024 | create | string | 987.94 | 0.00 |
| 1024 | value.random | string | 87.47 | 0.00 |
| 1024 | values.range | string | 160.89 | 0.00 |
| 1024 | values.array | string | 1879.43 | 0.00 |
| 1024 | values.text | string | 73.88 | 0.00 |
| 1024 | sequence.array | string | 2077.79 | 0.00 |
| 1024 | sequence.text | string | 185.31 | 0.00 |
| 1024 | sequence.edited.text | string | 2921.64 | 0.00 |
| 1024 | sequence.masked.text | string | 5316.51 | 0.00 |
| 65536 | insert | array | 286355.32 | 0.00 |
| 65536 | insert.append | array | 1092978.26 | 0.00 |
| 65536 | replace | array | 276516.48 | 0.00 |
| 65536 | remove | array | 2380.05 | 0.00 |
| 65536 | remove.middle | array | 228064.55 | 0.00 |
| 65536 | replace.middle | array | 239456.88 | 0.00 |
| 65536 | apply | array | 825.84 | 0.00 |
| 65536 | apply.array | array | 589.26 | 0.00 |
| 65536 | concurrent.apply | array | 4103671.43 | 0.00 |
| 65536 | merge | array | 221555.75 | 0.00 |
| 65536 | create | array | 212044.07 | 0.00 |
| 65536 | value.random | array | 60.68 | 0.00 |
| 65536 | values.range | array | 135.12 | 0.00 |
| 65536 | values.array | array | 216639.68 | 0.00 |
| 65536 | values.text | array | 802003.12 | 0.00 |
| 65536 | sequence.array | array | 204043.65 | 0.00 |
| 65536 | sequence.text | array | 743838.24 | 0.00 |
| 65536 | sequence.edited.text | array | 914500.00 | 0.00 |
| 65536 | sequence.masked.text | array | 783753.12 | 0.00 |
| 65536 | insert | string | 467.86 | 0.00 |
| 65536 | insert.append | string | 23797.62 | 0.00 |
| 65536 | replace | string | 1355.54 | 0.00 |
| 65536 | remove | string | 1022.60 | 0.00 |
| 65536 | remove.middle | string | 985.57 | 0.00 |
| 65536 | replace.middle | string | 1294.93 | 0.00 |
| 65536 | apply | string | 867.25 | 0.00 |
| 65536 | apply.array | string | 259408.59 | 0.00 |
| 65536 | concurrent.apply | string | 137095.08 | 0.00 |
| 65536 | merge | string | 1092.88 | 0.00 |
| 65536 | create | string | 926.71 | 0.00 |
| 65536 | value.random | string | 50.29 | 0.00 |
| 65536 | values.range | string | 155.50 | 0.00 |
| 65536 | values.array | string | 227972.73 | 0.00 |
| 65536 | values.text | string | 87.12 | 0.00 |
| 65536 | sequence.array | string | 270273.44 | 0.00 |
| 65536 | sequence.text | string | 200.78 | 0.00 |
| 65536 | sequence.edited.text | string | 92872.96 | 0.00 |
| 65536 | sequence.masked.text | string | 3485.17 | 0.00 |
| 1048576 | insert | array | 3216550.00 | 0.00 |
| 1048576 | insert.append | array | 24219100.00 | 0.00 |
| 1048576 | replace | array | 3153087.50 | 0.00 |
| 1048576 | remove | array | 11117.91 | 0.00 |
| 1048576 | remove.middle | array | 3192033.33 | 0.00 |
| 1048576 | replace.middle | array | 2546310.00 | 0.00 |
| 1048576 | apply | array | 1467.76 | 0.00 |
| 1048576 | apply.array | array | 681.08 | 0.00 |
| 1048576 | concurrent.apply | array | 66710700.00 | 0.00 |
| 1048576 | merge | array | 3521550.00 | 0.00 |
| 1048576 | create | array | 4322650.00 | 0.00 |
| 1048576 | value.random | array | 49.76 | 0.00 |
| 1048576 | values.range | array | 123.01 | 0.00 |
| 1048576 | values.array | array | 2303318.18 | 0.00 |
| 1048576 | values.text | array | 12713150.00 | 0.00 |
| 1048576 | sequence.array | array | 2277063.64 | 0.00 |
| 1048576 | sequence.text | array | 46357050.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 30286900.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 44776050.00 | 0.00 |
| 1048576 | insert | string | 515.19 | 0.00 |
| 1048576 | insert.append | string | 501532.00 | 0.00 |
| 1048576 | replace | string | 1439.81 | 0.00 |
| 1048576 | remove | string | 989.92 | 0.00 |
| 1048576 | remove.middle | string | 950.76 | 0.00 |
| 1048576 | replace.middle | string | 1396.33 | 0.00 |
| 1048576 | apply | string | 1075.37 | 0.00 |
| 1048576 | apply.array | string | 3394937.50 | 0.00 |
| 1048576 | concurrent.apply | string | 1052537.50 | 0.00 |
| 1048576 | merge | string | 1166.22 | 0.00 |
| 1048576 | create | string | 967.50 | 0.00 |
| 1048576 | value.random | string | 42.95 | 0.00 |
| 1048576 | values.range | string | 150.30 | 0.00 |
| 1048576 | values.array | string | 2997033.33 | 0.00 |
| 1048576 | values.text | string | 56.95 | 0.00 |
| 1048576 | sequence.array | string | 3000633.33 | 0.00 |
| 1048576 | sequence.text | string | 195.76 | 0.00 |
| 1048576 | sequence.edited.text | string | 1658450.00 | 0.00 |
| 1048576 | sequence.masked.text | string | 3261.11 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
