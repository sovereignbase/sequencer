# Tuple benchmarks

2026-11-27T17:04:05.620Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 2,643,800 | 2,382,637 | 0.90× |
| 2 | create.sequence | 909,075 | 782,645 | 0.86× |
| 2 | replace.random | 1,186,036 | 1,228,633 | 1.04× |
| 2 | apply.replace | 591,341 | 847,540 | 1.43× |
| 2 | apply.duplicate | 1,673,212 | 1,653,191 | 0.99× |
| 2 | merge.duplicate | 1,534,152 | 1,545,314 | 1.01× |
| 2 | length | 131,025,355 | 135,281,331 | 1.03× |
| 2 | value.random | 34,577,059 | 53,968,707 | 1.56× |
| 2 | values | 12,174,694 | 12,183,516 | 1.00× |
| 2 | sequence | 3,146,456 | 2,326,525 | 0.74× |
| 4 | create.empty | 2,461,538 | 2,186,253 | 0.89× |
| 4 | create.sequence | 683,019 | 741,392 | 1.09× |
| 4 | replace.random | 1,031,364 | 1,335,656 | 1.30× |
| 4 | apply.replace | 612,942 | 941,889 | 1.54× |
| 4 | apply.duplicate | 1,765,023 | 1,706,894 | 0.97× |
| 4 | merge.duplicate | 1,319,493 | 1,222,417 | 0.93× |
| 4 | length | 38,847,582 | 37,561,182 | 0.97× |
| 4 | value.random | 24,909,539 | 56,503,083 | 2.27× |
| 4 | values | 6,932,461 | 6,003,545 | 0.87× |
| 4 | sequence | 2,454,591 | 2,537,313 | 1.03× |
| 8 | create.empty | 2,574,589 | 2,404,515 | 0.93× |
| 8 | create.sequence | 439,589 | 529,439 | 1.20× |
| 8 | replace.random | 964,294 | 1,333,673 | 1.38× |
| 8 | apply.replace | 592,297 | 936,457 | 1.58× |
| 8 | apply.duplicate | 1,588,490 | 1,615,910 | 1.02× |
| 8 | merge.duplicate | 910,300 | 873,874 | 0.96× |
| 8 | length | 35,189,408 | 37,711,760 | 1.07× |
| 8 | value.random | 18,170,591 | 57,139,936 | 3.14× |
| 8 | values | 4,763,457 | 4,907,466 | 1.03× |
| 8 | sequence | 1,687,170 | 2,019,987 | 1.20× |
| 100 | create.empty | 2,348,614 | 2,195,672 | 0.93× |
| 100 | create.sequence | 67,894 | 87,731 | 1.29× |
| 100 | replace.random | 1,010,257 | 1,541,707 | 1.53× |
| 100 | apply.replace | 622,460 | 1,062,709 | 1.71× |
| 100 | apply.duplicate | 1,613,259 | 1,564,807 | 0.97× |
| 100 | merge.duplicate | 98,439 | 74,990 | 0.76× |
| 100 | length | 38,556,788 | 38,047,687 | 0.99× |
| 100 | value.random | 11,451,157 | 54,806,461 | 4.79× |
| 100 | values | 545,132 | 676,406 | 1.24× |
| 100 | sequence | 184,686 | 185,098 | 1.00× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
