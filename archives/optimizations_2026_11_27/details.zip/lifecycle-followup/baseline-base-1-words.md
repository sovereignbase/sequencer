# Words benchmarks

2026-11-27T17:04:42.071Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 32,013 | 147,523 | 154 |
| append | packed | 5.90 | 3.61 | 13.98 | 28,749 | 161,854 | 266 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,720 | 593 | 199 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 28,512 | 1,656 | 238 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 467 | 194 | 86 |
| random | packed | 49.58 | 35.38 | 23.45 | 14,337 | 434 | 96 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 597 | 214 | 96 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 15,382 | 405 | 136 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 785.79 | 0.00 |
| append | numeric | encode | 31237.41 | 0.00 |
| append | numeric | decode | 3361.07 | 0.00 |
| append | numeric | create | 1971.94 | 0.00 |
| append | numeric | load | 6778.62 | 0.00 |
| append | numeric | apply | 3650414.29 | 0.00 |
| append | numeric | receive | 6498475.00 | 0.00 |
| append | binary | sequence | 516.95 | 0.00 |
| append | binary | encode | 34783.38 | 0.00 |
| append | binary | decode | 2204.99 | 0.00 |
| append | binary | create | 2145.28 | 0.00 |
| append | binary | load | 6178.41 | 0.00 |
| append | binary | apply | 1824985.71 | 0.00 |
| append | binary | receive | 3756221.43 | 0.00 |
| prepend | numeric | sequence | 521381.44 | 0.00 |
| prepend | numeric | encode | 581456.98 | 0.00 |
| prepend | numeric | decode | 185023.62 | 0.00 |
| prepend | numeric | create | 619392.59 | 0.00 |
| prepend | numeric | load | 1686620.00 | 0.00 |
| prepend | numeric | apply | 2701731.58 | 0.00 |
| prepend | numeric | receive | 5024470.00 | 0.00 |
| prepend | binary | sequence | 390484.50 | 0.00 |
| prepend | binary | encode | 35073.28 | 0.00 |
| prepend | binary | decode | 1990.76 | 0.00 |
| prepend | binary | create | 606567.47 | 0.00 |
| prepend | binary | load | 603814.46 | 0.00 |
| prepend | binary | apply | 2465838.10 | 0.00 |
| prepend | binary | receive | 4197016.67 | 0.00 |
| random | numeric | sequence | 936303.70 | 0.00 |
| random | numeric | encode | 2143233.33 | 0.00 |
| random | numeric | decode | 783910.94 | 0.00 |
| random | numeric | create | 1908066.67 | 0.00 |
| random | numeric | load | 5166900.00 | 0.00 |
| random | numeric | apply | 7813128.57 | 0.00 |
| random | numeric | receive | 11692780.00 | 0.00 |
| random | binary | sequence | 882371.93 | 0.00 |
| random | binary | encode | 69750.35 | 0.00 |
| random | binary | decode | 1612.60 | 0.00 |
| random | binary | create | 2107562.50 | 0.00 |
| random | binary | load | 2302309.09 | 0.00 |
| random | binary | apply | 6790287.50 | 0.00 |
| random | binary | receive | 10376500.00 | 0.00 |
| concurrent | numeric | sequence | 867684.48 | 0.00 |
| concurrent | numeric | encode | 1675006.67 | 0.00 |
| concurrent | numeric | decode | 759719.70 | 0.00 |
| concurrent | numeric | create | 2390261.90 | 0.00 |
| concurrent | numeric | load | 4678990.91 | 0.00 |
| concurrent | numeric | apply | 7494871.43 | 0.00 |
| concurrent | numeric | receive | 10459440.00 | 0.00 |
| concurrent | binary | sequence | 756598.51 | 0.00 |
| concurrent | binary | encode | 65009.09 | 0.00 |
| concurrent | binary | decode | 3748.86 | 0.00 |
| concurrent | binary | create | 2549815.00 | 0.00 |
| concurrent | binary | load | 2470614.29 | 0.00 |
| concurrent | binary | apply | 5247520.00 | 0.00 |
| concurrent | binary | receive | 7370871.43 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
