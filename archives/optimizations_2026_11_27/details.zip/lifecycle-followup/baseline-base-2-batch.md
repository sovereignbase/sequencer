# Batch benchmarks

2026-11-27T17:06:33.148Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 1,301,575 | 1,156,939 | 569,503 | 76.05 | 5.99 | 0.012 |
| append | batch | 2,769,316 | 254,237,288 | 229,885,057 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,641,228 | 1,567,439 | 827,803 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 1,998,867 | 2,150,461 | 2,063,345 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 785,330 | 932,300 | 915,485 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 1,127,968 | 1,609,960 | 1,526,601 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 1,003,999 | 1,072,942 | 853,692 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 1,144,208 | 1,691,237 | 1,637,421 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,230,618 | 1,136,041 | 802,107 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,293,759 | 1,714,359 | 1,523,771 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,344,342 | 1,337,271 | 886,774 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,279,986 | 1,684,329 | 1,608,019 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 687,860 | 993,863 | 709,463 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 955,985 | 1,265,703 | 1,187,566 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,124,680 | 1,309,858 | 960,553 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 1,237,790 | 1,702,973 | 1,652,619 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,214,317 | 1,303,498 | 914,676 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 1,293,842 | 1,628,620 | 1,555,613 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 752,035 | 991,539 | 719,908 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 912,152 | 1,145,771 | 1,259,552 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 4.610 | 0.000 |
| append | individual | apply | 5.186 | 0.000 |
| append | individual | receive | 10.536 | 0.000 |
| append | individual | encode | 7.367 | 0.000 |
| append | individual | decode | 6.334 | 0.000 |
| append | batch | author | 2.167 | 0.000 |
| append | batch | apply | 0.024 | 0.000 |
| append | batch | receive | 0.026 | 0.000 |
| append | batch | encode | 0.198 | 0.000 |
| append | batch | decode | 0.090 | 0.000 |
| prepend | individual | author | 3.656 | 0.000 |
| prepend | individual | apply | 3.828 | 0.000 |
| prepend | individual | receive | 7.248 | 0.000 |
| prepend | individual | encode | 5.476 | 0.000 |
| prepend | individual | decode | 7.937 | 0.000 |
| prepend | batch | author | 3.002 | 0.000 |
| prepend | batch | apply | 2.790 | 0.000 |
| prepend | batch | receive | 2.908 | 0.000 |
| prepend | batch | encode | 0.179 | 0.000 |
| prepend | batch | decode | 0.103 | 0.000 |
| random.characters | individual | author | 7.640 | 0.000 |
| random.characters | individual | apply | 6.436 | 0.000 |
| random.characters | individual | receive | 6.554 | 0.000 |
| random.characters | individual | encode | 6.538 | 0.000 |
| random.characters | individual | decode | 8.003 | 0.000 |
| random.characters | batch | author | 5.319 | 0.000 |
| random.characters | batch | apply | 3.727 | 0.000 |
| random.characters | batch | receive | 3.930 | 0.000 |
| random.characters | batch | encode | 0.204 | 0.000 |
| random.characters | batch | decode | 0.100 | 0.000 |
| random.words | individual | author | 5.976 | 0.000 |
| random.words | individual | apply | 5.592 | 0.000 |
| random.words | individual | receive | 7.028 | 0.000 |
| random.words | individual | encode | 3.918 | 0.000 |
| random.words | individual | decode | 7.057 | 0.000 |
| random.words | batch | author | 5.244 | 0.000 |
| random.words | batch | apply | 3.548 | 0.000 |
| random.words | batch | receive | 3.664 | 0.000 |
| random.words | batch | encode | 0.359 | 0.000 |
| random.words | batch | decode | 0.109 | 0.000 |
| concurrent.characters | individual | author | 9.751 | 0.000 |
| concurrent.characters | individual | apply | 10.563 | 0.000 |
| concurrent.characters | individual | receive | 14.961 | 0.000 |
| concurrent.characters | individual | encode | 8.275 | 0.000 |
| concurrent.characters | individual | decode | 11.365 | 0.000 |
| concurrent.characters | batch | author | 9.275 | 0.000 |
| concurrent.characters | batch | apply | 7.000 | 0.000 |
| concurrent.characters | batch | receive | 7.875 | 0.000 |
| concurrent.characters | batch | encode | 0.332 | 0.000 |
| concurrent.characters | batch | decode | 0.116 | 0.000 |
| concurrent.words | individual | author | 8.926 | 0.000 |
| concurrent.words | individual | apply | 8.974 | 0.000 |
| concurrent.words | individual | receive | 13.532 | 0.000 |
| concurrent.words | individual | encode | 8.890 | 0.000 |
| concurrent.words | individual | decode | 10.894 | 0.000 |
| concurrent.words | batch | author | 9.375 | 0.000 |
| concurrent.words | batch | apply | 7.125 | 0.000 |
| concurrent.words | batch | receive | 7.463 | 0.000 |
| concurrent.words | batch | encode | 0.845 | 0.000 |
| concurrent.words | batch | decode | 0.143 | 0.000 |
| concurrent.mixed | individual | author | 17.445 | 0.000 |
| concurrent.mixed | individual | apply | 12.074 | 0.000 |
| concurrent.mixed | individual | receive | 16.914 | 0.000 |
| concurrent.mixed | individual | encode | 8.107 | 0.000 |
| concurrent.mixed | individual | decode | 10.720 | 0.000 |
| concurrent.mixed | batch | author | 12.553 | 0.000 |
| concurrent.mixed | batch | apply | 9.481 | 0.000 |
| concurrent.mixed | batch | receive | 10.105 | 0.000 |
| concurrent.mixed | batch | encode | 0.847 | 0.000 |
| concurrent.mixed | batch | decode | 0.181 | 0.000 |
| causal.characters | individual | author | 10.670 | 0.000 |
| causal.characters | individual | apply | 9.161 | 0.000 |
| causal.characters | individual | receive | 12.493 | 0.000 |
| causal.characters | individual | encode | 8.523 | 0.000 |
| causal.characters | individual | decode | 10.162 | 0.000 |
| causal.characters | batch | author | 9.695 | 0.000 |
| causal.characters | batch | apply | 7.046 | 0.000 |
| causal.characters | batch | receive | 7.261 | 0.000 |
| causal.characters | batch | encode | 0.227 | 0.000 |
| causal.characters | batch | decode | 0.127 | 0.000 |
| causal.words | individual | author | 9.882 | 0.000 |
| causal.words | individual | apply | 9.206 | 0.000 |
| causal.words | individual | receive | 13.119 | 0.000 |
| causal.words | individual | encode | 8.048 | 0.000 |
| causal.words | individual | decode | 8.962 | 0.000 |
| causal.words | batch | author | 9.275 | 0.000 |
| causal.words | batch | apply | 7.368 | 0.000 |
| causal.words | batch | receive | 7.714 | 0.000 |
| causal.words | batch | encode | 0.549 | 0.000 |
| causal.words | batch | decode | 0.147 | 0.000 |
| causal.mixed | individual | author | 15.957 | 0.000 |
| causal.mixed | individual | apply | 12.102 | 0.000 |
| causal.mixed | individual | receive | 16.669 | 0.000 |
| causal.mixed | individual | encode | 9.373 | 0.000 |
| causal.mixed | individual | decode | 10.006 | 0.000 |
| causal.mixed | batch | author | 13.156 | 0.000 |
| causal.mixed | batch | apply | 10.473 | 0.000 |
| causal.mixed | batch | receive | 9.527 | 0.000 |
| causal.mixed | batch | encode | 0.434 | 0.000 |
| causal.mixed | batch | decode | 0.116 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
