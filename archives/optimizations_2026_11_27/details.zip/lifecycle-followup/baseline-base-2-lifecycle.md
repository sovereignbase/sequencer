# Sequencer dynamic lifecycle benchmark

2026-11-27T17:05:00.764Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.23 | 162.89 | 56.49 |
| CommonJS | 199.41 | 164.51 | 56.69 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 311,915 | 3.206 | 3.206 | 3.206 | 0.000 | 0: 3.206 | 0: 3.206 |
| apply | random | A | scaleDown | 24,999 | 346,066 | 2.890 | 2.890 | 2.890 | 0.000 | 0: 2.890 | 0: 2.890 |
| apply | random | A | fullLifecycle | 49,999 | 328,104 | 3.048 | 3.048 | 3.048 | 0.000 | 0: 3.048 | 0: 3.048 |
| create | — | A | scaleUp | 7 | 385 | 2596.914 | 2596.914 | 2596.914 | 0.000 | 0: 2596.914 | 0: 2596.914 |
| create | — | A | scaleDown | 6 | 574 | 1742.800 | 1742.800 | 1742.800 | 0.000 | 0: 1742.800 | 0: 1742.800 |
| create | — | A | fullLifecycle | 13 | 454 | 2202.708 | 2202.708 | 2202.708 | 0.000 | 0: 2202.708 | 0: 2202.708 |
| insert | head | A | scaleUp | 12,500 | 1,275,224 | 0.784 | 0.784 | 0.784 | 0.000 | 0: 0.784 | 0: 0.784 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,275,224 | 0.784 | 0.784 | 0.784 | 0.000 | 0: 0.784 | 0: 0.784 |
| insert | random | A | scaleUp | 25,000 | 586,481 | 1.705 | 1.705 | 1.705 | 0.000 | 0: 1.705 | 0: 1.705 |
| insert | random | A | scaleDown | 25,000 | 618,418 | 1.617 | 1.617 | 1.617 | 0.000 | 0: 1.617 | 0: 1.617 |
| insert | random | A | fullLifecycle | 50,000 | 602,027 | 1.661 | 1.661 | 1.661 | 0.000 | 0: 1.661 | 0: 1.661 |
| insert | tail | A | scaleUp | 12,500 | 1,461,305 | 0.684 | 0.684 | 0.684 | 0.000 | 0: 0.684 | 0: 0.684 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,461,305 | 0.684 | 0.684 | 0.684 | 0.000 | 0: 0.684 | 0: 0.684 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 724,482 | 1.380 | 1.380 | 1.380 | 0.000 | 0: 1.380 | 0: 1.380 |
| remove | head | A | fullLifecycle | 12,500 | 724,482 | 1.380 | 1.380 | 1.380 | 0.000 | 0: 1.380 | 0: 1.380 |
| remove | random | A | scaleUp | 25,000 | 501,737 | 1.993 | 1.993 | 1.993 | 0.000 | 0: 1.993 | 0: 1.993 |
| remove | random | A | scaleDown | 25,000 | 520,001 | 1.923 | 1.923 | 1.923 | 0.000 | 0: 1.923 | 0: 1.923 |
| remove | random | A | fullLifecycle | 50,000 | 510,706 | 1.958 | 1.958 | 1.958 | 0.000 | 0: 1.958 | 0: 1.958 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 798,834 | 1.252 | 1.252 | 1.252 | 0.000 | 0: 1.252 | 0: 1.252 |
| remove | tail | A | fullLifecycle | 12,500 | 798,834 | 1.252 | 1.252 | 1.252 | 0.000 | 0: 1.252 | 0: 1.252 |
| replace | head | A | scaleUp | 25,000 | 513,852 | 1.946 | 1.946 | 1.946 | 0.000 | 0: 1.946 | 0: 1.946 |
| replace | head | A | scaleDown | 25,000 | 511,761 | 1.954 | 1.954 | 1.954 | 0.000 | 0: 1.954 | 0: 1.954 |
| replace | head | A | fullLifecycle | 50,000 | 512,805 | 1.950 | 1.950 | 1.950 | 0.000 | 0: 1.950 | 0: 1.950 |
| replace | random | A | scaleUp | 25,000 | 338,241 | 2.956 | 2.956 | 2.956 | 0.000 | 0: 2.956 | 0: 2.956 |
| replace | random | A | scaleDown | 25,000 | 383,008 | 2.611 | 2.611 | 2.611 | 0.000 | 0: 2.611 | 0: 2.611 |
| replace | random | A | fullLifecycle | 50,000 | 359,235 | 2.784 | 2.784 | 2.784 | 0.000 | 0: 2.784 | 0: 2.784 |
| replace | tail | A | scaleUp | 25,000 | 537,900 | 1.859 | 1.859 | 1.859 | 0.000 | 0: 1.859 | 0: 1.859 |
| replace | tail | A | scaleDown | 25,000 | 53,506 | 18.689 | 18.689 | 18.689 | 0.000 | 0: 18.689 | 0: 18.689 |
| replace | tail | A | fullLifecycle | 50,000 | 97,331 | 10.274 | 10.274 | 10.274 | 0.000 | 0: 10.274 | 0: 10.274 |
| sequence | — | A | scaleUp | 6 | 55 | 18039.617 | 18039.617 | 18039.617 | 0.000 | 0: 18039.617 | 0: 18039.617 |
| sequence | — | A | scaleDown | 6 | 93 | 10761.900 | 10761.900 | 10761.900 | 0.000 | 0: 10761.900 | 0: 10761.900 |
| sequence | — | A | fullLifecycle | 12 | 69 | 14400.758 | 14400.758 | 14400.758 | 0.000 | 0: 14400.758 | 0: 14400.758 |
| value | head | A | scaleUp | 25,000 | 3,106,323 | 0.322 | 0.322 | 0.322 | 0.000 | 0: 0.322 | 0: 0.322 |
| value | head | A | scaleDown | 25,000 | 2,466,262 | 0.405 | 0.405 | 0.405 | 0.000 | 0: 0.405 | 0: 0.405 |
| value | head | A | fullLifecycle | 50,000 | 2,749,534 | 0.364 | 0.364 | 0.364 | 0.000 | 0: 0.364 | 0: 0.364 |
| value | random | A | scaleUp | 25,000 | 866,440 | 1.154 | 1.154 | 1.154 | 0.000 | 0: 1.154 | 0: 1.154 |
| value | random | A | scaleDown | 25,000 | 978,933 | 1.022 | 1.022 | 1.022 | 0.000 | 0: 1.022 | 0: 1.022 |
| value | random | A | fullLifecycle | 50,000 | 919,258 | 1.088 | 1.088 | 1.088 | 0.000 | 0: 1.088 | 0: 1.088 |
| value | tail | A | scaleUp | 25,000 | 6,582,585 | 0.152 | 0.152 | 0.152 | 0.000 | 0: 0.152 | 0: 0.152 |
| value | tail | A | scaleDown | 25,000 | 4,381,199 | 0.228 | 0.228 | 0.228 | 0.000 | 0: 0.228 | 0: 0.228 |
| value | tail | A | fullLifecycle | 50,000 | 5,260,887 | 0.190 | 0.190 | 0.190 | 0.000 | 0: 0.190 | 0: 0.190 |
| values | — | A | scaleUp | 6 | 77 | 13062.000 | 13062.000 | 13062.000 | 0.000 | 0: 13062.000 | 0: 13062.000 |
| values | — | A | scaleDown | 6 | 242 | 4125.733 | 4125.733 | 4125.733 | 0.000 | 0: 4125.733 | 0: 4125.733 |
| values | — | A | fullLifecycle | 12 | 116 | 8593.867 | 8593.867 | 8593.867 | 0.000 | 0: 8593.867 | 0: 8593.867 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5410752.667 | 427.165 | 8.478 |
| A | scaleDown | 5 | 4407357.600 | 432.094 | 8.548 |
| A | fullLifecycle | 11 | 4954664.000 | 429.144 | 8.506 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3116296.167 | 246.023 | 4.883 |
| A | scaleDown | 5 | 2595337.600 | 254.445 | 5.034 |
| A | fullLifecycle | 11 | 2879496.818 | 249.405 | 4.944 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 251,896 | 3.970 | 1.900 | 44.700 |
| apply | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 292,660 | 3.417 | 1.800 | 103.200 |
| apply | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 308,191 | 3.245 | 1.500 | 702.500 |
| apply | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 300,575 | 3.327 | 1.500 | 2960.000 |
| apply | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 307,097 | 3.256 | 1.500 | 2960.000 |
| apply | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 311,915 | 3.206 | 1.500 | 2960.000 |
| apply | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 313,895 | 3.186 | 1.500 | 2960.000 |
| apply | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 317,768 | 3.147 | 1.500 | 2960.000 |
| apply | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 320,358 | 3.122 | 1.500 | 2960.000 |
| apply | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 322,241 | 3.103 | 1.500 | 2960.000 |
| apply | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 326,251 | 3.065 | 1.400 | 2960.000 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 328,104 | 3.048 | 1.200 | 2960.000 |
| insert | head | 0 | up | 1,000 | 50,007 | A | 500 | 935,279 | 1.069 | 0.400 | 38.000 |
| insert | head | 0 | up | 5,000 | 256,206 | A | 2,500 | 1,093,900 | 0.914 | 0.400 | 38.000 |
| insert | head | 0 | up | 10,000 | 508,328 | A | 5,000 | 1,173,131 | 0.852 | 0.300 | 213.700 |
| insert | head | 0 | up | 15,000 | 756,035 | A | 7,500 | 1,181,307 | 0.847 | 0.300 | 396.600 |
| insert | head | 0 | up | 20,000 | 1,005,850 | A | 10,000 | 1,229,392 | 0.813 | 0.300 | 396.600 |
| insert | head | 0 | up | 25,000 | 1,252,902 | A | 12,500 | 1,275,224 | 0.784 | 0.300 | 396.600 |
| insert | head | 0 | down | 20,000 | 1,007,225 | A | 12,500 | 1,275,224 | 0.784 | 0.300 | 396.600 |
| insert | head | 0 | down | 15,000 | 759,799 | A | 12,500 | 1,275,224 | 0.784 | 0.300 | 396.600 |
| insert | head | 0 | down | 10,000 | 506,363 | A | 12,500 | 1,275,224 | 0.784 | 0.300 | 396.600 |
| insert | head | 0 | down | 5,000 | 254,264 | A | 12,500 | 1,275,224 | 0.784 | 0.300 | 396.600 |
| insert | head | 0 | down | 1,000 | 50,210 | A | 12,500 | 1,275,224 | 0.784 | 0.300 | 396.600 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,275,224 | 0.784 | 0.300 | 396.600 |
| insert | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 517,679 | 1.932 | 0.400 | 347.800 |
| insert | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 525,635 | 1.902 | 0.400 | 645.900 |
| insert | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 545,497 | 1.833 | 0.400 | 924.000 |
| insert | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 578,469 | 1.729 | 0.400 | 924.000 |
| insert | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 576,809 | 1.734 | 0.400 | 924.000 |
| insert | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 586,481 | 1.705 | 0.400 | 924.000 |
| insert | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 571,880 | 1.749 | 0.400 | 924.000 |
| insert | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 573,417 | 1.744 | 0.400 | 924.000 |
| insert | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 577,974 | 1.730 | 0.400 | 924.000 |
| insert | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 584,410 | 1.711 | 0.400 | 924.000 |
| insert | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 597,190 | 1.675 | 0.400 | 924.000 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 602,027 | 1.661 | 0.400 | 924.000 |
| insert | tail | 0 | up | 1,000 | 50,007 | A | 500 | 1,099,868 | 0.909 | 0.300 | 11.200 |
| insert | tail | 0 | up | 5,000 | 256,206 | A | 2,500 | 1,212,592 | 0.825 | 0.300 | 64.600 |
| insert | tail | 0 | up | 10,000 | 508,328 | A | 5,000 | 1,375,819 | 0.727 | 0.300 | 83.500 |
| insert | tail | 0 | up | 15,000 | 756,035 | A | 7,500 | 1,434,610 | 0.697 | 0.300 | 157.300 |
| insert | tail | 0 | up | 20,000 | 1,005,850 | A | 10,000 | 1,481,043 | 0.675 | 0.300 | 157.300 |
| insert | tail | 0 | up | 25,000 | 1,252,902 | A | 12,500 | 1,461,305 | 0.684 | 0.300 | 293.500 |
| insert | tail | 0 | down | 20,000 | 1,007,225 | A | 12,500 | 1,461,305 | 0.684 | 0.300 | 293.500 |
| insert | tail | 0 | down | 15,000 | 759,799 | A | 12,500 | 1,461,305 | 0.684 | 0.300 | 293.500 |
| insert | tail | 0 | down | 10,000 | 506,363 | A | 12,500 | 1,461,305 | 0.684 | 0.300 | 293.500 |
| insert | tail | 0 | down | 5,000 | 254,264 | A | 12,500 | 1,461,305 | 0.684 | 0.300 | 293.500 |
| insert | tail | 0 | down | 1,000 | 50,210 | A | 12,500 | 1,461,305 | 0.684 | 0.300 | 293.500 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,461,305 | 0.684 | 0.300 | 293.500 |
| remove | head | 0 | up | 1,000 | 50,007 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 256,206 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 508,328 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 756,035 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,005,850 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,252,902 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,007,225 | A | 2,500 | 680,494 | 1.470 | 0.900 | 16.600 |
| remove | head | 0 | down | 15,000 | 759,799 | A | 5,000 | 702,366 | 1.424 | 0.900 | 16.600 |
| remove | head | 0 | down | 10,000 | 506,363 | A | 7,500 | 678,764 | 1.473 | 0.800 | 631.000 |
| remove | head | 0 | down | 5,000 | 254,264 | A | 10,000 | 698,553 | 1.432 | 0.800 | 631.000 |
| remove | head | 0 | down | 1,000 | 50,210 | A | 12,000 | 718,326 | 1.392 | 0.800 | 631.000 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 724,482 | 1.380 | 0.600 | 631.000 |
| remove | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 466,418 | 2.144 | 0.900 | 33.100 |
| remove | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 451,202 | 2.216 | 0.900 | 110.500 |
| remove | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 476,263 | 2.100 | 0.900 | 316.400 |
| remove | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 496,710 | 2.013 | 0.800 | 316.400 |
| remove | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 497,407 | 2.010 | 0.800 | 316.400 |
| remove | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 501,737 | 1.993 | 0.800 | 316.400 |
| remove | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 492,688 | 2.030 | 0.800 | 316.400 |
| remove | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 494,449 | 2.022 | 0.800 | 316.400 |
| remove | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 494,839 | 2.021 | 0.800 | 321.700 |
| remove | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 499,086 | 2.004 | 0.800 | 321.700 |
| remove | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 506,906 | 1.973 | 0.800 | 321.700 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 510,706 | 1.958 | 0.700 | 321.700 |
| remove | tail | 0 | up | 1,000 | 50,007 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 256,206 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 508,328 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 756,035 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,005,850 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,252,902 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,007,225 | A | 2,500 | 788,544 | 1.268 | 0.800 | 81.700 |
| remove | tail | 0 | down | 15,000 | 759,799 | A | 5,000 | 766,342 | 1.305 | 0.800 | 131.600 |
| remove | tail | 0 | down | 10,000 | 506,363 | A | 7,500 | 755,051 | 1.324 | 0.800 | 341.000 |
| remove | tail | 0 | down | 5,000 | 254,264 | A | 10,000 | 775,542 | 1.289 | 0.700 | 341.000 |
| remove | tail | 0 | down | 1,000 | 50,210 | A | 12,000 | 793,063 | 1.261 | 0.700 | 341.000 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 798,834 | 1.252 | 0.700 | 341.000 |
| replace | head | 0 | up | 1,000 | 50,007 | A | 1,000 | 336,689 | 2.970 | 1.200 | 556.000 |
| replace | head | 0 | up | 5,000 | 256,206 | A | 5,000 | 381,642 | 2.620 | 1.200 | 874.500 |
| replace | head | 0 | up | 10,000 | 508,328 | A | 10,000 | 458,730 | 2.180 | 1.100 | 874.500 |
| replace | head | 0 | up | 15,000 | 756,035 | A | 15,000 | 492,132 | 2.032 | 1.000 | 874.500 |
| replace | head | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 510,384 | 1.959 | 1.000 | 874.500 |
| replace | head | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 513,852 | 1.946 | 1.000 | 874.500 |
| replace | head | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 507,661 | 1.970 | 1.000 | 874.500 |
| replace | head | 0 | down | 15,000 | 759,799 | A | 35,000 | 506,278 | 1.975 | 1.000 | 874.500 |
| replace | head | 0 | down | 10,000 | 506,363 | A | 40,000 | 506,570 | 1.974 | 1.000 | 874.500 |
| replace | head | 0 | down | 5,000 | 254,264 | A | 45,000 | 506,172 | 1.976 | 1.000 | 874.500 |
| replace | head | 0 | down | 1,000 | 50,210 | A | 49,000 | 510,623 | 1.958 | 0.900 | 874.500 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 512,805 | 1.950 | 0.900 | 874.500 |
| replace | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 312,911 | 3.196 | 1.300 | 305.400 |
| replace | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 322,285 | 3.103 | 1.300 | 415.500 |
| replace | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 348,912 | 2.866 | 1.300 | 415.500 |
| replace | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 346,831 | 2.883 | 1.200 | 893.300 |
| replace | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 338,426 | 2.955 | 1.200 | 1636.300 |
| replace | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 338,241 | 2.956 | 1.200 | 1636.300 |
| replace | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 341,380 | 2.929 | 1.200 | 1636.300 |
| replace | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 337,883 | 2.960 | 1.200 | 1636.300 |
| replace | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 344,256 | 2.905 | 1.200 | 1636.300 |
| replace | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 348,686 | 2.868 | 1.000 | 1636.300 |
| replace | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 356,131 | 2.808 | 1.000 | 1636.300 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 359,235 | 2.784 | 0.900 | 1636.300 |
| replace | tail | 0 | up | 1,000 | 50,007 | A | 1,000 | 405,548 | 2.466 | 1.100 | 125.100 |
| replace | tail | 0 | up | 5,000 | 256,206 | A | 5,000 | 442,564 | 2.260 | 1.100 | 161.900 |
| replace | tail | 0 | up | 10,000 | 508,328 | A | 10,000 | 497,810 | 2.009 | 1.000 | 164.300 |
| replace | tail | 0 | up | 15,000 | 756,035 | A | 15,000 | 523,996 | 1.908 | 1.000 | 164.300 |
| replace | tail | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 529,327 | 1.889 | 1.000 | 332.900 |
| replace | tail | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 537,900 | 1.859 | 1.000 | 332.900 |
| replace | tail | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 125,435 | 7.972 | 1.000 | 3471.900 |
| replace | tail | 0 | down | 15,000 | 759,799 | A | 35,000 | 95,513 | 10.470 | 1.000 | 3471.900 |
| replace | tail | 0 | down | 10,000 | 506,363 | A | 40,000 | 96,228 | 10.392 | 1.000 | 3471.900 |
| replace | tail | 0 | down | 5,000 | 254,264 | A | 45,000 | 93,032 | 10.749 | 0.900 | 3471.900 |
| replace | tail | 0 | down | 1,000 | 50,210 | A | 49,000 | 95,808 | 10.438 | 0.900 | 3471.900 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 97,331 | 10.274 | 0.900 | 3471.900 |
| value | head | 0 | up | 1,000 | 50,007 | A | 1,000 | 1,185,255 | 0.844 | 0.100 | 270.400 |
| value | head | 0 | up | 5,000 | 256,206 | A | 5,000 | 2,251,745 | 0.444 | 0.100 | 270.400 |
| value | head | 0 | up | 10,000 | 508,328 | A | 10,000 | 2,719,608 | 0.368 | 0.100 | 270.400 |
| value | head | 0 | up | 15,000 | 756,035 | A | 15,000 | 2,911,999 | 0.343 | 0.100 | 270.400 |
| value | head | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 3,021,650 | 0.331 | 0.100 | 270.400 |
| value | head | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 3,106,323 | 0.322 | 0.100 | 270.400 |
| value | head | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 2,942,071 | 0.340 | 0.100 | 270.400 |
| value | head | 0 | down | 15,000 | 759,799 | A | 35,000 | 2,863,665 | 0.349 | 0.100 | 270.400 |
| value | head | 0 | down | 10,000 | 506,363 | A | 40,000 | 2,817,636 | 0.355 | 0.100 | 270.400 |
| value | head | 0 | down | 5,000 | 254,264 | A | 45,000 | 2,763,771 | 0.362 | 0.100 | 270.400 |
| value | head | 0 | down | 1,000 | 50,210 | A | 49,000 | 2,746,822 | 0.364 | 0.100 | 270.400 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,749,534 | 0.364 | 0.100 | 270.400 |
| value | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 1,029,018 | 0.972 | 0.200 | 79.000 |
| value | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 695,584 | 1.438 | 0.100 | 1730.500 |
| value | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 798,492 | 1.252 | 0.100 | 1730.500 |
| value | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 830,114 | 1.205 | 0.100 | 1730.500 |
| value | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 852,853 | 1.173 | 0.100 | 1730.500 |
| value | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 866,440 | 1.154 | 0.100 | 1730.500 |
| value | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 868,734 | 1.151 | 0.100 | 1730.500 |
| value | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 879,702 | 1.137 | 0.100 | 1730.500 |
| value | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 887,016 | 1.127 | 0.100 | 1730.500 |
| value | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 892,207 | 1.121 | 0.100 | 1730.500 |
| value | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 911,133 | 1.098 | 0.100 | 1730.500 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 919,258 | 1.088 | 0.100 | 1730.500 |
| value | tail | 0 | up | 1,000 | 50,007 | A | 1,000 | 4,522,840 | 0.221 | 0.100 | 11.800 |
| value | tail | 0 | up | 5,000 | 256,206 | A | 5,000 | 5,141,917 | 0.194 | 0.100 | 11.800 |
| value | tail | 0 | up | 10,000 | 508,328 | A | 10,000 | 5,542,008 | 0.180 | 0.100 | 56.900 |
| value | tail | 0 | up | 15,000 | 756,035 | A | 15,000 | 6,034,760 | 0.166 | 0.000 | 56.900 |
| value | tail | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 6,365,170 | 0.157 | 0.000 | 56.900 |
| value | tail | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 6,582,585 | 0.152 | 0.000 | 56.900 |
| value | tail | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 6,040,958 | 0.166 | 0.000 | 56.900 |
| value | tail | 0 | down | 15,000 | 759,799 | A | 35,000 | 5,722,227 | 0.175 | 0.000 | 56.900 |
| value | tail | 0 | down | 10,000 | 506,363 | A | 40,000 | 5,525,320 | 0.181 | 0.000 | 56.900 |
| value | tail | 0 | down | 5,000 | 254,264 | A | 45,000 | 5,340,105 | 0.187 | 0.000 | 56.900 |
| value | tail | 0 | down | 1,000 | 50,210 | A | 49,000 | 5,265,250 | 0.190 | 0.000 | 56.900 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,260,887 | 0.190 | 0.000 | 56.900 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,663 | 375.500 |
| create | — | 0 | up | 5,000 | A | 1 | 1,013 | 987.000 |
| create | — | 0 | up | 10,000 | A | 1 | 625 | 1599.400 |
| create | — | 0 | up | 15,000 | A | 1 | 439 | 2280.000 |
| create | — | 0 | up | 20,000 | A | 1 | 272 | 3678.400 |
| create | — | 0 | up | 25,000 | A | 1 | 110 | 9119.900 |
| create | — | 0 | down | 20,000 | A | 1 | 241 | 4152.100 |
| create | — | 0 | down | 15,000 | A | 1 | 331 | 3023.700 |
| create | — | 0 | down | 10,000 | A | 1 | 557 | 1795.500 |
| create | — | 0 | down | 5,000 | A | 1 | 1,161 | 861.400 |
| create | — | 0 | down | 1,000 | A | 1 | 1,676 | 596.800 |
| create | — | 0 | down | 0 | A | 1 | 36,630 | 27.300 |
| sequence | — | 0 | up | 1,000 | A | 1 | 414 | 2417.200 |
| sequence | — | 0 | up | 5,000 | A | 1 | 121 | 8293.700 |
| sequence | — | 0 | up | 10,000 | A | 1 | 91 | 11030.200 |
| sequence | — | 0 | up | 15,000 | A | 1 | 63 | 15760.400 |
| sequence | — | 0 | up | 20,000 | A | 1 | 43 | 23283.700 |
| sequence | — | 0 | up | 25,000 | A | 1 | 21 | 47452.500 |
| sequence | — | 0 | down | 20,000 | A | 1 | 48 | 20933.700 |
| sequence | — | 0 | down | 15,000 | A | 1 | 69 | 14591.400 |
| sequence | — | 0 | down | 10,000 | A | 1 | 83 | 12038.100 |
| sequence | — | 0 | down | 5,000 | A | 1 | 115 | 8694.200 |
| sequence | — | 0 | down | 1,000 | A | 1 | 144 | 6943.800 |
| sequence | — | 0 | down | 0 | A | 1 | 730 | 1370.200 |
| values | — | 0 | up | 1,000 | A | 1 | 519 | 1926.000 |
| values | — | 0 | up | 5,000 | A | 1 | 231 | 4327.600 |
| values | — | 0 | up | 10,000 | A | 1 | 49 | 20361.000 |
| values | — | 0 | up | 15,000 | A | 1 | 131 | 7647.200 |
| values | — | 0 | up | 20,000 | A | 1 | 92 | 10915.900 |
| values | — | 0 | up | 25,000 | A | 1 | 30 | 33194.300 |
| values | — | 0 | down | 20,000 | A | 1 | 110 | 9106.600 |
| values | — | 0 | down | 15,000 | A | 1 | 140 | 7155.600 |
| values | — | 0 | down | 10,000 | A | 1 | 186 | 5387.100 |
| values | — | 0 | down | 5,000 | A | 1 | 381 | 2622.300 |
| values | — | 0 | down | 1,000 | A | 1 | 2,115 | 472.800 |
| values | — | 0 | down | 0 | A | 1 | 100,000 | 10.000 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.613 | 0.232 | 0.382 |
| 0 | up | 5000 | 3.122 | 1.167 | 1.955 |
| 0 | up | 10000 | 6.220 | 2.342 | 3.878 |
| 0 | up | 15000 | 9.408 | 3.640 | 5.768 |
| 0 | up | 20000 | 12.780 | 5.106 | 7.674 |
| 0 | up | 25000 | 16.189 | 6.630 | 9.559 |
| 0 | down | 20000 | 13.291 | 5.606 | 7.685 |
| 0 | down | 15000 | 9.922 | 4.125 | 5.797 |
| 0 | down | 10000 | 7.152 | 3.289 | 3.863 |
| 0 | down | 5000 | 4.095 | 2.155 | 1.940 |
| 0 | down | 1000 | 1.797 | 1.414 | 0.383 |
| 0 | down | 0 | 1.224 | 1.224 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 50,007 | 0.402 | 421.580 | 8.430 | 115.766 | 15.526 |
| 0 | up | A | 5,000 | 5,000 | 256,206 | 2.057 | 431.302 | 8.417 | 148.813 | 19.653 |
| 0 | up | A | 10,000 | 10,000 | 508,328 | 4.090 | 428.881 | 8.437 | 189.898 | 24.524 |
| 0 | up | A | 15,000 | 15,000 | 756,035 | 6.108 | 426.991 | 8.472 | 203.969 | 29.294 |
| 0 | up | A | 20,000 | 20,000 | 1,005,850 | 8.143 | 426.916 | 8.489 | 274.586 | 34.104 |
| 0 | up | A | 25,000 | 25,000 | 1,252,902 | 10.161 | 426.177 | 8.504 | 288.750 | 38.838 |
| 0 | down | A | 20,000 | 20,000 | 1,007,225 | 8.223 | 431.124 | 8.561 | 292.230 | 34.151 |
| 0 | down | A | 15,000 | 15,000 | 759,799 | 6.203 | 433.606 | 8.560 | 297.063 | 29.426 |
| 0 | down | A | 10,000 | 10,000 | 506,363 | 4.124 | 432.479 | 8.541 | 295.422 | 24.627 |
| 0 | down | A | 5,000 | 5,000 | 254,264 | 2.060 | 431.993 | 8.495 | 293.559 | 19.849 |
| 0 | down | A | 1,000 | 1,000 | 50,210 | 0.406 | 425.476 | 8.474 | 292.688 | 15.978 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 294.043 | 14.906 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 50007 | 184507 | 184.507 | 3.690 | 272.03 | 14.52 | 162.13 | 12.30 |
| 0 | up | A | 5000 | 256206 | 1218174 | 243.635 | 4.755 | 1644.25 | 73.50 | 830.68 | 61.66 |
| 0 | up | A | 10000 | 508328 | 2441689 | 244.169 | 4.803 | 3276.35 | 148.92 | 1655.21 | 124.79 |
| 0 | up | A | 15000 | 756035 | 3694120 | 246.275 | 4.886 | 4916.66 | 225.99 | 3545.68 | 200.14 |
| 0 | up | A | 20000 | 1005850 | 4950983 | 247.549 | 4.922 | 7073.44 | 311.23 | 5103.00 | 263.55 |
| 0 | up | A | 25000 | 1252902 | 6208304 | 248.332 | 4.955 | 9192.05 | 392.29 | 6496.81 | 335.16 |
| 0 | down | A | 20000 | 1007225 | 5103545 | 255.177 | 5.067 | 7538.07 | 326.43 | 5289.65 | 278.22 |
| 0 | down | A | 15000 | 759799 | 3844421 | 256.295 | 5.060 | 5730.74 | 247.34 | 4004.94 | 209.82 |
| 0 | down | A | 10000 | 506363 | 2541344 | 254.134 | 5.019 | 3828.12 | 165.02 | 2670.80 | 139.89 |
| 0 | down | A | 5000 | 254264 | 1247949 | 249.590 | 4.908 | 1909.46 | 79.58 | 1334.90 | 67.69 |
| 0 | down | A | 1000 | 50210 | 239429 | 239.429 | 4.769 | 375.26 | 16.04 | 262.97 | 13.69 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 427.165 | 8.478 | 246.023 | 4.883 |
| 0 | A | scaleDown | 432.094 | 8.548 | 254.445 | 5.034 |
| 0 | A | fullLifecycle | 429.144 | 8.506 | 249.405 | 4.944 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
