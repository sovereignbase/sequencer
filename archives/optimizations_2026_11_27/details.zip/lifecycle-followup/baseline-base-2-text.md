# Large string benchmarks

2026-11-27T17:06:04.588Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2775.55 | 0.00 |
| 1024 | insert.append | array | 23087.72 | 0.00 |
| 1024 | replace | array | 3218.80 | 0.00 |
| 1024 | remove | array | 1184.23 | 0.00 |
| 1024 | remove.middle | array | 2080.18 | 0.00 |
| 1024 | replace.middle | array | 2271.58 | 0.00 |
| 1024 | apply | array | 769.41 | 0.00 |
| 1024 | apply.array | array | 534.08 | 0.00 |
| 1024 | concurrent.apply | array | 64612.63 | 0.00 |
| 1024 | merge | array | 3096.87 | 0.00 |
| 1024 | create | array | 3083.58 | 0.00 |
| 1024 | value.random | array | 81.03 | 0.00 |
| 1024 | values.range | array | 109.34 | 0.00 |
| 1024 | values.array | array | 1279.64 | 0.00 |
| 1024 | values.text | array | 13224.17 | 0.00 |
| 1024 | sequence.array | array | 1557.40 | 0.00 |
| 1024 | sequence.text | array | 9576.10 | 0.00 |
| 1024 | sequence.edited.text | array | 14033.22 | 0.00 |
| 1024 | sequence.masked.text | array | 11008.81 | 0.00 |
| 1024 | insert | string | 378.03 | 0.00 |
| 1024 | insert.append | string | 3759.98 | 0.00 |
| 1024 | replace | string | 1367.38 | 0.00 |
| 1024 | remove | string | 999.93 | 0.00 |
| 1024 | remove.middle | string | 1068.02 | 0.00 |
| 1024 | replace.middle | string | 1681.95 | 0.00 |
| 1024 | apply | string | 1351.90 | 0.00 |
| 1024 | apply.array | string | 2527.25 | 0.00 |
| 1024 | concurrent.apply | string | 4250.56 | 0.00 |
| 1024 | merge | string | 1479.66 | 0.00 |
| 1024 | create | string | 1089.21 | 0.00 |
| 1024 | value.random | string | 54.92 | 0.00 |
| 1024 | values.range | string | 154.46 | 0.00 |
| 1024 | values.array | string | 1804.18 | 0.00 |
| 1024 | values.text | string | 81.02 | 0.00 |
| 1024 | sequence.array | string | 2002.25 | 0.00 |
| 1024 | sequence.text | string | 196.41 | 0.00 |
| 1024 | sequence.edited.text | string | 2073.86 | 0.00 |
| 1024 | sequence.masked.text | string | 3475.95 | 0.00 |
| 65536 | insert | array | 245300.98 | 0.00 |
| 65536 | insert.append | array | 1077348.00 | 0.00 |
| 65536 | replace | array | 249026.61 | 0.00 |
| 65536 | remove | array | 2749.71 | 0.00 |
| 65536 | remove.middle | array | 229523.85 | 0.00 |
| 65536 | replace.middle | array | 236523.58 | 0.00 |
| 65536 | apply | array | 1059.80 | 0.00 |
| 65536 | apply.array | array | 605.60 | 0.00 |
| 65536 | concurrent.apply | array | 4275550.00 | 0.00 |
| 65536 | merge | array | 214885.47 | 0.00 |
| 65536 | create | array | 207123.97 | 0.00 |
| 65536 | value.random | array | 46.49 | 0.00 |
| 65536 | values.range | array | 138.32 | 0.00 |
| 65536 | values.array | array | 246881.75 | 0.00 |
| 65536 | values.text | array | 2011657.14 | 0.00 |
| 65536 | sequence.array | array | 484865.08 | 0.00 |
| 65536 | sequence.text | array | 1337889.47 | 0.00 |
| 65536 | sequence.edited.text | array | 1593662.50 | 0.00 |
| 65536 | sequence.masked.text | array | 967860.00 | 0.00 |
| 65536 | insert | string | 490.86 | 0.00 |
| 65536 | insert.append | string | 24425.00 | 0.00 |
| 65536 | replace | string | 1477.51 | 0.00 |
| 65536 | remove | string | 1147.95 | 0.00 |
| 65536 | remove.middle | string | 1085.06 | 0.00 |
| 65536 | replace.middle | string | 1940.12 | 0.00 |
| 65536 | apply | string | 1095.01 | 0.00 |
| 65536 | apply.array | string | 203779.67 | 0.00 |
| 65536 | concurrent.apply | string | 156273.13 | 0.00 |
| 65536 | merge | string | 1249.38 | 0.00 |
| 65536 | create | string | 991.98 | 0.00 |
| 65536 | value.random | string | 50.62 | 0.00 |
| 65536 | values.range | string | 292.93 | 0.00 |
| 65536 | values.array | string | 278709.37 | 0.00 |
| 65536 | values.text | string | 109.14 | 0.00 |
| 65536 | sequence.array | string | 226570.27 | 0.00 |
| 65536 | sequence.text | string | 222.60 | 0.00 |
| 65536 | sequence.edited.text | string | 104432.92 | 0.00 |
| 65536 | sequence.masked.text | string | 4310.50 | 0.00 |
| 1048576 | insert | array | 3937100.00 | 0.00 |
| 1048576 | insert.append | array | 30475200.00 | 0.00 |
| 1048576 | replace | array | 3719114.29 | 0.00 |
| 1048576 | remove | array | 16406.89 | 0.00 |
| 1048576 | remove.middle | array | 3148722.22 | 0.00 |
| 1048576 | replace.middle | array | 2900118.18 | 0.00 |
| 1048576 | apply | array | 1300.18 | 0.00 |
| 1048576 | apply.array | array | 618.82 | 0.00 |
| 1048576 | concurrent.apply | array | 68300200.00 | 0.00 |
| 1048576 | merge | array | 3202250.00 | 0.00 |
| 1048576 | create | array | 2948555.56 | 0.00 |
| 1048576 | value.random | array | 35.88 | 0.00 |
| 1048576 | values.range | array | 93.53 | 0.00 |
| 1048576 | values.array | array | 2371281.82 | 0.00 |
| 1048576 | values.text | array | 12916600.00 | 0.00 |
| 1048576 | sequence.array | array | 2207658.33 | 0.00 |
| 1048576 | sequence.text | array | 64422150.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 32381100.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 156068100.00 | 0.00 |
| 1048576 | insert | string | 683.80 | 0.00 |
| 1048576 | insert.append | string | 1104395.65 | 0.00 |
| 1048576 | replace | string | 2224.11 | 0.00 |
| 1048576 | remove | string | 1292.92 | 0.00 |
| 1048576 | remove.middle | string | 1096.95 | 0.00 |
| 1048576 | replace.middle | string | 1550.34 | 0.00 |
| 1048576 | apply | string | 1263.89 | 0.00 |
| 1048576 | apply.array | string | 3706242.86 | 0.00 |
| 1048576 | concurrent.apply | string | 1443888.89 | 0.00 |
| 1048576 | merge | string | 1251.77 | 0.00 |
| 1048576 | create | string | 1274.29 | 0.00 |
| 1048576 | value.random | string | 69.00 | 0.00 |
| 1048576 | values.range | string | 183.36 | 0.00 |
| 1048576 | values.array | string | 3918575.00 | 0.00 |
| 1048576 | values.text | string | 100.23 | 0.00 |
| 1048576 | sequence.array | string | 3755000.00 | 0.00 |
| 1048576 | sequence.text | string | 200.48 | 0.00 |
| 1048576 | sequence.edited.text | string | 1658425.00 | 0.00 |
| 1048576 | sequence.masked.text | string | 3484.81 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
