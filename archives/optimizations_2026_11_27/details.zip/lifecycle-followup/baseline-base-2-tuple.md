# Tuple benchmarks

2026-11-27T17:05:50.204Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 2,575,885 | 2,241,439 | 0.87× |
| 2 | create.sequence | 906,160 | 775,414 | 0.86× |
| 2 | replace.random | 1,180,197 | 1,411,686 | 1.20× |
| 2 | apply.replace | 670,235 | 894,717 | 1.33× |
| 2 | apply.duplicate | 1,606,388 | 1,432,296 | 0.89× |
| 2 | merge.duplicate | 1,351,374 | 1,452,960 | 1.08× |
| 2 | length | 135,678,278 | 135,513,723 | 1.00× |
| 2 | value.random | 33,841,222 | 39,258,174 | 1.16× |
| 2 | values | 12,647,692 | 11,508,277 | 0.91× |
| 2 | sequence | 2,739,066 | 2,836,369 | 1.04× |
| 4 | create.empty | 2,323,750 | 2,246,125 | 0.97× |
| 4 | create.sequence | 678,508 | 640,029 | 0.94× |
| 4 | replace.random | 1,048,934 | 1,542,477 | 1.47× |
| 4 | apply.replace | 662,550 | 999,983 | 1.51× |
| 4 | apply.duplicate | 1,774,242 | 1,731,395 | 0.98× |
| 4 | merge.duplicate | 1,222,468 | 1,179,859 | 0.97× |
| 4 | length | 38,629,590 | 36,655,294 | 0.95× |
| 4 | value.random | 25,390,922 | 56,678,447 | 2.23× |
| 4 | values | 6,603,204 | 7,144,913 | 1.08× |
| 4 | sequence | 2,476,802 | 1,536,952 | 0.62× |
| 8 | create.empty | 2,409,921 | 2,246,720 | 0.93× |
| 8 | create.sequence | 428,851 | 527,645 | 1.23× |
| 8 | replace.random | 977,278 | 559,753 | 0.57× |
| 8 | apply.replace | 584,508 | 928,354 | 1.59× |
| 8 | apply.duplicate | 1,688,121 | 1,605,953 | 0.95× |
| 8 | merge.duplicate | 706,574 | 642,642 | 0.91× |
| 8 | length | 27,088,166 | 25,914,466 | 0.96× |
| 8 | value.random | 7,704,770 | 25,213,815 | 3.27× |
| 8 | values | 3,072,513 | 3,156,559 | 1.03× |
| 8 | sequence | 1,102,517 | 1,363,304 | 1.24× |
| 100 | create.empty | 1,767,815 | 1,989,796 | 1.13× |
| 100 | create.sequence | 66,282 | 82,573 | 1.25× |
| 100 | replace.random | 949,959 | 1,519,890 | 1.60× |
| 100 | apply.replace | 610,935 | 1,009,914 | 1.65× |
| 100 | apply.duplicate | 1,750,356 | 1,753,575 | 1.00× |
| 100 | merge.duplicate | 113,992 | 79,332 | 0.70× |
| 100 | length | 32,491,448 | 38,204,426 | 1.18× |
| 100 | value.random | 13,662,584 | 59,174,369 | 4.33× |
| 100 | values | 497,877 | 638,761 | 1.28× |
| 100 | sequence | 184,934 | 184,234 | 1.00× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
