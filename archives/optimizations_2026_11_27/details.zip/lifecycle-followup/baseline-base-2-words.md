# Words benchmarks

2026-11-27T17:06:25.978Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 26,874 | 203,233 | 211 |
| append | packed | 5.90 | 3.61 | 13.98 | 31,418 | 199,585 | 353 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,713 | 779 | 206 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 30,978 | 1,558 | 266 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 437 | 249 | 89 |
| random | packed | 49.58 | 35.38 | 23.45 | 13,499 | 482 | 122 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 647 | 211 | 95 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 14,713 | 414 | 150 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 716.40 | 0.00 |
| append | numeric | encode | 37210.19 | 0.00 |
| append | numeric | decode | 3067.59 | 0.00 |
| append | numeric | create | 1765.43 | 0.00 |
| append | numeric | load | 4920.47 | 0.00 |
| append | numeric | apply | 2673252.63 | 0.00 |
| append | numeric | receive | 4742063.64 | 0.00 |
| append | binary | sequence | 534.06 | 0.00 |
| append | binary | encode | 31828.50 | 0.00 |
| append | binary | decode | 2472.12 | 0.00 |
| append | binary | create | 1931.76 | 0.00 |
| append | binary | load | 5010.41 | 0.00 |
| append | binary | apply | 2119904.17 | 0.00 |
| append | binary | receive | 2833716.67 | 0.00 |
| prepend | numeric | sequence | 526852.63 | 0.00 |
| prepend | numeric | encode | 583712.79 | 0.00 |
| prepend | numeric | decode | 192546.92 | 0.00 |
| prepend | numeric | create | 642462.82 | 0.00 |
| prepend | numeric | load | 1284415.38 | 0.00 |
| prepend | numeric | apply | 2629495.00 | 0.00 |
| prepend | numeric | receive | 4857100.00 | 0.00 |
| prepend | binary | sequence | 377042.11 | 0.00 |
| prepend | binary | encode | 32280.96 | 0.00 |
| prepend | binary | decode | 2363.91 | 0.00 |
| prepend | binary | create | 589358.82 | 0.00 |
| prepend | binary | load | 641706.41 | 0.00 |
| prepend | binary | apply | 2418985.71 | 0.00 |
| prepend | binary | receive | 3753085.71 | 0.00 |
| random | numeric | sequence | 918767.27 | 0.00 |
| random | numeric | encode | 2290372.73 | 0.00 |
| random | numeric | decode | 738379.41 | 0.00 |
| random | numeric | create | 2002132.00 | 0.00 |
| random | numeric | load | 4015584.62 | 0.00 |
| random | numeric | apply | 8028671.43 | 0.00 |
| random | numeric | receive | 11298720.00 | 0.00 |
| random | binary | sequence | 849800.00 | 0.00 |
| random | binary | encode | 74079.12 | 0.00 |
| random | binary | decode | 2254.99 | 0.00 |
| random | binary | create | 2092691.67 | 0.00 |
| random | binary | load | 2074236.00 | 0.00 |
| random | binary | apply | 6482487.50 | 0.00 |
| random | binary | receive | 8165585.71 | 0.00 |
| concurrent | numeric | sequence | 798176.19 | 0.00 |
| concurrent | numeric | encode | 1545545.45 | 0.00 |
| concurrent | numeric | decode | 814224.19 | 0.00 |
| concurrent | numeric | create | 2344831.82 | 0.00 |
| concurrent | numeric | load | 4744718.18 | 0.00 |
| concurrent | numeric | apply | 6434937.50 | 0.00 |
| concurrent | numeric | receive | 10511600.00 | 0.00 |
| concurrent | binary | sequence | 760078.79 | 0.00 |
| concurrent | binary | encode | 67965.49 | 0.00 |
| concurrent | binary | decode | 2801.30 | 0.00 |
| concurrent | binary | create | 2332627.27 | 0.00 |
| concurrent | binary | load | 2415071.43 | 0.00 |
| concurrent | binary | apply | 5094020.00 | 0.00 |
| concurrent | binary | receive | 6678412.50 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
