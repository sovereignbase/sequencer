# Batch benchmarks

2026-11-27T20:43:29.495Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 2,198,124 | 1,215,239 | 518,609 | 76.05 | 5.99 | 0.012 |
| append | batch | 2,045,966 | 161,290,323 | 243,902,439 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,232,337 | 1,517,950 | 966,215 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 1,798,615 | 2,318,213 | 2,031,075 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 1,120,972 | 1,204,094 | 965,950 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 1,285,237 | 1,664,494 | 1,546,751 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 1,091,445 | 1,133,915 | 849,678 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 1,140,099 | 1,733,904 | 1,713,356 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,478,816 | 1,379,041 | 920,507 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,513,260 | 1,648,397 | 1,843,969 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,262,414 | 1,441,874 | 853,631 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,600,640 | 1,795,386 | 1,715,266 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 708,098 | 1,023,445 | 750,319 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 982,640 | 1,353,088 | 1,225,753 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,061,966 | 1,259,129 | 826,572 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 1,307,987 | 1,929,074 | 1,784,307 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,248,530 | 1,386,145 | 954,730 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 1,299,700 | 1,615,857 | 1,505,061 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 730,251 | 1,029,698 | 756,430 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 865,645 | 1,249,440 | 1,246,261 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 2.730 | 0.000 |
| append | individual | apply | 4.937 | 0.000 |
| append | individual | receive | 11.569 | 0.000 |
| append | individual | encode | 7.835 | 0.000 |
| append | individual | decode | 7.830 | 0.000 |
| append | batch | author | 2.933 | 0.000 |
| append | batch | apply | 0.037 | 0.000 |
| append | batch | receive | 0.025 | 0.000 |
| append | batch | encode | 0.377 | 0.000 |
| append | batch | decode | 0.086 | 0.000 |
| prepend | individual | author | 4.869 | 0.000 |
| prepend | individual | apply | 3.953 | 0.000 |
| prepend | individual | receive | 6.210 | 0.000 |
| prepend | individual | encode | 5.406 | 0.000 |
| prepend | individual | decode | 8.212 | 0.000 |
| prepend | batch | author | 3.336 | 0.000 |
| prepend | batch | apply | 2.588 | 0.000 |
| prepend | batch | receive | 2.954 | 0.000 |
| prepend | batch | encode | 0.175 | 0.000 |
| prepend | batch | decode | 0.097 | 0.000 |
| random.characters | individual | author | 5.352 | 0.000 |
| random.characters | individual | apply | 4.983 | 0.000 |
| random.characters | individual | receive | 6.212 | 0.000 |
| random.characters | individual | encode | 5.229 | 0.000 |
| random.characters | individual | decode | 7.731 | 0.000 |
| random.characters | batch | author | 4.668 | 0.000 |
| random.characters | batch | apply | 3.605 | 0.000 |
| random.characters | batch | receive | 3.879 | 0.000 |
| random.characters | batch | encode | 0.212 | 0.000 |
| random.characters | batch | decode | 0.104 | 0.000 |
| random.words | individual | author | 5.497 | 0.000 |
| random.words | individual | apply | 5.291 | 0.000 |
| random.words | individual | receive | 7.062 | 0.000 |
| random.words | individual | encode | 4.255 | 0.000 |
| random.words | individual | decode | 6.260 | 0.000 |
| random.words | batch | author | 5.263 | 0.000 |
| random.words | batch | apply | 3.460 | 0.000 |
| random.words | batch | receive | 3.502 | 0.000 |
| random.words | batch | encode | 0.403 | 0.000 |
| random.words | batch | decode | 0.101 | 0.000 |
| concurrent.characters | individual | author | 8.115 | 0.000 |
| concurrent.characters | individual | apply | 8.702 | 0.000 |
| concurrent.characters | individual | receive | 13.036 | 0.000 |
| concurrent.characters | individual | encode | 6.744 | 0.000 |
| concurrent.characters | individual | decode | 9.149 | 0.000 |
| concurrent.characters | batch | author | 7.930 | 0.000 |
| concurrent.characters | batch | apply | 7.280 | 0.000 |
| concurrent.characters | batch | receive | 6.508 | 0.000 |
| concurrent.characters | batch | encode | 0.328 | 0.000 |
| concurrent.characters | batch | decode | 0.100 | 0.000 |
| concurrent.words | individual | author | 9.506 | 0.000 |
| concurrent.words | individual | apply | 8.322 | 0.000 |
| concurrent.words | individual | receive | 14.058 | 0.000 |
| concurrent.words | individual | encode | 8.995 | 0.000 |
| concurrent.words | individual | decode | 9.913 | 0.000 |
| concurrent.words | batch | author | 7.497 | 0.000 |
| concurrent.words | batch | apply | 6.684 | 0.000 |
| concurrent.words | batch | receive | 6.996 | 0.000 |
| concurrent.words | batch | encode | 0.656 | 0.000 |
| concurrent.words | batch | decode | 0.124 | 0.000 |
| concurrent.mixed | individual | author | 16.947 | 0.000 |
| concurrent.mixed | individual | apply | 11.725 | 0.000 |
| concurrent.mixed | individual | receive | 15.993 | 0.000 |
| concurrent.mixed | individual | encode | 8.155 | 0.000 |
| concurrent.mixed | individual | decode | 9.721 | 0.000 |
| concurrent.mixed | batch | author | 12.212 | 0.000 |
| concurrent.mixed | batch | apply | 8.869 | 0.000 |
| concurrent.mixed | batch | receive | 9.790 | 0.000 |
| concurrent.mixed | batch | encode | 0.554 | 0.000 |
| concurrent.mixed | batch | decode | 0.120 | 0.000 |
| causal.characters | individual | author | 11.300 | 0.000 |
| causal.characters | individual | apply | 9.530 | 0.000 |
| causal.characters | individual | receive | 14.518 | 0.000 |
| causal.characters | individual | encode | 7.540 | 0.000 |
| causal.characters | individual | decode | 9.990 | 0.000 |
| causal.characters | batch | author | 9.174 | 0.000 |
| causal.characters | batch | apply | 6.221 | 0.000 |
| causal.characters | batch | receive | 6.725 | 0.000 |
| causal.characters | batch | encode | 0.227 | 0.000 |
| causal.characters | batch | decode | 0.117 | 0.000 |
| causal.words | individual | author | 9.611 | 0.000 |
| causal.words | individual | apply | 8.657 | 0.000 |
| causal.words | individual | receive | 12.569 | 0.000 |
| causal.words | individual | encode | 8.062 | 0.000 |
| causal.words | individual | decode | 10.474 | 0.000 |
| causal.words | batch | author | 9.233 | 0.000 |
| causal.words | batch | apply | 7.426 | 0.000 |
| causal.words | batch | receive | 7.973 | 0.000 |
| causal.words | batch | encode | 0.563 | 0.000 |
| causal.words | batch | decode | 0.125 | 0.000 |
| causal.mixed | individual | author | 16.433 | 0.000 |
| causal.mixed | individual | apply | 11.654 | 0.000 |
| causal.mixed | individual | receive | 15.864 | 0.000 |
| causal.mixed | individual | encode | 8.543 | 0.000 |
| causal.mixed | individual | decode | 9.447 | 0.000 |
| causal.mixed | batch | author | 13.862 | 0.000 |
| causal.mixed | batch | apply | 9.604 | 0.000 |
| causal.mixed | batch | receive | 9.629 | 0.000 |
| causal.mixed | batch | encode | 0.408 | 0.000 |
| causal.mixed | batch | decode | 0.119 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
