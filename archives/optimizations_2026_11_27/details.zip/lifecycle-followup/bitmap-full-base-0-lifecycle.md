# Sequencer dynamic lifecycle benchmark

2026-11-27T20:41:57.849Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.23 | 162.89 | 56.49 |
| CommonJS | 199.41 | 164.51 | 56.69 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 334,578 | 2.989 | 2.989 | 2.989 | 0.000 | 0: 2.989 | 0: 2.989 |
| apply | random | A | scaleDown | 24,999 | 355,600 | 2.812 | 2.812 | 2.812 | 0.000 | 0: 2.812 | 0: 2.812 |
| apply | random | A | fullLifecycle | 49,999 | 344,769 | 2.900 | 2.900 | 2.900 | 0.000 | 0: 2.900 | 0: 2.900 |
| create | — | A | scaleUp | 7 | 423 | 2366.371 | 2366.371 | 2366.371 | 0.000 | 0: 2366.371 | 0: 2366.371 |
| create | — | A | scaleDown | 6 | 675 | 1481.217 | 1481.217 | 1481.217 | 0.000 | 0: 1481.217 | 0: 1481.217 |
| create | — | A | fullLifecycle | 13 | 511 | 1957.838 | 1957.838 | 1957.838 | 0.000 | 0: 1957.838 | 0: 1957.838 |
| insert | head | A | scaleUp | 12,500 | 1,218,609 | 0.821 | 0.821 | 0.821 | 0.000 | 0: 0.821 | 0: 0.821 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,218,609 | 0.821 | 0.821 | 0.821 | 0.000 | 0: 0.821 | 0: 0.821 |
| insert | random | A | scaleUp | 25,000 | 564,606 | 1.771 | 1.771 | 1.771 | 0.000 | 0: 1.771 | 0: 1.771 |
| insert | random | A | scaleDown | 25,000 | 642,565 | 1.556 | 1.556 | 1.556 | 0.000 | 0: 1.556 | 0: 1.556 |
| insert | random | A | fullLifecycle | 50,000 | 601,068 | 1.664 | 1.664 | 1.664 | 0.000 | 0: 1.664 | 0: 1.664 |
| insert | tail | A | scaleUp | 12,500 | 1,417,250 | 0.706 | 0.706 | 0.706 | 0.000 | 0: 0.706 | 0: 0.706 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,417,250 | 0.706 | 0.706 | 0.706 | 0.000 | 0: 0.706 | 0: 0.706 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 735,433 | 1.360 | 1.360 | 1.360 | 0.000 | 0: 1.360 | 0: 1.360 |
| remove | head | A | fullLifecycle | 12,500 | 735,433 | 1.360 | 1.360 | 1.360 | 0.000 | 0: 1.360 | 0: 1.360 |
| remove | random | A | scaleUp | 25,000 | 517,790 | 1.931 | 1.931 | 1.931 | 0.000 | 0: 1.931 | 0: 1.931 |
| remove | random | A | scaleDown | 25,000 | 402,993 | 2.481 | 2.481 | 2.481 | 0.000 | 0: 2.481 | 0: 2.481 |
| remove | random | A | fullLifecycle | 50,000 | 453,236 | 2.206 | 2.206 | 2.206 | 0.000 | 0: 2.206 | 0: 2.206 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 850,849 | 1.175 | 1.175 | 1.175 | 0.000 | 0: 1.175 | 0: 1.175 |
| remove | tail | A | fullLifecycle | 12,500 | 850,849 | 1.175 | 1.175 | 1.175 | 0.000 | 0: 1.175 | 0: 1.175 |
| replace | head | A | scaleUp | 25,000 | 542,176 | 1.844 | 1.844 | 1.844 | 0.000 | 0: 1.844 | 0: 1.844 |
| replace | head | A | scaleDown | 25,000 | 499,098 | 2.004 | 2.004 | 2.004 | 0.000 | 0: 2.004 | 0: 2.004 |
| replace | head | A | fullLifecycle | 50,000 | 519,746 | 1.924 | 1.924 | 1.924 | 0.000 | 0: 1.924 | 0: 1.924 |
| replace | random | A | scaleUp | 25,000 | 339,778 | 2.943 | 2.943 | 2.943 | 0.000 | 0: 2.943 | 0: 2.943 |
| replace | random | A | scaleDown | 25,000 | 376,465 | 2.656 | 2.656 | 2.656 | 0.000 | 0: 2.656 | 0: 2.656 |
| replace | random | A | fullLifecycle | 50,000 | 357,182 | 2.800 | 2.800 | 2.800 | 0.000 | 0: 2.800 | 0: 2.800 |
| replace | tail | A | scaleUp | 25,000 | 510,776 | 1.958 | 1.958 | 1.958 | 0.000 | 0: 1.958 | 0: 1.958 |
| replace | tail | A | scaleDown | 25,000 | 55,924 | 17.881 | 17.881 | 17.881 | 0.000 | 0: 17.881 | 0: 17.881 |
| replace | tail | A | fullLifecycle | 50,000 | 100,811 | 9.920 | 9.920 | 9.920 | 0.000 | 0: 9.920 | 0: 9.920 |
| sequence | — | A | scaleUp | 6 | 62 | 16015.267 | 16015.267 | 16015.267 | 0.000 | 0: 16015.267 | 0: 16015.267 |
| sequence | — | A | scaleDown | 6 | 99 | 10142.867 | 10142.867 | 10142.867 | 0.000 | 0: 10142.867 | 0: 10142.867 |
| sequence | — | A | fullLifecycle | 12 | 76 | 13079.067 | 13079.067 | 13079.067 | 0.000 | 0: 13079.067 | 0: 13079.067 |
| value | head | A | scaleUp | 25,000 | 3,250,215 | 0.308 | 0.308 | 0.308 | 0.000 | 0: 0.308 | 0: 0.308 |
| value | head | A | scaleDown | 25,000 | 2,431,268 | 0.411 | 0.411 | 0.411 | 0.000 | 0: 0.411 | 0: 0.411 |
| value | head | A | fullLifecycle | 50,000 | 2,781,719 | 0.359 | 0.359 | 0.359 | 0.000 | 0: 0.359 | 0: 0.359 |
| value | random | A | scaleUp | 25,000 | 945,630 | 1.057 | 1.057 | 1.057 | 0.000 | 0: 1.057 | 0: 1.057 |
| value | random | A | scaleDown | 25,000 | 1,010,305 | 0.990 | 0.990 | 0.990 | 0.000 | 0: 0.990 | 0: 0.990 |
| value | random | A | fullLifecycle | 50,000 | 976,898 | 1.024 | 1.024 | 1.024 | 0.000 | 0: 1.024 | 0: 1.024 |
| value | tail | A | scaleUp | 25,000 | 4,933,107 | 0.203 | 0.203 | 0.203 | 0.000 | 0: 0.203 | 0: 0.203 |
| value | tail | A | scaleDown | 25,000 | 4,288,974 | 0.233 | 0.233 | 0.233 | 0.000 | 0: 0.233 | 0: 0.233 |
| value | tail | A | fullLifecycle | 50,000 | 4,588,545 | 0.218 | 0.218 | 0.218 | 0.000 | 0: 0.218 | 0: 0.218 |
| values | — | A | scaleUp | 6 | 122 | 8224.300 | 8224.300 | 8224.300 | 0.000 | 0: 8224.300 | 0: 8224.300 |
| values | — | A | scaleDown | 6 | 246 | 4069.433 | 4069.433 | 4069.433 | 0.000 | 0: 4069.433 | 0: 4069.433 |
| values | — | A | fullLifecycle | 12 | 163 | 6146.867 | 6146.867 | 6146.867 | 0.000 | 0: 6146.867 | 0: 6146.867 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5448434.000 | 430.140 | 8.475 |
| A | scaleDown | 5 | 4404655.200 | 431.829 | 8.549 |
| A | fullLifecycle | 11 | 4973989.091 | 430.818 | 8.505 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3135629.000 | 247.550 | 4.877 |
| A | scaleDown | 5 | 2594145.800 | 254.328 | 5.035 |
| A | fullLifecycle | 11 | 2889500.273 | 250.272 | 4.940 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 248,595 | 4.023 | 1.700 | 200.900 |
| apply | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 336,592 | 2.971 | 1.400 | 200.900 |
| apply | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 325,909 | 3.068 | 1.400 | 1246.600 |
| apply | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 337,624 | 2.962 | 1.400 | 1246.600 |
| apply | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 333,033 | 3.003 | 1.400 | 1246.600 |
| apply | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 334,578 | 2.989 | 1.400 | 1246.600 |
| apply | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 333,799 | 2.996 | 1.400 | 1246.600 |
| apply | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 334,650 | 2.988 | 1.400 | 1246.600 |
| apply | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 336,646 | 2.970 | 1.400 | 1246.600 |
| apply | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 338,268 | 2.956 | 1.400 | 1246.600 |
| apply | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 342,864 | 2.917 | 1.200 | 1246.600 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 344,769 | 2.900 | 1.100 | 1246.600 |
| insert | head | 0 | up | 1,000 | 49,966 | A | 500 | 899,604 | 1.112 | 0.300 | 49.900 |
| insert | head | 0 | up | 5,000 | 254,523 | A | 2,500 | 741,598 | 1.348 | 0.300 | 1314.500 |
| insert | head | 0 | up | 10,000 | 509,098 | A | 5,000 | 997,486 | 1.003 | 0.300 | 1314.500 |
| insert | head | 0 | up | 15,000 | 765,837 | A | 7,500 | 1,129,076 | 0.886 | 0.300 | 1314.500 |
| insert | head | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 1,176,914 | 0.850 | 0.300 | 1314.500 |
| insert | head | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 1,218,609 | 0.821 | 0.300 | 1314.500 |
| insert | head | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 1,218,609 | 0.821 | 0.300 | 1314.500 |
| insert | head | 0 | down | 15,000 | 757,461 | A | 12,500 | 1,218,609 | 0.821 | 0.300 | 1314.500 |
| insert | head | 0 | down | 10,000 | 505,565 | A | 12,500 | 1,218,609 | 0.821 | 0.300 | 1314.500 |
| insert | head | 0 | down | 5,000 | 249,719 | A | 12,500 | 1,218,609 | 0.821 | 0.300 | 1314.500 |
| insert | head | 0 | down | 1,000 | 50,567 | A | 12,500 | 1,218,609 | 0.821 | 0.300 | 1314.500 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,218,609 | 0.821 | 0.300 | 1314.500 |
| insert | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 550,025 | 1.818 | 0.400 | 301.700 |
| insert | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 541,788 | 1.846 | 0.400 | 1369.500 |
| insert | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 516,220 | 1.937 | 0.400 | 2873.000 |
| insert | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 559,931 | 1.786 | 0.400 | 2873.000 |
| insert | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 553,567 | 1.806 | 0.400 | 2873.000 |
| insert | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 564,606 | 1.771 | 0.400 | 2873.000 |
| insert | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 565,743 | 1.768 | 0.400 | 2873.000 |
| insert | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 562,813 | 1.777 | 0.400 | 2873.000 |
| insert | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 576,769 | 1.734 | 0.400 | 2873.000 |
| insert | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 585,460 | 1.708 | 0.400 | 2873.000 |
| insert | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 595,867 | 1.678 | 0.400 | 2873.000 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 601,068 | 1.664 | 0.400 | 2873.000 |
| insert | tail | 0 | up | 1,000 | 49,966 | A | 500 | 1,166,861 | 0.857 | 0.300 | 7.200 |
| insert | tail | 0 | up | 5,000 | 254,523 | A | 2,500 | 1,363,736 | 0.733 | 0.300 | 70.500 |
| insert | tail | 0 | up | 10,000 | 509,098 | A | 5,000 | 1,400,364 | 0.714 | 0.300 | 217.700 |
| insert | tail | 0 | up | 15,000 | 765,837 | A | 7,500 | 1,453,826 | 0.688 | 0.300 | 217.700 |
| insert | tail | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 1,467,610 | 0.681 | 0.300 | 217.700 |
| insert | tail | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 1,417,250 | 0.706 | 0.300 | 347.000 |
| insert | tail | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 1,417,250 | 0.706 | 0.300 | 347.000 |
| insert | tail | 0 | down | 15,000 | 757,461 | A | 12,500 | 1,417,250 | 0.706 | 0.300 | 347.000 |
| insert | tail | 0 | down | 10,000 | 505,565 | A | 12,500 | 1,417,250 | 0.706 | 0.300 | 347.000 |
| insert | tail | 0 | down | 5,000 | 249,719 | A | 12,500 | 1,417,250 | 0.706 | 0.300 | 347.000 |
| insert | tail | 0 | down | 1,000 | 50,567 | A | 12,500 | 1,417,250 | 0.706 | 0.300 | 347.000 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,417,250 | 0.706 | 0.300 | 347.000 |
| remove | head | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 682,370 | 1.465 | 0.800 | 95.000 |
| remove | head | 0 | down | 15,000 | 757,461 | A | 5,000 | 699,722 | 1.429 | 0.800 | 95.000 |
| remove | head | 0 | down | 10,000 | 505,565 | A | 7,500 | 684,500 | 1.461 | 0.800 | 631.600 |
| remove | head | 0 | down | 5,000 | 249,719 | A | 10,000 | 711,000 | 1.406 | 0.700 | 631.600 |
| remove | head | 0 | down | 1,000 | 50,567 | A | 12,000 | 729,284 | 1.371 | 0.700 | 631.600 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 735,433 | 1.360 | 0.700 | 631.600 |
| remove | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 434,254 | 2.303 | 0.800 | 299.000 |
| remove | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 523,549 | 1.910 | 0.800 | 299.000 |
| remove | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 522,690 | 1.913 | 0.800 | 361.400 |
| remove | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 535,737 | 1.867 | 0.800 | 361.400 |
| remove | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 515,955 | 1.938 | 0.800 | 361.400 |
| remove | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 517,790 | 1.931 | 0.800 | 361.400 |
| remove | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 510,061 | 1.961 | 0.800 | 361.400 |
| remove | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 414,913 | 2.410 | 0.800 | 15411.200 |
| remove | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 427,542 | 2.339 | 0.800 | 15411.200 |
| remove | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 439,635 | 2.275 | 0.800 | 15411.200 |
| remove | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 448,900 | 2.228 | 0.800 | 15411.200 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 453,236 | 2.206 | 0.600 | 15411.200 |
| remove | tail | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 807,702 | 1.238 | 0.700 | 21.800 |
| remove | tail | 0 | down | 15,000 | 757,461 | A | 5,000 | 822,071 | 1.216 | 0.700 | 21.800 |
| remove | tail | 0 | down | 10,000 | 505,565 | A | 7,500 | 835,440 | 1.197 | 0.700 | 21.800 |
| remove | tail | 0 | down | 5,000 | 249,719 | A | 10,000 | 838,800 | 1.192 | 0.700 | 44.400 |
| remove | tail | 0 | down | 1,000 | 50,567 | A | 12,000 | 844,214 | 1.185 | 0.700 | 45.800 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 850,849 | 1.175 | 0.600 | 45.800 |
| replace | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 441,073 | 2.267 | 1.100 | 66.200 |
| replace | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 522,635 | 1.913 | 1.000 | 154.500 |
| replace | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 555,108 | 1.801 | 1.000 | 154.500 |
| replace | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 566,611 | 1.765 | 1.000 | 348.000 |
| replace | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 543,828 | 1.839 | 1.000 | 1216.200 |
| replace | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 542,176 | 1.844 | 1.000 | 1216.200 |
| replace | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 535,678 | 1.867 | 1.000 | 1216.200 |
| replace | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 514,798 | 1.943 | 1.000 | 1471.800 |
| replace | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 514,134 | 1.945 | 1.000 | 1471.800 |
| replace | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 514,146 | 1.945 | 1.000 | 1471.800 |
| replace | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 517,304 | 1.933 | 1.000 | 1471.800 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 519,746 | 1.924 | 0.900 | 1471.800 |
| replace | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 334,113 | 2.993 | 1.000 | 261.700 |
| replace | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 352,858 | 2.834 | 1.000 | 921.100 |
| replace | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 373,370 | 2.678 | 1.000 | 921.100 |
| replace | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 347,789 | 2.875 | 1.000 | 2717.300 |
| replace | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 332,311 | 3.009 | 1.000 | 2755.200 |
| replace | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 339,778 | 2.943 | 1.000 | 2755.200 |
| replace | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 345,122 | 2.898 | 1.000 | 2755.200 |
| replace | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 331,297 | 3.018 | 1.000 | 4984.000 |
| replace | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 340,291 | 2.939 | 1.000 | 4984.000 |
| replace | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 346,475 | 2.886 | 1.000 | 4984.000 |
| replace | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 354,120 | 2.824 | 1.000 | 4984.000 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 357,182 | 2.800 | 0.900 | 4984.000 |
| replace | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 450,450 | 2.220 | 0.900 | 113.900 |
| replace | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 501,444 | 1.994 | 0.900 | 700.600 |
| replace | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 531,223 | 1.882 | 0.900 | 700.600 |
| replace | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 540,507 | 1.850 | 0.900 | 700.600 |
| replace | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 530,739 | 1.884 | 0.900 | 700.600 |
| replace | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 510,776 | 1.958 | 0.900 | 1625.700 |
| replace | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 131,436 | 7.608 | 0.900 | 1625.700 |
| replace | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 97,650 | 10.241 | 0.900 | 1625.700 |
| replace | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 99,049 | 10.096 | 0.900 | 1625.700 |
| replace | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 96,368 | 10.377 | 0.900 | 1625.700 |
| replace | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 99,221 | 10.079 | 0.900 | 1625.700 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 100,811 | 9.920 | 0.900 | 1625.700 |
| value | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 1,099,747 | 0.909 | 0.100 | 261.500 |
| value | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 2,374,056 | 0.421 | 0.100 | 261.500 |
| value | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 2,848,191 | 0.351 | 0.100 | 261.500 |
| value | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 3,076,292 | 0.325 | 0.100 | 261.500 |
| value | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 3,179,195 | 0.315 | 0.100 | 261.500 |
| value | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 3,250,215 | 0.308 | 0.100 | 261.500 |
| value | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 3,007,609 | 0.332 | 0.100 | 261.500 |
| value | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 2,889,696 | 0.346 | 0.100 | 261.500 |
| value | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 2,858,000 | 0.350 | 0.100 | 261.500 |
| value | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 2,818,719 | 0.355 | 0.100 | 261.500 |
| value | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 2,776,959 | 0.360 | 0.100 | 261.500 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,781,719 | 0.359 | 0.100 | 261.500 |
| value | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 1,007,151 | 0.993 | 0.100 | 239.900 |
| value | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 1,053,252 | 0.949 | 0.100 | 239.900 |
| value | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 1,008,136 | 0.992 | 0.100 | 239.900 |
| value | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 991,146 | 1.009 | 0.100 | 239.900 |
| value | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 953,939 | 1.048 | 0.100 | 239.900 |
| value | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 945,630 | 1.057 | 0.100 | 239.900 |
| value | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 945,215 | 1.058 | 0.100 | 239.900 |
| value | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 938,282 | 1.066 | 0.100 | 239.900 |
| value | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 950,229 | 1.052 | 0.100 | 239.900 |
| value | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 956,431 | 1.046 | 0.100 | 239.900 |
| value | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 968,513 | 1.033 | 0.100 | 239.900 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 976,898 | 1.024 | 0.100 | 239.900 |
| value | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 4,970,179 | 0.201 | 0.100 | 12.000 |
| value | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 2,349,293 | 0.426 | 0.100 | 1163.900 |
| value | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 3,416,934 | 0.293 | 0.100 | 1163.900 |
| value | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 4,128,137 | 0.242 | 0.000 | 1163.900 |
| value | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 4,611,695 | 0.217 | 0.000 | 1163.900 |
| value | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 4,933,107 | 0.203 | 0.000 | 1163.900 |
| value | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 4,796,777 | 0.208 | 0.000 | 1163.900 |
| value | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 4,683,590 | 0.214 | 0.000 | 1163.900 |
| value | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 4,664,777 | 0.214 | 0.000 | 1163.900 |
| value | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 4,622,259 | 0.216 | 0.000 | 1163.900 |
| value | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 4,574,395 | 0.219 | 0.000 | 1163.900 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 4,588,545 | 0.218 | 0.000 | 1163.900 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,584 | 387.000 |
| create | — | 0 | up | 5,000 | A | 1 | 810 | 1235.200 |
| create | — | 0 | up | 10,000 | A | 1 | 455 | 2198.500 |
| create | — | 0 | up | 15,000 | A | 1 | 373 | 2677.400 |
| create | — | 0 | up | 20,000 | A | 1 | 278 | 3594.800 |
| create | — | 0 | up | 25,000 | A | 1 | 157 | 6374.900 |
| create | — | 0 | down | 20,000 | A | 1 | 285 | 3509.100 |
| create | — | 0 | down | 15,000 | A | 1 | 389 | 2569.400 |
| create | — | 0 | down | 10,000 | A | 1 | 566 | 1767.900 |
| create | — | 0 | down | 5,000 | A | 1 | 1,214 | 824.000 |
| create | — | 0 | down | 1,000 | A | 1 | 4,919 | 203.300 |
| create | — | 0 | down | 0 | A | 1 | 73,529 | 13.600 |
| sequence | — | 0 | up | 1,000 | A | 1 | 420 | 2380.600 |
| sequence | — | 0 | up | 5,000 | A | 1 | 132 | 7572.500 |
| sequence | — | 0 | up | 10,000 | A | 1 | 61 | 16395.900 |
| sequence | — | 0 | up | 15,000 | A | 1 | 52 | 19091.400 |
| sequence | — | 0 | up | 20,000 | A | 1 | 42 | 23641.300 |
| sequence | — | 0 | up | 25,000 | A | 1 | 37 | 27009.900 |
| sequence | — | 0 | down | 20,000 | A | 1 | 57 | 17503.000 |
| sequence | — | 0 | down | 15,000 | A | 1 | 68 | 14697.000 |
| sequence | — | 0 | down | 10,000 | A | 1 | 84 | 11942.700 |
| sequence | — | 0 | down | 5,000 | A | 1 | 109 | 9142.200 |
| sequence | — | 0 | down | 1,000 | A | 1 | 158 | 6325.000 |
| sequence | — | 0 | down | 0 | A | 1 | 802 | 1247.300 |
| values | — | 0 | up | 1,000 | A | 1 | 584 | 1713.100 |
| values | — | 0 | up | 5,000 | A | 1 | 191 | 5238.500 |
| values | — | 0 | up | 10,000 | A | 1 | 134 | 7446.000 |
| values | — | 0 | up | 15,000 | A | 1 | 108 | 9268.900 |
| values | — | 0 | up | 20,000 | A | 1 | 85 | 11817.300 |
| values | — | 0 | up | 25,000 | A | 1 | 72 | 13862.000 |
| values | — | 0 | down | 20,000 | A | 1 | 112 | 8889.900 |
| values | — | 0 | down | 15,000 | A | 1 | 144 | 6964.300 |
| values | — | 0 | down | 10,000 | A | 1 | 195 | 5141.300 |
| values | — | 0 | down | 5,000 | A | 1 | 342 | 2923.100 |
| values | — | 0 | down | 1,000 | A | 1 | 2,045 | 489.000 |
| values | — | 0 | down | 0 | A | 1 | 111,111 | 9.000 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.613 | 0.232 | 0.381 |
| 0 | up | 5000 | 3.108 | 1.167 | 1.942 |
| 0 | up | 10000 | 6.228 | 2.343 | 3.884 |
| 0 | up | 15000 | 9.486 | 3.643 | 5.843 |
| 0 | up | 20000 | 12.852 | 5.113 | 7.739 |
| 0 | up | 25000 | 16.278 | 6.637 | 9.641 |
| 0 | down | 20000 | 13.340 | 5.613 | 7.727 |
| 0 | down | 15000 | 9.910 | 4.131 | 5.779 |
| 0 | down | 10000 | 7.153 | 3.295 | 3.857 |
| 0 | down | 5000 | 4.067 | 2.161 | 1.905 |
| 0 | down | 1000 | 1.807 | 1.421 | 0.386 |
| 0 | down | 0 | 1.231 | 1.231 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 49,966 | 0.402 | 421.140 | 8.429 | 122.117 | 15.525 |
| 0 | up | A | 5,000 | 5,000 | 254,523 | 2.043 | 428.454 | 8.417 | 155.410 | 19.641 |
| 0 | up | A | 10,000 | 10,000 | 509,098 | 4.098 | 429.682 | 8.440 | 194.602 | 24.533 |
| 0 | up | A | 15,000 | 15,000 | 765,837 | 6.183 | 432.249 | 8.466 | 208.910 | 29.444 |
| 0 | up | A | 20,000 | 20,000 | 1,014,350 | 8.209 | 430.368 | 8.486 | 278.793 | 34.234 |
| 0 | up | A | 25,000 | 25,000 | 1,263,607 | 10.242 | 429.572 | 8.499 | 294.375 | 39.002 |
| 0 | down | A | 20,000 | 20,000 | 1,012,792 | 8.267 | 433.443 | 8.559 | 296.094 | 34.236 |
| 0 | down | A | 15,000 | 15,000 | 757,461 | 6.185 | 432.337 | 8.562 | 301.371 | 29.390 |
| 0 | down | A | 10,000 | 10,000 | 505,565 | 4.118 | 431.804 | 8.541 | 298.660 | 24.615 |
| 0 | down | A | 5,000 | 5,000 | 249,719 | 2.025 | 424.661 | 8.503 | 296.582 | 19.779 |
| 0 | down | A | 1,000 | 1,000 | 50,567 | 0.408 | 428.020 | 8.464 | 295.148 | 15.984 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 296.223 | 14.907 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 49966 | 184228 | 184.228 | 3.687 | 271.76 | 14.53 | 161.92 | 12.35 |
| 0 | up | A | 5000 | 254523 | 1210131 | 242.026 | 4.755 | 1634.13 | 73.21 | 825.25 | 61.48 |
| 0 | up | A | 10000 | 509098 | 2448079 | 244.808 | 4.809 | 3283.48 | 149.01 | 1658.86 | 124.83 |
| 0 | up | A | 15000 | 765837 | 3734371 | 248.958 | 4.876 | 4974.88 | 226.26 | 3590.17 | 200.09 |
| 0 | up | A | 20000 | 1014350 | 4987172 | 249.359 | 4.917 | 7129.39 | 311.11 | 5143.68 | 263.60 |
| 0 | up | A | 25000 | 1263607 | 6249793 | 249.992 | 4.946 | 9254.82 | 392.21 | 6545.54 | 334.80 |
| 0 | down | A | 20000 | 1012792 | 5129580 | 256.479 | 5.065 | 7576.63 | 326.54 | 5319.60 | 278.20 |
| 0 | down | A | 15000 | 757461 | 3834350 | 255.623 | 5.062 | 5712.74 | 247.20 | 3993.54 | 209.87 |
| 0 | down | A | 10000 | 505565 | 2537356 | 253.736 | 5.019 | 3822.17 | 165.03 | 2665.76 | 139.77 |
| 0 | down | A | 5000 | 249719 | 1229097 | 245.819 | 4.922 | 1877.54 | 79.58 | 1312.05 | 67.88 |
| 0 | down | A | 1000 | 50567 | 240346 | 240.346 | 4.753 | 377.29 | 15.97 | 264.47 | 13.64 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 430.140 | 8.475 | 247.550 | 4.877 |
| 0 | A | scaleDown | 431.829 | 8.549 | 254.328 | 5.035 |
| 0 | A | fullLifecycle | 430.818 | 8.505 | 250.272 | 4.940 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
