# Large string benchmarks

2026-11-27T20:42:59.987Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2393.25 | 0.00 |
| 1024 | insert.append | array | 12609.53 | 0.00 |
| 1024 | replace | array | 3080.03 | 0.00 |
| 1024 | remove | array | 987.34 | 0.00 |
| 1024 | remove.middle | array | 1959.14 | 0.00 |
| 1024 | replace.middle | array | 2619.78 | 0.00 |
| 1024 | apply | array | 972.81 | 0.00 |
| 1024 | apply.array | array | 546.02 | 0.00 |
| 1024 | concurrent.apply | array | 67718.65 | 0.00 |
| 1024 | merge | array | 3168.65 | 0.00 |
| 1024 | create | array | 2672.71 | 0.00 |
| 1024 | value.random | array | 43.77 | 0.00 |
| 1024 | values.range | array | 102.30 | 0.00 |
| 1024 | values.array | array | 1300.97 | 0.00 |
| 1024 | values.text | array | 12706.96 | 0.00 |
| 1024 | sequence.array | array | 1597.81 | 0.00 |
| 1024 | sequence.text | array | 8612.67 | 0.00 |
| 1024 | sequence.edited.text | array | 12688.23 | 0.00 |
| 1024 | sequence.masked.text | array | 10540.18 | 0.00 |
| 1024 | insert | string | 397.71 | 0.00 |
| 1024 | insert.append | string | 3544.26 | 0.00 |
| 1024 | replace | string | 1090.49 | 0.00 |
| 1024 | remove | string | 873.51 | 0.00 |
| 1024 | remove.middle | string | 905.05 | 0.00 |
| 1024 | replace.middle | string | 1267.75 | 0.00 |
| 1024 | apply | string | 1125.68 | 0.00 |
| 1024 | apply.array | string | 2276.14 | 0.00 |
| 1024 | concurrent.apply | string | 3825.71 | 0.00 |
| 1024 | merge | string | 1413.70 | 0.00 |
| 1024 | create | string | 920.56 | 0.00 |
| 1024 | value.random | string | 52.14 | 0.00 |
| 1024 | values.range | string | 156.67 | 0.00 |
| 1024 | values.array | string | 1864.16 | 0.00 |
| 1024 | values.text | string | 94.16 | 0.00 |
| 1024 | sequence.array | string | 2282.53 | 0.00 |
| 1024 | sequence.text | string | 201.69 | 0.00 |
| 1024 | sequence.edited.text | string | 1956.38 | 0.00 |
| 1024 | sequence.masked.text | string | 3189.87 | 0.00 |
| 65536 | insert | array | 247671.29 | 0.00 |
| 65536 | insert.append | array | 1066808.00 | 0.00 |
| 65536 | replace | array | 245448.62 | 0.00 |
| 65536 | remove | array | 2571.91 | 0.00 |
| 65536 | remove.middle | array | 230520.18 | 0.00 |
| 65536 | replace.middle | array | 234335.51 | 0.00 |
| 65536 | apply | array | 1104.94 | 0.00 |
| 65536 | apply.array | array | 1211.12 | 0.00 |
| 65536 | concurrent.apply | array | 4491316.67 | 0.00 |
| 65536 | merge | array | 218294.78 | 0.00 |
| 65536 | create | array | 204277.24 | 0.00 |
| 65536 | value.random | array | 49.08 | 0.00 |
| 65536 | values.range | array | 135.56 | 0.00 |
| 65536 | values.array | array | 211201.59 | 0.00 |
| 65536 | values.text | array | 774424.24 | 0.00 |
| 65536 | sequence.array | array | 195725.00 | 0.00 |
| 65536 | sequence.text | array | 686037.84 | 0.00 |
| 65536 | sequence.edited.text | array | 938703.33 | 0.00 |
| 65536 | sequence.masked.text | array | 680897.30 | 0.00 |
| 65536 | insert | string | 394.04 | 0.00 |
| 65536 | insert.append | string | 21971.09 | 0.00 |
| 65536 | replace | string | 1411.67 | 0.00 |
| 65536 | remove | string | 849.33 | 0.00 |
| 65536 | remove.middle | string | 924.66 | 0.00 |
| 65536 | replace.middle | string | 1184.59 | 0.00 |
| 65536 | apply | string | 948.45 | 0.00 |
| 65536 | apply.array | string | 264550.78 | 0.00 |
| 65536 | concurrent.apply | string | 153969.33 | 0.00 |
| 65536 | merge | string | 1661.89 | 0.00 |
| 65536 | create | string | 1614.75 | 0.00 |
| 65536 | value.random | string | 93.36 | 0.00 |
| 65536 | values.range | string | 192.74 | 0.00 |
| 65536 | values.array | string | 271423.66 | 0.00 |
| 65536 | values.text | string | 133.26 | 0.00 |
| 65536 | sequence.array | string | 237449.06 | 0.00 |
| 65536 | sequence.text | string | 314.37 | 0.00 |
| 65536 | sequence.edited.text | string | 121032.85 | 0.00 |
| 65536 | sequence.masked.text | string | 3222.34 | 0.00 |
| 1048576 | insert | array | 3219275.00 | 0.00 |
| 1048576 | insert.append | array | 24402800.00 | 0.00 |
| 1048576 | replace | array | 2884888.89 | 0.00 |
| 1048576 | remove | array | 9977.46 | 0.00 |
| 1048576 | remove.middle | array | 3042411.11 | 0.00 |
| 1048576 | replace.middle | array | 2931922.22 | 0.00 |
| 1048576 | apply | array | 946.57 | 0.00 |
| 1048576 | apply.array | array | 567.82 | 0.00 |
| 1048576 | concurrent.apply | array | 66230700.00 | 0.00 |
| 1048576 | merge | array | 3224200.00 | 0.00 |
| 1048576 | create | array | 3387487.50 | 0.00 |
| 1048576 | value.random | array | 36.34 | 0.00 |
| 1048576 | values.range | array | 95.06 | 0.00 |
| 1048576 | values.array | array | 2149266.67 | 0.00 |
| 1048576 | values.text | array | 12799450.00 | 0.00 |
| 1048576 | sequence.array | array | 2327754.55 | 0.00 |
| 1048576 | sequence.text | array | 55947800.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 60947500.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 59126300.00 | 0.00 |
| 1048576 | insert | string | 472.46 | 0.00 |
| 1048576 | insert.append | string | 572075.00 | 0.00 |
| 1048576 | replace | string | 1418.74 | 0.00 |
| 1048576 | remove | string | 1102.95 | 0.00 |
| 1048576 | remove.middle | string | 938.15 | 0.00 |
| 1048576 | replace.middle | string | 1342.82 | 0.00 |
| 1048576 | apply | string | 970.78 | 0.00 |
| 1048576 | apply.array | string | 3366862.50 | 0.00 |
| 1048576 | concurrent.apply | string | 1511964.71 | 0.00 |
| 1048576 | merge | string | 1196.69 | 0.00 |
| 1048576 | create | string | 891.14 | 0.00 |
| 1048576 | value.random | string | 48.07 | 0.00 |
| 1048576 | values.range | string | 141.54 | 0.00 |
| 1048576 | values.array | string | 3342025.00 | 0.00 |
| 1048576 | values.text | string | 66.46 | 0.00 |
| 1048576 | sequence.array | string | 3036644.44 | 0.00 |
| 1048576 | sequence.text | string | 164.12 | 0.00 |
| 1048576 | sequence.edited.text | string | 1485576.47 | 0.00 |
| 1048576 | sequence.masked.text | string | 2946.09 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
