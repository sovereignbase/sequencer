# Tuple benchmarks

2026-11-27T20:42:45.479Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 3,091,027 | 2,502,858 | 0.81× |
| 2 | create.sequence | 1,036,182 | 917,154 | 0.89× |
| 2 | replace.random | 1,266,156 | 1,462,660 | 1.16× |
| 2 | apply.replace | 743,783 | 937,693 | 1.26× |
| 2 | apply.duplicate | 1,714,617 | 1,800,567 | 1.05× |
| 2 | merge.duplicate | 1,682,711 | 1,803,901 | 1.07× |
| 2 | length | 140,099,603 | 126,659,843 | 0.90× |
| 2 | value.random | 26,133,803 | 21,236,476 | 0.81× |
| 2 | values | 9,850,381 | 12,391,050 | 1.26× |
| 2 | sequence | 3,478,233 | 3,191,223 | 0.92× |
| 4 | create.empty | 2,481,362 | 2,513,029 | 1.01× |
| 4 | create.sequence | 734,777 | 764,036 | 1.04× |
| 4 | replace.random | 1,050,530 | 1,594,801 | 1.52× |
| 4 | apply.replace | 613,631 | 1,027,599 | 1.67× |
| 4 | apply.duplicate | 1,871,011 | 1,798,079 | 0.96× |
| 4 | merge.duplicate | 1,385,543 | 1,428,962 | 1.03× |
| 4 | length | 39,207,272 | 33,127,239 | 0.84× |
| 4 | value.random | 26,631,104 | 49,646,109 | 1.86× |
| 4 | values | 6,914,961 | 6,551,543 | 0.95× |
| 4 | sequence | 2,511,381 | 2,436,587 | 0.97× |
| 8 | create.empty | 2,563,800 | 2,478,466 | 0.97× |
| 8 | create.sequence | 486,119 | 545,897 | 1.12× |
| 8 | replace.random | 1,048,296 | 1,650,545 | 1.57× |
| 8 | apply.replace | 640,028 | 958,815 | 1.50× |
| 8 | apply.duplicate | 1,810,568 | 1,715,979 | 0.95× |
| 8 | merge.duplicate | 1,022,084 | 863,393 | 0.84× |
| 8 | length | 40,243,014 | 40,397,823 | 1.00× |
| 8 | value.random | 19,941,957 | 62,670,271 | 3.14× |
| 8 | values | 4,702,808 | 4,980,892 | 1.06× |
| 8 | sequence | 1,853,981 | 1,698,514 | 0.92× |
| 100 | create.empty | 2,467,676 | 2,326,837 | 0.94× |
| 100 | create.sequence | 70,518 | 87,871 | 1.25× |
| 100 | replace.random | 1,082,700 | 1,683,238 | 1.55× |
| 100 | apply.replace | 687,623 | 1,070,024 | 1.56× |
| 100 | apply.duplicate | 1,766,933 | 1,790,487 | 1.01× |
| 100 | merge.duplicate | 120,419 | 77,662 | 0.64× |
| 100 | length | 39,828,240 | 31,134,108 | 0.78× |
| 100 | value.random | 13,071,358 | 61,100,487 | 4.67× |
| 100 | values | 553,702 | 683,754 | 1.23× |
| 100 | sequence | 196,408 | 202,431 | 1.03× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
