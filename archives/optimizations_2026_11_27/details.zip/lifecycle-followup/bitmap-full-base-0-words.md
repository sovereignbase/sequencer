# Words benchmarks

2026-11-27T20:43:22.591Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 35,860 | 174,294 | 312 |
| append | packed | 5.90 | 3.61 | 13.98 | 31,137 | 138,935 | 342 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 2,011 | 817 | 196 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 33,996 | 1,796 | 252 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 444 | 286 | 87 |
| random | packed | 49.58 | 35.38 | 23.45 | 17,874 | 503 | 132 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 674 | 279 | 109 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 15,999 | 449 | 145 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 476.84 | 0.00 |
| append | numeric | encode | 27886.22 | 0.00 |
| append | numeric | decode | 2633.35 | 0.00 |
| append | numeric | create | 1687.51 | 0.00 |
| append | numeric | load | 5737.43 | 0.00 |
| append | numeric | apply | 2659500.00 | 0.00 |
| append | numeric | receive | 3201356.25 | 0.00 |
| append | binary | sequence | 670.25 | 0.00 |
| append | binary | encode | 32115.79 | 0.00 |
| append | binary | decode | 2063.46 | 0.00 |
| append | binary | create | 2084.61 | 0.00 |
| append | binary | load | 7197.61 | 0.00 |
| append | binary | apply | 1839546.43 | 0.00 |
| append | binary | receive | 2926466.67 | 0.00 |
| prepend | numeric | sequence | 418018.33 | 0.00 |
| prepend | numeric | encode | 497299.01 | 0.00 |
| prepend | numeric | decode | 154328.40 | 0.00 |
| prepend | numeric | create | 580049.43 | 0.00 |
| prepend | numeric | load | 1223870.73 | 0.00 |
| prepend | numeric | apply | 2469752.38 | 0.00 |
| prepend | numeric | receive | 5114380.00 | 0.00 |
| prepend | binary | sequence | 324081.94 | 0.00 |
| prepend | binary | encode | 29415.35 | 0.00 |
| prepend | binary | decode | 1875.11 | 0.00 |
| prepend | binary | create | 536065.96 | 0.00 |
| prepend | binary | load | 556655.56 | 0.00 |
| prepend | binary | apply | 3213687.50 | 0.00 |
| prepend | binary | receive | 3973338.46 | 0.00 |
| random | numeric | sequence | 942305.56 | 0.00 |
| random | numeric | encode | 2252717.39 | 0.00 |
| random | numeric | decode | 965155.77 | 0.00 |
| random | numeric | create | 1579309.37 | 0.00 |
| random | numeric | load | 3490573.33 | 0.00 |
| random | numeric | apply | 7806414.29 | 0.00 |
| random | numeric | receive | 11477260.00 | 0.00 |
| random | binary | sequence | 807448.39 | 0.00 |
| random | binary | encode | 55946.64 | 0.00 |
| random | binary | decode | 2327.07 | 0.00 |
| random | binary | create | 1985226.92 | 0.00 |
| random | binary | load | 1987100.00 | 0.00 |
| random | binary | apply | 5663477.78 | 0.00 |
| random | binary | receive | 7573157.14 | 0.00 |
| concurrent | numeric | sequence | 768027.27 | 0.00 |
| concurrent | numeric | encode | 1483250.00 | 0.00 |
| concurrent | numeric | decode | 660231.58 | 0.00 |
| concurrent | numeric | create | 2139508.33 | 0.00 |
| concurrent | numeric | load | 3581557.14 | 0.00 |
| concurrent | numeric | apply | 6059333.33 | 0.00 |
| concurrent | numeric | receive | 9143533.33 | 0.00 |
| concurrent | binary | sequence | 691054.79 | 0.00 |
| concurrent | binary | encode | 62504.50 | 0.00 |
| concurrent | binary | decode | 2865.57 | 0.00 |
| concurrent | binary | create | 2365063.64 | 0.00 |
| concurrent | binary | load | 2227152.17 | 0.00 |
| concurrent | binary | apply | 5014850.00 | 0.00 |
| concurrent | binary | receive | 6903100.00 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
