# Batch benchmarks

2026-11-27T20:48:30.848Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 1,786,884 | 1,173,985 | 586,247 | 76.05 | 5.99 | 0.012 |
| append | batch | 1,633,186 | 251,046,025 | 218,978,102 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,653,576 | 1,589,657 | 850,991 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 1,206,685 | 2,014,572 | 891,080 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 1,107,665 | 1,002,573 | 767,951 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 1,130,135 | 1,457,124 | 1,434,412 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 1,087,488 | 1,131,670 | 785,484 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 1,108,832 | 1,748,863 | 1,536,885 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,362,568 | 1,244,478 | 859,716 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,441,770 | 1,736,136 | 1,698,899 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,077,103 | 1,259,208 | 857,798 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,192,701 | 1,624,431 | 1,496,241 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 681,029 | 956,198 | 711,959 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 941,620 | 1,167,724 | 1,206,734 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,185,209 | 1,432,819 | 1,010,297 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 1,185,092 | 1,770,512 | 1,354,264 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,099,485 | 1,265,876 | 839,672 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 964,219 | 1,627,847 | 1,552,936 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 722,400 | 974,501 | 726,823 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 950,179 | 1,279,372 | 1,261,710 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 3.358 | 0.000 |
| append | individual | apply | 5.111 | 0.000 |
| append | individual | receive | 10.235 | 0.000 |
| append | individual | encode | 7.118 | 0.000 |
| append | individual | decode | 8.661 | 0.000 |
| append | batch | author | 3.674 | 0.000 |
| append | batch | apply | 0.024 | 0.000 |
| append | batch | receive | 0.027 | 0.000 |
| append | batch | encode | 0.218 | 0.000 |
| append | batch | decode | 0.105 | 0.000 |
| prepend | individual | author | 3.629 | 0.000 |
| prepend | individual | apply | 3.774 | 0.000 |
| prepend | individual | receive | 7.051 | 0.000 |
| prepend | individual | encode | 5.608 | 0.000 |
| prepend | individual | decode | 6.617 | 0.000 |
| prepend | batch | author | 4.972 | 0.000 |
| prepend | batch | apply | 2.978 | 0.000 |
| prepend | batch | receive | 6.733 | 0.000 |
| prepend | batch | encode | 0.266 | 0.000 |
| prepend | batch | decode | 0.112 | 0.000 |
| random.characters | individual | author | 5.417 | 0.000 |
| random.characters | individual | apply | 5.985 | 0.000 |
| random.characters | individual | receive | 7.813 | 0.000 |
| random.characters | individual | encode | 5.161 | 0.000 |
| random.characters | individual | decode | 6.970 | 0.000 |
| random.characters | batch | author | 5.309 | 0.000 |
| random.characters | batch | apply | 4.118 | 0.000 |
| random.characters | batch | receive | 4.183 | 0.000 |
| random.characters | batch | encode | 0.224 | 0.000 |
| random.characters | batch | decode | 0.104 | 0.000 |
| random.words | individual | author | 5.517 | 0.000 |
| random.words | individual | apply | 5.302 | 0.000 |
| random.words | individual | receive | 7.639 | 0.000 |
| random.words | individual | encode | 4.180 | 0.000 |
| random.words | individual | decode | 7.376 | 0.000 |
| random.words | batch | author | 5.411 | 0.000 |
| random.words | batch | apply | 3.431 | 0.000 |
| random.words | batch | receive | 3.904 | 0.000 |
| random.words | batch | encode | 0.435 | 0.000 |
| random.words | batch | decode | 0.110 | 0.000 |
| concurrent.characters | individual | author | 8.807 | 0.000 |
| concurrent.characters | individual | apply | 9.643 | 0.000 |
| concurrent.characters | individual | receive | 13.958 | 0.000 |
| concurrent.characters | individual | encode | 8.037 | 0.000 |
| concurrent.characters | individual | decode | 9.937 | 0.000 |
| concurrent.characters | batch | author | 8.323 | 0.000 |
| concurrent.characters | batch | apply | 6.912 | 0.000 |
| concurrent.characters | batch | receive | 7.063 | 0.000 |
| concurrent.characters | batch | encode | 0.357 | 0.000 |
| concurrent.characters | batch | decode | 0.110 | 0.000 |
| concurrent.words | individual | author | 11.141 | 0.000 |
| concurrent.words | individual | apply | 9.530 | 0.000 |
| concurrent.words | individual | receive | 13.989 | 0.000 |
| concurrent.words | individual | encode | 9.332 | 0.000 |
| concurrent.words | individual | decode | 13.480 | 0.000 |
| concurrent.words | batch | author | 10.061 | 0.000 |
| concurrent.words | batch | apply | 7.387 | 0.000 |
| concurrent.words | batch | receive | 8.020 | 0.000 |
| concurrent.words | batch | encode | 0.753 | 0.000 |
| concurrent.words | batch | decode | 0.118 | 0.000 |
| concurrent.mixed | individual | author | 17.620 | 0.000 |
| concurrent.mixed | individual | apply | 12.550 | 0.000 |
| concurrent.mixed | individual | receive | 16.855 | 0.000 |
| concurrent.mixed | individual | encode | 8.832 | 0.000 |
| concurrent.mixed | individual | decode | 9.675 | 0.000 |
| concurrent.mixed | batch | author | 12.744 | 0.000 |
| concurrent.mixed | batch | apply | 10.276 | 0.000 |
| concurrent.mixed | batch | receive | 9.944 | 0.000 |
| concurrent.mixed | batch | encode | 0.537 | 0.000 |
| concurrent.mixed | batch | decode | 0.111 | 0.000 |
| causal.characters | individual | author | 10.125 | 0.000 |
| causal.characters | individual | apply | 8.375 | 0.000 |
| causal.characters | individual | receive | 11.878 | 0.000 |
| causal.characters | individual | encode | 6.140 | 0.000 |
| causal.characters | individual | decode | 12.049 | 0.000 |
| causal.characters | batch | author | 10.126 | 0.000 |
| causal.characters | batch | apply | 6.778 | 0.000 |
| causal.characters | batch | receive | 8.861 | 0.000 |
| causal.characters | batch | encode | 0.300 | 0.000 |
| causal.characters | batch | decode | 0.138 | 0.000 |
| causal.words | individual | author | 10.914 | 0.000 |
| causal.words | individual | apply | 9.480 | 0.000 |
| causal.words | individual | receive | 14.291 | 0.000 |
| causal.words | individual | encode | 7.721 | 0.000 |
| causal.words | individual | decode | 11.288 | 0.000 |
| causal.words | batch | author | 12.445 | 0.000 |
| causal.words | batch | apply | 7.372 | 0.000 |
| causal.words | batch | receive | 7.727 | 0.000 |
| causal.words | batch | encode | 0.693 | 0.000 |
| causal.words | batch | decode | 0.126 | 0.000 |
| causal.mixed | individual | author | 16.611 | 0.000 |
| causal.mixed | individual | apply | 12.314 | 0.000 |
| causal.mixed | individual | receive | 16.510 | 0.000 |
| causal.mixed | individual | encode | 9.135 | 0.000 |
| causal.mixed | individual | decode | 10.303 | 0.000 |
| causal.mixed | batch | author | 12.629 | 0.000 |
| causal.mixed | batch | apply | 9.380 | 0.000 |
| causal.mixed | batch | receive | 9.511 | 0.000 |
| causal.mixed | batch | encode | 0.406 | 0.000 |
| causal.mixed | batch | decode | 0.108 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
