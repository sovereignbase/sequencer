# Sequencer dynamic lifecycle benchmark

2026-11-27T20:47:00.873Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.23 | 162.89 | 56.49 |
| CommonJS | 199.41 | 164.51 | 56.69 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 317,110 | 3.153 | 3.153 | 3.153 | 0.000 | 0: 3.153 | 0: 3.153 |
| apply | random | A | scaleDown | 24,999 | 354,379 | 2.822 | 2.822 | 2.822 | 0.000 | 0: 2.822 | 0: 2.822 |
| apply | random | A | fullLifecycle | 49,999 | 334,709 | 2.988 | 2.988 | 2.988 | 0.000 | 0: 2.988 | 0: 2.988 |
| create | — | A | scaleUp | 7 | 517 | 1935.971 | 1935.971 | 1935.971 | 0.000 | 0: 1935.971 | 0: 1935.971 |
| create | — | A | scaleDown | 6 | 656 | 1524.783 | 1524.783 | 1524.783 | 0.000 | 0: 1524.783 | 0: 1524.783 |
| create | — | A | fullLifecycle | 13 | 573 | 1746.192 | 1746.192 | 1746.192 | 0.000 | 0: 1746.192 | 0: 1746.192 |
| insert | head | A | scaleUp | 12,500 | 1,344,578 | 0.744 | 0.744 | 0.744 | 0.000 | 0: 0.744 | 0: 0.744 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,344,578 | 0.744 | 0.744 | 0.744 | 0.000 | 0: 0.744 | 0: 0.744 |
| insert | random | A | scaleUp | 25,000 | 604,352 | 1.655 | 1.655 | 1.655 | 0.000 | 0: 1.655 | 0: 1.655 |
| insert | random | A | scaleDown | 25,000 | 606,717 | 1.648 | 1.648 | 1.648 | 0.000 | 0: 1.648 | 0: 1.648 |
| insert | random | A | fullLifecycle | 50,000 | 605,532 | 1.651 | 1.651 | 1.651 | 0.000 | 0: 1.651 | 0: 1.651 |
| insert | tail | A | scaleUp | 12,500 | 1,395,089 | 0.717 | 0.717 | 0.717 | 0.000 | 0: 0.717 | 0: 0.717 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,395,089 | 0.717 | 0.717 | 0.717 | 0.000 | 0: 0.717 | 0: 0.717 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 706,806 | 1.415 | 1.415 | 1.415 | 0.000 | 0: 1.415 | 0: 1.415 |
| remove | head | A | fullLifecycle | 12,500 | 706,806 | 1.415 | 1.415 | 1.415 | 0.000 | 0: 1.415 | 0: 1.415 |
| remove | random | A | scaleUp | 25,000 | 489,071 | 2.045 | 2.045 | 2.045 | 0.000 | 0: 2.045 | 0: 2.045 |
| remove | random | A | scaleDown | 25,000 | 520,990 | 1.919 | 1.919 | 1.919 | 0.000 | 0: 1.919 | 0: 1.919 |
| remove | random | A | fullLifecycle | 50,000 | 504,526 | 1.982 | 1.982 | 1.982 | 0.000 | 0: 1.982 | 0: 1.982 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 836,686 | 1.195 | 1.195 | 1.195 | 0.000 | 0: 1.195 | 0: 1.195 |
| remove | tail | A | fullLifecycle | 12,500 | 836,686 | 1.195 | 1.195 | 1.195 | 0.000 | 0: 1.195 | 0: 1.195 |
| replace | head | A | scaleUp | 25,000 | 548,463 | 1.823 | 1.823 | 1.823 | 0.000 | 0: 1.823 | 0: 1.823 |
| replace | head | A | scaleDown | 25,000 | 500,408 | 1.998 | 1.998 | 1.998 | 0.000 | 0: 1.998 | 0: 1.998 |
| replace | head | A | fullLifecycle | 50,000 | 523,335 | 1.911 | 1.911 | 1.911 | 0.000 | 0: 1.911 | 0: 1.911 |
| replace | random | A | scaleUp | 25,000 | 369,784 | 2.704 | 2.704 | 2.704 | 0.000 | 0: 2.704 | 0: 2.704 |
| replace | random | A | scaleDown | 25,000 | 394,541 | 2.535 | 2.535 | 2.535 | 0.000 | 0: 2.535 | 0: 2.535 |
| replace | random | A | fullLifecycle | 50,000 | 381,761 | 2.619 | 2.619 | 2.619 | 0.000 | 0: 2.619 | 0: 2.619 |
| replace | tail | A | scaleUp | 25,000 | 549,861 | 1.819 | 1.819 | 1.819 | 0.000 | 0: 1.819 | 0: 1.819 |
| replace | tail | A | scaleDown | 25,000 | 54,442 | 18.368 | 18.368 | 18.368 | 0.000 | 0: 18.368 | 0: 18.368 |
| replace | tail | A | fullLifecycle | 50,000 | 99,075 | 10.093 | 10.093 | 10.093 | 0.000 | 0: 10.093 | 0: 10.093 |
| sequence | — | A | scaleUp | 6 | 75 | 13315.900 | 13315.900 | 13315.900 | 0.000 | 0: 13315.900 | 0: 13315.900 |
| sequence | — | A | scaleDown | 6 | 93 | 10810.117 | 10810.117 | 10810.117 | 0.000 | 0: 10810.117 | 0: 10810.117 |
| sequence | — | A | fullLifecycle | 12 | 83 | 12063.008 | 12063.008 | 12063.008 | 0.000 | 0: 12063.008 | 0: 12063.008 |
| value | head | A | scaleUp | 25,000 | 3,436,143 | 0.291 | 0.291 | 0.291 | 0.000 | 0: 0.291 | 0: 0.291 |
| value | head | A | scaleDown | 25,000 | 2,494,338 | 0.401 | 0.401 | 0.401 | 0.000 | 0: 0.401 | 0: 0.401 |
| value | head | A | fullLifecycle | 50,000 | 2,890,457 | 0.346 | 0.346 | 0.346 | 0.000 | 0: 0.346 | 0: 0.346 |
| value | random | A | scaleUp | 25,000 | 916,318 | 1.091 | 1.091 | 1.091 | 0.000 | 0: 1.091 | 0: 1.091 |
| value | random | A | scaleDown | 25,000 | 993,112 | 1.007 | 1.007 | 1.007 | 0.000 | 0: 1.007 | 0: 1.007 |
| value | random | A | fullLifecycle | 50,000 | 953,171 | 1.049 | 1.049 | 1.049 | 0.000 | 0: 1.049 | 0: 1.049 |
| value | tail | A | scaleUp | 25,000 | 6,503,642 | 0.154 | 0.154 | 0.154 | 0.000 | 0: 0.154 | 0: 0.154 |
| value | tail | A | scaleDown | 25,000 | 4,241,818 | 0.236 | 0.236 | 0.236 | 0.000 | 0: 0.236 | 0: 0.236 |
| value | tail | A | fullLifecycle | 50,000 | 5,134,683 | 0.195 | 0.195 | 0.195 | 0.000 | 0: 0.195 | 0: 0.195 |
| values | — | A | scaleUp | 6 | 79 | 12706.383 | 12706.383 | 12706.383 | 0.000 | 0: 12706.383 | 0: 12706.383 |
| values | — | A | scaleDown | 6 | 241 | 4157.267 | 4157.267 | 4157.267 | 0.000 | 0: 4157.267 | 0: 4157.267 |
| values | — | A | fullLifecycle | 12 | 119 | 8431.825 | 8431.825 | 8431.825 | 0.000 | 0: 8431.825 | 0: 8431.825 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5428540.000 | 428.569 | 8.477 |
| A | scaleDown | 5 | 4409840.000 | 432.337 | 8.548 |
| A | fullLifecycle | 11 | 4965494.545 | 430.082 | 8.506 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3126055.667 | 246.794 | 4.882 |
| A | scaleDown | 5 | 2596615.600 | 254.570 | 5.033 |
| A | fullLifecycle | 11 | 2885401.091 | 249.917 | 4.943 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 257,626 | 3.882 | 1.800 | 233.300 |
| apply | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 313,013 | 3.195 | 1.600 | 446.200 |
| apply | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 321,939 | 3.106 | 1.500 | 576.300 |
| apply | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 331,346 | 3.018 | 1.500 | 576.300 |
| apply | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 323,194 | 3.094 | 1.500 | 1530.800 |
| apply | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 317,110 | 3.153 | 1.500 | 1738.400 |
| apply | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 320,134 | 3.124 | 1.500 | 1738.400 |
| apply | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 323,935 | 3.087 | 1.500 | 1738.400 |
| apply | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 323,701 | 3.089 | 1.500 | 1738.400 |
| apply | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 328,437 | 3.045 | 1.500 | 1738.400 |
| apply | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 332,708 | 3.006 | 1.300 | 1738.400 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 334,709 | 2.988 | 1.100 | 1738.400 |
| insert | head | 0 | up | 1,000 | 51,204 | A | 500 | 925,926 | 1.080 | 0.300 | 53.600 |
| insert | head | 0 | up | 5,000 | 250,037 | A | 2,500 | 1,106,537 | 0.904 | 0.300 | 53.600 |
| insert | head | 0 | up | 10,000 | 506,154 | A | 5,000 | 1,256,566 | 0.796 | 0.300 | 53.600 |
| insert | head | 0 | up | 15,000 | 762,134 | A | 7,500 | 1,322,285 | 0.756 | 0.300 | 53.600 |
| insert | head | 0 | up | 20,000 | 1,012,964 | A | 10,000 | 1,333,404 | 0.750 | 0.300 | 53.600 |
| insert | head | 0 | up | 25,000 | 1,259,727 | A | 12,500 | 1,344,578 | 0.744 | 0.300 | 53.600 |
| insert | head | 0 | down | 20,000 | 1,009,630 | A | 12,500 | 1,344,578 | 0.744 | 0.300 | 53.600 |
| insert | head | 0 | down | 15,000 | 759,633 | A | 12,500 | 1,344,578 | 0.744 | 0.300 | 53.600 |
| insert | head | 0 | down | 10,000 | 507,941 | A | 12,500 | 1,344,578 | 0.744 | 0.300 | 53.600 |
| insert | head | 0 | down | 5,000 | 250,794 | A | 12,500 | 1,344,578 | 0.744 | 0.300 | 53.600 |
| insert | head | 0 | down | 1,000 | 51,447 | A | 12,500 | 1,344,578 | 0.744 | 0.300 | 53.600 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,344,578 | 0.744 | 0.300 | 53.600 |
| insert | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 518,027 | 1.930 | 0.500 | 332.100 |
| insert | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 541,489 | 1.847 | 0.500 | 1027.200 |
| insert | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 596,605 | 1.676 | 0.500 | 1027.200 |
| insert | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 622,616 | 1.606 | 0.500 | 1027.200 |
| insert | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 607,589 | 1.646 | 0.500 | 1027.200 |
| insert | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 604,352 | 1.655 | 0.500 | 1027.200 |
| insert | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 592,908 | 1.687 | 0.500 | 1027.200 |
| insert | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 578,922 | 1.727 | 0.500 | 1440.400 |
| insert | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 587,429 | 1.702 | 0.500 | 1440.400 |
| insert | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 594,603 | 1.682 | 0.500 | 1440.400 |
| insert | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 600,265 | 1.666 | 0.400 | 1440.400 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 605,532 | 1.651 | 0.400 | 1440.400 |
| insert | tail | 0 | up | 1,000 | 51,204 | A | 500 | 1,100,837 | 0.908 | 0.300 | 25.400 |
| insert | tail | 0 | up | 5,000 | 250,037 | A | 2,500 | 1,301,880 | 0.768 | 0.300 | 50.600 |
| insert | tail | 0 | up | 10,000 | 506,154 | A | 5,000 | 1,430,083 | 0.699 | 0.300 | 79.100 |
| insert | tail | 0 | up | 15,000 | 762,134 | A | 7,500 | 1,450,453 | 0.689 | 0.300 | 151.000 |
| insert | tail | 0 | up | 20,000 | 1,012,964 | A | 10,000 | 1,412,210 | 0.708 | 0.300 | 351.500 |
| insert | tail | 0 | up | 25,000 | 1,259,727 | A | 12,500 | 1,395,089 | 0.717 | 0.300 | 351.500 |
| insert | tail | 0 | down | 20,000 | 1,009,630 | A | 12,500 | 1,395,089 | 0.717 | 0.300 | 351.500 |
| insert | tail | 0 | down | 15,000 | 759,633 | A | 12,500 | 1,395,089 | 0.717 | 0.300 | 351.500 |
| insert | tail | 0 | down | 10,000 | 507,941 | A | 12,500 | 1,395,089 | 0.717 | 0.300 | 351.500 |
| insert | tail | 0 | down | 5,000 | 250,794 | A | 12,500 | 1,395,089 | 0.717 | 0.300 | 351.500 |
| insert | tail | 0 | down | 1,000 | 51,447 | A | 12,500 | 1,395,089 | 0.717 | 0.300 | 351.500 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,395,089 | 0.717 | 0.300 | 351.500 |
| remove | head | 0 | up | 1,000 | 51,204 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 250,037 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 506,154 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 762,134 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,012,964 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,259,727 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,009,630 | A | 2,500 | 694,695 | 1.439 | 0.900 | 15.200 |
| remove | head | 0 | down | 15,000 | 759,633 | A | 5,000 | 675,621 | 1.480 | 0.800 | 331.300 |
| remove | head | 0 | down | 10,000 | 507,941 | A | 7,500 | 653,361 | 1.531 | 0.800 | 661.800 |
| remove | head | 0 | down | 5,000 | 250,794 | A | 10,000 | 684,144 | 1.462 | 0.700 | 661.800 |
| remove | head | 0 | down | 1,000 | 51,447 | A | 12,000 | 700,223 | 1.428 | 0.700 | 661.800 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 706,806 | 1.415 | 0.700 | 661.800 |
| remove | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 416,840 | 2.399 | 0.800 | 480.700 |
| remove | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 490,220 | 2.040 | 0.800 | 480.700 |
| remove | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 491,039 | 2.037 | 0.800 | 480.700 |
| remove | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 500,484 | 1.998 | 0.800 | 660.700 |
| remove | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 493,604 | 2.026 | 0.800 | 660.700 |
| remove | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 489,071 | 2.045 | 0.800 | 660.700 |
| remove | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 486,030 | 2.057 | 0.800 | 660.700 |
| remove | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 486,236 | 2.057 | 0.800 | 660.700 |
| remove | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 488,140 | 2.049 | 0.800 | 660.700 |
| remove | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 494,966 | 2.020 | 0.800 | 660.700 |
| remove | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 500,536 | 1.998 | 0.800 | 660.700 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 504,526 | 1.982 | 0.700 | 660.700 |
| remove | tail | 0 | up | 1,000 | 51,204 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 250,037 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 506,154 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 762,134 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,012,964 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,259,727 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,009,630 | A | 2,500 | 798,492 | 1.252 | 0.800 | 50.200 |
| remove | tail | 0 | down | 15,000 | 759,633 | A | 5,000 | 805,906 | 1.241 | 0.800 | 50.200 |
| remove | tail | 0 | down | 10,000 | 507,941 | A | 7,500 | 814,757 | 1.227 | 0.700 | 50.200 |
| remove | tail | 0 | down | 5,000 | 250,794 | A | 10,000 | 828,109 | 1.208 | 0.700 | 50.200 |
| remove | tail | 0 | down | 1,000 | 51,447 | A | 12,000 | 832,686 | 1.201 | 0.700 | 50.200 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 836,686 | 1.195 | 0.700 | 50.200 |
| replace | head | 0 | up | 1,000 | 51,204 | A | 1,000 | 431,239 | 2.319 | 1.200 | 47.800 |
| replace | head | 0 | up | 5,000 | 250,037 | A | 5,000 | 490,239 | 2.040 | 1.100 | 293.800 |
| replace | head | 0 | up | 10,000 | 506,154 | A | 10,000 | 523,536 | 1.910 | 1.100 | 293.800 |
| replace | head | 0 | up | 15,000 | 762,134 | A | 15,000 | 543,266 | 1.841 | 1.100 | 345.600 |
| replace | head | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 549,001 | 1.821 | 1.100 | 345.600 |
| replace | head | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 548,463 | 1.823 | 1.000 | 646.300 |
| replace | head | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 541,183 | 1.848 | 1.000 | 646.300 |
| replace | head | 0 | down | 15,000 | 759,633 | A | 35,000 | 535,509 | 1.867 | 1.000 | 646.300 |
| replace | head | 0 | down | 10,000 | 507,941 | A | 40,000 | 531,139 | 1.883 | 1.000 | 646.300 |
| replace | head | 0 | down | 5,000 | 250,794 | A | 45,000 | 519,505 | 1.925 | 1.000 | 1783.600 |
| replace | head | 0 | down | 1,000 | 51,447 | A | 49,000 | 520,939 | 1.920 | 1.000 | 1783.600 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 523,335 | 1.911 | 0.900 | 1783.600 |
| replace | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 382,907 | 2.612 | 1.100 | 58.300 |
| replace | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 375,412 | 2.664 | 1.100 | 376.900 |
| replace | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 380,659 | 2.627 | 1.100 | 376.900 |
| replace | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 375,885 | 2.660 | 1.100 | 731.400 |
| replace | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 371,918 | 2.689 | 1.100 | 731.400 |
| replace | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 369,784 | 2.704 | 1.100 | 731.400 |
| replace | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 370,143 | 2.702 | 1.100 | 731.400 |
| replace | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 370,078 | 2.702 | 1.100 | 731.400 |
| replace | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 371,286 | 2.693 | 1.100 | 731.400 |
| replace | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 373,589 | 2.677 | 1.100 | 731.400 |
| replace | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 378,662 | 2.641 | 1.000 | 731.400 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 381,761 | 2.619 | 0.900 | 731.400 |
| replace | tail | 0 | up | 1,000 | 51,204 | A | 1,000 | 466,005 | 2.146 | 1.100 | 106.000 |
| replace | tail | 0 | up | 5,000 | 250,037 | A | 5,000 | 517,480 | 1.932 | 1.100 | 257.600 |
| replace | tail | 0 | up | 10,000 | 506,154 | A | 10,000 | 515,005 | 1.942 | 1.100 | 949.100 |
| replace | tail | 0 | up | 15,000 | 762,134 | A | 15,000 | 549,314 | 1.820 | 1.000 | 949.100 |
| replace | tail | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 545,212 | 1.834 | 1.000 | 949.100 |
| replace | tail | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 549,861 | 1.819 | 1.000 | 949.100 |
| replace | tail | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 129,639 | 7.714 | 1.000 | 1234.100 |
| replace | tail | 0 | down | 15,000 | 759,633 | A | 35,000 | 96,587 | 10.353 | 1.000 | 1234.100 |
| replace | tail | 0 | down | 10,000 | 507,941 | A | 40,000 | 97,211 | 10.287 | 1.000 | 1234.100 |
| replace | tail | 0 | down | 5,000 | 250,794 | A | 45,000 | 94,913 | 10.536 | 0.900 | 1234.100 |
| replace | tail | 0 | down | 1,000 | 51,447 | A | 49,000 | 97,546 | 10.252 | 0.900 | 1234.100 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 99,075 | 10.093 | 0.900 | 1234.100 |
| value | head | 0 | up | 1,000 | 51,204 | A | 1,000 | 1,517,451 | 0.659 | 0.100 | 221.100 |
| value | head | 0 | up | 5,000 | 250,037 | A | 5,000 | 2,692,660 | 0.371 | 0.100 | 221.100 |
| value | head | 0 | up | 10,000 | 506,154 | A | 10,000 | 3,109,549 | 0.322 | 0.100 | 221.100 |
| value | head | 0 | up | 15,000 | 762,134 | A | 15,000 | 3,303,383 | 0.303 | 0.100 | 221.100 |
| value | head | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 3,393,166 | 0.295 | 0.100 | 221.100 |
| value | head | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 3,436,143 | 0.291 | 0.100 | 221.100 |
| value | head | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 3,189,521 | 0.314 | 0.100 | 221.100 |
| value | head | 0 | down | 15,000 | 759,633 | A | 35,000 | 3,053,835 | 0.327 | 0.100 | 221.100 |
| value | head | 0 | down | 10,000 | 507,941 | A | 40,000 | 2,969,584 | 0.337 | 0.100 | 221.100 |
| value | head | 0 | down | 5,000 | 250,794 | A | 45,000 | 2,922,590 | 0.342 | 0.100 | 221.100 |
| value | head | 0 | down | 1,000 | 51,447 | A | 49,000 | 2,889,850 | 0.346 | 0.100 | 221.100 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,890,457 | 0.346 | 0.100 | 221.100 |
| value | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 1,233,046 | 0.811 | 0.100 | 50.400 |
| value | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 1,033,634 | 0.967 | 0.100 | 50.400 |
| value | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 962,371 | 1.039 | 0.100 | 91.600 |
| value | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 959,128 | 1.043 | 0.100 | 91.600 |
| value | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 934,641 | 1.070 | 0.100 | 91.600 |
| value | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 916,318 | 1.091 | 0.100 | 129.600 |
| value | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 913,442 | 1.095 | 0.100 | 129.600 |
| value | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 915,895 | 1.092 | 0.100 | 129.600 |
| value | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 918,947 | 1.088 | 0.100 | 129.600 |
| value | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 931,031 | 1.074 | 0.100 | 129.600 |
| value | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 944,598 | 1.059 | 0.100 | 129.600 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 953,171 | 1.049 | 0.100 | 129.600 |
| value | tail | 0 | up | 1,000 | 51,204 | A | 1,000 | 5,464,481 | 0.183 | 0.100 | 5.100 |
| value | tail | 0 | up | 5,000 | 250,037 | A | 5,000 | 5,514,503 | 0.181 | 0.100 | 24.900 |
| value | tail | 0 | up | 10,000 | 506,154 | A | 10,000 | 5,867,856 | 0.170 | 0.100 | 53.100 |
| value | tail | 0 | up | 15,000 | 762,134 | A | 15,000 | 6,232,860 | 0.160 | 0.000 | 53.100 |
| value | tail | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 6,416,426 | 0.156 | 0.000 | 53.100 |
| value | tail | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 6,503,642 | 0.154 | 0.000 | 53.100 |
| value | tail | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 5,989,937 | 0.167 | 0.000 | 53.100 |
| value | tail | 0 | down | 15,000 | 759,633 | A | 35,000 | 5,628,005 | 0.178 | 0.000 | 53.100 |
| value | tail | 0 | down | 10,000 | 507,941 | A | 40,000 | 5,401,026 | 0.185 | 0.000 | 53.100 |
| value | tail | 0 | down | 5,000 | 250,794 | A | 45,000 | 5,192,827 | 0.193 | 0.000 | 59.500 |
| value | tail | 0 | down | 1,000 | 51,447 | A | 49,000 | 5,135,246 | 0.195 | 0.000 | 59.500 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,134,683 | 0.195 | 0.000 | 59.500 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,561 | 390.500 |
| create | — | 0 | up | 5,000 | A | 1 | 1,124 | 889.800 |
| create | — | 0 | up | 10,000 | A | 1 | 646 | 1547.800 |
| create | — | 0 | up | 15,000 | A | 1 | 413 | 2422.400 |
| create | — | 0 | up | 20,000 | A | 1 | 309 | 3239.300 |
| create | — | 0 | up | 25,000 | A | 1 | 244 | 4094.600 |
| create | — | 0 | down | 20,000 | A | 1 | 277 | 3609.700 |
| create | — | 0 | down | 15,000 | A | 1 | 365 | 2740.100 |
| create | — | 0 | down | 10,000 | A | 1 | 559 | 1789.400 |
| create | — | 0 | down | 5,000 | A | 1 | 1,178 | 848.600 |
| create | — | 0 | down | 1,000 | A | 1 | 6,784 | 147.400 |
| create | — | 0 | down | 0 | A | 1 | 74,074 | 13.500 |
| sequence | — | 0 | up | 1,000 | A | 1 | 434 | 2305.100 |
| sequence | — | 0 | up | 5,000 | A | 1 | 126 | 7917.700 |
| sequence | — | 0 | up | 10,000 | A | 1 | 79 | 12618.300 |
| sequence | — | 0 | up | 15,000 | A | 1 | 72 | 13900.300 |
| sequence | — | 0 | up | 20,000 | A | 1 | 50 | 20161.700 |
| sequence | — | 0 | up | 25,000 | A | 1 | 43 | 22992.300 |
| sequence | — | 0 | down | 20,000 | A | 1 | 52 | 19126.200 |
| sequence | — | 0 | down | 15,000 | A | 1 | 66 | 15087.400 |
| sequence | — | 0 | down | 10,000 | A | 1 | 74 | 13434.200 |
| sequence | — | 0 | down | 5,000 | A | 1 | 110 | 9056.600 |
| sequence | — | 0 | down | 1,000 | A | 1 | 143 | 6969.400 |
| sequence | — | 0 | down | 0 | A | 1 | 843 | 1186.900 |
| values | — | 0 | up | 1,000 | A | 1 | 554 | 1805.200 |
| values | — | 0 | up | 5,000 | A | 1 | 220 | 4544.600 |
| values | — | 0 | up | 10,000 | A | 1 | 50 | 19827.500 |
| values | — | 0 | up | 15,000 | A | 1 | 34 | 29220.800 |
| values | — | 0 | up | 20,000 | A | 1 | 96 | 10401.500 |
| values | — | 0 | up | 25,000 | A | 1 | 96 | 10438.700 |
| values | — | 0 | down | 20,000 | A | 1 | 115 | 8674.600 |
| values | — | 0 | down | 15,000 | A | 1 | 136 | 7329.700 |
| values | — | 0 | down | 10,000 | A | 1 | 182 | 5506.200 |
| values | — | 0 | down | 5,000 | A | 1 | 368 | 2720.500 |
| values | — | 0 | down | 1,000 | A | 1 | 1,422 | 703.200 |
| values | — | 0 | down | 0 | A | 1 | 106,383 | 9.400 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.622 | 0.232 | 0.391 |
| 0 | up | 5000 | 3.076 | 1.168 | 1.908 |
| 0 | up | 10000 | 6.205 | 2.343 | 3.862 |
| 0 | up | 15000 | 9.457 | 3.643 | 5.815 |
| 0 | up | 20000 | 12.841 | 5.112 | 7.728 |
| 0 | up | 25000 | 16.247 | 6.636 | 9.611 |
| 0 | down | 20000 | 13.315 | 5.612 | 7.703 |
| 0 | down | 15000 | 9.926 | 4.131 | 5.796 |
| 0 | down | 10000 | 7.170 | 3.295 | 3.875 |
| 0 | down | 5000 | 4.075 | 2.161 | 1.913 |
| 0 | down | 1000 | 1.812 | 1.420 | 0.393 |
| 0 | down | 0 | 1.230 | 1.230 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 51,204 | 0.411 | 430.756 | 8.413 | 121.168 | 15.543 |
| 0 | up | A | 5,000 | 5,000 | 250,037 | 2.010 | 421.606 | 8.431 | 154.289 | 19.559 |
| 0 | up | A | 10,000 | 10,000 | 506,154 | 4.075 | 427.300 | 8.442 | 196.871 | 24.476 |
| 0 | up | A | 15,000 | 15,000 | 762,134 | 6.154 | 430.176 | 8.467 | 209.336 | 29.390 |
| 0 | up | A | 20,000 | 20,000 | 1,012,964 | 8.198 | 429.835 | 8.487 | 280.457 | 34.212 |
| 0 | up | A | 25,000 | 25,000 | 1,259,727 | 10.214 | 428.405 | 8.502 | 295.809 | 38.943 |
| 0 | down | A | 20,000 | 20,000 | 1,009,630 | 8.241 | 432.089 | 8.559 | 295.242 | 34.188 |
| 0 | down | A | 15,000 | 15,000 | 759,633 | 6.201 | 433.508 | 8.560 | 300.809 | 29.423 |
| 0 | down | A | 10,000 | 10,000 | 507,941 | 4.136 | 433.718 | 8.539 | 299.129 | 24.653 |
| 0 | down | A | 5,000 | 5,000 | 250,794 | 2.034 | 426.570 | 8.504 | 296.891 | 19.796 |
| 0 | down | A | 1,000 | 1,000 | 51,447 | 0.415 | 434.772 | 8.451 | 295.801 | 15.997 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 296.934 | 14.906 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 51204 | 187497 | 187.497 | 3.662 | 277.53 | 14.54 | 165.41 | 12.36 |
| 0 | up | A | 5000 | 250037 | 1195941 | 239.188 | 4.783 | 1610.38 | 73.38 | 813.25 | 61.61 |
| 0 | up | A | 10000 | 506154 | 2435808 | 243.581 | 4.812 | 3265.74 | 148.71 | 1649.99 | 124.72 |
| 0 | up | A | 15000 | 762134 | 3716482 | 247.765 | 4.876 | 4950.79 | 226.25 | 3565.22 | 200.28 |
| 0 | up | A | 20000 | 1012964 | 4982573 | 249.129 | 4.919 | 7121.78 | 311.32 | 5144.59 | 263.55 |
| 0 | up | A | 25000 | 1259727 | 6238033 | 249.521 | 4.952 | 9237.87 | 392.58 | 6535.88 | 334.89 |
| 0 | down | A | 20000 | 1009630 | 5113545 | 255.677 | 5.065 | 7558.03 | 326.74 | 5304.48 | 278.22 |
| 0 | down | A | 15000 | 759633 | 3843527 | 256.235 | 5.060 | 5727.79 | 247.31 | 4004.31 | 209.86 |
| 0 | down | A | 10000 | 507941 | 2547329 | 254.733 | 5.015 | 3837.94 | 164.83 | 2677.99 | 139.88 |
| 0 | down | A | 5000 | 250794 | 1235293 | 247.059 | 4.926 | 1887.01 | 79.61 | 1318.78 | 67.84 |
| 0 | down | A | 1000 | 51447 | 243384 | 243.384 | 4.731 | 382.91 | 15.90 | 268.58 | 13.64 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 428.569 | 8.477 | 246.794 | 4.882 |
| 0 | A | scaleDown | 432.337 | 8.548 | 254.570 | 5.033 |
| 0 | A | fullLifecycle | 430.082 | 8.506 | 249.917 | 4.943 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
