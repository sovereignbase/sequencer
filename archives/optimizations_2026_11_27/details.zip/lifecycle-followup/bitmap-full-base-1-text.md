# Large string benchmarks

2026-11-27T20:48:01.190Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2353.93 | 0.00 |
| 1024 | insert.append | array | 13307.66 | 0.00 |
| 1024 | replace | array | 3141.76 | 0.00 |
| 1024 | remove | array | 1154.65 | 0.00 |
| 1024 | remove.middle | array | 2083.57 | 0.00 |
| 1024 | replace.middle | array | 2645.56 | 0.00 |
| 1024 | apply | array | 785.88 | 0.00 |
| 1024 | apply.array | array | 656.41 | 0.00 |
| 1024 | concurrent.apply | array | 64946.23 | 0.00 |
| 1024 | merge | array | 3048.54 | 0.00 |
| 1024 | create | array | 3110.56 | 0.00 |
| 1024 | value.random | array | 45.51 | 0.00 |
| 1024 | values.range | array | 114.50 | 0.00 |
| 1024 | values.array | array | 1254.53 | 0.00 |
| 1024 | values.text | array | 13246.56 | 0.00 |
| 1024 | sequence.array | array | 1718.02 | 0.00 |
| 1024 | sequence.text | array | 9562.94 | 0.00 |
| 1024 | sequence.edited.text | array | 14456.01 | 0.00 |
| 1024 | sequence.masked.text | array | 10755.37 | 0.00 |
| 1024 | insert | string | 447.72 | 0.00 |
| 1024 | insert.append | string | 3958.02 | 0.00 |
| 1024 | replace | string | 1169.07 | 0.00 |
| 1024 | remove | string | 903.10 | 0.00 |
| 1024 | remove.middle | string | 945.67 | 0.00 |
| 1024 | replace.middle | string | 1439.71 | 0.00 |
| 1024 | apply | string | 769.02 | 0.00 |
| 1024 | apply.array | string | 2503.86 | 0.00 |
| 1024 | concurrent.apply | string | 4080.33 | 0.00 |
| 1024 | merge | string | 1456.37 | 0.00 |
| 1024 | create | string | 1024.27 | 0.00 |
| 1024 | value.random | string | 57.52 | 0.00 |
| 1024 | values.range | string | 161.68 | 0.00 |
| 1024 | values.array | string | 1964.95 | 0.00 |
| 1024 | values.text | string | 98.80 | 0.00 |
| 1024 | sequence.array | string | 2096.69 | 0.00 |
| 1024 | sequence.text | string | 190.77 | 0.00 |
| 1024 | sequence.edited.text | string | 2261.52 | 0.00 |
| 1024 | sequence.masked.text | string | 3465.19 | 0.00 |
| 65536 | insert | array | 240940.38 | 0.00 |
| 65536 | insert.append | array | 1064072.00 | 0.00 |
| 65536 | replace | array | 236994.34 | 0.00 |
| 65536 | remove | array | 2361.96 | 0.00 |
| 65536 | remove.middle | array | 232526.61 | 0.00 |
| 65536 | replace.middle | array | 233850.91 | 0.00 |
| 65536 | apply | array | 871.69 | 0.00 |
| 65536 | apply.array | array | 523.35 | 0.00 |
| 65536 | concurrent.apply | array | 3978428.57 | 0.00 |
| 65536 | merge | array | 209304.17 | 0.00 |
| 65536 | create | array | 211927.97 | 0.00 |
| 65536 | value.random | array | 51.69 | 0.00 |
| 65536 | values.range | array | 131.05 | 0.00 |
| 65536 | values.array | array | 199946.03 | 0.00 |
| 65536 | values.text | array | 792612.50 | 0.00 |
| 65536 | sequence.array | array | 217053.97 | 0.00 |
| 65536 | sequence.text | array | 781937.50 | 0.00 |
| 65536 | sequence.edited.text | array | 943148.15 | 0.00 |
| 65536 | sequence.masked.text | array | 737732.35 | 0.00 |
| 65536 | insert | string | 396.01 | 0.00 |
| 65536 | insert.append | string | 23566.07 | 0.00 |
| 65536 | replace | string | 1307.95 | 0.00 |
| 65536 | remove | string | 994.59 | 0.00 |
| 65536 | remove.middle | string | 980.62 | 0.00 |
| 65536 | replace.middle | string | 1346.75 | 0.00 |
| 65536 | apply | string | 859.36 | 0.00 |
| 65536 | apply.array | string | 246488.28 | 0.00 |
| 65536 | concurrent.apply | string | 142611.36 | 0.00 |
| 65536 | merge | string | 1132.09 | 0.00 |
| 65536 | create | string | 912.13 | 0.00 |
| 65536 | value.random | string | 43.25 | 0.00 |
| 65536 | values.range | string | 179.95 | 0.00 |
| 65536 | values.array | string | 253665.62 | 0.00 |
| 65536 | values.text | string | 62.67 | 0.00 |
| 65536 | sequence.array | string | 242932.81 | 0.00 |
| 65536 | sequence.text | string | 200.23 | 0.00 |
| 65536 | sequence.edited.text | string | 87390.59 | 0.00 |
| 65536 | sequence.masked.text | string | 3220.90 | 0.00 |
| 1048576 | insert | array | 3585950.00 | 0.00 |
| 1048576 | insert.append | array | 25515000.00 | 0.00 |
| 1048576 | replace | array | 3126637.50 | 0.00 |
| 1048576 | remove | array | 10134.04 | 0.00 |
| 1048576 | remove.middle | array | 2989477.78 | 0.00 |
| 1048576 | replace.middle | array | 2824255.56 | 0.00 |
| 1048576 | apply | array | 1060.36 | 0.00 |
| 1048576 | apply.array | array | 553.45 | 0.00 |
| 1048576 | concurrent.apply | array | 72354700.00 | 0.00 |
| 1048576 | merge | array | 3243062.50 | 0.00 |
| 1048576 | create | array | 3254250.00 | 0.00 |
| 1048576 | value.random | array | 38.20 | 0.00 |
| 1048576 | values.range | array | 102.90 | 0.00 |
| 1048576 | values.array | array | 2273563.64 | 0.00 |
| 1048576 | values.text | array | 12642750.00 | 0.00 |
| 1048576 | sequence.array | array | 2300318.18 | 0.00 |
| 1048576 | sequence.text | array | 59064100.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 65191050.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 61529100.00 | 0.00 |
| 1048576 | insert | string | 536.41 | 0.00 |
| 1048576 | insert.append | string | 546015.22 | 0.00 |
| 1048576 | replace | string | 1481.13 | 0.00 |
| 1048576 | remove | string | 1268.25 | 0.00 |
| 1048576 | remove.middle | string | 891.32 | 0.00 |
| 1048576 | replace.middle | string | 1680.70 | 0.00 |
| 1048576 | apply | string | 1218.01 | 0.00 |
| 1048576 | apply.array | string | 3351100.00 | 0.00 |
| 1048576 | concurrent.apply | string | 1301600.00 | 0.00 |
| 1048576 | merge | string | 1214.44 | 0.00 |
| 1048576 | create | string | 860.91 | 0.00 |
| 1048576 | value.random | string | 63.85 | 0.00 |
| 1048576 | values.range | string | 144.40 | 0.00 |
| 1048576 | values.array | string | 6916425.00 | 0.00 |
| 1048576 | values.text | string | 127.45 | 0.00 |
| 1048576 | sequence.array | string | 3198150.00 | 0.00 |
| 1048576 | sequence.text | string | 177.01 | 0.00 |
| 1048576 | sequence.edited.text | string | 1576406.25 | 0.00 |
| 1048576 | sequence.masked.text | string | 3218.34 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
