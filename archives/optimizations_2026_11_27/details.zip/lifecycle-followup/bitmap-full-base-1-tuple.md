# Tuple benchmarks

2026-11-27T20:47:47.005Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 3,000,012 | 2,477,942 | 0.83× |
| 2 | create.sequence | 962,539 | 833,638 | 0.87× |
| 2 | replace.random | 1,245,752 | 1,540,106 | 1.24× |
| 2 | apply.replace | 715,123 | 877,486 | 1.23× |
| 2 | apply.duplicate | 1,762,596 | 1,717,123 | 0.97× |
| 2 | merge.duplicate | 1,277,267 | 1,451,253 | 1.14× |
| 2 | length | 133,520,664 | 140,355,753 | 1.05× |
| 2 | value.random | 35,385,585 | 54,897,953 | 1.55× |
| 2 | values | 12,965,509 | 13,072,714 | 1.01× |
| 2 | sequence | 3,295,318 | 2,936,809 | 0.89× |
| 4 | create.empty | 2,526,269 | 2,388,398 | 0.95× |
| 4 | create.sequence | 698,469 | 696,630 | 1.00× |
| 4 | replace.random | 1,062,056 | 1,518,813 | 1.43× |
| 4 | apply.replace | 668,798 | 995,364 | 1.49× |
| 4 | apply.duplicate | 1,739,010 | 1,739,973 | 1.00× |
| 4 | merge.duplicate | 1,300,599 | 1,262,863 | 0.97× |
| 4 | length | 5,109,551 | 32,575,865 | 6.38× |
| 4 | value.random | 22,908,589 | 57,377,905 | 2.50× |
| 4 | values | 6,378,292 | 6,601,338 | 1.03× |
| 4 | sequence | 2,649,729 | 2,570,826 | 0.97× |
| 8 | create.empty | 2,480,244 | 2,455,356 | 0.99× |
| 8 | create.sequence | 477,882 | 526,346 | 1.10× |
| 8 | replace.random | 1,021,164 | 1,582,454 | 1.55× |
| 8 | apply.replace | 632,185 | 1,046,664 | 1.66× |
| 8 | apply.duplicate | 1,718,448 | 1,685,960 | 0.98× |
| 8 | merge.duplicate | 973,885 | 923,859 | 0.95× |
| 8 | length | 37,914,882 | 35,486,109 | 0.94× |
| 8 | value.random | 18,976,656 | 53,591,480 | 2.82× |
| 8 | values | 4,681,161 | 4,906,329 | 1.05× |
| 8 | sequence | 1,657,319 | 1,905,759 | 1.15× |
| 100 | create.empty | 2,420,326 | 2,249,089 | 0.93× |
| 100 | create.sequence | 70,456 | 90,702 | 1.29× |
| 100 | replace.random | 1,030,821 | 1,562,712 | 1.52× |
| 100 | apply.replace | 682,392 | 1,012,181 | 1.48× |
| 100 | apply.duplicate | 1,733,777 | 1,682,103 | 0.97× |
| 100 | merge.duplicate | 105,528 | 76,851 | 0.73× |
| 100 | length | 37,884,782 | 38,283,206 | 1.01× |
| 100 | value.random | 12,656,649 | 57,405,319 | 4.54× |
| 100 | values | 517,303 | 666,338 | 1.29× |
| 100 | sequence | 184,521 | 184,504 | 1.00× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
