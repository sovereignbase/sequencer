# Words benchmarks

2026-11-27T20:48:23.848Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 33,108 | 209,052 | 178 |
| append | packed | 5.90 | 3.61 | 13.98 | 30,857 | 184,089 | 293 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,646 | 795 | 249 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 32,949 | 1,669 | 248 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 445 | 234 | 80 |
| random | packed | 49.58 | 35.38 | 23.45 | 14,385 | 515 | 127 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 618 | 205 | 91 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 17,253 | 405 | 148 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 606.93 | 0.00 |
| append | numeric | encode | 30203.99 | 0.00 |
| append | numeric | decode | 2849.81 | 0.00 |
| append | numeric | create | 1914.19 | 0.00 |
| append | numeric | load | 4783.49 | 0.00 |
| append | numeric | apply | 2790850.00 | 0.00 |
| append | numeric | receive | 5615477.78 | 0.00 |
| append | binary | sequence | 547.22 | 0.00 |
| append | binary | encode | 32407.45 | 0.00 |
| append | binary | decode | 1794.78 | 0.00 |
| append | binary | create | 1998.34 | 0.00 |
| append | binary | load | 5432.15 | 0.00 |
| append | binary | apply | 1566893.75 | 0.00 |
| append | binary | receive | 3409826.67 | 0.00 |
| prepend | numeric | sequence | 469055.14 | 0.00 |
| prepend | numeric | encode | 607673.49 | 0.00 |
| prepend | numeric | decode | 162160.19 | 0.00 |
| prepend | numeric | create | 623414.81 | 0.00 |
| prepend | numeric | load | 1258405.00 | 0.00 |
| prepend | numeric | apply | 2460461.90 | 0.00 |
| prepend | numeric | receive | 4020723.08 | 0.00 |
| prepend | binary | sequence | 335554.00 | 0.00 |
| prepend | binary | encode | 30350.21 | 0.00 |
| prepend | binary | decode | 2073.00 | 0.00 |
| prepend | binary | create | 621996.30 | 0.00 |
| prepend | binary | load | 599315.48 | 0.00 |
| prepend | binary | apply | 2673252.63 | 0.00 |
| prepend | binary | receive | 4033823.08 | 0.00 |
| random | numeric | sequence | 951867.92 | 0.00 |
| random | numeric | encode | 2245421.74 | 0.00 |
| random | numeric | decode | 696008.33 | 0.00 |
| random | numeric | create | 1730837.93 | 0.00 |
| random | numeric | load | 4279741.67 | 0.00 |
| random | numeric | apply | 7859028.57 | 0.00 |
| random | numeric | receive | 12535925.00 | 0.00 |
| random | binary | sequence | 912567.27 | 0.00 |
| random | binary | encode | 69516.71 | 0.00 |
| random | binary | decode | 1577.33 | 0.00 |
| random | binary | create | 1948923.08 | 0.00 |
| random | binary | load | 1942369.23 | 0.00 |
| random | binary | apply | 6524900.00 | 0.00 |
| random | binary | receive | 7844814.29 | 0.00 |
| concurrent | numeric | sequence | 850486.44 | 0.00 |
| concurrent | numeric | encode | 1618067.74 | 0.00 |
| concurrent | numeric | decode | 869327.59 | 0.00 |
| concurrent | numeric | create | 2488533.33 | 0.00 |
| concurrent | numeric | load | 4874636.36 | 0.00 |
| concurrent | numeric | apply | 6002966.67 | 0.00 |
| concurrent | numeric | receive | 11032180.00 | 0.00 |
| concurrent | binary | sequence | 755485.07 | 0.00 |
| concurrent | binary | encode | 57959.33 | 0.00 |
| concurrent | binary | decode | 2985.90 | 0.00 |
| concurrent | binary | create | 2464052.38 | 0.00 |
| concurrent | binary | load | 2471976.19 | 0.00 |
| concurrent | binary | apply | 5179900.00 | 0.00 |
| concurrent | binary | receive | 6741812.50 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
