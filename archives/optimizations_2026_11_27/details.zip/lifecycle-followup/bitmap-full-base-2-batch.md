# Batch benchmarks

2026-11-27T20:50:09.782Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 2,469,339 | 1,173,962 | 516,769 | 76.05 | 5.99 | 0.012 |
| append | batch | 1,802,830 | 124,223,602 | 150,753,769 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,413,028 | 1,636,304 | 892,698 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 1,510,118 | 2,201,916 | 2,050,441 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 1,108,074 | 1,021,938 | 739,882 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 1,178,851 | 1,615,204 | 1,538,107 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 1,177,302 | 1,219,959 | 774,044 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 1,010,390 | 1,816,475 | 1,676,727 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,208,569 | 1,152,616 | 822,944 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,536,787 | 1,807,773 | 1,740,972 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,270,998 | 1,312,752 | 900,374 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,336,645 | 1,808,400 | 1,585,624 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 692,749 | 973,686 | 719,265 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 897,210 | 1,197,055 | 1,142,139 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,176,079 | 1,455,251 | 1,006,914 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 1,353,226 | 1,764,057 | 1,598,785 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,084,305 | 1,171,280 | 897,733 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 1,194,256 | 1,524,158 | 1,530,671 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 726,256 | 1,015,667 | 711,706 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 885,465 | 1,166,067 | 1,221,934 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 2.430 | 0.000 |
| append | individual | apply | 5.111 | 0.000 |
| append | individual | receive | 11.611 | 0.000 |
| append | individual | encode | 6.603 | 0.000 |
| append | individual | decode | 7.239 | 0.000 |
| append | batch | author | 3.328 | 0.000 |
| append | batch | apply | 0.048 | 0.000 |
| append | batch | receive | 0.040 | 0.000 |
| append | batch | encode | 0.288 | 0.000 |
| append | batch | decode | 0.134 | 0.000 |
| prepend | individual | author | 4.246 | 0.000 |
| prepend | individual | apply | 3.667 | 0.000 |
| prepend | individual | receive | 6.721 | 0.000 |
| prepend | individual | encode | 5.716 | 0.000 |
| prepend | individual | decode | 7.505 | 0.000 |
| prepend | batch | author | 3.973 | 0.000 |
| prepend | batch | apply | 2.725 | 0.000 |
| prepend | batch | receive | 2.926 | 0.000 |
| prepend | batch | encode | 0.214 | 0.000 |
| prepend | batch | decode | 0.098 | 0.000 |
| random.characters | individual | author | 5.415 | 0.000 |
| random.characters | individual | apply | 5.871 | 0.000 |
| random.characters | individual | receive | 8.109 | 0.000 |
| random.characters | individual | encode | 5.733 | 0.000 |
| random.characters | individual | decode | 6.857 | 0.000 |
| random.characters | batch | author | 5.090 | 0.000 |
| random.characters | batch | apply | 3.715 | 0.000 |
| random.characters | batch | receive | 3.901 | 0.000 |
| random.characters | batch | encode | 0.175 | 0.000 |
| random.characters | batch | decode | 0.116 | 0.000 |
| random.words | individual | author | 5.096 | 0.000 |
| random.words | individual | apply | 4.918 | 0.000 |
| random.words | individual | receive | 7.751 | 0.000 |
| random.words | individual | encode | 4.560 | 0.000 |
| random.words | individual | decode | 6.764 | 0.000 |
| random.words | batch | author | 5.938 | 0.000 |
| random.words | batch | apply | 3.303 | 0.000 |
| random.words | batch | receive | 3.578 | 0.000 |
| random.words | batch | encode | 0.394 | 0.000 |
| random.words | batch | decode | 0.106 | 0.000 |
| concurrent.characters | individual | author | 9.929 | 0.000 |
| concurrent.characters | individual | apply | 10.411 | 0.000 |
| concurrent.characters | individual | receive | 14.582 | 0.000 |
| concurrent.characters | individual | encode | 8.746 | 0.000 |
| concurrent.characters | individual | decode | 10.157 | 0.000 |
| concurrent.characters | batch | author | 7.808 | 0.000 |
| concurrent.characters | batch | apply | 6.638 | 0.000 |
| concurrent.characters | batch | receive | 6.893 | 0.000 |
| concurrent.characters | batch | encode | 0.309 | 0.000 |
| concurrent.characters | batch | decode | 0.105 | 0.000 |
| concurrent.words | individual | author | 9.441 | 0.000 |
| concurrent.words | individual | apply | 9.141 | 0.000 |
| concurrent.words | individual | receive | 13.328 | 0.000 |
| concurrent.words | individual | encode | 9.074 | 0.000 |
| concurrent.words | individual | decode | 13.234 | 0.000 |
| concurrent.words | batch | author | 8.978 | 0.000 |
| concurrent.words | batch | apply | 6.636 | 0.000 |
| concurrent.words | batch | receive | 7.568 | 0.000 |
| concurrent.words | batch | encode | 0.729 | 0.000 |
| concurrent.words | batch | decode | 0.104 | 0.000 |
| concurrent.mixed | individual | author | 17.322 | 0.000 |
| concurrent.mixed | individual | apply | 12.324 | 0.000 |
| concurrent.mixed | individual | receive | 16.684 | 0.000 |
| concurrent.mixed | individual | encode | 8.507 | 0.000 |
| concurrent.mixed | individual | decode | 12.448 | 0.000 |
| concurrent.mixed | batch | author | 13.375 | 0.000 |
| concurrent.mixed | batch | apply | 10.025 | 0.000 |
| concurrent.mixed | batch | receive | 10.507 | 0.000 |
| concurrent.mixed | batch | encode | 0.680 | 0.000 |
| concurrent.mixed | batch | decode | 0.130 | 0.000 |
| causal.characters | individual | author | 10.203 | 0.000 |
| causal.characters | individual | apply | 8.246 | 0.000 |
| causal.characters | individual | receive | 11.918 | 0.000 |
| causal.characters | individual | encode | 7.542 | 0.000 |
| causal.characters | individual | decode | 9.452 | 0.000 |
| causal.characters | batch | author | 8.868 | 0.000 |
| causal.characters | batch | apply | 6.803 | 0.000 |
| causal.characters | batch | receive | 7.506 | 0.000 |
| causal.characters | batch | encode | 0.334 | 0.000 |
| causal.characters | batch | decode | 0.110 | 0.000 |
| causal.words | individual | author | 11.067 | 0.000 |
| causal.words | individual | apply | 10.245 | 0.000 |
| causal.words | individual | receive | 13.367 | 0.000 |
| causal.words | individual | encode | 11.372 | 0.000 |
| causal.words | individual | decode | 11.137 | 0.000 |
| causal.words | batch | author | 10.048 | 0.000 |
| causal.words | batch | apply | 7.873 | 0.000 |
| causal.words | batch | receive | 7.840 | 0.000 |
| causal.words | batch | encode | 0.666 | 0.000 |
| causal.words | batch | decode | 0.162 | 0.000 |
| causal.mixed | individual | author | 16.523 | 0.000 |
| causal.mixed | individual | apply | 11.815 | 0.000 |
| causal.mixed | individual | receive | 16.861 | 0.000 |
| causal.mixed | individual | encode | 9.521 | 0.000 |
| causal.mixed | individual | decode | 9.264 | 0.000 |
| causal.mixed | batch | author | 13.552 | 0.000 |
| causal.mixed | batch | apply | 10.291 | 0.000 |
| causal.mixed | batch | receive | 9.821 | 0.000 |
| causal.mixed | batch | encode | 0.440 | 0.000 |
| causal.mixed | batch | decode | 0.125 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
