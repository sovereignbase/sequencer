# Sequencer dynamic lifecycle benchmark

2026-11-27T20:48:41.800Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.23 | 162.89 | 56.49 |
| CommonJS | 199.41 | 164.51 | 56.69 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 319,475 | 3.130 | 3.130 | 3.130 | 0.000 | 0: 3.130 | 0: 3.130 |
| apply | random | A | scaleDown | 24,999 | 344,033 | 2.907 | 2.907 | 2.907 | 0.000 | 0: 2.907 | 0: 2.907 |
| apply | random | A | fullLifecycle | 49,999 | 331,299 | 3.018 | 3.018 | 3.018 | 0.000 | 0: 3.018 | 0: 3.018 |
| create | — | A | scaleUp | 7 | 504 | 1985.800 | 1985.800 | 1985.800 | 0.000 | 0: 1985.800 | 0: 1985.800 |
| create | — | A | scaleDown | 6 | 668 | 1497.167 | 1497.167 | 1497.167 | 0.000 | 0: 1497.167 | 0: 1497.167 |
| create | — | A | fullLifecycle | 13 | 568 | 1760.277 | 1760.277 | 1760.277 | 0.000 | 0: 1760.277 | 0: 1760.277 |
| insert | head | A | scaleUp | 12,500 | 1,291,976 | 0.774 | 0.774 | 0.774 | 0.000 | 0: 0.774 | 0: 0.774 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,291,976 | 0.774 | 0.774 | 0.774 | 0.000 | 0: 0.774 | 0: 0.774 |
| insert | random | A | scaleUp | 25,000 | 585,462 | 1.708 | 1.708 | 1.708 | 0.000 | 0: 1.708 | 0: 1.708 |
| insert | random | A | scaleDown | 25,000 | 606,363 | 1.649 | 1.649 | 1.649 | 0.000 | 0: 1.649 | 0: 1.649 |
| insert | random | A | fullLifecycle | 50,000 | 595,730 | 1.679 | 1.679 | 1.679 | 0.000 | 0: 1.679 | 0: 1.679 |
| insert | tail | A | scaleUp | 12,500 | 1,419,261 | 0.705 | 0.705 | 0.705 | 0.000 | 0: 0.705 | 0: 0.705 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,419,261 | 0.705 | 0.705 | 0.705 | 0.000 | 0: 0.705 | 0: 0.705 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 696,748 | 1.435 | 1.435 | 1.435 | 0.000 | 0: 1.435 | 0: 1.435 |
| remove | head | A | fullLifecycle | 12,500 | 696,748 | 1.435 | 1.435 | 1.435 | 0.000 | 0: 1.435 | 0: 1.435 |
| remove | random | A | scaleUp | 25,000 | 495,095 | 2.020 | 2.020 | 2.020 | 0.000 | 0: 2.020 | 0: 2.020 |
| remove | random | A | scaleDown | 25,000 | 503,820 | 1.985 | 1.985 | 1.985 | 0.000 | 0: 1.985 | 0: 1.985 |
| remove | random | A | fullLifecycle | 50,000 | 499,419 | 2.002 | 2.002 | 2.002 | 0.000 | 0: 2.002 | 0: 2.002 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 758,044 | 1.319 | 1.319 | 1.319 | 0.000 | 0: 1.319 | 0: 1.319 |
| remove | tail | A | fullLifecycle | 12,500 | 758,044 | 1.319 | 1.319 | 1.319 | 0.000 | 0: 1.319 | 0: 1.319 |
| replace | head | A | scaleUp | 25,000 | 521,479 | 1.918 | 1.918 | 1.918 | 0.000 | 0: 1.918 | 0: 1.918 |
| replace | head | A | scaleDown | 25,000 | 507,445 | 1.971 | 1.971 | 1.971 | 0.000 | 0: 1.971 | 0: 1.971 |
| replace | head | A | fullLifecycle | 50,000 | 514,366 | 1.944 | 1.944 | 1.944 | 0.000 | 0: 1.944 | 0: 1.944 |
| replace | random | A | scaleUp | 25,000 | 331,523 | 3.016 | 3.016 | 3.016 | 0.000 | 0: 3.016 | 0: 3.016 |
| replace | random | A | scaleDown | 25,000 | 379,496 | 2.635 | 2.635 | 2.635 | 0.000 | 0: 2.635 | 0: 2.635 |
| replace | random | A | fullLifecycle | 50,000 | 353,891 | 2.826 | 2.826 | 2.826 | 0.000 | 0: 2.826 | 0: 2.826 |
| replace | tail | A | scaleUp | 25,000 | 535,914 | 1.866 | 1.866 | 1.866 | 0.000 | 0: 1.866 | 0: 1.866 |
| replace | tail | A | scaleDown | 25,000 | 54,313 | 18.412 | 18.412 | 18.412 | 0.000 | 0: 18.412 | 0: 18.412 |
| replace | tail | A | fullLifecycle | 50,000 | 98,630 | 10.139 | 10.139 | 10.139 | 0.000 | 0: 10.139 | 0: 10.139 |
| sequence | — | A | scaleUp | 6 | 74 | 13508.100 | 13508.100 | 13508.100 | 0.000 | 0: 13508.100 | 0: 13508.100 |
| sequence | — | A | scaleDown | 6 | 91 | 11020.767 | 11020.767 | 11020.767 | 0.000 | 0: 11020.767 | 0: 11020.767 |
| sequence | — | A | fullLifecycle | 12 | 82 | 12264.433 | 12264.433 | 12264.433 | 0.000 | 0: 12264.433 | 0: 12264.433 |
| value | head | A | scaleUp | 25,000 | 3,005,639 | 0.333 | 0.333 | 0.333 | 0.000 | 0: 0.333 | 0: 0.333 |
| value | head | A | scaleDown | 25,000 | 2,220,091 | 0.450 | 0.450 | 0.450 | 0.000 | 0: 0.450 | 0: 0.450 |
| value | head | A | fullLifecycle | 50,000 | 2,553,822 | 0.392 | 0.392 | 0.392 | 0.000 | 0: 0.392 | 0: 0.392 |
| value | random | A | scaleUp | 25,000 | 914,120 | 1.094 | 1.094 | 1.094 | 0.000 | 0: 1.094 | 0: 1.094 |
| value | random | A | scaleDown | 25,000 | 991,816 | 1.008 | 1.008 | 1.008 | 0.000 | 0: 1.008 | 0: 1.008 |
| value | random | A | fullLifecycle | 50,000 | 951,384 | 1.051 | 1.051 | 1.051 | 0.000 | 0: 1.051 | 0: 1.051 |
| value | tail | A | scaleUp | 25,000 | 5,963,740 | 0.168 | 0.168 | 0.168 | 0.000 | 0: 0.168 | 0: 0.168 |
| value | tail | A | scaleDown | 25,000 | 4,223,472 | 0.237 | 0.237 | 0.237 | 0.000 | 0: 0.237 | 0: 0.237 |
| value | tail | A | fullLifecycle | 50,000 | 4,944,963 | 0.202 | 0.202 | 0.202 | 0.000 | 0: 0.202 | 0: 0.202 |
| values | — | A | scaleUp | 6 | 152 | 6593.083 | 6593.083 | 6593.083 | 0.000 | 0: 6593.083 | 0: 6593.083 |
| values | — | A | scaleDown | 6 | 244 | 4090.817 | 4090.817 | 4090.817 | 0.000 | 0: 4090.817 | 0: 4090.817 |
| values | — | A | fullLifecycle | 12 | 187 | 5341.950 | 5341.950 | 5341.950 | 0.000 | 0: 5341.950 | 0: 5341.950 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5410752.667 | 427.165 | 8.478 |
| A | scaleDown | 5 | 4407357.600 | 432.094 | 8.548 |
| A | fullLifecycle | 11 | 4954664.000 | 429.144 | 8.506 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3116296.167 | 246.023 | 4.883 |
| A | scaleDown | 5 | 2595337.600 | 254.445 | 5.034 |
| A | fullLifecycle | 11 | 2879496.818 | 249.405 | 4.944 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 270,424 | 3.698 | 1.800 | 66.900 |
| apply | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 321,626 | 3.109 | 1.800 | 86.000 |
| apply | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 296,532 | 3.372 | 1.600 | 2719.900 |
| apply | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 312,724 | 3.198 | 1.600 | 2719.900 |
| apply | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 315,260 | 3.172 | 1.500 | 2719.900 |
| apply | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 319,475 | 3.130 | 1.500 | 2719.900 |
| apply | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 321,728 | 3.108 | 1.500 | 2719.900 |
| apply | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 323,691 | 3.089 | 1.500 | 2719.900 |
| apply | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 324,338 | 3.083 | 1.500 | 2719.900 |
| apply | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 326,585 | 3.062 | 1.500 | 2719.900 |
| apply | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 329,657 | 3.033 | 1.400 | 2719.900 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 331,299 | 3.018 | 1.200 | 2719.900 |
| insert | head | 0 | up | 1,000 | 50,007 | A | 500 | 992,654 | 1.007 | 0.300 | 16.300 |
| insert | head | 0 | up | 5,000 | 256,206 | A | 2,500 | 1,195,200 | 0.837 | 0.300 | 21.000 |
| insert | head | 0 | up | 10,000 | 508,328 | A | 5,000 | 1,258,812 | 0.794 | 0.300 | 107.400 |
| insert | head | 0 | up | 15,000 | 756,035 | A | 7,500 | 1,264,500 | 0.791 | 0.300 | 230.500 |
| insert | head | 0 | up | 20,000 | 1,005,850 | A | 10,000 | 1,264,398 | 0.791 | 0.300 | 230.500 |
| insert | head | 0 | up | 25,000 | 1,252,902 | A | 12,500 | 1,291,976 | 0.774 | 0.300 | 230.500 |
| insert | head | 0 | down | 20,000 | 1,007,225 | A | 12,500 | 1,291,976 | 0.774 | 0.300 | 230.500 |
| insert | head | 0 | down | 15,000 | 759,799 | A | 12,500 | 1,291,976 | 0.774 | 0.300 | 230.500 |
| insert | head | 0 | down | 10,000 | 506,363 | A | 12,500 | 1,291,976 | 0.774 | 0.300 | 230.500 |
| insert | head | 0 | down | 5,000 | 254,264 | A | 12,500 | 1,291,976 | 0.774 | 0.300 | 230.500 |
| insert | head | 0 | down | 1,000 | 50,210 | A | 12,500 | 1,291,976 | 0.774 | 0.300 | 230.500 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,291,976 | 0.774 | 0.300 | 230.500 |
| insert | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 545,881 | 1.832 | 0.400 | 333.300 |
| insert | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 581,247 | 1.720 | 0.400 | 733.300 |
| insert | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 567,344 | 1.763 | 0.400 | 968.300 |
| insert | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 595,810 | 1.678 | 0.400 | 968.300 |
| insert | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 582,337 | 1.717 | 0.400 | 968.300 |
| insert | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 585,462 | 1.708 | 0.400 | 968.300 |
| insert | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 571,644 | 1.749 | 0.400 | 968.300 |
| insert | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 571,006 | 1.751 | 0.400 | 968.300 |
| insert | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 571,998 | 1.748 | 0.400 | 968.300 |
| insert | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 579,465 | 1.726 | 0.400 | 968.300 |
| insert | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 591,065 | 1.692 | 0.400 | 968.300 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 595,730 | 1.679 | 0.400 | 968.300 |
| insert | tail | 0 | up | 1,000 | 50,007 | A | 500 | 1,053,297 | 0.949 | 0.300 | 57.400 |
| insert | tail | 0 | up | 5,000 | 256,206 | A | 2,500 | 1,316,552 | 0.760 | 0.300 | 57.400 |
| insert | tail | 0 | up | 10,000 | 508,328 | A | 5,000 | 1,395,946 | 0.716 | 0.300 | 77.500 |
| insert | tail | 0 | up | 15,000 | 756,035 | A | 7,500 | 1,431,544 | 0.699 | 0.300 | 157.500 |
| insert | tail | 0 | up | 20,000 | 1,005,850 | A | 10,000 | 1,453,045 | 0.688 | 0.300 | 157.500 |
| insert | tail | 0 | up | 25,000 | 1,252,902 | A | 12,500 | 1,419,261 | 0.705 | 0.300 | 328.300 |
| insert | tail | 0 | down | 20,000 | 1,007,225 | A | 12,500 | 1,419,261 | 0.705 | 0.300 | 328.300 |
| insert | tail | 0 | down | 15,000 | 759,799 | A | 12,500 | 1,419,261 | 0.705 | 0.300 | 328.300 |
| insert | tail | 0 | down | 10,000 | 506,363 | A | 12,500 | 1,419,261 | 0.705 | 0.300 | 328.300 |
| insert | tail | 0 | down | 5,000 | 254,264 | A | 12,500 | 1,419,261 | 0.705 | 0.300 | 328.300 |
| insert | tail | 0 | down | 1,000 | 50,210 | A | 12,500 | 1,419,261 | 0.705 | 0.300 | 328.300 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,419,261 | 0.705 | 0.300 | 328.300 |
| remove | head | 0 | up | 1,000 | 50,007 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 256,206 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 508,328 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 756,035 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,005,850 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,252,902 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,007,225 | A | 2,500 | 682,426 | 1.465 | 0.900 | 44.500 |
| remove | head | 0 | down | 15,000 | 759,799 | A | 5,000 | 686,587 | 1.456 | 0.900 | 44.500 |
| remove | head | 0 | down | 10,000 | 506,363 | A | 7,500 | 658,478 | 1.519 | 0.900 | 615.200 |
| remove | head | 0 | down | 5,000 | 254,264 | A | 10,000 | 677,094 | 1.477 | 0.900 | 615.200 |
| remove | head | 0 | down | 1,000 | 50,210 | A | 12,000 | 692,297 | 1.444 | 0.800 | 615.200 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 696,748 | 1.435 | 0.700 | 615.200 |
| remove | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 494,315 | 2.023 | 0.800 | 55.200 |
| remove | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 525,812 | 1.902 | 0.800 | 88.500 |
| remove | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 495,759 | 2.017 | 0.800 | 300.700 |
| remove | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 509,696 | 1.962 | 0.800 | 300.700 |
| remove | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 496,369 | 2.015 | 0.800 | 300.700 |
| remove | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 495,095 | 2.020 | 0.800 | 300.700 |
| remove | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 487,826 | 2.050 | 0.800 | 300.700 |
| remove | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 486,711 | 2.055 | 0.800 | 300.700 |
| remove | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 485,194 | 2.061 | 0.800 | 573.100 |
| remove | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 490,123 | 2.040 | 0.800 | 573.100 |
| remove | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 495,959 | 2.016 | 0.800 | 573.100 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 499,419 | 2.002 | 0.700 | 573.100 |
| remove | tail | 0 | up | 1,000 | 50,007 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 256,206 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 508,328 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 756,035 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,005,850 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,252,902 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,007,225 | A | 2,500 | 773,132 | 1.293 | 0.900 | 19.900 |
| remove | tail | 0 | down | 15,000 | 759,799 | A | 5,000 | 751,044 | 1.331 | 0.900 | 19.900 |
| remove | tail | 0 | down | 10,000 | 506,363 | A | 7,500 | 727,125 | 1.375 | 0.800 | 429.000 |
| remove | tail | 0 | down | 5,000 | 254,264 | A | 10,000 | 740,456 | 1.351 | 0.800 | 429.000 |
| remove | tail | 0 | down | 1,000 | 50,210 | A | 12,000 | 752,243 | 1.329 | 0.800 | 429.000 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 758,044 | 1.319 | 0.700 | 429.000 |
| replace | head | 0 | up | 1,000 | 50,007 | A | 1,000 | 373,678 | 2.676 | 1.200 | 396.100 |
| replace | head | 0 | up | 5,000 | 256,206 | A | 5,000 | 443,412 | 2.255 | 1.200 | 923.100 |
| replace | head | 0 | up | 10,000 | 508,328 | A | 10,000 | 493,810 | 2.025 | 1.100 | 923.100 |
| replace | head | 0 | up | 15,000 | 756,035 | A | 15,000 | 519,561 | 1.925 | 1.100 | 923.100 |
| replace | head | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 525,431 | 1.903 | 1.100 | 923.100 |
| replace | head | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 521,479 | 1.918 | 1.100 | 923.100 |
| replace | head | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 516,015 | 1.938 | 1.100 | 923.100 |
| replace | head | 0 | down | 15,000 | 759,799 | A | 35,000 | 512,057 | 1.953 | 1.100 | 923.100 |
| replace | head | 0 | down | 10,000 | 506,363 | A | 40,000 | 510,276 | 1.960 | 1.100 | 923.100 |
| replace | head | 0 | down | 5,000 | 254,264 | A | 45,000 | 508,977 | 1.965 | 1.100 | 923.100 |
| replace | head | 0 | down | 1,000 | 50,210 | A | 49,000 | 512,491 | 1.951 | 1.000 | 923.100 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 514,366 | 1.944 | 0.900 | 923.100 |
| replace | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 322,716 | 3.099 | 1.200 | 306.600 |
| replace | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 369,042 | 2.710 | 1.200 | 380.400 |
| replace | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 345,980 | 2.890 | 1.200 | 1928.800 |
| replace | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 347,526 | 2.877 | 1.200 | 1928.800 |
| replace | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 337,800 | 2.960 | 1.200 | 1928.800 |
| replace | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 331,523 | 3.016 | 1.200 | 2220.500 |
| replace | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 336,840 | 2.969 | 1.200 | 2220.500 |
| replace | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 333,676 | 2.997 | 1.200 | 2220.500 |
| replace | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 339,406 | 2.946 | 1.200 | 2220.500 |
| replace | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 344,498 | 2.903 | 1.200 | 2220.500 |
| replace | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 350,993 | 2.849 | 1.100 | 2220.500 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 353,891 | 2.826 | 0.900 | 2220.500 |
| replace | tail | 0 | up | 1,000 | 50,007 | A | 1,000 | 413,121 | 2.421 | 1.100 | 112.500 |
| replace | tail | 0 | up | 5,000 | 256,206 | A | 5,000 | 509,492 | 1.963 | 1.100 | 173.100 |
| replace | tail | 0 | up | 10,000 | 508,328 | A | 10,000 | 527,290 | 1.896 | 1.100 | 173.800 |
| replace | tail | 0 | up | 15,000 | 756,035 | A | 15,000 | 537,403 | 1.861 | 1.100 | 173.800 |
| replace | tail | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 531,725 | 1.881 | 1.100 | 303.400 |
| replace | tail | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 535,914 | 1.866 | 1.100 | 303.400 |
| replace | tail | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 129,426 | 7.726 | 1.100 | 3024.600 |
| replace | tail | 0 | down | 15,000 | 759,799 | A | 35,000 | 95,965 | 10.420 | 1.100 | 3024.600 |
| replace | tail | 0 | down | 10,000 | 506,363 | A | 40,000 | 96,637 | 10.348 | 1.100 | 3024.600 |
| replace | tail | 0 | down | 5,000 | 254,264 | A | 45,000 | 94,337 | 10.600 | 1.000 | 3024.600 |
| replace | tail | 0 | down | 1,000 | 50,210 | A | 49,000 | 97,100 | 10.299 | 1.000 | 3024.600 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 98,630 | 10.139 | 0.900 | 3024.600 |
| value | head | 0 | up | 1,000 | 50,007 | A | 1,000 | 1,459,002 | 0.685 | 0.100 | 309.100 |
| value | head | 0 | up | 5,000 | 256,206 | A | 5,000 | 2,540,780 | 0.394 | 0.100 | 309.100 |
| value | head | 0 | up | 10,000 | 508,328 | A | 10,000 | 2,703,580 | 0.370 | 0.100 | 309.100 |
| value | head | 0 | up | 15,000 | 756,035 | A | 15,000 | 2,893,965 | 0.346 | 0.100 | 309.100 |
| value | head | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 2,955,039 | 0.338 | 0.100 | 309.100 |
| value | head | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 3,005,639 | 0.333 | 0.100 | 309.100 |
| value | head | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 2,806,886 | 0.356 | 0.100 | 309.100 |
| value | head | 0 | down | 15,000 | 759,799 | A | 35,000 | 2,703,141 | 0.370 | 0.100 | 309.100 |
| value | head | 0 | down | 10,000 | 506,363 | A | 40,000 | 2,635,654 | 0.379 | 0.100 | 309.100 |
| value | head | 0 | down | 5,000 | 254,264 | A | 45,000 | 2,583,786 | 0.387 | 0.100 | 309.100 |
| value | head | 0 | down | 1,000 | 50,210 | A | 49,000 | 2,553,959 | 0.392 | 0.100 | 309.100 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,553,822 | 0.392 | 0.100 | 309.100 |
| value | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 1,218,918 | 0.820 | 0.100 | 38.800 |
| value | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 1,087,240 | 0.920 | 0.100 | 48.500 |
| value | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 979,144 | 1.021 | 0.100 | 48.500 |
| value | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 964,860 | 1.036 | 0.100 | 94.600 |
| value | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 933,982 | 1.071 | 0.100 | 94.600 |
| value | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 914,120 | 1.094 | 0.100 | 94.600 |
| value | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 913,840 | 1.094 | 0.100 | 94.600 |
| value | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 913,016 | 1.095 | 0.100 | 94.600 |
| value | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 916,733 | 1.091 | 0.100 | 94.600 |
| value | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 925,574 | 1.080 | 0.100 | 94.600 |
| value | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 943,264 | 1.060 | 0.100 | 94.600 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 951,384 | 1.051 | 0.100 | 94.600 |
| value | tail | 0 | up | 1,000 | 50,007 | A | 1,000 | 4,476,276 | 0.223 | 0.100 | 24.100 |
| value | tail | 0 | up | 5,000 | 256,206 | A | 5,000 | 5,359,631 | 0.187 | 0.100 | 24.100 |
| value | tail | 0 | up | 10,000 | 508,328 | A | 10,000 | 5,592,216 | 0.179 | 0.100 | 24.100 |
| value | tail | 0 | up | 15,000 | 756,035 | A | 15,000 | 5,897,849 | 0.170 | 0.100 | 46.500 |
| value | tail | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 6,118,079 | 0.163 | 0.100 | 46.500 |
| value | tail | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 5,963,740 | 0.168 | 0.000 | 197.700 |
| value | tail | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 5,573,411 | 0.179 | 0.000 | 197.700 |
| value | tail | 0 | down | 15,000 | 759,799 | A | 35,000 | 5,312,528 | 0.188 | 0.000 | 197.700 |
| value | tail | 0 | down | 10,000 | 506,363 | A | 40,000 | 5,131,165 | 0.195 | 0.000 | 197.700 |
| value | tail | 0 | down | 5,000 | 254,264 | A | 45,000 | 5,004,003 | 0.200 | 0.000 | 197.700 |
| value | tail | 0 | down | 1,000 | 50,210 | A | 49,000 | 4,939,367 | 0.202 | 0.000 | 197.700 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 4,944,963 | 0.202 | 0.000 | 197.700 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 1,302 | 767.800 |
| create | — | 0 | up | 5,000 | A | 1 | 1,014 | 985.900 |
| create | — | 0 | up | 10,000 | A | 1 | 535 | 1867.600 |
| create | — | 0 | up | 15,000 | A | 1 | 412 | 2425.200 |
| create | — | 0 | up | 20,000 | A | 1 | 286 | 3500.100 |
| create | — | 0 | up | 25,000 | A | 1 | 261 | 3836.400 |
| create | — | 0 | down | 20,000 | A | 1 | 285 | 3511.400 |
| create | — | 0 | down | 15,000 | A | 1 | 379 | 2641.900 |
| create | — | 0 | down | 10,000 | A | 1 | 573 | 1745.100 |
| create | — | 0 | down | 5,000 | A | 1 | 1,203 | 831.600 |
| create | — | 0 | down | 1,000 | A | 1 | 4,198 | 238.200 |
| create | — | 0 | down | 0 | A | 1 | 67,568 | 14.800 |
| sequence | — | 0 | up | 1,000 | A | 1 | 384 | 2602.500 |
| sequence | — | 0 | up | 5,000 | A | 1 | 119 | 8402.100 |
| sequence | — | 0 | up | 10,000 | A | 1 | 85 | 11776.000 |
| sequence | — | 0 | up | 15,000 | A | 1 | 70 | 14335.300 |
| sequence | — | 0 | up | 20,000 | A | 1 | 46 | 21519.600 |
| sequence | — | 0 | up | 25,000 | A | 1 | 45 | 22413.100 |
| sequence | — | 0 | down | 20,000 | A | 1 | 56 | 17979.000 |
| sequence | — | 0 | down | 15,000 | A | 1 | 66 | 15055.500 |
| sequence | — | 0 | down | 10,000 | A | 1 | 72 | 13875.600 |
| sequence | — | 0 | down | 5,000 | A | 1 | 111 | 9038.200 |
| sequence | — | 0 | down | 1,000 | A | 1 | 116 | 8646.900 |
| sequence | — | 0 | down | 0 | A | 1 | 654 | 1529.400 |
| values | — | 0 | up | 1,000 | A | 1 | 550 | 1817.700 |
| values | — | 0 | up | 5,000 | A | 1 | 233 | 4294.500 |
| values | — | 0 | up | 10,000 | A | 1 | 139 | 7186.500 |
| values | — | 0 | up | 15,000 | A | 1 | 141 | 7091.600 |
| values | — | 0 | up | 20,000 | A | 1 | 118 | 8493.000 |
| values | — | 0 | up | 25,000 | A | 1 | 94 | 10675.200 |
| values | — | 0 | down | 20,000 | A | 1 | 112 | 8951.500 |
| values | — | 0 | down | 15,000 | A | 1 | 148 | 6751.600 |
| values | — | 0 | down | 10,000 | A | 1 | 216 | 4619.700 |
| values | — | 0 | down | 5,000 | A | 1 | 272 | 3678.800 |
| values | — | 0 | down | 1,000 | A | 1 | 1,895 | 527.800 |
| values | — | 0 | down | 0 | A | 1 | 64,516 | 15.500 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.613 | 0.232 | 0.382 |
| 0 | up | 5000 | 3.122 | 1.167 | 1.955 |
| 0 | up | 10000 | 6.220 | 2.342 | 3.878 |
| 0 | up | 15000 | 9.408 | 3.640 | 5.768 |
| 0 | up | 20000 | 12.780 | 5.106 | 7.674 |
| 0 | up | 25000 | 16.189 | 6.630 | 9.559 |
| 0 | down | 20000 | 13.291 | 5.606 | 7.685 |
| 0 | down | 15000 | 9.922 | 4.125 | 5.797 |
| 0 | down | 10000 | 7.152 | 3.289 | 3.863 |
| 0 | down | 5000 | 4.095 | 2.155 | 1.940 |
| 0 | down | 1000 | 1.797 | 1.414 | 0.383 |
| 0 | down | 0 | 1.224 | 1.224 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 50,007 | 0.402 | 421.580 | 8.430 | 121.074 | 15.525 |
| 0 | up | A | 5,000 | 5,000 | 256,206 | 2.057 | 431.302 | 8.417 | 154.801 | 19.669 |
| 0 | up | A | 10,000 | 10,000 | 508,328 | 4.090 | 428.881 | 8.437 | 195.676 | 24.521 |
| 0 | up | A | 15,000 | 15,000 | 756,035 | 6.108 | 426.991 | 8.472 | 209.047 | 29.294 |
| 0 | up | A | 20,000 | 20,000 | 1,005,850 | 8.143 | 426.916 | 8.489 | 282.953 | 34.104 |
| 0 | up | A | 25,000 | 25,000 | 1,252,902 | 10.161 | 426.177 | 8.504 | 296.410 | 38.838 |
| 0 | down | A | 20,000 | 20,000 | 1,007,225 | 8.223 | 431.124 | 8.561 | 296.363 | 34.151 |
| 0 | down | A | 15,000 | 15,000 | 759,799 | 6.203 | 433.606 | 8.560 | 301.320 | 29.426 |
| 0 | down | A | 10,000 | 10,000 | 506,363 | 4.124 | 432.479 | 8.541 | 298.066 | 24.627 |
| 0 | down | A | 5,000 | 5,000 | 254,264 | 2.060 | 431.993 | 8.495 | 295.859 | 19.848 |
| 0 | down | A | 1,000 | 1,000 | 50,210 | 0.406 | 425.476 | 8.474 | 294.199 | 15.978 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 295.766 | 14.906 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 50007 | 184507 | 184.507 | 3.690 | 272.03 | 14.52 | 162.13 | 12.30 |
| 0 | up | A | 5000 | 256206 | 1218174 | 243.635 | 4.755 | 1644.25 | 73.50 | 830.68 | 61.66 |
| 0 | up | A | 10000 | 508328 | 2441689 | 244.169 | 4.803 | 3276.35 | 148.92 | 1655.21 | 124.79 |
| 0 | up | A | 15000 | 756035 | 3694120 | 246.275 | 4.886 | 4916.66 | 225.99 | 3545.68 | 200.14 |
| 0 | up | A | 20000 | 1005850 | 4950983 | 247.549 | 4.922 | 7073.44 | 311.23 | 5103.00 | 263.55 |
| 0 | up | A | 25000 | 1252902 | 6208304 | 248.332 | 4.955 | 9192.05 | 392.29 | 6496.81 | 335.16 |
| 0 | down | A | 20000 | 1007225 | 5103545 | 255.177 | 5.067 | 7538.07 | 326.43 | 5289.65 | 278.22 |
| 0 | down | A | 15000 | 759799 | 3844421 | 256.295 | 5.060 | 5730.74 | 247.34 | 4004.94 | 209.82 |
| 0 | down | A | 10000 | 506363 | 2541344 | 254.134 | 5.019 | 3828.12 | 165.02 | 2670.80 | 139.89 |
| 0 | down | A | 5000 | 254264 | 1247949 | 249.590 | 4.908 | 1909.46 | 79.58 | 1334.90 | 67.69 |
| 0 | down | A | 1000 | 50210 | 239429 | 239.429 | 4.769 | 375.26 | 16.04 | 262.97 | 13.69 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 427.165 | 8.478 | 246.023 | 4.883 |
| 0 | A | scaleDown | 432.094 | 8.548 | 254.445 | 5.034 |
| 0 | A | fullLifecycle | 429.144 | 8.506 | 249.405 | 4.944 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
