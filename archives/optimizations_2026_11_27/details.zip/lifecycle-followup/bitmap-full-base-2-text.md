# Large string benchmarks

2026-11-27T20:49:41.939Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2436.58 | 0.00 |
| 1024 | insert.append | array | 13296.12 | 0.00 |
| 1024 | replace | array | 3453.53 | 0.00 |
| 1024 | remove | array | 1011.30 | 0.00 |
| 1024 | remove.middle | array | 1899.60 | 0.00 |
| 1024 | replace.middle | array | 2339.48 | 0.00 |
| 1024 | apply | array | 1238.38 | 0.00 |
| 1024 | apply.array | array | 636.39 | 0.00 |
| 1024 | concurrent.apply | array | 71748.71 | 0.00 |
| 1024 | merge | array | 3057.99 | 0.00 |
| 1024 | create | array | 3061.75 | 0.00 |
| 1024 | value.random | array | 44.52 | 0.00 |
| 1024 | values.range | array | 109.80 | 0.00 |
| 1024 | values.array | array | 1622.49 | 0.00 |
| 1024 | values.text | array | 13542.96 | 0.00 |
| 1024 | sequence.array | array | 1613.05 | 0.00 |
| 1024 | sequence.text | array | 9489.34 | 0.00 |
| 1024 | sequence.edited.text | array | 14896.13 | 0.00 |
| 1024 | sequence.masked.text | array | 10950.77 | 0.00 |
| 1024 | insert | string | 490.44 | 0.00 |
| 1024 | insert.append | string | 3945.16 | 0.00 |
| 1024 | replace | string | 1422.12 | 0.00 |
| 1024 | remove | string | 893.49 | 0.00 |
| 1024 | remove.middle | string | 989.14 | 0.00 |
| 1024 | replace.middle | string | 1384.01 | 0.00 |
| 1024 | apply | string | 805.38 | 0.00 |
| 1024 | apply.array | string | 2456.16 | 0.00 |
| 1024 | concurrent.apply | string | 3973.33 | 0.00 |
| 1024 | merge | string | 1535.93 | 0.00 |
| 1024 | create | string | 987.66 | 0.00 |
| 1024 | value.random | string | 56.27 | 0.00 |
| 1024 | values.range | string | 211.27 | 0.00 |
| 1024 | values.array | string | 1919.64 | 0.00 |
| 1024 | values.text | string | 70.96 | 0.00 |
| 1024 | sequence.array | string | 2083.30 | 0.00 |
| 1024 | sequence.text | string | 186.87 | 0.00 |
| 1024 | sequence.edited.text | string | 2190.46 | 0.00 |
| 1024 | sequence.masked.text | string | 3488.32 | 0.00 |
| 65536 | insert | array | 278351.06 | 0.00 |
| 65536 | insert.append | array | 1095612.00 | 0.00 |
| 65536 | replace | array | 258350.52 | 0.00 |
| 65536 | remove | array | 2436.49 | 0.00 |
| 65536 | remove.middle | array | 250388.07 | 0.00 |
| 65536 | replace.middle | array | 237632.73 | 0.00 |
| 65536 | apply | array | 835.18 | 0.00 |
| 65536 | apply.array | array | 592.31 | 0.00 |
| 65536 | concurrent.apply | array | 4201050.00 | 0.00 |
| 65536 | merge | array | 216530.17 | 0.00 |
| 65536 | create | array | 212742.37 | 0.00 |
| 65536 | value.random | array | 48.13 | 0.00 |
| 65536 | values.range | array | 134.40 | 0.00 |
| 65536 | values.array | array | 201665.87 | 0.00 |
| 65536 | values.text | array | 787700.00 | 0.00 |
| 65536 | sequence.array | array | 206234.13 | 0.00 |
| 65536 | sequence.text | array | 728217.14 | 0.00 |
| 65536 | sequence.edited.text | array | 910957.14 | 0.00 |
| 65536 | sequence.masked.text | array | 763360.61 | 0.00 |
| 65536 | insert | string | 482.03 | 0.00 |
| 65536 | insert.append | string | 23391.58 | 0.00 |
| 65536 | replace | string | 1259.61 | 0.00 |
| 65536 | remove | string | 864.44 | 0.00 |
| 65536 | remove.middle | string | 889.05 | 0.00 |
| 65536 | replace.middle | string | 1183.63 | 0.00 |
| 65536 | apply | string | 809.44 | 0.00 |
| 65536 | apply.array | string | 266697.66 | 0.00 |
| 65536 | concurrent.apply | string | 152552.44 | 0.00 |
| 65536 | merge | string | 1142.69 | 0.00 |
| 65536 | create | string | 969.51 | 0.00 |
| 65536 | value.random | string | 54.35 | 0.00 |
| 65536 | values.range | string | 150.04 | 0.00 |
| 65536 | values.array | string | 257374.22 | 0.00 |
| 65536 | values.text | string | 67.47 | 0.00 |
| 65536 | sequence.array | string | 269053.91 | 0.00 |
| 65536 | sequence.text | string | 237.53 | 0.00 |
| 65536 | sequence.edited.text | string | 91018.18 | 0.00 |
| 65536 | sequence.masked.text | string | 3304.41 | 0.00 |
| 1048576 | insert | array | 3417100.00 | 0.00 |
| 1048576 | insert.append | array | 24621600.00 | 0.00 |
| 1048576 | replace | array | 3228075.00 | 0.00 |
| 1048576 | remove | array | 15295.78 | 0.00 |
| 1048576 | remove.middle | array | 3667342.86 | 0.00 |
| 1048576 | replace.middle | array | 3128300.00 | 0.00 |
| 1048576 | apply | array | 1402.91 | 0.00 |
| 1048576 | apply.array | array | 736.13 | 0.00 |
| 1048576 | concurrent.apply | array | 80256100.00 | 0.00 |
| 1048576 | merge | array | 3221725.00 | 0.00 |
| 1048576 | create | array | 3230725.00 | 0.00 |
| 1048576 | value.random | array | 46.74 | 0.00 |
| 1048576 | values.range | array | 110.26 | 0.00 |
| 1048576 | values.array | array | 2403745.45 | 0.00 |
| 1048576 | values.text | array | 13966350.00 | 0.00 |
| 1048576 | sequence.array | array | 2576680.00 | 0.00 |
| 1048576 | sequence.text | array | 66774350.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 70866500.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 64952300.00 | 0.00 |
| 1048576 | insert | string | 473.18 | 0.00 |
| 1048576 | insert.append | string | 572511.36 | 0.00 |
| 1048576 | replace | string | 1390.92 | 0.00 |
| 1048576 | remove | string | 1145.04 | 0.00 |
| 1048576 | remove.middle | string | 934.28 | 0.00 |
| 1048576 | replace.middle | string | 1313.55 | 0.00 |
| 1048576 | apply | string | 1144.89 | 0.00 |
| 1048576 | apply.array | string | 3491412.50 | 0.00 |
| 1048576 | concurrent.apply | string | 1573831.25 | 0.00 |
| 1048576 | merge | string | 1234.27 | 0.00 |
| 1048576 | create | string | 1075.16 | 0.00 |
| 1048576 | value.random | string | 75.27 | 0.00 |
| 1048576 | values.range | string | 149.19 | 0.00 |
| 1048576 | values.array | string | 3162087.50 | 0.00 |
| 1048576 | values.text | string | 88.66 | 0.00 |
| 1048576 | sequence.array | string | 2967311.11 | 0.00 |
| 1048576 | sequence.text | string | 171.95 | 0.00 |
| 1048576 | sequence.edited.text | string | 1610650.00 | 0.00 |
| 1048576 | sequence.masked.text | string | 3319.19 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
