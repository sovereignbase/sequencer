# Tuple benchmarks

2026-11-27T20:49:27.712Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 2,931,779 | 2,461,072 | 0.84× |
| 2 | create.sequence | 1,000,673 | 893,608 | 0.89× |
| 2 | replace.random | 1,012,114 | 1,445,811 | 1.43× |
| 2 | apply.replace | 685,240 | 897,981 | 1.31× |
| 2 | apply.duplicate | 1,706,890 | 1,609,633 | 0.94× |
| 2 | merge.duplicate | 1,524,574 | 1,592,854 | 1.04× |
| 2 | length | 129,796,104 | 137,896,580 | 1.06× |
| 2 | value.random | 35,128,578 | 56,815,359 | 1.62× |
| 2 | values | 12,995,468 | 12,251,637 | 0.94× |
| 2 | sequence | 3,249,465 | 3,054,611 | 0.94× |
| 4 | create.empty | 2,471,397 | 2,400,423 | 0.97× |
| 4 | create.sequence | 677,511 | 748,183 | 1.10× |
| 4 | replace.random | 1,000,481 | 1,516,709 | 1.52× |
| 4 | apply.replace | 643,849 | 947,026 | 1.47× |
| 4 | apply.duplicate | 1,736,583 | 1,746,214 | 1.01× |
| 4 | merge.duplicate | 1,357,203 | 1,323,802 | 0.98× |
| 4 | length | 35,863,816 | 5,634,646 | 0.16× |
| 4 | value.random | 22,842,493 | 55,883,411 | 2.45× |
| 4 | values | 6,707,272 | 7,232,255 | 1.08× |
| 4 | sequence | 2,516,110 | 2,496,005 | 0.99× |
| 8 | create.empty | 2,612,698 | 2,373,150 | 0.91× |
| 8 | create.sequence | 457,119 | 577,050 | 1.26× |
| 8 | replace.random | 1,050,893 | 1,605,535 | 1.53× |
| 8 | apply.replace | 644,924 | 979,619 | 1.52× |
| 8 | apply.duplicate | 1,693,642 | 1,710,053 | 1.01× |
| 8 | merge.duplicate | 944,292 | 913,429 | 0.97× |
| 8 | length | 38,582,438 | 37,837,099 | 0.98× |
| 8 | value.random | 18,114,090 | 50,665,440 | 2.80× |
| 8 | values | 4,686,582 | 4,986,558 | 1.06× |
| 8 | sequence | 1,497,845 | 1,827,220 | 1.22× |
| 100 | create.empty | 2,358,186 | 2,180,994 | 0.92× |
| 100 | create.sequence | 69,286 | 88,443 | 1.28× |
| 100 | replace.random | 1,059,973 | 1,600,819 | 1.51× |
| 100 | apply.replace | 603,900 | 897,976 | 1.49× |
| 100 | apply.duplicate | 1,426,162 | 1,375,441 | 0.96× |
| 100 | merge.duplicate | 106,539 | 80,917 | 0.76× |
| 100 | length | 37,535,654 | 35,566,858 | 0.95× |
| 100 | value.random | 12,461,519 | 54,975,583 | 4.41× |
| 100 | values | 541,725 | 679,091 | 1.25× |
| 100 | sequence | 185,649 | 174,330 | 0.94× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
