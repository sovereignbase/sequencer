# Words benchmarks

2026-11-27T20:50:02.781Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 30,236 | 168,604 | 140 |
| append | packed | 5.90 | 3.61 | 13.98 | 26,867 | 226,157 | 357 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,510 | 775 | 228 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 31,024 | 1,576 | 238 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 498 | 246 | 80 |
| random | packed | 49.58 | 35.38 | 23.45 | 15,085 | 528 | 125 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 690 | 253 | 108 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 17,707 | 414 | 143 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 501.65 | 0.00 |
| append | numeric | encode | 33072.81 | 0.00 |
| append | numeric | decode | 2831.29 | 0.00 |
| append | numeric | create | 1772.13 | 0.00 |
| append | numeric | load | 5931.07 | 0.00 |
| append | numeric | apply | 2965794.12 | 0.00 |
| append | numeric | receive | 7168014.29 | 0.00 |
| append | binary | sequence | 677.51 | 0.00 |
| append | binary | encode | 37220.31 | 0.00 |
| append | binary | decode | 2396.31 | 0.00 |
| append | binary | create | 1916.50 | 0.00 |
| append | binary | load | 4421.70 | 0.00 |
| append | binary | apply | 2013724.00 | 0.00 |
| append | binary | receive | 2804766.67 | 0.00 |
| prepend | numeric | sequence | 474425.47 | 0.00 |
| prepend | numeric | encode | 662046.05 | 0.00 |
| prepend | numeric | decode | 210529.41 | 0.00 |
| prepend | numeric | create | 667056.00 | 0.00 |
| prepend | numeric | load | 1289623.08 | 0.00 |
| prepend | numeric | apply | 2376468.18 | 0.00 |
| prepend | numeric | receive | 4392408.33 | 0.00 |
| prepend | binary | sequence | 342786.99 | 0.00 |
| prepend | binary | encode | 32233.38 | 0.00 |
| prepend | binary | decode | 2050.39 | 0.00 |
| prepend | binary | create | 585497.67 | 0.00 |
| prepend | binary | load | 634693.67 | 0.00 |
| prepend | binary | apply | 2407166.67 | 0.00 |
| prepend | binary | receive | 4200475.00 | 0.00 |
| random | numeric | sequence | 937912.96 | 0.00 |
| random | numeric | encode | 2007648.00 | 0.00 |
| random | numeric | decode | 1145740.91 | 0.00 |
| random | numeric | create | 1732644.83 | 0.00 |
| random | numeric | load | 4062800.00 | 0.00 |
| random | numeric | apply | 8525066.67 | 0.00 |
| random | numeric | receive | 12551050.00 | 0.00 |
| random | binary | sequence | 899632.14 | 0.00 |
| random | binary | encode | 66292.19 | 0.00 |
| random | binary | decode | 1514.58 | 0.00 |
| random | binary | create | 1897900.00 | 0.00 |
| random | binary | load | 1893025.93 | 0.00 |
| random | binary | apply | 6303125.00 | 0.00 |
| random | binary | receive | 7973371.43 | 0.00 |
| concurrent | numeric | sequence | 795474.60 | 0.00 |
| concurrent | numeric | encode | 1449540.00 | 0.00 |
| concurrent | numeric | decode | 785042.19 | 0.00 |
| concurrent | numeric | create | 2476352.38 | 0.00 |
| concurrent | numeric | load | 3958507.69 | 0.00 |
| concurrent | numeric | apply | 6114133.33 | 0.00 |
| concurrent | numeric | receive | 9291116.67 | 0.00 |
| concurrent | binary | sequence | 740307.35 | 0.00 |
| concurrent | binary | encode | 56476.19 | 0.00 |
| concurrent | binary | decode | 2765.90 | 0.00 |
| concurrent | binary | create | 2361440.91 | 0.00 |
| concurrent | binary | load | 2415609.52 | 0.00 |
| concurrent | binary | apply | 5408000.00 | 0.00 |
| concurrent | binary | receive | 7001437.50 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
