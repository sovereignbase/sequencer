# Batch benchmarks

2026-11-27T20:55:13.230Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 1,090,909 | 1,075,365 | 512,632 | 76.05 | 5.99 | 0.012 |
| append | batch | 2,134,396 | 185,185,185 | 180,722,892 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 999,367 | 1,168,862 | 534,669 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 713,190 | 953,850 | 966,978 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 774,383 | 547,041 | 506,714 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 909,270 | 974,643 | 1,220,678 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 960,476 | 951,535 | 673,756 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 901,740 | 1,572,574 | 1,268,579 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,170,013 | 1,114,134 | 771,159 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,155,546 | 1,760,693 | 1,403,673 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 927,020 | 1,280,478 | 791,306 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,287,360 | 1,587,050 | 1,511,944 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 696,181 | 969,916 | 705,584 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 786,483 | 1,164,314 | 1,073,470 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,133,316 | 1,442,863 | 995,818 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 1,199,005 | 1,834,666 | 1,600,277 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,083,658 | 1,242,957 | 902,534 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 1,222,668 | 1,602,907 | 1,514,559 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 746,984 | 1,002,322 | 735,321 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 848,356 | 1,181,009 | 1,117,922 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 5.500 | 0.000 |
| append | individual | apply | 5.579 | 0.000 |
| append | individual | receive | 11.704 | 0.000 |
| append | individual | encode | 11.885 | 0.000 |
| append | individual | decode | 8.233 | 0.000 |
| append | batch | author | 2.811 | 0.000 |
| append | batch | apply | 0.032 | 0.000 |
| append | batch | receive | 0.033 | 0.000 |
| append | batch | encode | 0.247 | 0.000 |
| append | batch | decode | 0.108 | 0.000 |
| prepend | individual | author | 6.004 | 0.000 |
| prepend | individual | apply | 5.133 | 0.000 |
| prepend | individual | receive | 11.222 | 0.000 |
| prepend | individual | encode | 11.762 | 0.000 |
| prepend | individual | decode | 10.163 | 0.000 |
| prepend | batch | author | 8.413 | 0.000 |
| prepend | batch | apply | 6.290 | 0.000 |
| prepend | batch | receive | 6.205 | 0.000 |
| prepend | batch | encode | 0.395 | 0.000 |
| prepend | batch | decode | 0.227 | 0.000 |
| random.characters | individual | author | 7.748 | 0.000 |
| random.characters | individual | apply | 10.968 | 0.000 |
| random.characters | individual | receive | 11.841 | 0.000 |
| random.characters | individual | encode | 8.549 | 0.000 |
| random.characters | individual | decode | 14.415 | 0.000 |
| random.characters | batch | author | 6.599 | 0.000 |
| random.characters | batch | apply | 6.156 | 0.000 |
| random.characters | batch | receive | 4.915 | 0.000 |
| random.characters | batch | encode | 0.343 | 0.000 |
| random.characters | batch | decode | 0.188 | 0.000 |
| random.words | individual | author | 6.247 | 0.000 |
| random.words | individual | apply | 6.306 | 0.000 |
| random.words | individual | receive | 8.905 | 0.000 |
| random.words | individual | encode | 6.596 | 0.000 |
| random.words | individual | decode | 8.469 | 0.000 |
| random.words | batch | author | 6.654 | 0.000 |
| random.words | batch | apply | 3.815 | 0.000 |
| random.words | batch | receive | 4.730 | 0.000 |
| random.words | batch | encode | 0.514 | 0.000 |
| random.words | batch | decode | 0.122 | 0.000 |
| concurrent.characters | individual | author | 10.256 | 0.000 |
| concurrent.characters | individual | apply | 10.771 | 0.000 |
| concurrent.characters | individual | receive | 15.561 | 0.000 |
| concurrent.characters | individual | encode | 8.817 | 0.000 |
| concurrent.characters | individual | decode | 11.062 | 0.000 |
| concurrent.characters | batch | author | 10.385 | 0.000 |
| concurrent.characters | batch | apply | 6.815 | 0.000 |
| concurrent.characters | batch | receive | 8.549 | 0.000 |
| concurrent.characters | batch | encode | 0.338 | 0.000 |
| concurrent.characters | batch | decode | 0.110 | 0.000 |
| concurrent.words | individual | author | 12.945 | 0.000 |
| concurrent.words | individual | apply | 9.371 | 0.000 |
| concurrent.words | individual | receive | 15.165 | 0.000 |
| concurrent.words | individual | encode | 10.170 | 0.000 |
| concurrent.words | individual | decode | 13.254 | 0.000 |
| concurrent.words | batch | author | 9.321 | 0.000 |
| concurrent.words | batch | apply | 7.561 | 0.000 |
| concurrent.words | batch | receive | 7.937 | 0.000 |
| concurrent.words | batch | encode | 0.829 | 0.000 |
| concurrent.words | batch | decode | 0.151 | 0.000 |
| concurrent.mixed | individual | author | 17.237 | 0.000 |
| concurrent.mixed | individual | apply | 12.372 | 0.000 |
| concurrent.mixed | individual | receive | 17.007 | 0.000 |
| concurrent.mixed | individual | encode | 9.199 | 0.000 |
| concurrent.mixed | individual | decode | 12.186 | 0.000 |
| concurrent.mixed | batch | author | 15.258 | 0.000 |
| concurrent.mixed | batch | apply | 10.307 | 0.000 |
| concurrent.mixed | batch | receive | 11.179 | 0.000 |
| concurrent.mixed | batch | encode | 1.137 | 0.000 |
| concurrent.mixed | batch | decode | 0.121 | 0.000 |
| causal.characters | individual | author | 10.588 | 0.000 |
| causal.characters | individual | apply | 8.317 | 0.000 |
| causal.characters | individual | receive | 12.050 | 0.000 |
| causal.characters | individual | encode | 6.245 | 0.000 |
| causal.characters | individual | decode | 11.352 | 0.000 |
| causal.characters | batch | author | 10.008 | 0.000 |
| causal.characters | batch | apply | 6.541 | 0.000 |
| causal.characters | batch | receive | 7.499 | 0.000 |
| causal.characters | batch | encode | 0.224 | 0.000 |
| causal.characters | batch | decode | 0.110 | 0.000 |
| causal.words | individual | author | 11.074 | 0.000 |
| causal.words | individual | apply | 9.654 | 0.000 |
| causal.words | individual | receive | 13.296 | 0.000 |
| causal.words | individual | encode | 8.644 | 0.000 |
| causal.words | individual | decode | 12.882 | 0.000 |
| causal.words | batch | author | 9.815 | 0.000 |
| causal.words | batch | apply | 7.486 | 0.000 |
| causal.words | batch | receive | 7.923 | 0.000 |
| causal.words | batch | encode | 0.770 | 0.000 |
| causal.words | batch | decode | 0.164 | 0.000 |
| causal.mixed | individual | author | 16.065 | 0.000 |
| causal.mixed | individual | apply | 11.972 | 0.000 |
| causal.mixed | individual | receive | 16.319 | 0.000 |
| causal.mixed | individual | encode | 8.490 | 0.000 |
| causal.mixed | individual | decode | 9.542 | 0.000 |
| causal.mixed | batch | author | 14.145 | 0.000 |
| causal.mixed | batch | apply | 10.161 | 0.000 |
| causal.mixed | batch | receive | 10.734 | 0.000 |
| causal.mixed | batch | encode | 0.446 | 0.000 |
| causal.mixed | batch | decode | 0.103 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
