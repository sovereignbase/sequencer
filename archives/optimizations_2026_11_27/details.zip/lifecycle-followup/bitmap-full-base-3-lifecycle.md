# Sequencer dynamic lifecycle benchmark

2026-11-27T20:53:43.580Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.23 | 162.89 | 56.49 |
| CommonJS | 199.41 | 164.51 | 56.69 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 306,319 | 3.265 | 3.265 | 3.265 | 0.000 | 0: 3.265 | 0: 3.265 |
| apply | random | A | scaleDown | 24,999 | 330,859 | 3.022 | 3.022 | 3.022 | 0.000 | 0: 3.022 | 0: 3.022 |
| apply | random | A | fullLifecycle | 49,999 | 318,116 | 3.144 | 3.144 | 3.144 | 0.000 | 0: 3.144 | 0: 3.144 |
| create | — | A | scaleUp | 7 | 487 | 2052.471 | 2052.471 | 2052.471 | 0.000 | 0: 2052.471 | 0: 2052.471 |
| create | — | A | scaleDown | 6 | 647 | 1545.417 | 1545.417 | 1545.417 | 0.000 | 0: 1545.417 | 0: 1545.417 |
| create | — | A | fullLifecycle | 13 | 550 | 1818.446 | 1818.446 | 1818.446 | 0.000 | 0: 1818.446 | 0: 1818.446 |
| insert | head | A | scaleUp | 12,500 | 1,260,703 | 0.793 | 0.793 | 0.793 | 0.000 | 0: 0.793 | 0: 0.793 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,260,703 | 0.793 | 0.793 | 0.793 | 0.000 | 0: 0.793 | 0: 0.793 |
| insert | random | A | scaleUp | 25,000 | 560,966 | 1.783 | 1.783 | 1.783 | 0.000 | 0: 1.783 | 0: 1.783 |
| insert | random | A | scaleDown | 25,000 | 639,002 | 1.565 | 1.565 | 1.565 | 0.000 | 0: 1.565 | 0: 1.565 |
| insert | random | A | fullLifecycle | 50,000 | 597,447 | 1.674 | 1.674 | 1.674 | 0.000 | 0: 1.674 | 0: 1.674 |
| insert | tail | A | scaleUp | 12,500 | 1,256,395 | 0.796 | 0.796 | 0.796 | 0.000 | 0: 0.796 | 0: 0.796 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,256,395 | 0.796 | 0.796 | 0.796 | 0.000 | 0: 0.796 | 0: 0.796 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 716,123 | 1.396 | 1.396 | 1.396 | 0.000 | 0: 1.396 | 0: 1.396 |
| remove | head | A | fullLifecycle | 12,500 | 716,123 | 1.396 | 1.396 | 1.396 | 0.000 | 0: 1.396 | 0: 1.396 |
| remove | random | A | scaleUp | 25,000 | 470,099 | 2.127 | 2.127 | 2.127 | 0.000 | 0: 2.127 | 0: 2.127 |
| remove | random | A | scaleDown | 25,000 | 520,559 | 1.921 | 1.921 | 1.921 | 0.000 | 0: 1.921 | 0: 1.921 |
| remove | random | A | fullLifecycle | 50,000 | 494,044 | 2.024 | 2.024 | 2.024 | 0.000 | 0: 2.024 | 0: 2.024 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 788,673 | 1.268 | 1.268 | 1.268 | 0.000 | 0: 1.268 | 0: 1.268 |
| remove | tail | A | fullLifecycle | 12,500 | 788,673 | 1.268 | 1.268 | 1.268 | 0.000 | 0: 1.268 | 0: 1.268 |
| replace | head | A | scaleUp | 25,000 | 474,490 | 2.108 | 2.108 | 2.108 | 0.000 | 0: 2.108 | 0: 2.108 |
| replace | head | A | scaleDown | 25,000 | 506,369 | 1.975 | 1.975 | 1.975 | 0.000 | 0: 1.975 | 0: 1.975 |
| replace | head | A | fullLifecycle | 50,000 | 489,911 | 2.041 | 2.041 | 2.041 | 0.000 | 0: 2.041 | 0: 2.041 |
| replace | random | A | scaleUp | 25,000 | 344,709 | 2.901 | 2.901 | 2.901 | 0.000 | 0: 2.901 | 0: 2.901 |
| replace | random | A | scaleDown | 25,000 | 387,000 | 2.584 | 2.584 | 2.584 | 0.000 | 0: 2.584 | 0: 2.584 |
| replace | random | A | fullLifecycle | 50,000 | 364,632 | 2.742 | 2.742 | 2.742 | 0.000 | 0: 2.742 | 0: 2.742 |
| replace | tail | A | scaleUp | 25,000 | 497,708 | 2.009 | 2.009 | 2.009 | 0.000 | 0: 2.009 | 0: 2.009 |
| replace | tail | A | scaleDown | 25,000 | 56,677 | 17.644 | 17.644 | 17.644 | 0.000 | 0: 17.644 | 0: 17.644 |
| replace | tail | A | fullLifecycle | 50,000 | 101,766 | 9.826 | 9.826 | 9.826 | 0.000 | 0: 9.826 | 0: 9.826 |
| sequence | — | A | scaleUp | 6 | 58 | 17106.800 | 17106.800 | 17106.800 | 0.000 | 0: 17106.800 | 0: 17106.800 |
| sequence | — | A | scaleDown | 6 | 92 | 10875.233 | 10875.233 | 10875.233 | 0.000 | 0: 10875.233 | 0: 10875.233 |
| sequence | — | A | fullLifecycle | 12 | 71 | 13991.017 | 13991.017 | 13991.017 | 0.000 | 0: 13991.017 | 0: 13991.017 |
| value | head | A | scaleUp | 25,000 | 3,165,839 | 0.316 | 0.316 | 0.316 | 0.000 | 0: 0.316 | 0: 0.316 |
| value | head | A | scaleDown | 25,000 | 2,479,839 | 0.403 | 0.403 | 0.403 | 0.000 | 0: 0.403 | 0: 0.403 |
| value | head | A | fullLifecycle | 50,000 | 2,781,162 | 0.360 | 0.360 | 0.360 | 0.000 | 0: 0.360 | 0: 0.360 |
| value | random | A | scaleUp | 25,000 | 888,267 | 1.126 | 1.126 | 1.126 | 0.000 | 0: 1.126 | 0: 1.126 |
| value | random | A | scaleDown | 25,000 | 1,014,507 | 0.986 | 0.986 | 0.986 | 0.000 | 0: 0.986 | 0: 0.986 |
| value | random | A | fullLifecycle | 50,000 | 947,199 | 1.056 | 1.056 | 1.056 | 0.000 | 0: 1.056 | 0: 1.056 |
| value | tail | A | scaleUp | 25,000 | 6,307,716 | 0.159 | 0.159 | 0.159 | 0.000 | 0: 0.159 | 0: 0.159 |
| value | tail | A | scaleDown | 25,000 | 4,236,355 | 0.236 | 0.236 | 0.236 | 0.000 | 0: 0.236 | 0: 0.236 |
| value | tail | A | fullLifecycle | 50,000 | 5,068,578 | 0.197 | 0.197 | 0.197 | 0.000 | 0: 0.197 | 0: 0.197 |
| values | — | A | scaleUp | 6 | 143 | 7001.150 | 7001.150 | 7001.150 | 0.000 | 0: 7001.150 | 0: 7001.150 |
| values | — | A | scaleDown | 6 | 236 | 4239.050 | 4239.050 | 4239.050 | 0.000 | 0: 4239.050 | 0: 4239.050 |
| values | — | A | fullLifecycle | 12 | 178 | 5620.100 | 5620.100 | 5620.100 | 0.000 | 0: 5620.100 | 0: 5620.100 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5439899.333 | 429.466 | 8.475 |
| A | scaleDown | 5 | 4402917.600 | 431.659 | 8.549 |
| A | fullLifecycle | 11 | 4968544.000 | 430.346 | 8.505 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3131086.833 | 247.191 | 4.878 |
| A | scaleDown | 5 | 2593300.000 | 254.245 | 5.036 |
| A | fullLifecycle | 11 | 2886638.273 | 250.024 | 4.941 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 50,041 | A | 1,000 | 256,463 | 3.899 | 2.000 | 32.100 |
| apply | random | 0 | up | 5,000 | 253,849 | A | 5,000 | 290,725 | 3.440 | 1.800 | 293.000 |
| apply | random | 0 | up | 10,000 | 510,883 | A | 10,000 | 296,195 | 3.376 | 1.600 | 913.300 |
| apply | random | 0 | up | 15,000 | 762,464 | A | 15,000 | 308,532 | 3.241 | 1.600 | 913.300 |
| apply | random | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 314,039 | 3.184 | 1.600 | 913.300 |
| apply | random | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 306,319 | 3.265 | 1.600 | 913.300 |
| apply | random | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 295,327 | 3.386 | 1.600 | 4733.100 |
| apply | random | 0 | down | 15,000 | 754,542 | A | 35,000 | 301,603 | 3.316 | 1.600 | 4733.100 |
| apply | random | 0 | down | 10,000 | 504,420 | A | 40,000 | 306,958 | 3.258 | 1.600 | 4733.100 |
| apply | random | 0 | down | 5,000 | 253,074 | A | 45,000 | 312,459 | 3.200 | 1.600 | 4733.100 |
| apply | random | 0 | down | 1,000 | 48,660 | A | 49,000 | 316,230 | 3.162 | 1.400 | 4733.100 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 318,116 | 3.144 | 1.300 | 4733.100 |
| insert | head | 0 | up | 1,000 | 50,041 | A | 500 | 832,085 | 1.202 | 0.400 | 38.300 |
| insert | head | 0 | up | 5,000 | 253,849 | A | 2,500 | 1,056,993 | 0.946 | 0.400 | 38.300 |
| insert | head | 0 | up | 10,000 | 510,883 | A | 5,000 | 1,159,958 | 0.862 | 0.300 | 179.400 |
| insert | head | 0 | up | 15,000 | 762,464 | A | 7,500 | 1,239,813 | 0.807 | 0.300 | 179.400 |
| insert | head | 0 | up | 20,000 | 1,009,832 | A | 10,000 | 1,275,624 | 0.784 | 0.300 | 179.400 |
| insert | head | 0 | up | 25,000 | 1,264,057 | A | 12,500 | 1,260,703 | 0.793 | 0.300 | 179.400 |
| insert | head | 0 | down | 20,000 | 1,014,321 | A | 12,500 | 1,260,703 | 0.793 | 0.300 | 179.400 |
| insert | head | 0 | down | 15,000 | 754,542 | A | 12,500 | 1,260,703 | 0.793 | 0.300 | 179.400 |
| insert | head | 0 | down | 10,000 | 504,420 | A | 12,500 | 1,260,703 | 0.793 | 0.300 | 179.400 |
| insert | head | 0 | down | 5,000 | 253,074 | A | 12,500 | 1,260,703 | 0.793 | 0.300 | 179.400 |
| insert | head | 0 | down | 1,000 | 48,660 | A | 12,500 | 1,260,703 | 0.793 | 0.300 | 179.400 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,260,703 | 0.793 | 0.300 | 179.400 |
| insert | random | 0 | up | 1,000 | 50,041 | A | 1,000 | 419,674 | 2.383 | 0.500 | 386.800 |
| insert | random | 0 | up | 5,000 | 253,849 | A | 5,000 | 463,323 | 2.158 | 0.500 | 1131.000 |
| insert | random | 0 | up | 10,000 | 510,883 | A | 10,000 | 545,265 | 1.834 | 0.500 | 1131.000 |
| insert | random | 0 | up | 15,000 | 762,464 | A | 15,000 | 572,325 | 1.747 | 0.500 | 1131.000 |
| insert | random | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 579,944 | 1.724 | 0.400 | 1131.000 |
| insert | random | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 560,966 | 1.783 | 0.400 | 1131.000 |
| insert | random | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 562,396 | 1.778 | 0.400 | 1131.000 |
| insert | random | 0 | down | 15,000 | 754,542 | A | 35,000 | 566,203 | 1.766 | 0.400 | 1131.000 |
| insert | random | 0 | down | 10,000 | 504,420 | A | 40,000 | 577,026 | 1.733 | 0.400 | 1131.000 |
| insert | random | 0 | down | 5,000 | 253,074 | A | 45,000 | 584,508 | 1.711 | 0.400 | 1131.000 |
| insert | random | 0 | down | 1,000 | 48,660 | A | 49,000 | 592,262 | 1.688 | 0.400 | 1131.000 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 597,447 | 1.674 | 0.400 | 1131.000 |
| insert | tail | 0 | up | 1,000 | 50,041 | A | 500 | 1,098,901 | 0.910 | 0.300 | 14.100 |
| insert | tail | 0 | up | 5,000 | 253,849 | A | 2,500 | 1,217,671 | 0.821 | 0.300 | 64.100 |
| insert | tail | 0 | up | 10,000 | 510,883 | A | 5,000 | 1,346,439 | 0.743 | 0.300 | 86.300 |
| insert | tail | 0 | up | 15,000 | 762,464 | A | 7,500 | 1,225,731 | 0.816 | 0.300 | 744.100 |
| insert | tail | 0 | up | 20,000 | 1,009,832 | A | 10,000 | 1,292,557 | 0.774 | 0.300 | 744.100 |
| insert | tail | 0 | up | 25,000 | 1,264,057 | A | 12,500 | 1,256,395 | 0.796 | 0.300 | 744.100 |
| insert | tail | 0 | down | 20,000 | 1,014,321 | A | 12,500 | 1,256,395 | 0.796 | 0.300 | 744.100 |
| insert | tail | 0 | down | 15,000 | 754,542 | A | 12,500 | 1,256,395 | 0.796 | 0.300 | 744.100 |
| insert | tail | 0 | down | 10,000 | 504,420 | A | 12,500 | 1,256,395 | 0.796 | 0.300 | 744.100 |
| insert | tail | 0 | down | 5,000 | 253,074 | A | 12,500 | 1,256,395 | 0.796 | 0.300 | 744.100 |
| insert | tail | 0 | down | 1,000 | 48,660 | A | 12,500 | 1,256,395 | 0.796 | 0.300 | 744.100 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,256,395 | 0.796 | 0.300 | 744.100 |
| remove | head | 0 | up | 1,000 | 50,041 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 253,849 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 510,883 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 762,464 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,009,832 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,264,057 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,014,321 | A | 2,500 | 676,700 | 1.478 | 0.900 | 45.600 |
| remove | head | 0 | down | 15,000 | 754,542 | A | 5,000 | 700,457 | 1.428 | 0.800 | 45.600 |
| remove | head | 0 | down | 10,000 | 504,420 | A | 7,500 | 673,225 | 1.485 | 0.800 | 760.200 |
| remove | head | 0 | down | 5,000 | 253,074 | A | 10,000 | 698,363 | 1.432 | 0.800 | 760.200 |
| remove | head | 0 | down | 1,000 | 48,660 | A | 12,000 | 709,799 | 1.409 | 0.800 | 760.200 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 716,123 | 1.396 | 0.800 | 760.200 |
| remove | random | 0 | up | 1,000 | 50,041 | A | 1,000 | 391,803 | 2.552 | 0.900 | 512.700 |
| remove | random | 0 | up | 5,000 | 253,849 | A | 5,000 | 428,416 | 2.334 | 0.900 | 1093.000 |
| remove | random | 0 | up | 10,000 | 510,883 | A | 10,000 | 452,942 | 2.208 | 0.900 | 1093.000 |
| remove | random | 0 | up | 15,000 | 762,464 | A | 15,000 | 478,767 | 2.089 | 0.800 | 1093.000 |
| remove | random | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 483,592 | 2.068 | 0.800 | 1093.000 |
| remove | random | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 470,099 | 2.127 | 0.800 | 1093.000 |
| remove | random | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 469,792 | 2.129 | 0.800 | 1093.000 |
| remove | random | 0 | down | 15,000 | 754,542 | A | 35,000 | 473,966 | 2.110 | 0.800 | 1093.000 |
| remove | random | 0 | down | 10,000 | 504,420 | A | 40,000 | 479,461 | 2.086 | 0.800 | 1093.000 |
| remove | random | 0 | down | 5,000 | 253,074 | A | 45,000 | 486,390 | 2.056 | 0.800 | 1093.000 |
| remove | random | 0 | down | 1,000 | 48,660 | A | 49,000 | 490,377 | 2.039 | 0.800 | 1093.000 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 494,044 | 2.024 | 0.800 | 1093.000 |
| remove | tail | 0 | up | 1,000 | 50,041 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 253,849 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 510,883 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 762,464 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,009,832 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,264,057 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,014,321 | A | 2,500 | 768,214 | 1.302 | 0.800 | 47.200 |
| remove | tail | 0 | down | 15,000 | 754,542 | A | 5,000 | 711,318 | 1.406 | 0.800 | 606.500 |
| remove | tail | 0 | down | 10,000 | 504,420 | A | 7,500 | 747,988 | 1.337 | 0.800 | 606.500 |
| remove | tail | 0 | down | 5,000 | 253,074 | A | 10,000 | 770,030 | 1.299 | 0.700 | 606.500 |
| remove | tail | 0 | down | 1,000 | 48,660 | A | 12,000 | 781,647 | 1.279 | 0.700 | 606.500 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 788,673 | 1.268 | 0.600 | 606.500 |
| replace | head | 0 | up | 1,000 | 50,041 | A | 1,000 | 437,579 | 2.285 | 1.200 | 82.600 |
| replace | head | 0 | up | 5,000 | 253,849 | A | 5,000 | 465,896 | 2.146 | 1.200 | 167.600 |
| replace | head | 0 | up | 10,000 | 510,883 | A | 10,000 | 510,329 | 1.960 | 1.100 | 167.600 |
| replace | head | 0 | up | 15,000 | 762,464 | A | 15,000 | 528,247 | 1.893 | 1.100 | 309.400 |
| replace | head | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 543,115 | 1.841 | 1.100 | 309.400 |
| replace | head | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 474,490 | 2.108 | 1.100 | 4544.100 |
| replace | head | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 477,051 | 2.096 | 1.100 | 4544.100 |
| replace | head | 0 | down | 15,000 | 754,542 | A | 35,000 | 480,187 | 2.083 | 1.100 | 4544.100 |
| replace | head | 0 | down | 10,000 | 504,420 | A | 40,000 | 479,224 | 2.087 | 1.000 | 4544.100 |
| replace | head | 0 | down | 5,000 | 253,074 | A | 45,000 | 483,025 | 2.070 | 1.000 | 4544.100 |
| replace | head | 0 | down | 1,000 | 48,660 | A | 49,000 | 487,079 | 2.053 | 1.000 | 4544.100 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 489,911 | 2.041 | 1.000 | 4544.100 |
| replace | random | 0 | up | 1,000 | 50,041 | A | 1,000 | 385,282 | 2.595 | 1.300 | 62.100 |
| replace | random | 0 | up | 5,000 | 253,849 | A | 5,000 | 348,987 | 2.865 | 1.300 | 427.400 |
| replace | random | 0 | up | 10,000 | 510,883 | A | 10,000 | 364,051 | 2.747 | 1.200 | 427.400 |
| replace | random | 0 | up | 15,000 | 762,464 | A | 15,000 | 364,971 | 2.740 | 1.200 | 684.900 |
| replace | random | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 367,301 | 2.723 | 1.200 | 684.900 |
| replace | random | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 344,709 | 2.901 | 1.200 | 1967.000 |
| replace | random | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 346,919 | 2.883 | 1.100 | 1967.000 |
| replace | random | 0 | down | 15,000 | 754,542 | A | 35,000 | 345,680 | 2.893 | 1.100 | 1967.000 |
| replace | random | 0 | down | 10,000 | 504,420 | A | 40,000 | 351,890 | 2.842 | 1.100 | 1967.000 |
| replace | random | 0 | down | 5,000 | 253,074 | A | 45,000 | 356,008 | 2.809 | 1.100 | 1967.000 |
| replace | random | 0 | down | 1,000 | 48,660 | A | 49,000 | 361,397 | 2.767 | 1.000 | 1967.000 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 364,632 | 2.742 | 0.900 | 1967.000 |
| replace | tail | 0 | up | 1,000 | 50,041 | A | 1,000 | 442,772 | 2.259 | 1.200 | 121.100 |
| replace | tail | 0 | up | 5,000 | 253,849 | A | 5,000 | 485,305 | 2.061 | 1.200 | 121.100 |
| replace | tail | 0 | up | 10,000 | 510,883 | A | 10,000 | 462,302 | 2.163 | 1.000 | 2618.200 |
| replace | tail | 0 | up | 15,000 | 762,464 | A | 15,000 | 496,053 | 2.016 | 1.000 | 2618.200 |
| replace | tail | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 496,443 | 2.014 | 1.000 | 2618.200 |
| replace | tail | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 497,708 | 2.009 | 1.000 | 2618.200 |
| replace | tail | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 129,629 | 7.714 | 1.000 | 2618.200 |
| replace | tail | 0 | down | 15,000 | 754,542 | A | 35,000 | 97,708 | 10.235 | 1.000 | 2618.200 |
| replace | tail | 0 | down | 10,000 | 504,420 | A | 40,000 | 99,331 | 10.067 | 1.000 | 2618.200 |
| replace | tail | 0 | down | 5,000 | 253,074 | A | 45,000 | 97,714 | 10.234 | 1.000 | 2618.200 |
| replace | tail | 0 | down | 1,000 | 48,660 | A | 49,000 | 100,147 | 9.985 | 0.900 | 2618.200 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 101,766 | 9.826 | 0.900 | 2618.200 |
| value | head | 0 | up | 1,000 | 50,041 | A | 1,000 | 1,576,293 | 0.634 | 0.200 | 225.900 |
| value | head | 0 | up | 5,000 | 253,849 | A | 5,000 | 2,453,025 | 0.408 | 0.100 | 225.900 |
| value | head | 0 | up | 10,000 | 510,883 | A | 10,000 | 2,871,253 | 0.348 | 0.100 | 225.900 |
| value | head | 0 | up | 15,000 | 762,464 | A | 15,000 | 3,059,851 | 0.327 | 0.100 | 225.900 |
| value | head | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 3,200,307 | 0.312 | 0.100 | 225.900 |
| value | head | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 3,165,839 | 0.316 | 0.100 | 225.900 |
| value | head | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 2,995,387 | 0.334 | 0.100 | 225.900 |
| value | head | 0 | down | 15,000 | 754,542 | A | 35,000 | 2,917,712 | 0.343 | 0.100 | 225.900 |
| value | head | 0 | down | 10,000 | 504,420 | A | 40,000 | 2,858,858 | 0.350 | 0.100 | 225.900 |
| value | head | 0 | down | 5,000 | 253,074 | A | 45,000 | 2,815,157 | 0.355 | 0.100 | 225.900 |
| value | head | 0 | down | 1,000 | 48,660 | A | 49,000 | 2,777,022 | 0.360 | 0.100 | 225.900 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,781,162 | 0.360 | 0.100 | 225.900 |
| value | random | 0 | up | 1,000 | 50,041 | A | 1,000 | 1,265,823 | 0.790 | 0.100 | 51.500 |
| value | random | 0 | up | 5,000 | 253,849 | A | 5,000 | 1,000,560 | 0.999 | 0.100 | 51.500 |
| value | random | 0 | up | 10,000 | 510,883 | A | 10,000 | 978,043 | 1.022 | 0.100 | 51.500 |
| value | random | 0 | up | 15,000 | 762,464 | A | 15,000 | 956,486 | 1.045 | 0.100 | 51.500 |
| value | random | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 951,864 | 1.051 | 0.100 | 61.500 |
| value | random | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 888,267 | 1.126 | 0.100 | 61.500 |
| value | random | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 898,077 | 1.113 | 0.100 | 61.500 |
| value | random | 0 | down | 15,000 | 754,542 | A | 35,000 | 903,863 | 1.106 | 0.100 | 61.600 |
| value | random | 0 | down | 10,000 | 504,420 | A | 40,000 | 916,160 | 1.092 | 0.100 | 61.600 |
| value | random | 0 | down | 5,000 | 253,074 | A | 45,000 | 924,794 | 1.081 | 0.100 | 61.600 |
| value | random | 0 | down | 1,000 | 48,660 | A | 49,000 | 938,253 | 1.066 | 0.100 | 61.600 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 947,199 | 1.056 | 0.100 | 61.600 |
| value | tail | 0 | up | 1,000 | 50,041 | A | 1,000 | 5,130,836 | 0.195 | 0.100 | 14.000 |
| value | tail | 0 | up | 5,000 | 253,849 | A | 5,000 | 5,162,623 | 0.194 | 0.100 | 26.200 |
| value | tail | 0 | up | 10,000 | 510,883 | A | 10,000 | 5,689,253 | 0.176 | 0.100 | 26.200 |
| value | tail | 0 | up | 15,000 | 762,464 | A | 15,000 | 6,010,819 | 0.166 | 0.000 | 33.800 |
| value | tail | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 6,273,526 | 0.159 | 0.000 | 33.800 |
| value | tail | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 6,307,716 | 0.159 | 0.000 | 33.800 |
| value | tail | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 5,849,550 | 0.171 | 0.000 | 33.800 |
| value | tail | 0 | down | 15,000 | 754,542 | A | 35,000 | 5,528,265 | 0.181 | 0.000 | 45.800 |
| value | tail | 0 | down | 10,000 | 504,420 | A | 40,000 | 5,304,407 | 0.189 | 0.000 | 45.800 |
| value | tail | 0 | down | 5,000 | 253,074 | A | 45,000 | 5,143,739 | 0.194 | 0.000 | 45.800 |
| value | tail | 0 | down | 1,000 | 48,660 | A | 49,000 | 5,062,245 | 0.198 | 0.000 | 45.800 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,068,578 | 0.197 | 0.000 | 45.800 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,361 | 423.500 |
| create | — | 0 | up | 5,000 | A | 1 | 811 | 1233.200 |
| create | — | 0 | up | 10,000 | A | 1 | 646 | 1548.400 |
| create | — | 0 | up | 15,000 | A | 1 | 409 | 2444.700 |
| create | — | 0 | up | 20,000 | A | 1 | 283 | 3536.700 |
| create | — | 0 | up | 25,000 | A | 1 | 197 | 5068.300 |
| create | — | 0 | down | 20,000 | A | 1 | 282 | 3549.700 |
| create | — | 0 | down | 15,000 | A | 1 | 392 | 2548.700 |
| create | — | 0 | down | 10,000 | A | 1 | 474 | 2111.500 |
| create | — | 0 | down | 5,000 | A | 1 | 1,116 | 896.100 |
| create | — | 0 | down | 1,000 | A | 1 | 6,698 | 149.300 |
| create | — | 0 | down | 0 | A | 1 | 58,140 | 17.200 |
| sequence | — | 0 | up | 1,000 | A | 1 | 367 | 2722.200 |
| sequence | — | 0 | up | 5,000 | A | 1 | 135 | 7382.100 |
| sequence | — | 0 | up | 10,000 | A | 1 | 77 | 13068.700 |
| sequence | — | 0 | up | 15,000 | A | 1 | 74 | 13595.700 |
| sequence | — | 0 | up | 20,000 | A | 1 | 35 | 28982.400 |
| sequence | — | 0 | up | 25,000 | A | 1 | 27 | 36889.700 |
| sequence | — | 0 | down | 20,000 | A | 1 | 50 | 19891.900 |
| sequence | — | 0 | down | 15,000 | A | 1 | 68 | 14634.500 |
| sequence | — | 0 | down | 10,000 | A | 1 | 75 | 13421.000 |
| sequence | — | 0 | down | 5,000 | A | 1 | 103 | 9737.900 |
| sequence | — | 0 | down | 1,000 | A | 1 | 166 | 6041.100 |
| sequence | — | 0 | down | 0 | A | 1 | 656 | 1525.000 |
| values | — | 0 | up | 1,000 | A | 1 | 482 | 2073.200 |
| values | — | 0 | up | 5,000 | A | 1 | 185 | 5408.400 |
| values | — | 0 | up | 10,000 | A | 1 | 211 | 4738.500 |
| values | — | 0 | up | 15,000 | A | 1 | 150 | 6664.900 |
| values | — | 0 | up | 20,000 | A | 1 | 88 | 11395.700 |
| values | — | 0 | up | 25,000 | A | 1 | 85 | 11726.200 |
| values | — | 0 | down | 20,000 | A | 1 | 93 | 10754.500 |
| values | — | 0 | down | 15,000 | A | 1 | 141 | 7096.700 |
| values | — | 0 | down | 10,000 | A | 1 | 204 | 4901.200 |
| values | — | 0 | down | 5,000 | A | 1 | 443 | 2257.900 |
| values | — | 0 | down | 1,000 | A | 1 | 2,429 | 411.700 |
| values | — | 0 | down | 0 | A | 1 | 81,301 | 12.300 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.614 | 0.232 | 0.382 |
| 0 | up | 5000 | 3.104 | 1.168 | 1.937 |
| 0 | up | 10000 | 6.240 | 2.342 | 3.898 |
| 0 | up | 15000 | 9.457 | 3.640 | 5.817 |
| 0 | up | 20000 | 12.811 | 5.107 | 7.704 |
| 0 | up | 25000 | 16.275 | 6.631 | 9.644 |
| 0 | down | 20000 | 13.346 | 5.607 | 7.739 |
| 0 | down | 15000 | 9.885 | 4.128 | 5.757 |
| 0 | down | 10000 | 7.141 | 3.292 | 3.848 |
| 0 | down | 5000 | 4.088 | 2.157 | 1.931 |
| 0 | down | 1000 | 1.786 | 1.414 | 0.371 |
| 0 | down | 0 | 1.225 | 1.225 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 50,041 | 0.402 | 421.672 | 8.427 | 121.609 | 15.526 |
| 0 | up | A | 5,000 | 5,000 | 253,849 | 2.039 | 427.629 | 8.423 | 154.723 | 19.632 |
| 0 | up | A | 10,000 | 10,000 | 510,883 | 4.110 | 430.944 | 8.435 | 196.332 | 24.560 |
| 0 | up | A | 15,000 | 15,000 | 762,464 | 6.157 | 430.382 | 8.467 | 209.539 | 29.392 |
| 0 | up | A | 20,000 | 20,000 | 1,009,832 | 8.173 | 428.522 | 8.487 | 281.031 | 34.165 |
| 0 | up | A | 25,000 | 25,000 | 1,264,057 | 10.246 | 429.759 | 8.500 | 295.371 | 39.009 |
| 0 | down | A | 20,000 | 20,000 | 1,014,321 | 8.275 | 433.859 | 8.555 | 298.723 | 34.259 |
| 0 | down | A | 15,000 | 15,000 | 754,542 | 6.164 | 430.905 | 8.566 | 302.223 | 29.345 |
| 0 | down | A | 10,000 | 10,000 | 504,420 | 4.110 | 430.931 | 8.543 | 300.766 | 24.597 |
| 0 | down | A | 5,000 | 5,000 | 253,074 | 2.052 | 430.392 | 8.503 | 299.059 | 19.830 |
| 0 | down | A | 1,000 | 1,000 | 48,660 | 0.393 | 412.560 | 8.478 | 297.578 | 15.954 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 298.902 | 14.906 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 50041 | 184359 | 184.359 | 3.684 | 272.12 | 14.48 | 162.13 | 12.35 |
| 0 | up | A | 5000 | 253849 | 1210131 | 242.026 | 4.767 | 1631.56 | 73.59 | 824.15 | 61.70 |
| 0 | up | A | 10000 | 510883 | 2452112 | 245.211 | 4.800 | 3291.52 | 148.51 | 1662.88 | 124.76 |
| 0 | up | A | 15000 | 762464 | 3718728 | 247.915 | 4.877 | 4953.57 | 226.18 | 3565.41 | 200.21 |
| 0 | up | A | 20000 | 1009832 | 4967551 | 248.378 | 4.919 | 7097.32 | 310.72 | 5120.56 | 263.24 |
| 0 | up | A | 25000 | 1264057 | 6253640 | 250.146 | 4.947 | 9263.03 | 392.29 | 6552.58 | 334.88 |
| 0 | down | A | 20000 | 1014321 | 5127975 | 256.399 | 5.056 | 7587.58 | 326.56 | 5325.66 | 277.90 |
| 0 | down | A | 15000 | 754542 | 3826315 | 255.088 | 5.071 | 5697.28 | 247.45 | 3981.92 | 209.66 |
| 0 | down | A | 10000 | 504420 | 2533733 | 253.373 | 5.023 | 3814.68 | 164.99 | 2660.13 | 140.01 |
| 0 | down | A | 5000 | 253074 | 1246106 | 249.221 | 4.924 | 1903.81 | 79.91 | 1330.40 | 67.87 |
| 0 | down | A | 1000 | 48660 | 232371 | 232.371 | 4.775 | 363.99 | 15.96 | 255.01 | 13.61 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 429.466 | 8.475 | 247.191 | 4.878 |
| 0 | A | scaleDown | 431.659 | 8.549 | 254.245 | 5.036 |
| 0 | A | fullLifecycle | 430.346 | 8.505 | 250.024 | 4.941 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
