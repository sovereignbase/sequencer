# Large string benchmarks

2026-11-27T20:54:44.936Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2321.22 | 0.00 |
| 1024 | insert.append | array | 13367.61 | 0.00 |
| 1024 | replace | array | 3343.65 | 0.00 |
| 1024 | remove | array | 1077.03 | 0.00 |
| 1024 | remove.middle | array | 2035.66 | 0.00 |
| 1024 | replace.middle | array | 2311.93 | 0.00 |
| 1024 | apply | array | 805.92 | 0.00 |
| 1024 | apply.array | array | 597.25 | 0.00 |
| 1024 | concurrent.apply | array | 66593.09 | 0.00 |
| 1024 | merge | array | 3233.38 | 0.00 |
| 1024 | create | array | 2998.79 | 0.00 |
| 1024 | value.random | array | 44.85 | 0.00 |
| 1024 | values.range | array | 114.67 | 0.00 |
| 1024 | values.array | array | 1430.81 | 0.00 |
| 1024 | values.text | array | 14678.46 | 0.00 |
| 1024 | sequence.array | array | 1630.30 | 0.00 |
| 1024 | sequence.text | array | 10879.81 | 0.00 |
| 1024 | sequence.edited.text | array | 15029.15 | 0.00 |
| 1024 | sequence.masked.text | array | 11683.97 | 0.00 |
| 1024 | insert | string | 466.27 | 0.00 |
| 1024 | insert.append | string | 4361.95 | 0.00 |
| 1024 | replace | string | 1149.45 | 0.00 |
| 1024 | remove | string | 956.77 | 0.00 |
| 1024 | remove.middle | string | 1014.14 | 0.00 |
| 1024 | replace.middle | string | 1316.32 | 0.00 |
| 1024 | apply | string | 796.86 | 0.00 |
| 1024 | apply.array | string | 2379.60 | 0.00 |
| 1024 | concurrent.apply | string | 3849.14 | 0.00 |
| 1024 | merge | string | 1334.92 | 0.00 |
| 1024 | create | string | 946.31 | 0.00 |
| 1024 | value.random | string | 80.69 | 0.00 |
| 1024 | values.range | string | 195.34 | 0.00 |
| 1024 | values.array | string | 1977.12 | 0.00 |
| 1024 | values.text | string | 71.90 | 0.00 |
| 1024 | sequence.array | string | 1965.42 | 0.00 |
| 1024 | sequence.text | string | 211.45 | 0.00 |
| 1024 | sequence.edited.text | string | 2149.43 | 0.00 |
| 1024 | sequence.masked.text | string | 3407.56 | 0.00 |
| 65536 | insert | array | 248848.51 | 0.00 |
| 65536 | insert.append | array | 1097308.00 | 0.00 |
| 65536 | replace | array | 254075.76 | 0.00 |
| 65536 | remove | array | 2452.77 | 0.00 |
| 65536 | remove.middle | array | 225640.54 | 0.00 |
| 65536 | replace.middle | array | 235850.91 | 0.00 |
| 65536 | apply | array | 873.41 | 0.00 |
| 65536 | apply.array | array | 581.56 | 0.00 |
| 65536 | concurrent.apply | array | 4042485.71 | 0.00 |
| 65536 | merge | array | 209476.67 | 0.00 |
| 65536 | create | array | 230344.95 | 0.00 |
| 65536 | value.random | array | 54.72 | 0.00 |
| 65536 | values.range | array | 138.21 | 0.00 |
| 65536 | values.array | array | 203731.75 | 0.00 |
| 65536 | values.text | array | 795412.50 | 0.00 |
| 65536 | sequence.array | array | 202646.83 | 0.00 |
| 65536 | sequence.text | array | 685678.38 | 0.00 |
| 65536 | sequence.edited.text | array | 953543.33 | 0.00 |
| 65536 | sequence.masked.text | array | 696727.78 | 0.00 |
| 65536 | insert | string | 464.94 | 0.00 |
| 65536 | insert.append | string | 21041.30 | 0.00 |
| 65536 | replace | string | 1280.54 | 0.00 |
| 65536 | remove | string | 1306.69 | 0.00 |
| 65536 | remove.middle | string | 901.86 | 0.00 |
| 65536 | replace.middle | string | 1222.44 | 0.00 |
| 65536 | apply | string | 725.52 | 0.00 |
| 65536 | apply.array | string | 252701.56 | 0.00 |
| 65536 | concurrent.apply | string | 143163.43 | 0.00 |
| 65536 | merge | string | 1160.75 | 0.00 |
| 65536 | create | string | 963.39 | 0.00 |
| 65536 | value.random | string | 50.63 | 0.00 |
| 65536 | values.range | string | 186.00 | 0.00 |
| 65536 | values.array | string | 252351.56 | 0.00 |
| 65536 | values.text | string | 89.68 | 0.00 |
| 65536 | sequence.array | string | 249000.00 | 0.00 |
| 65536 | sequence.text | string | 271.01 | 0.00 |
| 65536 | sequence.edited.text | string | 90487.00 | 0.00 |
| 65536 | sequence.masked.text | string | 3330.57 | 0.00 |
| 1048576 | insert | array | 3783125.00 | 0.00 |
| 1048576 | insert.append | array | 24561300.00 | 0.00 |
| 1048576 | replace | array | 3153025.00 | 0.00 |
| 1048576 | remove | array | 14732.00 | 0.00 |
| 1048576 | remove.middle | array | 2907955.56 | 0.00 |
| 1048576 | replace.middle | array | 2901881.82 | 0.00 |
| 1048576 | apply | array | 1041.92 | 0.00 |
| 1048576 | apply.array | array | 539.99 | 0.00 |
| 1048576 | concurrent.apply | array | 71338100.00 | 0.00 |
| 1048576 | merge | array | 3021277.78 | 0.00 |
| 1048576 | create | array | 2963611.11 | 0.00 |
| 1048576 | value.random | array | 43.86 | 0.00 |
| 1048576 | values.range | array | 101.57 | 0.00 |
| 1048576 | values.array | array | 2211216.67 | 0.00 |
| 1048576 | values.text | array | 13006950.00 | 0.00 |
| 1048576 | sequence.array | array | 2214200.00 | 0.00 |
| 1048576 | sequence.text | array | 57245850.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 68363400.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 60683950.00 | 0.00 |
| 1048576 | insert | string | 408.75 | 0.00 |
| 1048576 | insert.append | string | 540629.79 | 0.00 |
| 1048576 | replace | string | 1292.11 | 0.00 |
| 1048576 | remove | string | 960.95 | 0.00 |
| 1048576 | remove.middle | string | 848.62 | 0.00 |
| 1048576 | replace.middle | string | 1262.95 | 0.00 |
| 1048576 | apply | string | 1067.75 | 0.00 |
| 1048576 | apply.array | string | 3375225.00 | 0.00 |
| 1048576 | concurrent.apply | string | 1396538.89 | 0.00 |
| 1048576 | merge | string | 1193.41 | 0.00 |
| 1048576 | create | string | 909.90 | 0.00 |
| 1048576 | value.random | string | 56.40 | 0.00 |
| 1048576 | values.range | string | 139.36 | 0.00 |
| 1048576 | values.array | string | 3214462.50 | 0.00 |
| 1048576 | values.text | string | 62.23 | 0.00 |
| 1048576 | sequence.array | string | 3247787.50 | 0.00 |
| 1048576 | sequence.text | string | 167.59 | 0.00 |
| 1048576 | sequence.edited.text | string | 1489594.12 | 0.00 |
| 1048576 | sequence.masked.text | string | 3021.67 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
