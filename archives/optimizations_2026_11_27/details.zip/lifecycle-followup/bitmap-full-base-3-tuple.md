# Tuple benchmarks

2026-11-27T20:54:30.509Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 3,048,362 | 593,750 | 0.19× |
| 2 | create.sequence | 937,606 | 805,856 | 0.86× |
| 2 | replace.random | 1,243,218 | 1,611,225 | 1.30× |
| 2 | apply.replace | 732,523 | 935,854 | 1.28× |
| 2 | apply.duplicate | 1,472,037 | 1,679,623 | 1.14× |
| 2 | merge.duplicate | 1,466,278 | 1,507,014 | 1.03× |
| 2 | length | 133,498,532 | 137,336,080 | 1.03× |
| 2 | value.random | 35,315,442 | 56,741,907 | 1.61× |
| 2 | values | 13,609,787 | 13,080,803 | 0.96× |
| 2 | sequence | 3,210,748 | 2,826,097 | 0.88× |
| 4 | create.empty | 2,450,298 | 2,421,316 | 0.99× |
| 4 | create.sequence | 677,058 | 715,442 | 1.06× |
| 4 | replace.random | 1,019,329 | 1,508,866 | 1.48× |
| 4 | apply.replace | 639,059 | 914,558 | 1.43× |
| 4 | apply.duplicate | 1,754,497 | 1,500,928 | 0.86× |
| 4 | merge.duplicate | 1,242,674 | 1,226,668 | 0.99× |
| 4 | length | 37,757,750 | 38,317,677 | 1.01× |
| 4 | value.random | 22,069,213 | 54,865,781 | 2.49× |
| 4 | values | 7,002,169 | 7,279,960 | 1.04× |
| 4 | sequence | 2,441,705 | 2,325,751 | 0.95× |
| 8 | create.empty | 2,568,375 | 2,378,907 | 0.93× |
| 8 | create.sequence | 474,087 | 529,324 | 1.12× |
| 8 | replace.random | 1,070,130 | 1,635,169 | 1.53× |
| 8 | apply.replace | 632,711 | 1,063,603 | 1.68× |
| 8 | apply.duplicate | 1,673,502 | 1,717,627 | 1.03× |
| 8 | merge.duplicate | 908,437 | 873,739 | 0.96× |
| 8 | length | 36,469,092 | 37,788,738 | 1.04× |
| 8 | value.random | 18,029,480 | 54,161,557 | 3.00× |
| 8 | values | 4,625,461 | 4,967,879 | 1.07× |
| 8 | sequence | 1,790,316 | 1,960,759 | 1.10× |
| 100 | create.empty | 2,319,850 | 2,129,528 | 0.92× |
| 100 | create.sequence | 57,134 | 81,257 | 1.42× |
| 100 | replace.random | 967,711 | 1,540,520 | 1.59× |
| 100 | apply.replace | 653,801 | 1,040,724 | 1.59× |
| 100 | apply.duplicate | 1,733,770 | 1,698,102 | 0.98× |
| 100 | merge.duplicate | 106,716 | 72,381 | 0.68× |
| 100 | length | 37,656,793 | 37,991,223 | 1.01× |
| 100 | value.random | 11,358,531 | 52,294,090 | 4.60× |
| 100 | values | 528,991 | 654,414 | 1.24× |
| 100 | sequence | 178,574 | 171,123 | 0.96× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
