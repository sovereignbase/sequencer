# Words benchmarks

2026-11-27T20:55:05.919Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 33,712 | 148,751 | 119 |
| append | packed | 5.90 | 3.61 | 13.98 | 26,300 | 191,788 | 295 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,736 | 788 | 234 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 31,853 | 1,643 | 218 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 408 | 116 | 61 |
| random | packed | 49.58 | 35.38 | 23.45 | 12,792 | 468 | 116 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 528 | 237 | 100 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 17,710 | 319 | 119 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 546.06 | 0.00 |
| append | numeric | encode | 29663.23 | 0.00 |
| append | numeric | decode | 2791.97 | 0.00 |
| append | numeric | create | 1733.04 | 0.00 |
| append | numeric | load | 6722.64 | 0.00 |
| append | numeric | apply | 3585114.29 | 0.00 |
| append | numeric | receive | 8390833.33 | 0.00 |
| append | binary | sequence | 1007.43 | 0.00 |
| append | binary | encode | 38023.35 | 0.00 |
| append | binary | decode | 1850.00 | 0.00 |
| append | binary | create | 2108.62 | 0.00 |
| append | binary | load | 5214.10 | 0.00 |
| append | binary | apply | 1729726.67 | 0.00 |
| append | binary | receive | 3393400.00 | 0.00 |
| prepend | numeric | sequence | 468090.65 | 0.00 |
| prepend | numeric | encode | 575960.92 | 0.00 |
| prepend | numeric | decode | 227505.00 | 0.00 |
| prepend | numeric | create | 616007.32 | 0.00 |
| prepend | numeric | load | 1269342.50 | 0.00 |
| prepend | numeric | apply | 2292713.64 | 0.00 |
| prepend | numeric | receive | 4267475.00 | 0.00 |
| prepend | binary | sequence | 337582.55 | 0.00 |
| prepend | binary | encode | 31394.48 | 0.00 |
| prepend | binary | decode | 2186.03 | 0.00 |
| prepend | binary | create | 575849.43 | 0.00 |
| prepend | binary | load | 608484.34 | 0.00 |
| prepend | binary | apply | 2816616.67 | 0.00 |
| prepend | binary | receive | 4580590.91 | 0.00 |
| random | numeric | sequence | 1460805.71 | 0.00 |
| random | numeric | encode | 2449090.48 | 0.00 |
| random | numeric | decode | 865208.62 | 0.00 |
| random | numeric | create | 2032840.00 | 0.00 |
| random | numeric | load | 8628100.00 | 0.00 |
| random | numeric | apply | 13070100.00 | 0.00 |
| random | numeric | receive | 16502625.00 | 0.00 |
| random | binary | sequence | 1106697.83 | 0.00 |
| random | binary | encode | 78176.87 | 0.00 |
| random | binary | decode | 1794.20 | 0.00 |
| random | binary | create | 2150708.33 | 0.00 |
| random | binary | load | 2138495.83 | 0.00 |
| random | binary | apply | 7148771.43 | 0.00 |
| random | binary | receive | 8595766.67 | 0.00 |
| concurrent | numeric | sequence | 1042290.00 | 0.00 |
| concurrent | numeric | encode | 1892625.93 | 0.00 |
| concurrent | numeric | decode | 917132.73 | 0.00 |
| concurrent | numeric | create | 2547935.00 | 0.00 |
| concurrent | numeric | load | 4219625.00 | 0.00 |
| concurrent | numeric | apply | 6137366.67 | 0.00 |
| concurrent | numeric | receive | 10020600.00 | 0.00 |
| concurrent | binary | sequence | 711222.54 | 0.00 |
| concurrent | binary | encode | 56464.45 | 0.00 |
| concurrent | binary | decode | 7614.15 | 0.00 |
| concurrent | binary | create | 2908244.44 | 0.00 |
| concurrent | binary | load | 3139243.75 | 0.00 |
| concurrent | binary | apply | 5932844.44 | 0.00 |
| concurrent | binary | receive | 8401333.33 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
