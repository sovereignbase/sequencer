# Batch benchmarks

2026-11-27T20:56:55.674Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 1,619,783 | 1,077,373 | 724,227 | 76.05 | 5.99 | 0.012 |
| append | batch | 2,263,468 | 224,719,101 | 58,997,050 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,299,236 | 1,570,927 | 912,076 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 1,735,810 | 2,345,766 | 2,221,153 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 693,954 | 1,128,520 | 861,104 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 1,133,530 | 1,646,407 | 1,578,532 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 1,044,586 | 1,182,429 | 802,504 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 1,225,640 | 1,513,623 | 1,537,279 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,247,816 | 1,214,870 | 828,255 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,347,754 | 1,627,516 | 1,669,844 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,243,987 | 1,338,628 | 870,979 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,414,127 | 1,723,395 | 1,406,882 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 670,912 | 997,108 | 723,075 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 945,701 | 1,167,372 | 1,252,505 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,144,121 | 1,384,115 | 983,840 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 1,295,952 | 1,684,234 | 1,683,478 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,113,792 | 1,352,158 | 831,163 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 1,317,046 | 1,774,387 | 1,637,197 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 727,886 | 1,018,710 | 711,002 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 900,259 | 1,212,256 | 1,268,526 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 3.704 | 0.000 |
| append | individual | apply | 5.569 | 0.000 |
| append | individual | receive | 8.285 | 0.000 |
| append | individual | encode | 6.296 | 0.000 |
| append | individual | decode | 7.580 | 0.000 |
| append | batch | author | 2.651 | 0.000 |
| append | batch | apply | 0.027 | 0.000 |
| append | batch | receive | 0.102 | 0.000 |
| append | batch | encode | 0.323 | 0.000 |
| append | batch | decode | 0.095 | 0.000 |
| prepend | individual | author | 4.618 | 0.000 |
| prepend | individual | apply | 3.819 | 0.000 |
| prepend | individual | receive | 6.578 | 0.000 |
| prepend | individual | encode | 5.579 | 0.000 |
| prepend | individual | decode | 9.674 | 0.000 |
| prepend | batch | author | 3.457 | 0.000 |
| prepend | batch | apply | 2.558 | 0.000 |
| prepend | batch | receive | 2.701 | 0.000 |
| prepend | batch | encode | 0.184 | 0.000 |
| prepend | batch | decode | 0.104 | 0.000 |
| random.characters | individual | author | 8.646 | 0.000 |
| random.characters | individual | apply | 5.317 | 0.000 |
| random.characters | individual | receive | 6.968 | 0.000 |
| random.characters | individual | encode | 4.772 | 0.000 |
| random.characters | individual | decode | 7.282 | 0.000 |
| random.characters | batch | author | 5.293 | 0.000 |
| random.characters | batch | apply | 3.644 | 0.000 |
| random.characters | batch | receive | 3.801 | 0.000 |
| random.characters | batch | encode | 0.200 | 0.000 |
| random.characters | batch | decode | 0.101 | 0.000 |
| random.words | individual | author | 5.744 | 0.000 |
| random.words | individual | apply | 5.074 | 0.000 |
| random.words | individual | receive | 7.477 | 0.000 |
| random.words | individual | encode | 4.017 | 0.000 |
| random.words | individual | decode | 7.390 | 0.000 |
| random.words | batch | author | 4.895 | 0.000 |
| random.words | batch | apply | 3.964 | 0.000 |
| random.words | batch | receive | 3.903 | 0.000 |
| random.words | batch | encode | 0.396 | 0.000 |
| random.words | batch | decode | 0.099 | 0.000 |
| concurrent.characters | individual | author | 9.617 | 0.000 |
| concurrent.characters | individual | apply | 9.878 | 0.000 |
| concurrent.characters | individual | receive | 14.488 | 0.000 |
| concurrent.characters | individual | encode | 7.952 | 0.000 |
| concurrent.characters | individual | decode | 11.392 | 0.000 |
| concurrent.characters | batch | author | 8.904 | 0.000 |
| concurrent.characters | batch | apply | 7.373 | 0.000 |
| concurrent.characters | batch | receive | 7.186 | 0.000 |
| concurrent.characters | batch | encode | 0.279 | 0.000 |
| concurrent.characters | batch | decode | 0.134 | 0.000 |
| concurrent.words | individual | author | 9.646 | 0.000 |
| concurrent.words | individual | apply | 8.964 | 0.000 |
| concurrent.words | individual | receive | 13.778 | 0.000 |
| concurrent.words | individual | encode | 7.719 | 0.000 |
| concurrent.words | individual | decode | 10.992 | 0.000 |
| concurrent.words | batch | author | 8.486 | 0.000 |
| concurrent.words | batch | apply | 6.963 | 0.000 |
| concurrent.words | batch | receive | 8.529 | 0.000 |
| concurrent.words | batch | encode | 0.754 | 0.000 |
| concurrent.words | batch | decode | 0.121 | 0.000 |
| concurrent.mixed | individual | author | 17.886 | 0.000 |
| concurrent.mixed | individual | apply | 12.035 | 0.000 |
| concurrent.mixed | individual | receive | 16.596 | 0.000 |
| concurrent.mixed | individual | encode | 8.177 | 0.000 |
| concurrent.mixed | individual | decode | 10.113 | 0.000 |
| concurrent.mixed | batch | author | 12.689 | 0.000 |
| concurrent.mixed | batch | apply | 10.280 | 0.000 |
| concurrent.mixed | batch | receive | 9.581 | 0.000 |
| concurrent.mixed | batch | encode | 0.599 | 0.000 |
| concurrent.mixed | batch | decode | 0.129 | 0.000 |
| causal.characters | individual | author | 10.488 | 0.000 |
| causal.characters | individual | apply | 8.670 | 0.000 |
| causal.characters | individual | receive | 12.197 | 0.000 |
| causal.characters | individual | encode | 8.271 | 0.000 |
| causal.characters | individual | decode | 10.836 | 0.000 |
| causal.characters | batch | author | 9.260 | 0.000 |
| causal.characters | batch | apply | 7.125 | 0.000 |
| causal.characters | batch | receive | 7.128 | 0.000 |
| causal.characters | batch | encode | 0.233 | 0.000 |
| causal.characters | batch | decode | 0.113 | 0.000 |
| causal.words | individual | author | 10.774 | 0.000 |
| causal.words | individual | apply | 8.875 | 0.000 |
| causal.words | individual | receive | 14.438 | 0.000 |
| causal.words | individual | encode | 8.757 | 0.000 |
| causal.words | individual | decode | 9.456 | 0.000 |
| causal.words | batch | author | 9.111 | 0.000 |
| causal.words | batch | apply | 6.763 | 0.000 |
| causal.words | batch | receive | 7.330 | 0.000 |
| causal.words | batch | encode | 0.622 | 0.000 |
| causal.words | batch | decode | 0.121 | 0.000 |
| causal.mixed | individual | author | 16.486 | 0.000 |
| causal.mixed | individual | apply | 11.780 | 0.000 |
| causal.mixed | individual | receive | 16.878 | 0.000 |
| causal.mixed | individual | encode | 8.718 | 0.000 |
| causal.mixed | individual | decode | 9.559 | 0.000 |
| causal.mixed | batch | author | 13.330 | 0.000 |
| causal.mixed | batch | apply | 9.899 | 0.000 |
| causal.mixed | batch | receive | 9.460 | 0.000 |
| causal.mixed | batch | encode | 0.483 | 0.000 |
| causal.mixed | batch | decode | 0.113 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
