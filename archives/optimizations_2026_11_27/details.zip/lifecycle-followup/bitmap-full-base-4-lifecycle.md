# Sequencer dynamic lifecycle benchmark

2026-11-27T20:55:24.305Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.23 | 162.89 | 56.49 |
| CommonJS | 199.41 | 164.51 | 56.69 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 322,964 | 3.096 | 3.096 | 3.096 | 0.000 | 0: 3.096 | 0: 3.096 |
| apply | random | A | scaleDown | 24,999 | 353,817 | 2.826 | 2.826 | 2.826 | 0.000 | 0: 2.826 | 0: 2.826 |
| apply | random | A | fullLifecycle | 49,999 | 337,687 | 2.961 | 2.961 | 2.961 | 0.000 | 0: 2.961 | 0: 2.961 |
| create | — | A | scaleUp | 7 | 547 | 1828.914 | 1828.914 | 1828.914 | 0.000 | 0: 1828.914 | 0: 1828.914 |
| create | — | A | scaleDown | 6 | 675 | 1481.583 | 1481.583 | 1481.583 | 0.000 | 0: 1481.583 | 0: 1481.583 |
| create | — | A | fullLifecycle | 13 | 599 | 1668.608 | 1668.608 | 1668.608 | 0.000 | 0: 1668.608 | 0: 1668.608 |
| insert | head | A | scaleUp | 12,500 | 1,260,081 | 0.794 | 0.794 | 0.794 | 0.000 | 0: 0.794 | 0: 0.794 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,260,081 | 0.794 | 0.794 | 0.794 | 0.000 | 0: 0.794 | 0: 0.794 |
| insert | random | A | scaleUp | 25,000 | 567,801 | 1.761 | 1.761 | 1.761 | 0.000 | 0: 1.761 | 0: 1.761 |
| insert | random | A | scaleDown | 25,000 | 619,539 | 1.614 | 1.614 | 1.614 | 0.000 | 0: 1.614 | 0: 1.614 |
| insert | random | A | fullLifecycle | 50,000 | 592,543 | 1.688 | 1.688 | 1.688 | 0.000 | 0: 1.688 | 0: 1.688 |
| insert | tail | A | scaleUp | 12,500 | 1,363,379 | 0.733 | 0.733 | 0.733 | 0.000 | 0: 0.733 | 0: 0.733 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,363,379 | 0.733 | 0.733 | 0.733 | 0.000 | 0: 0.733 | 0: 0.733 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 737,707 | 1.356 | 1.356 | 1.356 | 0.000 | 0: 1.356 | 0: 1.356 |
| remove | head | A | fullLifecycle | 12,500 | 737,707 | 1.356 | 1.356 | 1.356 | 0.000 | 0: 1.356 | 0: 1.356 |
| remove | random | A | scaleUp | 25,000 | 493,029 | 2.028 | 2.028 | 2.028 | 0.000 | 0: 2.028 | 0: 2.028 |
| remove | random | A | scaleDown | 25,000 | 532,557 | 1.878 | 1.878 | 1.878 | 0.000 | 0: 1.878 | 0: 1.878 |
| remove | random | A | fullLifecycle | 50,000 | 512,031 | 1.953 | 1.953 | 1.953 | 0.000 | 0: 1.953 | 0: 1.953 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 811,609 | 1.232 | 1.232 | 1.232 | 0.000 | 0: 1.232 | 0: 1.232 |
| remove | tail | A | fullLifecycle | 12,500 | 811,609 | 1.232 | 1.232 | 1.232 | 0.000 | 0: 1.232 | 0: 1.232 |
| replace | head | A | scaleUp | 25,000 | 550,065 | 1.818 | 1.818 | 1.818 | 0.000 | 0: 1.818 | 0: 1.818 |
| replace | head | A | scaleDown | 25,000 | 516,534 | 1.936 | 1.936 | 1.936 | 0.000 | 0: 1.936 | 0: 1.936 |
| replace | head | A | fullLifecycle | 50,000 | 532,772 | 1.877 | 1.877 | 1.877 | 0.000 | 0: 1.877 | 0: 1.877 |
| replace | random | A | scaleUp | 25,000 | 355,609 | 2.812 | 2.812 | 2.812 | 0.000 | 0: 2.812 | 0: 2.812 |
| replace | random | A | scaleDown | 25,000 | 393,807 | 2.539 | 2.539 | 2.539 | 0.000 | 0: 2.539 | 0: 2.539 |
| replace | random | A | fullLifecycle | 50,000 | 373,735 | 2.676 | 2.676 | 2.676 | 0.000 | 0: 2.676 | 0: 2.676 |
| replace | tail | A | scaleUp | 25,000 | 529,328 | 1.889 | 1.889 | 1.889 | 0.000 | 0: 1.889 | 0: 1.889 |
| replace | tail | A | scaleDown | 25,000 | 54,374 | 18.391 | 18.391 | 18.391 | 0.000 | 0: 18.391 | 0: 18.391 |
| replace | tail | A | fullLifecycle | 50,000 | 98,618 | 10.140 | 10.140 | 10.140 | 0.000 | 0: 10.140 | 0: 10.140 |
| sequence | — | A | scaleUp | 6 | 76 | 13155.983 | 13155.983 | 13155.983 | 0.000 | 0: 13155.983 | 0: 13155.983 |
| sequence | — | A | scaleDown | 6 | 95 | 10555.417 | 10555.417 | 10555.417 | 0.000 | 0: 10555.417 | 0: 10555.417 |
| sequence | — | A | fullLifecycle | 12 | 84 | 11855.700 | 11855.700 | 11855.700 | 0.000 | 0: 11855.700 | 0: 11855.700 |
| value | head | A | scaleUp | 25,000 | 3,558,820 | 0.281 | 0.281 | 0.281 | 0.000 | 0: 0.281 | 0: 0.281 |
| value | head | A | scaleDown | 25,000 | 2,544,607 | 0.393 | 0.393 | 0.393 | 0.000 | 0: 0.393 | 0: 0.393 |
| value | head | A | fullLifecycle | 50,000 | 2,967,447 | 0.337 | 0.337 | 0.337 | 0.000 | 0: 0.337 | 0: 0.337 |
| value | random | A | scaleUp | 25,000 | 938,097 | 1.066 | 1.066 | 1.066 | 0.000 | 0: 1.066 | 0: 1.066 |
| value | random | A | scaleDown | 25,000 | 985,462 | 1.015 | 1.015 | 1.015 | 0.000 | 0: 1.015 | 0: 1.015 |
| value | random | A | fullLifecycle | 50,000 | 961,196 | 1.040 | 1.040 | 1.040 | 0.000 | 0: 1.040 | 0: 1.040 |
| value | tail | A | scaleUp | 25,000 | 6,890,089 | 0.145 | 0.145 | 0.145 | 0.000 | 0: 0.145 | 0: 0.145 |
| value | tail | A | scaleDown | 25,000 | 4,416,727 | 0.226 | 0.226 | 0.226 | 0.000 | 0: 0.226 | 0: 0.226 |
| value | tail | A | fullLifecycle | 50,000 | 5,382,885 | 0.186 | 0.186 | 0.186 | 0.000 | 0: 0.186 | 0: 0.186 |
| values | — | A | scaleUp | 6 | 152 | 6579.150 | 6579.150 | 6579.150 | 0.000 | 0: 6579.150 | 0: 6579.150 |
| values | — | A | scaleDown | 6 | 241 | 4143.683 | 4143.683 | 4143.683 | 0.000 | 0: 4143.683 | 0: 4143.683 |
| values | — | A | fullLifecycle | 12 | 187 | 5361.417 | 5361.417 | 5361.417 | 0.000 | 0: 5361.417 | 0: 5361.417 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5400606.000 | 426.364 | 8.479 |
| A | scaleDown | 5 | 4392724.800 | 430.659 | 8.550 |
| A | fullLifecycle | 11 | 4942478.182 | 428.089 | 8.507 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3111164.000 | 245.618 | 4.885 |
| A | scaleDown | 5 | 2587628.000 | 253.689 | 5.036 |
| A | fullLifecycle | 11 | 2873193.091 | 248.859 | 4.946 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 50,671 | A | 1,000 | 282,654 | 3.538 | 1.600 | 88.300 |
| apply | random | 0 | up | 5,000 | 252,715 | A | 5,000 | 306,414 | 3.264 | 1.600 | 525.100 |
| apply | random | 0 | up | 10,000 | 501,654 | A | 10,000 | 315,367 | 3.171 | 1.500 | 753.200 |
| apply | random | 0 | up | 15,000 | 750,657 | A | 15,000 | 323,868 | 3.088 | 1.500 | 753.200 |
| apply | random | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 324,078 | 3.086 | 1.500 | 753.200 |
| apply | random | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 322,964 | 3.096 | 1.500 | 876.800 |
| apply | random | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 324,710 | 3.080 | 1.500 | 876.800 |
| apply | random | 0 | down | 15,000 | 756,010 | A | 35,000 | 327,356 | 3.055 | 1.500 | 876.800 |
| apply | random | 0 | down | 10,000 | 503,964 | A | 40,000 | 327,439 | 3.054 | 1.500 | 876.800 |
| apply | random | 0 | down | 5,000 | 252,028 | A | 45,000 | 331,813 | 3.014 | 1.500 | 876.800 |
| apply | random | 0 | down | 1,000 | 49,568 | A | 49,000 | 335,776 | 2.978 | 1.400 | 876.800 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 337,687 | 2.961 | 1.200 | 876.800 |
| insert | head | 0 | up | 1,000 | 50,671 | A | 500 | 962,279 | 1.039 | 0.300 | 57.900 |
| insert | head | 0 | up | 5,000 | 252,715 | A | 2,500 | 874,891 | 1.143 | 0.300 | 761.000 |
| insert | head | 0 | up | 10,000 | 501,654 | A | 5,000 | 1,086,248 | 0.921 | 0.300 | 761.000 |
| insert | head | 0 | up | 15,000 | 750,657 | A | 7,500 | 1,186,878 | 0.843 | 0.300 | 761.000 |
| insert | head | 0 | up | 20,000 | 1,008,112 | A | 10,000 | 1,224,035 | 0.817 | 0.300 | 761.000 |
| insert | head | 0 | up | 25,000 | 1,257,856 | A | 12,500 | 1,260,081 | 0.794 | 0.300 | 761.000 |
| insert | head | 0 | down | 20,000 | 1,007,326 | A | 12,500 | 1,260,081 | 0.794 | 0.300 | 761.000 |
| insert | head | 0 | down | 15,000 | 756,010 | A | 12,500 | 1,260,081 | 0.794 | 0.300 | 761.000 |
| insert | head | 0 | down | 10,000 | 503,964 | A | 12,500 | 1,260,081 | 0.794 | 0.300 | 761.000 |
| insert | head | 0 | down | 5,000 | 252,028 | A | 12,500 | 1,260,081 | 0.794 | 0.300 | 761.000 |
| insert | head | 0 | down | 1,000 | 49,568 | A | 12,500 | 1,260,081 | 0.794 | 0.300 | 761.000 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,260,081 | 0.794 | 0.300 | 761.000 |
| insert | random | 0 | up | 1,000 | 50,671 | A | 1,000 | 588,339 | 1.700 | 0.400 | 378.200 |
| insert | random | 0 | up | 5,000 | 252,715 | A | 5,000 | 638,790 | 1.565 | 0.400 | 378.200 |
| insert | random | 0 | up | 10,000 | 501,654 | A | 10,000 | 566,778 | 1.764 | 0.400 | 1749.500 |
| insert | random | 0 | up | 15,000 | 750,657 | A | 15,000 | 585,917 | 1.707 | 0.400 | 1749.500 |
| insert | random | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 585,835 | 1.707 | 0.400 | 1749.500 |
| insert | random | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 567,801 | 1.761 | 0.400 | 1749.500 |
| insert | random | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 566,381 | 1.766 | 0.400 | 1749.500 |
| insert | random | 0 | down | 15,000 | 756,010 | A | 35,000 | 558,946 | 1.789 | 0.400 | 1749.500 |
| insert | random | 0 | down | 10,000 | 503,964 | A | 40,000 | 567,228 | 1.763 | 0.400 | 1749.500 |
| insert | random | 0 | down | 5,000 | 252,028 | A | 45,000 | 577,398 | 1.732 | 0.400 | 1749.500 |
| insert | random | 0 | down | 1,000 | 49,568 | A | 49,000 | 587,231 | 1.703 | 0.400 | 1749.500 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 592,543 | 1.688 | 0.400 | 1749.500 |
| insert | tail | 0 | up | 1,000 | 50,671 | A | 500 | 584,249 | 1.712 | 0.300 | 462.400 |
| insert | tail | 0 | up | 5,000 | 252,715 | A | 2,500 | 1,062,157 | 0.941 | 0.300 | 462.400 |
| insert | tail | 0 | up | 10,000 | 501,654 | A | 5,000 | 1,246,603 | 0.802 | 0.300 | 462.400 |
| insert | tail | 0 | up | 15,000 | 750,657 | A | 7,500 | 1,327,105 | 0.754 | 0.300 | 462.400 |
| insert | tail | 0 | up | 20,000 | 1,008,112 | A | 10,000 | 1,374,060 | 0.728 | 0.300 | 462.400 |
| insert | tail | 0 | up | 25,000 | 1,257,856 | A | 12,500 | 1,363,379 | 0.733 | 0.300 | 462.400 |
| insert | tail | 0 | down | 20,000 | 1,007,326 | A | 12,500 | 1,363,379 | 0.733 | 0.300 | 462.400 |
| insert | tail | 0 | down | 15,000 | 756,010 | A | 12,500 | 1,363,379 | 0.733 | 0.300 | 462.400 |
| insert | tail | 0 | down | 10,000 | 503,964 | A | 12,500 | 1,363,379 | 0.733 | 0.300 | 462.400 |
| insert | tail | 0 | down | 5,000 | 252,028 | A | 12,500 | 1,363,379 | 0.733 | 0.300 | 462.400 |
| insert | tail | 0 | down | 1,000 | 49,568 | A | 12,500 | 1,363,379 | 0.733 | 0.300 | 462.400 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,363,379 | 0.733 | 0.300 | 462.400 |
| remove | head | 0 | up | 1,000 | 50,671 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 252,715 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 501,654 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 750,657 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,008,112 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,257,856 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,007,326 | A | 2,500 | 692,406 | 1.444 | 0.900 | 48.400 |
| remove | head | 0 | down | 15,000 | 756,010 | A | 5,000 | 710,167 | 1.408 | 0.800 | 48.400 |
| remove | head | 0 | down | 10,000 | 503,964 | A | 7,500 | 683,677 | 1.463 | 0.800 | 617.400 |
| remove | head | 0 | down | 5,000 | 252,028 | A | 10,000 | 712,616 | 1.403 | 0.800 | 617.400 |
| remove | head | 0 | down | 1,000 | 49,568 | A | 12,000 | 731,556 | 1.367 | 0.700 | 617.400 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 737,707 | 1.356 | 0.700 | 617.400 |
| remove | random | 0 | up | 1,000 | 50,671 | A | 1,000 | 482,602 | 2.072 | 0.800 | 252.500 |
| remove | random | 0 | up | 5,000 | 252,715 | A | 5,000 | 531,898 | 1.880 | 0.800 | 252.500 |
| remove | random | 0 | up | 10,000 | 501,654 | A | 10,000 | 454,232 | 2.202 | 0.800 | 2195.200 |
| remove | random | 0 | up | 15,000 | 750,657 | A | 15,000 | 476,192 | 2.100 | 0.800 | 2195.200 |
| remove | random | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 486,150 | 2.057 | 0.800 | 2195.200 |
| remove | random | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 493,029 | 2.028 | 0.800 | 2195.200 |
| remove | random | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 492,758 | 2.029 | 0.800 | 2195.200 |
| remove | random | 0 | down | 15,000 | 756,010 | A | 35,000 | 492,759 | 2.029 | 0.800 | 2195.200 |
| remove | random | 0 | down | 10,000 | 503,964 | A | 40,000 | 490,707 | 2.038 | 0.800 | 2195.200 |
| remove | random | 0 | down | 5,000 | 252,028 | A | 45,000 | 500,232 | 1.999 | 0.800 | 2195.200 |
| remove | random | 0 | down | 1,000 | 49,568 | A | 49,000 | 507,643 | 1.970 | 0.700 | 2195.200 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 512,031 | 1.953 | 0.700 | 2195.200 |
| remove | tail | 0 | up | 1,000 | 50,671 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 252,715 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 501,654 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 750,657 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,008,112 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,257,856 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,007,326 | A | 2,500 | 705,537 | 1.417 | 0.800 | 43.700 |
| remove | tail | 0 | down | 15,000 | 756,010 | A | 5,000 | 745,612 | 1.341 | 0.800 | 47.300 |
| remove | tail | 0 | down | 10,000 | 503,964 | A | 7,500 | 769,641 | 1.299 | 0.800 | 47.300 |
| remove | tail | 0 | down | 5,000 | 252,028 | A | 10,000 | 785,386 | 1.273 | 0.700 | 165.300 |
| remove | tail | 0 | down | 1,000 | 49,568 | A | 12,000 | 804,521 | 1.243 | 0.700 | 165.300 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 811,609 | 1.232 | 0.700 | 165.300 |
| replace | head | 0 | up | 1,000 | 50,671 | A | 1,000 | 439,387 | 2.276 | 1.100 | 97.400 |
| replace | head | 0 | up | 5,000 | 252,715 | A | 5,000 | 503,459 | 1.986 | 1.100 | 210.500 |
| replace | head | 0 | up | 10,000 | 501,654 | A | 10,000 | 541,867 | 1.845 | 1.100 | 210.500 |
| replace | head | 0 | up | 15,000 | 750,657 | A | 15,000 | 540,005 | 1.852 | 1.000 | 613.700 |
| replace | head | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 551,390 | 1.814 | 1.000 | 613.700 |
| replace | head | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 550,065 | 1.818 | 1.000 | 620.800 |
| replace | head | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 542,171 | 1.844 | 1.000 | 620.800 |
| replace | head | 0 | down | 15,000 | 756,010 | A | 35,000 | 536,237 | 1.865 | 1.000 | 620.800 |
| replace | head | 0 | down | 10,000 | 503,964 | A | 40,000 | 535,149 | 1.869 | 1.000 | 620.800 |
| replace | head | 0 | down | 5,000 | 252,028 | A | 45,000 | 530,480 | 1.885 | 1.000 | 620.800 |
| replace | head | 0 | down | 1,000 | 49,568 | A | 49,000 | 530,542 | 1.885 | 1.000 | 620.800 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 532,772 | 1.877 | 1.000 | 620.800 |
| replace | random | 0 | up | 1,000 | 50,671 | A | 1,000 | 284,260 | 3.518 | 1.100 | 773.000 |
| replace | random | 0 | up | 5,000 | 252,715 | A | 5,000 | 353,549 | 2.828 | 1.100 | 773.000 |
| replace | random | 0 | up | 10,000 | 501,654 | A | 10,000 | 333,769 | 2.996 | 1.100 | 2349.700 |
| replace | random | 0 | up | 15,000 | 750,657 | A | 15,000 | 340,293 | 2.939 | 1.100 | 2349.700 |
| replace | random | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 350,867 | 2.850 | 1.100 | 2349.700 |
| replace | random | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 355,609 | 2.812 | 1.100 | 2349.700 |
| replace | random | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 357,106 | 2.800 | 1.100 | 2349.700 |
| replace | random | 0 | down | 15,000 | 756,010 | A | 35,000 | 355,590 | 2.812 | 1.100 | 2349.700 |
| replace | random | 0 | down | 10,000 | 503,964 | A | 40,000 | 359,486 | 2.782 | 1.100 | 2349.700 |
| replace | random | 0 | down | 5,000 | 252,028 | A | 45,000 | 363,914 | 2.748 | 1.100 | 2349.700 |
| replace | random | 0 | down | 1,000 | 49,568 | A | 49,000 | 370,484 | 2.699 | 1.000 | 2349.700 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 373,735 | 2.676 | 0.900 | 2349.700 |
| replace | tail | 0 | up | 1,000 | 50,671 | A | 1,000 | 449,135 | 2.227 | 1.000 | 201.900 |
| replace | tail | 0 | up | 5,000 | 252,715 | A | 5,000 | 480,621 | 2.081 | 1.000 | 806.100 |
| replace | tail | 0 | up | 10,000 | 501,654 | A | 10,000 | 517,365 | 1.933 | 1.000 | 806.100 |
| replace | tail | 0 | up | 15,000 | 750,657 | A | 15,000 | 533,973 | 1.873 | 1.000 | 806.100 |
| replace | tail | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 516,690 | 1.935 | 1.000 | 1683.600 |
| replace | tail | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 529,328 | 1.889 | 1.000 | 1683.600 |
| replace | tail | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 131,406 | 7.610 | 1.000 | 1683.600 |
| replace | tail | 0 | down | 15,000 | 756,010 | A | 35,000 | 96,655 | 10.346 | 1.000 | 1683.600 |
| replace | tail | 0 | down | 10,000 | 503,964 | A | 40,000 | 96,367 | 10.377 | 1.000 | 1683.600 |
| replace | tail | 0 | down | 5,000 | 252,028 | A | 45,000 | 94,784 | 10.550 | 1.000 | 2660.400 |
| replace | tail | 0 | down | 1,000 | 49,568 | A | 49,000 | 97,165 | 10.292 | 0.900 | 2660.400 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 98,618 | 10.140 | 0.800 | 2660.400 |
| value | head | 0 | up | 1,000 | 50,671 | A | 1,000 | 1,536,807 | 0.651 | 0.100 | 275.400 |
| value | head | 0 | up | 5,000 | 252,715 | A | 5,000 | 2,723,312 | 0.367 | 0.100 | 275.400 |
| value | head | 0 | up | 10,000 | 501,654 | A | 10,000 | 3,150,102 | 0.317 | 0.100 | 275.400 |
| value | head | 0 | up | 15,000 | 750,657 | A | 15,000 | 3,354,729 | 0.298 | 0.100 | 275.400 |
| value | head | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 3,485,171 | 0.287 | 0.100 | 275.400 |
| value | head | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 3,558,820 | 0.281 | 0.100 | 275.400 |
| value | head | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 3,296,486 | 0.303 | 0.100 | 275.400 |
| value | head | 0 | down | 15,000 | 756,010 | A | 35,000 | 3,161,013 | 0.316 | 0.100 | 275.400 |
| value | head | 0 | down | 10,000 | 503,964 | A | 40,000 | 3,069,109 | 0.326 | 0.100 | 275.400 |
| value | head | 0 | down | 5,000 | 252,028 | A | 45,000 | 3,003,825 | 0.333 | 0.100 | 275.400 |
| value | head | 0 | down | 1,000 | 49,568 | A | 49,000 | 2,963,805 | 0.337 | 0.100 | 275.400 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,967,447 | 0.337 | 0.100 | 275.400 |
| value | random | 0 | up | 1,000 | 50,671 | A | 1,000 | 1,349,892 | 0.741 | 0.100 | 27.100 |
| value | random | 0 | up | 5,000 | 252,715 | A | 5,000 | 1,057,127 | 0.946 | 0.100 | 71.300 |
| value | random | 0 | up | 10,000 | 501,654 | A | 10,000 | 959,767 | 1.042 | 0.100 | 71.300 |
| value | random | 0 | up | 15,000 | 750,657 | A | 15,000 | 938,515 | 1.066 | 0.100 | 71.300 |
| value | random | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 945,832 | 1.057 | 0.100 | 71.300 |
| value | random | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 938,097 | 1.066 | 0.100 | 83.500 |
| value | random | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 936,531 | 1.068 | 0.100 | 83.500 |
| value | random | 0 | down | 15,000 | 756,010 | A | 35,000 | 929,454 | 1.076 | 0.100 | 83.500 |
| value | random | 0 | down | 10,000 | 503,964 | A | 40,000 | 930,932 | 1.074 | 0.100 | 94.300 |
| value | random | 0 | down | 5,000 | 252,028 | A | 45,000 | 938,951 | 1.065 | 0.100 | 221.500 |
| value | random | 0 | down | 1,000 | 49,568 | A | 49,000 | 952,316 | 1.050 | 0.100 | 221.500 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 961,196 | 1.040 | 0.100 | 221.500 |
| value | tail | 0 | up | 1,000 | 50,671 | A | 1,000 | 5,980,861 | 0.167 | 0.100 | 2.500 |
| value | tail | 0 | up | 5,000 | 252,715 | A | 5,000 | 6,055,468 | 0.165 | 0.000 | 6.000 |
| value | tail | 0 | up | 10,000 | 501,654 | A | 10,000 | 6,146,281 | 0.163 | 0.000 | 38.900 |
| value | tail | 0 | up | 15,000 | 750,657 | A | 15,000 | 6,456,890 | 0.155 | 0.000 | 48.500 |
| value | tail | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 6,759,726 | 0.148 | 0.000 | 48.500 |
| value | tail | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 6,890,089 | 0.145 | 0.000 | 48.500 |
| value | tail | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 6,251,172 | 0.160 | 0.000 | 48.500 |
| value | tail | 0 | down | 15,000 | 756,010 | A | 35,000 | 5,831,195 | 0.171 | 0.000 | 54.600 |
| value | tail | 0 | down | 10,000 | 503,964 | A | 40,000 | 5,630,314 | 0.178 | 0.000 | 54.600 |
| value | tail | 0 | down | 5,000 | 252,028 | A | 45,000 | 5,477,851 | 0.183 | 0.000 | 54.600 |
| value | tail | 0 | down | 1,000 | 49,568 | A | 49,000 | 5,378,055 | 0.186 | 0.000 | 54.600 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,382,885 | 0.186 | 0.000 | 54.600 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,865 | 349.100 |
| create | — | 0 | up | 5,000 | A | 1 | 993 | 1006.900 |
| create | — | 0 | up | 10,000 | A | 1 | 633 | 1579.600 |
| create | — | 0 | up | 15,000 | A | 1 | 405 | 2471.600 |
| create | — | 0 | up | 20,000 | A | 1 | 288 | 3468.600 |
| create | — | 0 | up | 25,000 | A | 1 | 261 | 3828.500 |
| create | — | 0 | down | 20,000 | A | 1 | 292 | 3426.100 |
| create | — | 0 | down | 15,000 | A | 1 | 381 | 2625.400 |
| create | — | 0 | down | 10,000 | A | 1 | 550 | 1817.200 |
| create | — | 0 | down | 5,000 | A | 1 | 1,182 | 846.100 |
| create | — | 0 | down | 1,000 | A | 1 | 6,200 | 161.300 |
| create | — | 0 | down | 0 | A | 1 | 74,627 | 13.400 |
| sequence | — | 0 | up | 1,000 | A | 1 | 413 | 2420.900 |
| sequence | — | 0 | up | 5,000 | A | 1 | 134 | 7486.000 |
| sequence | — | 0 | up | 10,000 | A | 1 | 85 | 11783.900 |
| sequence | — | 0 | up | 15,000 | A | 1 | 66 | 15253.300 |
| sequence | — | 0 | up | 20,000 | A | 1 | 51 | 19617.600 |
| sequence | — | 0 | up | 25,000 | A | 1 | 45 | 22374.200 |
| sequence | — | 0 | down | 20,000 | A | 1 | 55 | 18024.200 |
| sequence | — | 0 | down | 15,000 | A | 1 | 63 | 15974.100 |
| sequence | — | 0 | down | 10,000 | A | 1 | 82 | 12247.900 |
| sequence | — | 0 | down | 5,000 | A | 1 | 114 | 8810.300 |
| sequence | — | 0 | down | 1,000 | A | 1 | 143 | 7007.400 |
| sequence | — | 0 | down | 0 | A | 1 | 788 | 1268.600 |
| values | — | 0 | up | 1,000 | A | 1 | 518 | 1931.900 |
| values | — | 0 | up | 5,000 | A | 1 | 227 | 4410.200 |
| values | — | 0 | up | 10,000 | A | 1 | 187 | 5349.200 |
| values | — | 0 | up | 15,000 | A | 1 | 152 | 6591.400 |
| values | — | 0 | up | 20,000 | A | 1 | 99 | 10084.600 |
| values | — | 0 | up | 25,000 | A | 1 | 90 | 11107.600 |
| values | — | 0 | down | 20,000 | A | 1 | 116 | 8625.600 |
| values | — | 0 | down | 15,000 | A | 1 | 115 | 8691.700 |
| values | — | 0 | down | 10,000 | A | 1 | 199 | 5033.800 |
| values | — | 0 | down | 5,000 | A | 1 | 503 | 1988.300 |
| values | — | 0 | down | 1,000 | A | 1 | 1,946 | 513.900 |
| values | — | 0 | down | 0 | A | 1 | 113,636 | 8.800 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.619 | 0.232 | 0.387 |
| 0 | up | 5000 | 3.095 | 1.167 | 1.928 |
| 0 | up | 10000 | 6.171 | 2.343 | 3.827 |
| 0 | up | 15000 | 9.370 | 3.643 | 5.727 |
| 0 | up | 20000 | 12.804 | 5.113 | 7.691 |
| 0 | up | 25000 | 16.234 | 6.637 | 9.597 |
| 0 | down | 20000 | 13.299 | 5.613 | 7.685 |
| 0 | down | 15000 | 9.899 | 4.131 | 5.768 |
| 0 | down | 10000 | 7.140 | 3.295 | 3.845 |
| 0 | down | 5000 | 4.084 | 2.162 | 1.923 |
| 0 | down | 1000 | 1.799 | 1.420 | 0.378 |
| 0 | down | 0 | 1.231 | 1.231 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 50,671 | 0.407 | 426.984 | 8.427 | 120.824 | 15.536 |
| 0 | up | A | 5,000 | 5,000 | 252,715 | 2.030 | 425.641 | 8.421 | 154.207 | 19.613 |
| 0 | up | A | 10,000 | 10,000 | 501,654 | 4.041 | 423.725 | 8.447 | 195.344 | 24.419 |
| 0 | up | A | 15,000 | 15,000 | 750,657 | 6.065 | 423.942 | 8.471 | 208.199 | 29.211 |
| 0 | up | A | 20,000 | 20,000 | 1,008,112 | 8.161 | 427.874 | 8.489 | 281.152 | 34.138 |
| 0 | up | A | 25,000 | 25,000 | 1,257,856 | 10.199 | 427.784 | 8.502 | 295.906 | 38.913 |
| 0 | down | A | 20,000 | 20,000 | 1,007,326 | 8.225 | 431.205 | 8.561 | 294.988 | 34.153 |
| 0 | down | A | 15,000 | 15,000 | 756,010 | 6.173 | 431.547 | 8.562 | 296.871 | 29.368 |
| 0 | down | A | 10,000 | 10,000 | 503,964 | 4.105 | 430.448 | 8.541 | 295.809 | 24.591 |
| 0 | down | A | 5,000 | 5,000 | 252,028 | 2.043 | 428.418 | 8.499 | 293.883 | 19.814 |
| 0 | down | A | 1,000 | 1,000 | 49,568 | 0.400 | 419.744 | 8.468 | 292.145 | 15.968 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 293.449 | 14.906 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 50671 | 186687 | 186.687 | 3.684 | 275.58 | 14.63 | 164.19 | 12.39 |
| 0 | up | A | 5000 | 252715 | 1203749 | 240.750 | 4.763 | 1623.80 | 73.27 | 820.20 | 61.64 |
| 0 | up | A | 10000 | 501654 | 2417805 | 241.780 | 4.820 | 3239.34 | 148.63 | 1636.95 | 124.60 |
| 0 | up | A | 15000 | 750657 | 3667145 | 244.476 | 4.885 | 4881.17 | 225.50 | 3511.78 | 199.90 |
| 0 | up | A | 20000 | 1008112 | 4962378 | 248.119 | 4.922 | 7089.99 | 311.06 | 5113.11 | 263.47 |
| 0 | up | A | 25000 | 1257856 | 6229220 | 249.169 | 4.952 | 9217.18 | 392.27 | 6522.62 | 334.88 |
| 0 | down | A | 20000 | 1007326 | 5105481 | 255.274 | 5.068 | 7537.44 | 326.42 | 5290.22 | 278.28 |
| 0 | down | A | 15000 | 756010 | 3828153 | 255.210 | 5.064 | 5701.64 | 247.04 | 3986.59 | 209.82 |
| 0 | down | A | 10000 | 503964 | 2529609 | 252.961 | 5.019 | 3809.23 | 164.74 | 2657.43 | 139.77 |
| 0 | down | A | 5000 | 252028 | 1239034 | 247.807 | 4.916 | 1894.53 | 79.81 | 1324.48 | 67.85 |
| 0 | down | A | 1000 | 49568 | 235863 | 235.863 | 4.758 | 370.09 | 15.92 | 259.39 | 13.57 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 426.364 | 8.479 | 245.618 | 4.885 |
| 0 | A | scaleDown | 430.659 | 8.550 | 253.689 | 5.036 |
| 0 | A | fullLifecycle | 428.089 | 8.507 | 248.859 | 4.946 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
