# Large string benchmarks

2026-11-27T20:56:26.332Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2399.94 | 0.00 |
| 1024 | insert.append | array | 12776.09 | 0.00 |
| 1024 | replace | array | 3203.14 | 0.00 |
| 1024 | remove | array | 1065.98 | 0.00 |
| 1024 | remove.middle | array | 2045.04 | 0.00 |
| 1024 | replace.middle | array | 3032.95 | 0.00 |
| 1024 | apply | array | 1246.89 | 0.00 |
| 1024 | apply.array | array | 994.76 | 0.00 |
| 1024 | concurrent.apply | array | 76952.92 | 0.00 |
| 1024 | merge | array | 3961.50 | 0.00 |
| 1024 | create | array | 3388.05 | 0.00 |
| 1024 | value.random | array | 49.07 | 0.00 |
| 1024 | values.range | array | 119.89 | 0.00 |
| 1024 | values.array | array | 1522.48 | 0.00 |
| 1024 | values.text | array | 14646.87 | 0.00 |
| 1024 | sequence.array | array | 1594.20 | 0.00 |
| 1024 | sequence.text | array | 10427.61 | 0.00 |
| 1024 | sequence.edited.text | array | 15761.18 | 0.00 |
| 1024 | sequence.masked.text | array | 11588.43 | 0.00 |
| 1024 | insert | string | 447.64 | 0.00 |
| 1024 | insert.append | string | 4630.64 | 0.00 |
| 1024 | replace | string | 1251.67 | 0.00 |
| 1024 | remove | string | 1244.47 | 0.00 |
| 1024 | remove.middle | string | 1007.85 | 0.00 |
| 1024 | replace.middle | string | 1375.18 | 0.00 |
| 1024 | apply | string | 811.65 | 0.00 |
| 1024 | apply.array | string | 2350.68 | 0.00 |
| 1024 | concurrent.apply | string | 3635.00 | 0.00 |
| 1024 | merge | string | 1505.13 | 0.00 |
| 1024 | create | string | 1054.00 | 0.00 |
| 1024 | value.random | string | 59.93 | 0.00 |
| 1024 | values.range | string | 155.45 | 0.00 |
| 1024 | values.array | string | 1880.74 | 0.00 |
| 1024 | values.text | string | 72.72 | 0.00 |
| 1024 | sequence.array | string | 2024.72 | 0.00 |
| 1024 | sequence.text | string | 204.65 | 0.00 |
| 1024 | sequence.edited.text | string | 2149.56 | 0.00 |
| 1024 | sequence.masked.text | string | 3611.38 | 0.00 |
| 65536 | insert | array | 289383.87 | 0.00 |
| 65536 | insert.append | array | 1075320.83 | 0.00 |
| 65536 | replace | array | 258518.56 | 0.00 |
| 65536 | remove | array | 2282.63 | 0.00 |
| 65536 | remove.middle | array | 223550.00 | 0.00 |
| 65536 | replace.middle | array | 232829.36 | 0.00 |
| 65536 | apply | array | 733.45 | 0.00 |
| 65536 | apply.array | array | 558.00 | 0.00 |
| 65536 | concurrent.apply | array | 4257566.67 | 0.00 |
| 65536 | merge | array | 231331.19 | 0.00 |
| 65536 | create | array | 216945.69 | 0.00 |
| 65536 | value.random | array | 48.87 | 0.00 |
| 65536 | values.range | array | 131.25 | 0.00 |
| 65536 | values.array | array | 207296.03 | 0.00 |
| 65536 | values.text | array | 768687.88 | 0.00 |
| 65536 | sequence.array | array | 209472.22 | 0.00 |
| 65536 | sequence.text | array | 750917.65 | 0.00 |
| 65536 | sequence.edited.text | array | 950081.48 | 0.00 |
| 65536 | sequence.masked.text | array | 798715.63 | 0.00 |
| 65536 | insert | string | 435.46 | 0.00 |
| 65536 | insert.append | string | 23295.53 | 0.00 |
| 65536 | replace | string | 1212.32 | 0.00 |
| 65536 | remove | string | 861.39 | 0.00 |
| 65536 | remove.middle | string | 985.47 | 0.00 |
| 65536 | replace.middle | string | 1252.92 | 0.00 |
| 65536 | apply | string | 802.94 | 0.00 |
| 65536 | apply.array | string | 251484.38 | 0.00 |
| 65536 | concurrent.apply | string | 144824.86 | 0.00 |
| 65536 | merge | string | 1038.49 | 0.00 |
| 65536 | create | string | 919.40 | 0.00 |
| 65536 | value.random | string | 55.14 | 0.00 |
| 65536 | values.range | string | 148.85 | 0.00 |
| 65536 | values.array | string | 255536.72 | 0.00 |
| 65536 | values.text | string | 68.55 | 0.00 |
| 65536 | sequence.array | string | 248242.97 | 0.00 |
| 65536 | sequence.text | string | 200.98 | 0.00 |
| 65536 | sequence.edited.text | string | 90198.20 | 0.00 |
| 65536 | sequence.masked.text | string | 3330.89 | 0.00 |
| 1048576 | insert | array | 3166700.00 | 0.00 |
| 1048576 | insert.append | array | 21435700.00 | 0.00 |
| 1048576 | replace | array | 3166212.50 | 0.00 |
| 1048576 | remove | array | 10458.40 | 0.00 |
| 1048576 | remove.middle | array | 3057911.11 | 0.00 |
| 1048576 | replace.middle | array | 2544020.00 | 0.00 |
| 1048576 | apply | array | 1081.35 | 0.00 |
| 1048576 | apply.array | array | 568.32 | 0.00 |
| 1048576 | concurrent.apply | array | 68956000.00 | 0.00 |
| 1048576 | merge | array | 3134887.50 | 0.00 |
| 1048576 | create | array | 3017711.11 | 0.00 |
| 1048576 | value.random | array | 38.99 | 0.00 |
| 1048576 | values.range | array | 102.79 | 0.00 |
| 1048576 | values.array | array | 2653100.00 | 0.00 |
| 1048576 | values.text | array | 12675900.00 | 0.00 |
| 1048576 | sequence.array | array | 2209800.00 | 0.00 |
| 1048576 | sequence.text | array | 60521850.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 62811650.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 58825350.00 | 0.00 |
| 1048576 | insert | string | 377.47 | 0.00 |
| 1048576 | insert.append | string | 579038.64 | 0.00 |
| 1048576 | replace | string | 1337.37 | 0.00 |
| 1048576 | remove | string | 961.62 | 0.00 |
| 1048576 | remove.middle | string | 912.55 | 0.00 |
| 1048576 | replace.middle | string | 1309.63 | 0.00 |
| 1048576 | apply | string | 958.87 | 0.00 |
| 1048576 | apply.array | string | 3524862.50 | 0.00 |
| 1048576 | concurrent.apply | string | 1510405.88 | 0.00 |
| 1048576 | merge | string | 1206.47 | 0.00 |
| 1048576 | create | string | 1026.79 | 0.00 |
| 1048576 | value.random | string | 46.11 | 0.00 |
| 1048576 | values.range | string | 143.32 | 0.00 |
| 1048576 | values.array | string | 3261812.50 | 0.00 |
| 1048576 | values.text | string | 67.96 | 0.00 |
| 1048576 | sequence.array | string | 3272637.50 | 0.00 |
| 1048576 | sequence.text | string | 181.46 | 0.00 |
| 1048576 | sequence.edited.text | string | 1515547.06 | 0.00 |
| 1048576 | sequence.masked.text | string | 3374.52 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
