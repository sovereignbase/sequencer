# Tuple benchmarks

2026-11-27T20:56:11.031Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 3,009,988 | 2,431,033 | 0.81× |
| 2 | create.sequence | 995,813 | 811,666 | 0.82× |
| 2 | replace.random | 1,040,360 | 1,602,912 | 1.54× |
| 2 | apply.replace | 719,234 | 899,233 | 1.25× |
| 2 | apply.duplicate | 1,658,031 | 1,702,198 | 1.03× |
| 2 | merge.duplicate | 1,594,910 | 1,616,512 | 1.01× |
| 2 | length | 132,257,913 | 136,884,423 | 1.03× |
| 2 | value.random | 22,619,464 | 45,347,618 | 2.00× |
| 2 | values | 11,184,008 | 10,906,605 | 0.98× |
| 2 | sequence | 1,848,778 | 2,263,510 | 1.22× |
| 4 | create.empty | 1,893,571 | 1,656,299 | 0.87× |
| 4 | create.sequence | 375,114 | 449,950 | 1.20× |
| 4 | replace.random | 826,697 | 1,225,354 | 1.48× |
| 4 | apply.replace | 470,047 | 809,216 | 1.72× |
| 4 | apply.duplicate | 1,551,611 | 1,609,149 | 1.04× |
| 4 | merge.duplicate | 1,280,440 | 1,270,981 | 0.99× |
| 4 | length | 119,800,112 | 126,248,285 | 1.05× |
| 4 | value.random | 26,323,763 | 58,097,723 | 2.21× |
| 4 | values | 8,591,273 | 9,289,201 | 1.08× |
| 4 | sequence | 2,628,966 | 2,433,595 | 0.93× |
| 8 | create.empty | 2,543,965 | 2,462,757 | 0.97× |
| 8 | create.sequence | 455,641 | 548,298 | 1.20× |
| 8 | replace.random | 1,051,997 | 1,490,022 | 1.42× |
| 8 | apply.replace | 630,713 | 1,026,216 | 1.63× |
| 8 | apply.duplicate | 1,760,564 | 1,694,456 | 0.96× |
| 8 | merge.duplicate | 953,797 | 949,636 | 1.00× |
| 8 | length | 38,056,746 | 38,395,426 | 1.01× |
| 8 | value.random | 19,317,302 | 58,330,644 | 3.02× |
| 8 | values | 4,703,562 | 4,894,457 | 1.04× |
| 8 | sequence | 1,664,706 | 1,959,137 | 1.18× |
| 100 | create.empty | 2,297,998 | 2,215,677 | 0.96× |
| 100 | create.sequence | 71,573 | 82,966 | 1.16× |
| 100 | replace.random | 1,055,188 | 1,665,624 | 1.58× |
| 100 | apply.replace | 650,013 | 1,048,943 | 1.61× |
| 100 | apply.duplicate | 1,807,223 | 1,723,873 | 0.95× |
| 100 | merge.duplicate | 105,073 | 79,896 | 0.76× |
| 100 | length | 38,426,343 | 33,005,129 | 0.86× |
| 100 | value.random | 13,484,612 | 49,359,570 | 3.66× |
| 100 | values | 561,777 | 671,792 | 1.20× |
| 100 | sequence | 154,086 | 176,533 | 1.15× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
