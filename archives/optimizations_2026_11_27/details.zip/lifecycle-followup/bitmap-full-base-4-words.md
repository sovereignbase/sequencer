# Words benchmarks

2026-11-27T20:56:48.595Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 30,758 | 131,127 | 174 |
| append | packed | 5.90 | 3.61 | 13.98 | 32,365 | 186,566 | 293 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,406 | 816 | 237 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 28,647 | 1,570 | 244 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 486 | 243 | 80 |
| random | packed | 49.58 | 35.38 | 23.45 | 14,844 | 509 | 130 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 704 | 260 | 103 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 15,360 | 414 | 146 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 776.89 | 0.00 |
| append | numeric | encode | 32511.51 | 0.00 |
| append | numeric | decode | 2775.24 | 0.00 |
| append | numeric | create | 1612.14 | 0.00 |
| append | numeric | load | 7626.22 | 0.00 |
| append | numeric | apply | 3575650.00 | 0.00 |
| append | numeric | receive | 5761144.44 | 0.00 |
| append | binary | sequence | 464.44 | 0.00 |
| append | binary | encode | 30897.65 | 0.00 |
| append | binary | decode | 1792.88 | 0.00 |
| append | binary | create | 2271.33 | 0.00 |
| append | binary | load | 5360.03 | 0.00 |
| append | binary | apply | 1760582.76 | 0.00 |
| append | binary | receive | 3409593.33 | 0.00 |
| prepend | numeric | sequence | 492172.55 | 0.00 |
| prepend | numeric | encode | 711025.35 | 0.00 |
| prepend | numeric | decode | 254420.30 | 0.00 |
| prepend | numeric | create | 627941.25 | 0.00 |
| prepend | numeric | load | 1225002.44 | 0.00 |
| prepend | numeric | apply | 2299445.45 | 0.00 |
| prepend | numeric | receive | 4214741.67 | 0.00 |
| prepend | binary | sequence | 395992.13 | 0.00 |
| prepend | binary | encode | 34908.09 | 0.00 |
| prepend | binary | decode | 2330.75 | 0.00 |
| prepend | binary | create | 586602.33 | 0.00 |
| prepend | binary | load | 637072.15 | 0.00 |
| prepend | binary | apply | 2353200.00 | 0.00 |
| prepend | binary | receive | 4099430.77 | 0.00 |
| random | numeric | sequence | 977363.46 | 0.00 |
| random | numeric | encode | 2059520.00 | 0.00 |
| random | numeric | decode | 1198104.76 | 0.00 |
| random | numeric | create | 1817050.00 | 0.00 |
| random | numeric | load | 4118876.92 | 0.00 |
| random | numeric | apply | 8117385.71 | 0.00 |
| random | numeric | receive | 12517775.00 | 0.00 |
| random | binary | sequence | 893296.43 | 0.00 |
| random | binary | encode | 67368.51 | 0.00 |
| random | binary | decode | 1591.34 | 0.00 |
| random | binary | create | 1873422.22 | 0.00 |
| random | binary | load | 1963442.31 | 0.00 |
| random | binary | apply | 6575737.50 | 0.00 |
| random | binary | receive | 7699114.29 | 0.00 |
| concurrent | numeric | sequence | 817769.35 | 0.00 |
| concurrent | numeric | encode | 1419955.56 | 0.00 |
| concurrent | numeric | decode | 771227.69 | 0.00 |
| concurrent | numeric | create | 2415119.05 | 0.00 |
| concurrent | numeric | load | 3852146.15 | 0.00 |
| concurrent | numeric | apply | 5752322.22 | 0.00 |
| concurrent | numeric | receive | 9671133.33 | 0.00 |
| concurrent | binary | sequence | 815875.81 | 0.00 |
| concurrent | binary | encode | 65104.30 | 0.00 |
| concurrent | binary | decode | 3575.29 | 0.00 |
| concurrent | binary | create | 2367600.00 | 0.00 |
| concurrent | binary | load | 2415895.24 | 0.00 |
| concurrent | binary | apply | 5233460.00 | 0.00 |
| concurrent | binary | receive | 6855025.00 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
