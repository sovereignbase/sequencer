# Batch benchmarks

2026-11-27T20:45:07.086Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 1,360,945 | 1,114,185 | 537,423 | 76.05 | 5.99 | 0.012 |
| append | batch | 1,503,759 | 205,479,452 | 210,526,316 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,390,498 | 1,626,678 | 956,556 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 1,903,734 | 2,219,674 | 2,105,854 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 1,123,911 | 1,153,757 | 904,364 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 1,308,102 | 1,648,895 | 1,507,310 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 1,078,865 | 775,274 | 758,073 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 1,015,813 | 1,897,953 | 1,748,405 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,423,285 | 1,105,013 | 903,159 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,466,114 | 1,772,945 | 1,675,720 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,422,796 | 1,405,564 | 916,849 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 981,940 | 1,612,925 | 1,571,647 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 673,680 | 949,698 | 723,401 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 966,658 | 1,270,958 | 1,259,340 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,162,104 | 1,541,010 | 1,033,681 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 1,251,956 | 1,662,856 | 1,635,212 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,148,457 | 1,406,074 | 918,611 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 1,123,806 | 1,182,091 | 1,514,865 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 685,025 | 966,331 | 703,239 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 934,660 | 1,226,329 | 1,163,760 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 4.409 | 0.000 |
| append | individual | apply | 5.385 | 0.000 |
| append | individual | receive | 11.164 | 0.000 |
| append | individual | encode | 9.131 | 0.000 |
| append | individual | decode | 8.426 | 0.000 |
| append | batch | author | 3.990 | 0.000 |
| append | batch | apply | 0.029 | 0.000 |
| append | batch | receive | 0.029 | 0.000 |
| append | batch | encode | 0.242 | 0.000 |
| append | batch | decode | 0.099 | 0.000 |
| prepend | individual | author | 4.315 | 0.000 |
| prepend | individual | apply | 3.688 | 0.000 |
| prepend | individual | receive | 6.273 | 0.000 |
| prepend | individual | encode | 5.316 | 0.000 |
| prepend | individual | decode | 6.842 | 0.000 |
| prepend | batch | author | 3.152 | 0.000 |
| prepend | batch | apply | 2.703 | 0.000 |
| prepend | batch | receive | 2.849 | 0.000 |
| prepend | batch | encode | 0.190 | 0.000 |
| prepend | batch | decode | 0.100 | 0.000 |
| random.characters | individual | author | 5.339 | 0.000 |
| random.characters | individual | apply | 5.200 | 0.000 |
| random.characters | individual | receive | 6.635 | 0.000 |
| random.characters | individual | encode | 5.946 | 0.000 |
| random.characters | individual | decode | 7.686 | 0.000 |
| random.characters | batch | author | 4.587 | 0.000 |
| random.characters | batch | apply | 3.639 | 0.000 |
| random.characters | batch | receive | 3.981 | 0.000 |
| random.characters | batch | encode | 0.182 | 0.000 |
| random.characters | batch | decode | 0.104 | 0.000 |
| random.words | individual | author | 5.561 | 0.000 |
| random.words | individual | apply | 7.739 | 0.000 |
| random.words | individual | receive | 7.915 | 0.000 |
| random.words | individual | encode | 3.886 | 0.000 |
| random.words | individual | decode | 7.490 | 0.000 |
| random.words | batch | author | 5.907 | 0.000 |
| random.words | batch | apply | 3.161 | 0.000 |
| random.words | batch | receive | 3.432 | 0.000 |
| random.words | batch | encode | 0.423 | 0.000 |
| random.words | batch | decode | 0.100 | 0.000 |
| concurrent.characters | individual | author | 8.431 | 0.000 |
| concurrent.characters | individual | apply | 10.860 | 0.000 |
| concurrent.characters | individual | receive | 13.287 | 0.000 |
| concurrent.characters | individual | encode | 7.418 | 0.000 |
| concurrent.characters | individual | decode | 10.084 | 0.000 |
| concurrent.characters | batch | author | 8.185 | 0.000 |
| concurrent.characters | batch | apply | 6.768 | 0.000 |
| concurrent.characters | batch | receive | 7.161 | 0.000 |
| concurrent.characters | batch | encode | 0.279 | 0.000 |
| concurrent.characters | batch | decode | 0.151 | 0.000 |
| concurrent.words | individual | author | 8.434 | 0.000 |
| concurrent.words | individual | apply | 8.538 | 0.000 |
| concurrent.words | individual | receive | 13.088 | 0.000 |
| concurrent.words | individual | encode | 8.093 | 0.000 |
| concurrent.words | individual | decode | 10.523 | 0.000 |
| concurrent.words | batch | author | 12.221 | 0.000 |
| concurrent.words | batch | apply | 7.440 | 0.000 |
| concurrent.words | batch | receive | 7.635 | 0.000 |
| concurrent.words | batch | encode | 0.967 | 0.000 |
| concurrent.words | batch | decode | 0.126 | 0.000 |
| concurrent.mixed | individual | author | 17.813 | 0.000 |
| concurrent.mixed | individual | apply | 12.636 | 0.000 |
| concurrent.mixed | individual | receive | 16.588 | 0.000 |
| concurrent.mixed | individual | encode | 8.571 | 0.000 |
| concurrent.mixed | individual | decode | 10.164 | 0.000 |
| concurrent.mixed | batch | author | 12.414 | 0.000 |
| concurrent.mixed | batch | apply | 9.442 | 0.000 |
| concurrent.mixed | batch | receive | 9.529 | 0.000 |
| concurrent.mixed | batch | encode | 0.493 | 0.000 |
| concurrent.mixed | batch | decode | 0.132 | 0.000 |
| causal.characters | individual | author | 10.326 | 0.000 |
| causal.characters | individual | apply | 7.787 | 0.000 |
| causal.characters | individual | receive | 11.609 | 0.000 |
| causal.characters | individual | encode | 7.516 | 0.000 |
| causal.characters | individual | decode | 10.790 | 0.000 |
| causal.characters | batch | author | 9.585 | 0.000 |
| causal.characters | batch | apply | 7.216 | 0.000 |
| causal.characters | batch | receive | 7.338 | 0.000 |
| causal.characters | batch | encode | 0.275 | 0.000 |
| causal.characters | batch | decode | 0.110 | 0.000 |
| causal.words | individual | author | 10.449 | 0.000 |
| causal.words | individual | apply | 8.534 | 0.000 |
| causal.words | individual | receive | 13.063 | 0.000 |
| causal.words | individual | encode | 9.093 | 0.000 |
| causal.words | individual | decode | 9.947 | 0.000 |
| causal.words | batch | author | 10.678 | 0.000 |
| causal.words | batch | apply | 10.151 | 0.000 |
| causal.words | batch | receive | 7.921 | 0.000 |
| causal.words | batch | encode | 0.833 | 0.000 |
| causal.words | batch | decode | 0.188 | 0.000 |
| causal.mixed | individual | author | 17.518 | 0.000 |
| causal.mixed | individual | apply | 12.418 | 0.000 |
| causal.mixed | individual | receive | 17.064 | 0.000 |
| causal.mixed | individual | encode | 9.521 | 0.000 |
| causal.mixed | individual | decode | 9.700 | 0.000 |
| causal.mixed | batch | author | 12.839 | 0.000 |
| causal.mixed | batch | apply | 9.785 | 0.000 |
| causal.mixed | batch | receive | 10.311 | 0.000 |
| causal.mixed | batch | encode | 0.553 | 0.000 |
| causal.mixed | batch | decode | 0.136 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
