# Sequencer dynamic lifecycle benchmark

2026-11-27T20:43:39.863Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 202.54 | 165.86 | 56.93 |
| CommonJS | 202.72 | 167.48 | 57.14 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 328,403 | 3.045 | 3.045 | 3.045 | 0.000 | 0: 3.045 | 0: 3.045 |
| apply | random | A | scaleDown | 24,999 | 323,519 | 3.091 | 3.091 | 3.091 | 0.000 | 0: 3.091 | 0: 3.091 |
| apply | random | A | fullLifecycle | 49,999 | 325,943 | 3.068 | 3.068 | 3.068 | 0.000 | 0: 3.068 | 0: 3.068 |
| create | — | A | scaleUp | 7 | 551 | 1814.329 | 1814.329 | 1814.329 | 0.000 | 0: 1814.329 | 0: 1814.329 |
| create | — | A | scaleDown | 6 | 624 | 1601.967 | 1601.967 | 1601.967 | 0.000 | 0: 1601.967 | 0: 1601.967 |
| create | — | A | fullLifecycle | 13 | 583 | 1716.315 | 1716.315 | 1716.315 | 0.000 | 0: 1716.315 | 0: 1716.315 |
| insert | head | A | scaleUp | 12,500 | 1,243,237 | 0.804 | 0.804 | 0.804 | 0.000 | 0: 0.804 | 0: 0.804 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,243,237 | 0.804 | 0.804 | 0.804 | 0.000 | 0: 0.804 | 0: 0.804 |
| insert | random | A | scaleUp | 25,000 | 609,117 | 1.642 | 1.642 | 1.642 | 0.000 | 0: 1.642 | 0: 1.642 |
| insert | random | A | scaleDown | 25,000 | 566,123 | 1.766 | 1.766 | 1.766 | 0.000 | 0: 1.766 | 0: 1.766 |
| insert | random | A | fullLifecycle | 50,000 | 586,834 | 1.704 | 1.704 | 1.704 | 0.000 | 0: 1.704 | 0: 1.704 |
| insert | tail | A | scaleUp | 12,500 | 1,431,631 | 0.699 | 0.699 | 0.699 | 0.000 | 0: 0.699 | 0: 0.699 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,431,631 | 0.699 | 0.699 | 0.699 | 0.000 | 0: 0.699 | 0: 0.699 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 679,954 | 1.471 | 1.471 | 1.471 | 0.000 | 0: 1.471 | 0: 1.471 |
| remove | head | A | fullLifecycle | 12,500 | 679,954 | 1.471 | 1.471 | 1.471 | 0.000 | 0: 1.471 | 0: 1.471 |
| remove | random | A | scaleUp | 25,000 | 521,238 | 1.919 | 1.919 | 1.919 | 0.000 | 0: 1.919 | 0: 1.919 |
| remove | random | A | scaleDown | 25,000 | 490,722 | 2.038 | 2.038 | 2.038 | 0.000 | 0: 2.038 | 0: 2.038 |
| remove | random | A | fullLifecycle | 50,000 | 505,520 | 1.978 | 1.978 | 1.978 | 0.000 | 0: 1.978 | 0: 1.978 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 787,674 | 1.270 | 1.270 | 1.270 | 0.000 | 0: 1.270 | 0: 1.270 |
| remove | tail | A | fullLifecycle | 12,500 | 787,674 | 1.270 | 1.270 | 1.270 | 0.000 | 0: 1.270 | 0: 1.270 |
| replace | head | A | scaleUp | 25,000 | 487,171 | 2.053 | 2.053 | 2.053 | 0.000 | 0: 2.053 | 0: 2.053 |
| replace | head | A | scaleDown | 25,000 | 463,320 | 2.158 | 2.158 | 2.158 | 0.000 | 0: 2.158 | 0: 2.158 |
| replace | head | A | fullLifecycle | 50,000 | 474,946 | 2.106 | 2.106 | 2.106 | 0.000 | 0: 2.106 | 0: 2.106 |
| replace | random | A | scaleUp | 25,000 | 330,107 | 3.029 | 3.029 | 3.029 | 0.000 | 0: 3.029 | 0: 3.029 |
| replace | random | A | scaleDown | 25,000 | 376,367 | 2.657 | 2.657 | 2.657 | 0.000 | 0: 2.657 | 0: 2.657 |
| replace | random | A | fullLifecycle | 50,000 | 351,722 | 2.843 | 2.843 | 2.843 | 0.000 | 0: 2.843 | 0: 2.843 |
| replace | tail | A | scaleUp | 25,000 | 515,569 | 1.940 | 1.940 | 1.940 | 0.000 | 0: 1.940 | 0: 1.940 |
| replace | tail | A | scaleDown | 25,000 | 151,597 | 6.596 | 6.596 | 6.596 | 0.000 | 0: 6.596 | 0: 6.596 |
| replace | tail | A | fullLifecycle | 50,000 | 234,300 | 4.268 | 4.268 | 4.268 | 0.000 | 0: 4.268 | 0: 4.268 |
| sequence | — | A | scaleUp | 6 | 74 | 13529.683 | 13529.683 | 13529.683 | 0.000 | 0: 13529.683 | 0: 13529.683 |
| sequence | — | A | scaleDown | 6 | 98 | 10235.967 | 10235.967 | 10235.967 | 0.000 | 0: 10235.967 | 0: 10235.967 |
| sequence | — | A | fullLifecycle | 12 | 84 | 11882.825 | 11882.825 | 11882.825 | 0.000 | 0: 11882.825 | 0: 11882.825 |
| value | head | A | scaleUp | 25,000 | 3,308,235 | 0.302 | 0.302 | 0.302 | 0.000 | 0: 0.302 | 0: 0.302 |
| value | head | A | scaleDown | 25,000 | 2,258,234 | 0.443 | 0.443 | 0.443 | 0.000 | 0: 0.443 | 0: 0.443 |
| value | head | A | fullLifecycle | 50,000 | 2,684,203 | 0.373 | 0.373 | 0.373 | 0.000 | 0: 0.373 | 0: 0.373 |
| value | random | A | scaleUp | 25,000 | 939,189 | 1.065 | 1.065 | 1.065 | 0.000 | 0: 1.065 | 0: 1.065 |
| value | random | A | scaleDown | 25,000 | 901,002 | 1.110 | 1.110 | 1.110 | 0.000 | 0: 1.110 | 0: 1.110 |
| value | random | A | fullLifecycle | 50,000 | 919,699 | 1.087 | 1.087 | 1.087 | 0.000 | 0: 1.087 | 0: 1.087 |
| value | tail | A | scaleUp | 25,000 | 6,680,384 | 0.150 | 0.150 | 0.150 | 0.000 | 0: 0.150 | 0: 0.150 |
| value | tail | A | scaleDown | 25,000 | 4,186,062 | 0.239 | 0.239 | 0.239 | 0.000 | 0: 0.239 | 0: 0.239 |
| value | tail | A | fullLifecycle | 50,000 | 5,146,945 | 0.194 | 0.194 | 0.194 | 0.000 | 0: 0.194 | 0: 0.194 |
| values | — | A | scaleUp | 6 | 108 | 9294.433 | 9294.433 | 9294.433 | 0.000 | 0: 9294.433 | 0: 9294.433 |
| values | — | A | scaleDown | 6 | 243 | 4114.967 | 4114.967 | 4114.967 | 0.000 | 0: 4114.967 | 0: 4114.967 |
| values | — | A | fullLifecycle | 12 | 149 | 6704.700 | 6704.700 | 6704.700 | 0.000 | 0: 6704.700 | 0: 6704.700 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5448434.000 | 430.140 | 8.475 |
| A | scaleDown | 5 | 4404655.200 | 431.829 | 8.549 |
| A | fullLifecycle | 11 | 4973989.091 | 430.818 | 8.505 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3135629.000 | 247.550 | 4.877 |
| A | scaleDown | 5 | 2594145.800 | 254.328 | 5.035 |
| A | fullLifecycle | 11 | 2889500.273 | 250.272 | 4.940 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 262,895 | 3.804 | 1.700 | 239.300 |
| apply | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 326,190 | 3.066 | 1.500 | 239.300 |
| apply | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 308,381 | 3.243 | 1.400 | 1009.100 |
| apply | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 323,655 | 3.090 | 1.400 | 1009.100 |
| apply | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 326,012 | 3.067 | 1.400 | 1009.100 |
| apply | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 328,403 | 3.045 | 1.400 | 1009.100 |
| apply | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 307,946 | 3.247 | 1.400 | 1009.100 |
| apply | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 311,413 | 3.211 | 1.400 | 1009.100 |
| apply | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 313,340 | 3.191 | 1.400 | 1009.100 |
| apply | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 318,257 | 3.142 | 1.400 | 1009.100 |
| apply | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 324,343 | 3.083 | 1.400 | 1009.100 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 325,943 | 3.068 | 1.200 | 1009.100 |
| insert | head | 0 | up | 1,000 | 49,966 | A | 500 | 1,117,069 | 0.895 | 0.300 | 22.800 |
| insert | head | 0 | up | 5,000 | 254,523 | A | 2,500 | 884,017 | 1.131 | 0.300 | 789.000 |
| insert | head | 0 | up | 10,000 | 509,098 | A | 5,000 | 1,055,053 | 0.948 | 0.300 | 789.000 |
| insert | head | 0 | up | 15,000 | 765,837 | A | 7,500 | 1,165,592 | 0.858 | 0.300 | 789.000 |
| insert | head | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 1,202,125 | 0.832 | 0.300 | 789.000 |
| insert | head | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 1,243,237 | 0.804 | 0.300 | 789.000 |
| insert | head | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 1,243,237 | 0.804 | 0.300 | 789.000 |
| insert | head | 0 | down | 15,000 | 757,461 | A | 12,500 | 1,243,237 | 0.804 | 0.300 | 789.000 |
| insert | head | 0 | down | 10,000 | 505,565 | A | 12,500 | 1,243,237 | 0.804 | 0.300 | 789.000 |
| insert | head | 0 | down | 5,000 | 249,719 | A | 12,500 | 1,243,237 | 0.804 | 0.300 | 789.000 |
| insert | head | 0 | down | 1,000 | 50,567 | A | 12,500 | 1,243,237 | 0.804 | 0.300 | 789.000 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,243,237 | 0.804 | 0.300 | 789.000 |
| insert | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 590,947 | 1.692 | 0.400 | 351.500 |
| insert | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 611,830 | 1.634 | 0.400 | 461.100 |
| insert | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 613,380 | 1.630 | 0.400 | 461.100 |
| insert | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 630,870 | 1.585 | 0.400 | 461.100 |
| insert | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 612,211 | 1.633 | 0.400 | 687.100 |
| insert | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 609,117 | 1.642 | 0.400 | 687.100 |
| insert | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 554,970 | 1.802 | 0.400 | 790.800 |
| insert | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 553,839 | 1.806 | 0.400 | 790.800 |
| insert | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 563,388 | 1.775 | 0.400 | 790.800 |
| insert | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 572,437 | 1.747 | 0.400 | 790.800 |
| insert | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 581,996 | 1.718 | 0.400 | 790.800 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 586,834 | 1.704 | 0.400 | 790.800 |
| insert | tail | 0 | up | 1,000 | 49,966 | A | 500 | 1,289,657 | 0.775 | 0.300 | 10.000 |
| insert | tail | 0 | up | 5,000 | 254,523 | A | 2,500 | 1,296,748 | 0.771 | 0.300 | 76.000 |
| insert | tail | 0 | up | 10,000 | 509,098 | A | 5,000 | 1,384,850 | 0.722 | 0.300 | 76.000 |
| insert | tail | 0 | up | 15,000 | 765,837 | A | 7,500 | 1,428,517 | 0.700 | 0.300 | 158.100 |
| insert | tail | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 1,451,779 | 0.689 | 0.300 | 158.100 |
| insert | tail | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 1,431,631 | 0.699 | 0.300 | 299.400 |
| insert | tail | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 1,431,631 | 0.699 | 0.300 | 299.400 |
| insert | tail | 0 | down | 15,000 | 757,461 | A | 12,500 | 1,431,631 | 0.699 | 0.300 | 299.400 |
| insert | tail | 0 | down | 10,000 | 505,565 | A | 12,500 | 1,431,631 | 0.699 | 0.300 | 299.400 |
| insert | tail | 0 | down | 5,000 | 249,719 | A | 12,500 | 1,431,631 | 0.699 | 0.300 | 299.400 |
| insert | tail | 0 | down | 1,000 | 50,567 | A | 12,500 | 1,431,631 | 0.699 | 0.300 | 299.400 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,431,631 | 0.699 | 0.300 | 299.400 |
| remove | head | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 514,848 | 1.942 | 0.800 | 82.000 |
| remove | head | 0 | down | 15,000 | 757,461 | A | 5,000 | 611,023 | 1.637 | 0.800 | 82.000 |
| remove | head | 0 | down | 10,000 | 505,565 | A | 7,500 | 610,744 | 1.637 | 0.800 | 783.500 |
| remove | head | 0 | down | 5,000 | 249,719 | A | 10,000 | 648,997 | 1.541 | 0.800 | 783.500 |
| remove | head | 0 | down | 1,000 | 50,567 | A | 12,000 | 672,914 | 1.486 | 0.700 | 783.500 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 679,954 | 1.471 | 0.700 | 783.500 |
| remove | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 515,677 | 1.939 | 0.800 | 264.600 |
| remove | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 552,029 | 1.812 | 0.800 | 264.600 |
| remove | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 520,264 | 1.922 | 0.800 | 321.000 |
| remove | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 536,494 | 1.864 | 0.800 | 321.000 |
| remove | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 522,086 | 1.915 | 0.800 | 321.000 |
| remove | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 521,238 | 1.919 | 0.800 | 321.000 |
| remove | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 483,670 | 2.068 | 0.800 | 321.000 |
| remove | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 484,410 | 2.064 | 0.800 | 321.000 |
| remove | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 485,139 | 2.061 | 0.800 | 547.900 |
| remove | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 493,224 | 2.027 | 0.800 | 547.900 |
| remove | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 501,350 | 1.995 | 0.800 | 547.900 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 505,520 | 1.978 | 0.700 | 547.900 |
| remove | tail | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 563,800 | 1.774 | 0.700 | 70.200 |
| remove | tail | 0 | down | 15,000 | 757,461 | A | 5,000 | 669,730 | 1.493 | 0.700 | 88.000 |
| remove | tail | 0 | down | 10,000 | 505,565 | A | 7,500 | 718,226 | 1.392 | 0.700 | 88.000 |
| remove | tail | 0 | down | 5,000 | 249,719 | A | 10,000 | 757,318 | 1.320 | 0.700 | 88.000 |
| remove | tail | 0 | down | 1,000 | 50,567 | A | 12,000 | 779,899 | 1.282 | 0.700 | 88.000 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 787,674 | 1.270 | 0.600 | 88.000 |
| replace | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 398,073 | 2.512 | 1.100 | 398.800 |
| replace | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 482,355 | 2.073 | 1.000 | 398.800 |
| replace | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 527,254 | 1.897 | 1.000 | 398.800 |
| replace | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 544,467 | 1.837 | 1.000 | 398.800 |
| replace | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 529,323 | 1.889 | 1.000 | 1566.100 |
| replace | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 487,171 | 2.053 | 1.000 | 4279.400 |
| replace | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 465,261 | 2.149 | 1.000 | 4279.400 |
| replace | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 454,027 | 2.203 | 1.000 | 4279.400 |
| replace | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 457,737 | 2.185 | 1.000 | 4279.400 |
| replace | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 464,260 | 2.154 | 1.000 | 4279.400 |
| replace | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 472,002 | 2.119 | 1.000 | 4279.400 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 474,946 | 2.106 | 0.900 | 4279.400 |
| replace | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 414,456 | 2.413 | 1.000 | 81.400 |
| replace | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 314,683 | 3.178 | 1.000 | 1174.900 |
| replace | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 344,130 | 2.906 | 1.000 | 1174.900 |
| replace | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 330,648 | 3.024 | 1.000 | 2759.300 |
| replace | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 321,312 | 3.112 | 1.000 | 2759.300 |
| replace | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 330,107 | 3.029 | 1.000 | 2759.300 |
| replace | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 318,430 | 3.140 | 1.000 | 2759.300 |
| replace | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 323,406 | 3.092 | 1.000 | 2759.300 |
| replace | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 331,650 | 3.015 | 1.000 | 2759.300 |
| replace | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 339,502 | 2.945 | 1.000 | 2759.300 |
| replace | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 348,646 | 2.868 | 1.000 | 2759.300 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 351,722 | 2.843 | 0.900 | 2759.300 |
| replace | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 480,931 | 2.079 | 1.000 | 96.700 |
| replace | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 522,892 | 1.912 | 1.000 | 98.600 |
| replace | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 541,888 | 1.845 | 1.000 | 149.500 |
| replace | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 540,517 | 1.850 | 1.000 | 994.600 |
| replace | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 532,934 | 1.876 | 1.000 | 994.600 |
| replace | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 515,569 | 1.940 | 1.000 | 1652.900 |
| replace | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 284,856 | 3.511 | 1.000 | 31968.800 |
| replace | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 221,391 | 4.517 | 1.000 | 31968.800 |
| replace | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 233,162 | 4.289 | 1.000 | 31968.800 |
| replace | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 226,250 | 4.420 | 1.000 | 31968.800 |
| replace | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 231,328 | 4.323 | 1.000 | 31968.800 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 234,300 | 4.268 | 0.800 | 31968.800 |
| value | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 1,668,335 | 0.599 | 0.100 | 242.000 |
| value | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 2,747,555 | 0.364 | 0.100 | 242.000 |
| value | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 3,064,383 | 0.326 | 0.100 | 242.000 |
| value | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 3,240,231 | 0.309 | 0.100 | 242.000 |
| value | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 3,281,755 | 0.305 | 0.100 | 242.000 |
| value | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 3,308,235 | 0.302 | 0.100 | 242.000 |
| value | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 2,875,519 | 0.348 | 0.100 | 242.000 |
| value | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 2,778,969 | 0.360 | 0.100 | 242.000 |
| value | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 2,718,777 | 0.368 | 0.100 | 242.000 |
| value | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 2,685,060 | 0.372 | 0.100 | 242.000 |
| value | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 2,676,411 | 0.374 | 0.100 | 242.000 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,684,203 | 0.373 | 0.100 | 242.000 |
| value | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 1,433,075 | 0.698 | 0.100 | 15.800 |
| value | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 1,094,475 | 0.914 | 0.100 | 69.700 |
| value | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 978,962 | 1.021 | 0.100 | 69.700 |
| value | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 970,277 | 1.031 | 0.100 | 69.700 |
| value | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 961,076 | 1.040 | 0.100 | 69.700 |
| value | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 939,189 | 1.065 | 0.100 | 69.700 |
| value | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 859,784 | 1.163 | 0.100 | 93.400 |
| value | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 864,012 | 1.157 | 0.100 | 93.400 |
| value | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 876,822 | 1.140 | 0.100 | 93.400 |
| value | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 892,064 | 1.121 | 0.100 | 93.400 |
| value | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 910,625 | 1.098 | 0.100 | 93.400 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 919,699 | 1.087 | 0.100 | 93.400 |
| value | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 5,685,048 | 0.176 | 0.100 | 8.400 |
| value | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 5,260,389 | 0.190 | 0.100 | 49.300 |
| value | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 5,859,604 | 0.171 | 0.100 | 49.300 |
| value | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 6,348,132 | 0.158 | 0.000 | 49.300 |
| value | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 6,524,221 | 0.153 | 0.000 | 49.300 |
| value | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 6,680,384 | 0.150 | 0.000 | 49.300 |
| value | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 5,810,238 | 0.172 | 0.000 | 49.300 |
| value | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 5,553,969 | 0.180 | 0.000 | 49.300 |
| value | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 5,348,523 | 0.187 | 0.000 | 49.300 |
| value | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 5,229,457 | 0.191 | 0.000 | 49.300 |
| value | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 5,144,735 | 0.194 | 0.000 | 49.300 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,146,945 | 0.194 | 0.000 | 49.300 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,232 | 448.100 |
| create | — | 0 | up | 5,000 | A | 1 | 961 | 1040.100 |
| create | — | 0 | up | 10,000 | A | 1 | 633 | 1578.600 |
| create | — | 0 | up | 15,000 | A | 1 | 422 | 2370.700 |
| create | — | 0 | up | 20,000 | A | 1 | 305 | 3280.100 |
| create | — | 0 | up | 25,000 | A | 1 | 257 | 3886.800 |
| create | — | 0 | down | 20,000 | A | 1 | 288 | 3476.100 |
| create | — | 0 | down | 15,000 | A | 1 | 373 | 2682.300 |
| create | — | 0 | down | 10,000 | A | 1 | 409 | 2446.400 |
| create | — | 0 | down | 5,000 | A | 1 | 1,173 | 852.600 |
| create | — | 0 | down | 1,000 | A | 1 | 7,407 | 135.000 |
| create | — | 0 | down | 0 | A | 1 | 51,546 | 19.400 |
| sequence | — | 0 | up | 1,000 | A | 1 | 383 | 2612.100 |
| sequence | — | 0 | up | 5,000 | A | 1 | 108 | 9267.600 |
| sequence | — | 0 | up | 10,000 | A | 1 | 93 | 10804.600 |
| sequence | — | 0 | up | 15,000 | A | 1 | 63 | 15950.200 |
| sequence | — | 0 | up | 20,000 | A | 1 | 49 | 20307.900 |
| sequence | — | 0 | up | 25,000 | A | 1 | 45 | 22235.700 |
| sequence | — | 0 | down | 20,000 | A | 1 | 58 | 17241.600 |
| sequence | — | 0 | down | 15,000 | A | 1 | 68 | 14739.000 |
| sequence | — | 0 | down | 10,000 | A | 1 | 77 | 12953.600 |
| sequence | — | 0 | down | 5,000 | A | 1 | 105 | 9567.800 |
| sequence | — | 0 | down | 1,000 | A | 1 | 185 | 5397.000 |
| sequence | — | 0 | down | 0 | A | 1 | 659 | 1516.800 |
| values | — | 0 | up | 1,000 | A | 1 | 580 | 1724.300 |
| values | — | 0 | up | 5,000 | A | 1 | 179 | 5590.600 |
| values | — | 0 | up | 10,000 | A | 1 | 51 | 19648.100 |
| values | — | 0 | up | 15,000 | A | 1 | 112 | 8894.600 |
| values | — | 0 | up | 20,000 | A | 1 | 114 | 8792.600 |
| values | — | 0 | up | 25,000 | A | 1 | 90 | 11116.400 |
| values | — | 0 | down | 20,000 | A | 1 | 106 | 9395.200 |
| values | — | 0 | down | 15,000 | A | 1 | 150 | 6655.900 |
| values | — | 0 | down | 10,000 | A | 1 | 176 | 5695.500 |
| values | — | 0 | down | 5,000 | A | 1 | 402 | 2487.400 |
| values | — | 0 | down | 1,000 | A | 1 | 2,261 | 442.200 |
| values | — | 0 | down | 0 | A | 1 | 73,529 | 13.600 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.613 | 0.232 | 0.381 |
| 0 | up | 5000 | 3.108 | 1.167 | 1.942 |
| 0 | up | 10000 | 6.228 | 2.343 | 3.884 |
| 0 | up | 15000 | 9.486 | 3.643 | 5.843 |
| 0 | up | 20000 | 12.852 | 5.113 | 7.739 |
| 0 | up | 25000 | 16.278 | 6.637 | 9.641 |
| 0 | down | 20000 | 13.340 | 5.613 | 7.727 |
| 0 | down | 15000 | 9.910 | 4.131 | 5.779 |
| 0 | down | 10000 | 7.153 | 3.295 | 3.857 |
| 0 | down | 5000 | 4.067 | 2.161 | 1.905 |
| 0 | down | 1000 | 1.807 | 1.421 | 0.386 |
| 0 | down | 0 | 1.231 | 1.231 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 49,966 | 0.402 | 421.140 | 8.429 | 121.391 | 15.534 |
| 0 | up | A | 5,000 | 5,000 | 254,523 | 2.043 | 428.454 | 8.417 | 155.984 | 19.635 |
| 0 | up | A | 10,000 | 10,000 | 509,098 | 4.098 | 429.682 | 8.440 | 194.590 | 24.546 |
| 0 | up | A | 15,000 | 15,000 | 765,837 | 6.183 | 432.249 | 8.466 | 210.141 | 29.453 |
| 0 | up | A | 20,000 | 20,000 | 1,014,350 | 8.209 | 430.368 | 8.486 | 279.574 | 34.243 |
| 0 | up | A | 25,000 | 25,000 | 1,263,607 | 10.242 | 429.572 | 8.499 | 294.547 | 39.011 |
| 0 | down | A | 20,000 | 20,000 | 1,012,792 | 8.267 | 433.443 | 8.559 | 296.313 | 34.246 |
| 0 | down | A | 15,000 | 15,000 | 757,461 | 6.185 | 432.337 | 8.562 | 301.191 | 29.400 |
| 0 | down | A | 10,000 | 10,000 | 505,565 | 4.118 | 431.804 | 8.541 | 298.219 | 24.625 |
| 0 | down | A | 5,000 | 5,000 | 249,719 | 2.025 | 424.661 | 8.503 | 297.059 | 19.789 |
| 0 | down | A | 1,000 | 1,000 | 50,567 | 0.408 | 428.020 | 8.464 | 294.695 | 15.993 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 295.984 | 14.916 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 49966 | 184228 | 184.228 | 3.687 | 271.76 | 14.53 | 161.92 | 12.35 |
| 0 | up | A | 5000 | 254523 | 1210131 | 242.026 | 4.755 | 1634.13 | 73.21 | 825.25 | 61.48 |
| 0 | up | A | 10000 | 509098 | 2448079 | 244.808 | 4.809 | 3283.48 | 149.01 | 1658.86 | 124.83 |
| 0 | up | A | 15000 | 765837 | 3734371 | 248.958 | 4.876 | 4974.88 | 226.26 | 3590.17 | 200.09 |
| 0 | up | A | 20000 | 1014350 | 4987172 | 249.359 | 4.917 | 7129.39 | 311.11 | 5143.68 | 263.60 |
| 0 | up | A | 25000 | 1263607 | 6249793 | 249.992 | 4.946 | 9254.82 | 392.21 | 6545.54 | 334.80 |
| 0 | down | A | 20000 | 1012792 | 5129580 | 256.479 | 5.065 | 7576.63 | 326.54 | 5319.60 | 278.20 |
| 0 | down | A | 15000 | 757461 | 3834350 | 255.623 | 5.062 | 5712.74 | 247.20 | 3993.54 | 209.87 |
| 0 | down | A | 10000 | 505565 | 2537356 | 253.736 | 5.019 | 3822.17 | 165.03 | 2665.76 | 139.77 |
| 0 | down | A | 5000 | 249719 | 1229097 | 245.819 | 4.922 | 1877.54 | 79.58 | 1312.05 | 67.88 |
| 0 | down | A | 1000 | 50567 | 240346 | 240.346 | 4.753 | 377.29 | 15.97 | 264.47 | 13.64 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 430.140 | 8.475 | 247.550 | 4.877 |
| 0 | A | scaleDown | 431.829 | 8.549 | 254.328 | 5.035 |
| 0 | A | fullLifecycle | 430.818 | 8.505 | 250.272 | 4.940 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
