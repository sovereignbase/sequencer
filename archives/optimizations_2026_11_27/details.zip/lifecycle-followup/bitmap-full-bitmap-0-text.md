# Large string benchmarks

2026-11-27T20:44:39.334Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2279.98 | 0.00 |
| 1024 | insert.append | array | 12781.20 | 0.00 |
| 1024 | replace | array | 3167.13 | 0.00 |
| 1024 | remove | array | 985.33 | 0.00 |
| 1024 | remove.middle | array | 1988.44 | 0.00 |
| 1024 | replace.middle | array | 2445.35 | 0.00 |
| 1024 | apply | array | 814.38 | 0.00 |
| 1024 | apply.array | array | 614.58 | 0.00 |
| 1024 | concurrent.apply | array | 70833.99 | 0.00 |
| 1024 | merge | array | 3025.29 | 0.00 |
| 1024 | create | array | 3005.58 | 0.00 |
| 1024 | value.random | array | 46.15 | 0.00 |
| 1024 | values.range | array | 124.59 | 0.00 |
| 1024 | values.array | array | 1262.79 | 0.00 |
| 1024 | values.text | array | 14083.84 | 0.00 |
| 1024 | sequence.array | array | 1865.17 | 0.00 |
| 1024 | sequence.text | array | 9616.69 | 0.00 |
| 1024 | sequence.edited.text | array | 9460.35 | 0.00 |
| 1024 | sequence.masked.text | array | 10960.46 | 0.00 |
| 1024 | insert | string | 406.24 | 0.00 |
| 1024 | insert.append | string | 4128.25 | 0.00 |
| 1024 | replace | string | 1215.05 | 0.00 |
| 1024 | remove | string | 935.67 | 0.00 |
| 1024 | remove.middle | string | 992.88 | 0.00 |
| 1024 | replace.middle | string | 1353.76 | 0.00 |
| 1024 | apply | string | 753.26 | 0.00 |
| 1024 | apply.array | string | 2470.53 | 0.00 |
| 1024 | concurrent.apply | string | 3957.72 | 0.00 |
| 1024 | merge | string | 1393.77 | 0.00 |
| 1024 | create | string | 962.07 | 0.00 |
| 1024 | value.random | string | 91.76 | 0.00 |
| 1024 | values.range | string | 185.97 | 0.00 |
| 1024 | values.array | string | 1966.69 | 0.00 |
| 1024 | values.text | string | 74.67 | 0.00 |
| 1024 | sequence.array | string | 2061.01 | 0.00 |
| 1024 | sequence.text | string | 197.99 | 0.00 |
| 1024 | sequence.edited.text | string | 704.69 | 0.00 |
| 1024 | sequence.masked.text | string | 3575.97 | 0.00 |
| 65536 | insert | array | 258996.91 | 0.00 |
| 65536 | insert.append | array | 1067736.00 | 0.00 |
| 65536 | replace | array | 231835.19 | 0.00 |
| 65536 | remove | array | 2490.66 | 0.00 |
| 65536 | remove.middle | array | 250178.90 | 0.00 |
| 65536 | replace.middle | array | 241532.11 | 0.00 |
| 65536 | apply | array | 765.75 | 0.00 |
| 65536 | apply.array | array | 581.85 | 0.00 |
| 65536 | concurrent.apply | array | 3939142.86 | 0.00 |
| 65536 | merge | array | 205732.79 | 0.00 |
| 65536 | create | array | 225413.39 | 0.00 |
| 65536 | value.random | array | 44.96 | 0.00 |
| 65536 | values.range | array | 128.94 | 0.00 |
| 65536 | values.array | array | 201527.78 | 0.00 |
| 65536 | values.text | array | 768418.18 | 0.00 |
| 65536 | sequence.array | array | 197845.67 | 0.00 |
| 65536 | sequence.text | array | 875260.00 | 0.00 |
| 65536 | sequence.edited.text | array | 727625.71 | 0.00 |
| 65536 | sequence.masked.text | array | 784509.38 | 0.00 |
| 65536 | insert | string | 379.68 | 0.00 |
| 65536 | insert.append | string | 20202.02 | 0.00 |
| 65536 | replace | string | 1126.40 | 0.00 |
| 65536 | remove | string | 854.36 | 0.00 |
| 65536 | remove.middle | string | 999.34 | 0.00 |
| 65536 | replace.middle | string | 1229.36 | 0.00 |
| 65536 | apply | string | 687.35 | 0.00 |
| 65536 | apply.array | string | 261307.81 | 0.00 |
| 65536 | concurrent.apply | string | 143893.68 | 0.00 |
| 65536 | merge | string | 1447.09 | 0.00 |
| 65536 | create | string | 1043.03 | 0.00 |
| 65536 | value.random | string | 51.75 | 0.00 |
| 65536 | values.range | string | 147.58 | 0.00 |
| 65536 | values.array | string | 237603.12 | 0.00 |
| 65536 | values.text | string | 69.13 | 0.00 |
| 65536 | sequence.array | string | 251492.97 | 0.00 |
| 65536 | sequence.text | string | 218.23 | 0.00 |
| 65536 | sequence.edited.text | string | 6318.37 | 0.00 |
| 65536 | sequence.masked.text | string | 3337.70 | 0.00 |
| 1048576 | insert | array | 3002644.44 | 0.00 |
| 1048576 | insert.append | array | 20011700.00 | 0.00 |
| 1048576 | replace | array | 3410537.50 | 0.00 |
| 1048576 | remove | array | 11832.47 | 0.00 |
| 1048576 | remove.middle | array | 3171966.67 | 0.00 |
| 1048576 | replace.middle | array | 2932681.82 | 0.00 |
| 1048576 | apply | array | 970.74 | 0.00 |
| 1048576 | apply.array | array | 689.72 | 0.00 |
| 1048576 | concurrent.apply | array | 64028800.00 | 0.00 |
| 1048576 | merge | array | 3259637.50 | 0.00 |
| 1048576 | create | array | 2997700.00 | 0.00 |
| 1048576 | value.random | array | 46.01 | 0.00 |
| 1048576 | values.range | array | 102.27 | 0.00 |
| 1048576 | values.array | array | 2823888.89 | 0.00 |
| 1048576 | values.text | array | 12828750.00 | 0.00 |
| 1048576 | sequence.array | array | 2229583.33 | 0.00 |
| 1048576 | sequence.text | array | 58343050.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 45711250.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 45195400.00 | 0.00 |
| 1048576 | insert | string | 480.53 | 0.00 |
| 1048576 | insert.append | string | 530629.17 | 0.00 |
| 1048576 | replace | string | 1369.26 | 0.00 |
| 1048576 | remove | string | 998.05 | 0.00 |
| 1048576 | remove.middle | string | 1049.28 | 0.00 |
| 1048576 | replace.middle | string | 1520.95 | 0.00 |
| 1048576 | apply | string | 867.10 | 0.00 |
| 1048576 | apply.array | string | 3253662.50 | 0.00 |
| 1048576 | concurrent.apply | string | 1634862.50 | 0.00 |
| 1048576 | merge | string | 1216.71 | 0.00 |
| 1048576 | create | string | 934.41 | 0.00 |
| 1048576 | value.random | string | 46.01 | 0.00 |
| 1048576 | values.range | string | 157.32 | 0.00 |
| 1048576 | values.array | string | 3135062.50 | 0.00 |
| 1048576 | values.text | string | 61.11 | 0.00 |
| 1048576 | sequence.array | string | 3193837.50 | 0.00 |
| 1048576 | sequence.text | string | 192.58 | 0.00 |
| 1048576 | sequence.edited.text | string | 85438.91 | 0.00 |
| 1048576 | sequence.masked.text | string | 2993.25 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
