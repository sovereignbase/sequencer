# Tuple benchmarks

2026-11-27T20:44:24.945Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 2,633,839 | 2,413,551 | 0.92× |
| 2 | create.sequence | 1,043,708 | 851,487 | 0.82× |
| 2 | replace.random | 1,243,525 | 630,125 | 0.51× |
| 2 | apply.replace | 648,909 | 815,240 | 1.26× |
| 2 | apply.duplicate | 1,904,570 | 1,746,881 | 0.92× |
| 2 | merge.duplicate | 1,590,964 | 1,737,916 | 1.09× |
| 2 | length | 138,238,492 | 136,001,261 | 0.98× |
| 2 | value.random | 33,952,417 | 54,438,568 | 1.60× |
| 2 | values | 12,153,431 | 13,632,001 | 1.12× |
| 2 | sequence | 3,088,481 | 2,850,292 | 0.92× |
| 4 | create.empty | 2,558,680 | 2,510,479 | 0.98× |
| 4 | create.sequence | 726,489 | 717,973 | 0.99× |
| 4 | replace.random | 1,067,703 | 1,466,783 | 1.37× |
| 4 | apply.replace | 632,437 | 978,767 | 1.55× |
| 4 | apply.duplicate | 1,676,000 | 1,813,335 | 1.08× |
| 4 | merge.duplicate | 1,429,688 | 1,451,070 | 1.01× |
| 4 | length | 37,475,626 | 37,168,362 | 0.99× |
| 4 | value.random | 25,153,187 | 59,877,570 | 2.38× |
| 4 | values | 7,099,112 | 6,828,414 | 0.96× |
| 4 | sequence | 2,687,034 | 2,428,910 | 0.90× |
| 8 | create.empty | 2,672,410 | 2,510,604 | 0.94× |
| 8 | create.sequence | 491,951 | 515,445 | 1.05× |
| 8 | replace.random | 1,046,539 | 1,636,093 | 1.56× |
| 8 | apply.replace | 667,870 | 1,049,182 | 1.57× |
| 8 | apply.duplicate | 1,766,092 | 1,743,275 | 0.99× |
| 8 | merge.duplicate | 1,005,279 | 427,975 | 0.43× |
| 8 | length | 39,241,077 | 35,190,263 | 0.90× |
| 8 | value.random | 17,357,837 | 56,169,374 | 3.24× |
| 8 | values | 4,584,962 | 4,971,853 | 1.08× |
| 8 | sequence | 1,672,604 | 1,845,117 | 1.10× |
| 100 | create.empty | 2,416,330 | 2,266,228 | 0.94× |
| 100 | create.sequence | 70,507 | 86,803 | 1.23× |
| 100 | replace.random | 1,042,139 | 1,677,494 | 1.61× |
| 100 | apply.replace | 633,530 | 961,433 | 1.52× |
| 100 | apply.duplicate | 1,760,867 | 1,747,322 | 0.99× |
| 100 | merge.duplicate | 111,421 | 69,498 | 0.62× |
| 100 | length | 37,949,644 | 37,677,938 | 0.99× |
| 100 | value.random | 12,824,974 | 53,228,752 | 4.15× |
| 100 | values | 570,555 | 690,482 | 1.21× |
| 100 | sequence | 173,736 | 183,738 | 1.06× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
