# Words benchmarks

2026-11-27T20:45:00.060Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 30,953 | 149,534 | 154 |
| append | packed | 5.90 | 3.61 | 13.98 | 30,417 | 163,592 | 291 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,777 | 645 | 237 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 29,177 | 1,560 | 234 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 501 | 265 | 85 |
| random | packed | 49.58 | 35.38 | 23.45 | 14,642 | 554 | 125 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 619 | 215 | 104 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 15,855 | 413 | 139 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 521.38 | 0.00 |
| append | numeric | encode | 32307.10 | 0.00 |
| append | numeric | decode | 2714.15 | 0.00 |
| append | numeric | create | 1772.23 | 0.00 |
| append | numeric | load | 6687.45 | 0.00 |
| append | numeric | apply | 4182466.67 | 0.00 |
| append | numeric | receive | 6488500.00 | 0.00 |
| append | binary | sequence | 491.66 | 0.00 |
| append | binary | encode | 32876.87 | 0.00 |
| append | binary | decode | 1809.66 | 0.00 |
| append | binary | create | 2161.18 | 0.00 |
| append | binary | load | 6112.75 | 0.00 |
| append | binary | apply | 1571387.50 | 0.00 |
| append | binary | receive | 3431726.67 | 0.00 |
| prepend | numeric | sequence | 461418.35 | 0.00 |
| prepend | numeric | encode | 562592.13 | 0.00 |
| prepend | numeric | decode | 132064.38 | 0.00 |
| prepend | numeric | create | 650161.04 | 0.00 |
| prepend | numeric | load | 1549390.91 | 0.00 |
| prepend | numeric | apply | 2593145.00 | 0.00 |
| prepend | numeric | receive | 4222408.33 | 0.00 |
| prepend | binary | sequence | 362542.03 | 0.00 |
| prepend | binary | encode | 34273.08 | 0.00 |
| prepend | binary | decode | 2881.48 | 0.00 |
| prepend | binary | create | 772943.08 | 0.00 |
| prepend | binary | load | 641167.95 | 0.00 |
| prepend | binary | apply | 2807327.78 | 0.00 |
| prepend | binary | receive | 4267383.33 | 0.00 |
| random | numeric | sequence | 937855.56 | 0.00 |
| random | numeric | encode | 1995846.15 | 0.00 |
| random | numeric | decode | 1050797.92 | 0.00 |
| random | numeric | create | 1713246.67 | 0.00 |
| random | numeric | load | 3770850.00 | 0.00 |
| random | numeric | apply | 7931671.43 | 0.00 |
| random | numeric | receive | 11748320.00 | 0.00 |
| random | binary | sequence | 952309.43 | 0.00 |
| random | binary | encode | 68295.65 | 0.00 |
| random | binary | decode | 1626.78 | 0.00 |
| random | binary | create | 1922637.04 | 0.00 |
| random | binary | load | 1806357.14 | 0.00 |
| random | binary | apply | 6314700.00 | 0.00 |
| random | binary | receive | 7972400.00 | 0.00 |
| concurrent | numeric | sequence | 776158.46 | 0.00 |
| concurrent | numeric | encode | 1616577.42 | 0.00 |
| concurrent | numeric | decode | 782453.13 | 0.00 |
| concurrent | numeric | create | 2329890.91 | 0.00 |
| concurrent | numeric | load | 4644436.36 | 0.00 |
| concurrent | numeric | apply | 6304237.50 | 0.00 |
| concurrent | numeric | receive | 9596650.00 | 0.00 |
| concurrent | binary | sequence | 721160.00 | 0.00 |
| concurrent | binary | encode | 63071.25 | 0.00 |
| concurrent | binary | decode | 2421.75 | 0.00 |
| concurrent | binary | create | 2365904.55 | 0.00 |
| concurrent | binary | load | 2421128.57 | 0.00 |
| concurrent | binary | apply | 5129280.00 | 0.00 |
| concurrent | binary | receive | 7187385.71 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
