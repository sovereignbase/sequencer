# Batch benchmarks

2026-11-27T20:46:50.029Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 1,013,565 | 1,110,659 | 610,612 | 76.05 | 5.99 | 0.012 |
| append | batch | 2,623,983 | 251,046,025 | 206,896,552 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,647,401 | 1,438,263 | 839,020 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 1,803,264 | 2,110,298 | 2,016,942 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 692,585 | 808,996 | 781,454 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 1,205,497 | 1,595,872 | 1,529,442 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 1,117,610 | 1,140,945 | 816,882 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 1,147,996 | 1,817,411 | 1,631,055 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,404,149 | 1,150,042 | 819,364 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,370,317 | 1,741,680 | 1,654,784 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,321,775 | 1,371,100 | 824,878 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,377,284 | 1,653,006 | 1,460,849 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 696,306 | 923,283 | 686,122 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 841,798 | 1,062,031 | 1,178,875 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,231,173 | 1,343,259 | 960,907 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 1,205,013 | 1,702,997 | 1,609,939 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,020,955 | 1,312,594 | 894,494 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 1,286,574 | 1,628,399 | 1,498,558 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 757,920 | 968,320 | 725,010 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 961,169 | 1,200,624 | 1,226,054 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 5.920 | 0.000 |
| append | individual | apply | 5.402 | 0.000 |
| append | individual | receive | 9.826 | 0.000 |
| append | individual | encode | 8.826 | 0.000 |
| append | individual | decode | 7.359 | 0.000 |
| append | batch | author | 2.287 | 0.000 |
| append | batch | apply | 0.024 | 0.000 |
| append | batch | receive | 0.029 | 0.000 |
| append | batch | encode | 0.202 | 0.000 |
| append | batch | decode | 0.098 | 0.000 |
| prepend | individual | author | 3.642 | 0.000 |
| prepend | individual | apply | 4.172 | 0.000 |
| prepend | individual | receive | 7.151 | 0.000 |
| prepend | individual | encode | 5.404 | 0.000 |
| prepend | individual | decode | 7.192 | 0.000 |
| prepend | batch | author | 3.327 | 0.000 |
| prepend | batch | apply | 2.843 | 0.000 |
| prepend | batch | receive | 2.975 | 0.000 |
| prepend | batch | encode | 0.257 | 0.000 |
| prepend | batch | decode | 0.110 | 0.000 |
| random.characters | individual | author | 8.663 | 0.000 |
| random.characters | individual | apply | 7.417 | 0.000 |
| random.characters | individual | receive | 7.678 | 0.000 |
| random.characters | individual | encode | 5.589 | 0.000 |
| random.characters | individual | decode | 7.276 | 0.000 |
| random.characters | batch | author | 4.977 | 0.000 |
| random.characters | batch | apply | 3.760 | 0.000 |
| random.characters | batch | receive | 3.923 | 0.000 |
| random.characters | batch | encode | 0.199 | 0.000 |
| random.characters | batch | decode | 0.112 | 0.000 |
| random.words | individual | author | 5.369 | 0.000 |
| random.words | individual | apply | 5.259 | 0.000 |
| random.words | individual | receive | 7.345 | 0.000 |
| random.words | individual | encode | 3.880 | 0.000 |
| random.words | individual | decode | 6.722 | 0.000 |
| random.words | batch | author | 5.226 | 0.000 |
| random.words | batch | apply | 3.301 | 0.000 |
| random.words | batch | receive | 3.679 | 0.000 |
| random.words | batch | encode | 0.409 | 0.000 |
| random.words | batch | decode | 0.109 | 0.000 |
| concurrent.characters | individual | author | 8.546 | 0.000 |
| concurrent.characters | individual | apply | 10.434 | 0.000 |
| concurrent.characters | individual | receive | 14.645 | 0.000 |
| concurrent.characters | individual | encode | 7.585 | 0.000 |
| concurrent.characters | individual | decode | 11.011 | 0.000 |
| concurrent.characters | batch | author | 8.757 | 0.000 |
| concurrent.characters | batch | apply | 6.890 | 0.000 |
| concurrent.characters | batch | receive | 7.252 | 0.000 |
| concurrent.characters | batch | encode | 0.312 | 0.000 |
| concurrent.characters | batch | decode | 0.107 | 0.000 |
| concurrent.words | individual | author | 9.079 | 0.000 |
| concurrent.words | individual | apply | 8.752 | 0.000 |
| concurrent.words | individual | receive | 14.548 | 0.000 |
| concurrent.words | individual | encode | 7.576 | 0.000 |
| concurrent.words | individual | decode | 11.869 | 0.000 |
| concurrent.words | batch | author | 8.713 | 0.000 |
| concurrent.words | batch | apply | 7.259 | 0.000 |
| concurrent.words | batch | receive | 8.214 | 0.000 |
| concurrent.words | batch | encode | 0.724 | 0.000 |
| concurrent.words | batch | decode | 0.113 | 0.000 |
| concurrent.mixed | individual | author | 17.234 | 0.000 |
| concurrent.mixed | individual | apply | 12.997 | 0.000 |
| concurrent.mixed | individual | receive | 17.490 | 0.000 |
| concurrent.mixed | individual | encode | 8.324 | 0.000 |
| concurrent.mixed | individual | decode | 11.502 | 0.000 |
| concurrent.mixed | batch | author | 14.255 | 0.000 |
| concurrent.mixed | batch | apply | 11.299 | 0.000 |
| concurrent.mixed | batch | receive | 10.179 | 0.000 |
| concurrent.mixed | batch | encode | 0.523 | 0.000 |
| concurrent.mixed | batch | decode | 0.107 | 0.000 |
| causal.characters | individual | author | 9.747 | 0.000 |
| causal.characters | individual | apply | 8.934 | 0.000 |
| causal.characters | individual | receive | 12.488 | 0.000 |
| causal.characters | individual | encode | 7.251 | 0.000 |
| causal.characters | individual | decode | 10.795 | 0.000 |
| causal.characters | batch | author | 9.958 | 0.000 |
| causal.characters | batch | apply | 7.046 | 0.000 |
| causal.characters | batch | receive | 7.454 | 0.000 |
| causal.characters | batch | encode | 0.243 | 0.000 |
| causal.characters | batch | decode | 0.116 | 0.000 |
| causal.words | individual | author | 11.754 | 0.000 |
| causal.words | individual | apply | 9.142 | 0.000 |
| causal.words | individual | receive | 13.415 | 0.000 |
| causal.words | individual | encode | 8.695 | 0.000 |
| causal.words | individual | decode | 11.932 | 0.000 |
| causal.words | batch | author | 9.327 | 0.000 |
| causal.words | batch | apply | 7.369 | 0.000 |
| causal.words | batch | receive | 8.008 | 0.000 |
| causal.words | batch | encode | 0.606 | 0.000 |
| causal.words | batch | decode | 0.109 | 0.000 |
| causal.mixed | individual | author | 15.833 | 0.000 |
| causal.mixed | individual | apply | 12.393 | 0.000 |
| causal.mixed | individual | receive | 16.552 | 0.000 |
| causal.mixed | individual | encode | 9.814 | 0.000 |
| causal.mixed | individual | decode | 9.234 | 0.000 |
| causal.mixed | batch | author | 12.485 | 0.000 |
| causal.mixed | batch | apply | 9.995 | 0.000 |
| causal.mixed | batch | receive | 9.787 | 0.000 |
| causal.mixed | batch | encode | 0.434 | 0.000 |
| causal.mixed | batch | decode | 0.112 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
