# Sequencer dynamic lifecycle benchmark

2026-11-27T20:45:17.594Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 202.54 | 165.86 | 56.93 |
| CommonJS | 202.72 | 167.48 | 57.14 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 295,529 | 3.384 | 3.384 | 3.384 | 0.000 | 0: 3.384 | 0: 3.384 |
| apply | random | A | scaleDown | 24,999 | 357,337 | 2.798 | 2.798 | 2.798 | 0.000 | 0: 2.798 | 0: 2.798 |
| apply | random | A | fullLifecycle | 49,999 | 323,507 | 3.091 | 3.091 | 3.091 | 0.000 | 0: 3.091 | 0: 3.091 |
| create | — | A | scaleUp | 7 | 499 | 2003.829 | 2003.829 | 2003.829 | 0.000 | 0: 2003.829 | 0: 2003.829 |
| create | — | A | scaleDown | 6 | 692 | 1445.750 | 1445.750 | 1445.750 | 0.000 | 0: 1445.750 | 0: 1445.750 |
| create | — | A | fullLifecycle | 13 | 573 | 1746.254 | 1746.254 | 1746.254 | 0.000 | 0: 1746.254 | 0: 1746.254 |
| insert | head | A | scaleUp | 12,500 | 1,255,133 | 0.797 | 0.797 | 0.797 | 0.000 | 0: 0.797 | 0: 0.797 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,255,133 | 0.797 | 0.797 | 0.797 | 0.000 | 0: 0.797 | 0: 0.797 |
| insert | random | A | scaleUp | 25,000 | 547,204 | 1.827 | 1.827 | 1.827 | 0.000 | 0: 1.827 | 0: 1.827 |
| insert | random | A | scaleDown | 25,000 | 601,326 | 1.663 | 1.663 | 1.663 | 0.000 | 0: 1.663 | 0: 1.663 |
| insert | random | A | fullLifecycle | 50,000 | 572,990 | 1.745 | 1.745 | 1.745 | 0.000 | 0: 1.745 | 0: 1.745 |
| insert | tail | A | scaleUp | 12,500 | 1,239,256 | 0.807 | 0.807 | 0.807 | 0.000 | 0: 0.807 | 0: 0.807 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,239,256 | 0.807 | 0.807 | 0.807 | 0.000 | 0: 0.807 | 0: 0.807 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 724,671 | 1.380 | 1.380 | 1.380 | 0.000 | 0: 1.380 | 0: 1.380 |
| remove | head | A | fullLifecycle | 12,500 | 724,671 | 1.380 | 1.380 | 1.380 | 0.000 | 0: 1.380 | 0: 1.380 |
| remove | random | A | scaleUp | 25,000 | 457,315 | 2.187 | 2.187 | 2.187 | 0.000 | 0: 2.187 | 0: 2.187 |
| remove | random | A | scaleDown | 25,000 | 544,217 | 1.838 | 1.838 | 1.838 | 0.000 | 0: 1.838 | 0: 1.838 |
| remove | random | A | fullLifecycle | 50,000 | 496,996 | 2.012 | 2.012 | 2.012 | 0.000 | 0: 2.012 | 0: 2.012 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 693,066 | 1.443 | 1.443 | 1.443 | 0.000 | 0: 1.443 | 0: 1.443 |
| remove | tail | A | fullLifecycle | 12,500 | 693,066 | 1.443 | 1.443 | 1.443 | 0.000 | 0: 1.443 | 0: 1.443 |
| replace | head | A | scaleUp | 25,000 | 504,168 | 1.983 | 1.983 | 1.983 | 0.000 | 0: 1.983 | 0: 1.983 |
| replace | head | A | scaleDown | 25,000 | 524,186 | 1.908 | 1.908 | 1.908 | 0.000 | 0: 1.908 | 0: 1.908 |
| replace | head | A | fullLifecycle | 50,000 | 513,982 | 1.946 | 1.946 | 1.946 | 0.000 | 0: 1.946 | 0: 1.946 |
| replace | random | A | scaleUp | 25,000 | 340,980 | 2.933 | 2.933 | 2.933 | 0.000 | 0: 2.933 | 0: 2.933 |
| replace | random | A | scaleDown | 25,000 | 388,439 | 2.574 | 2.574 | 2.574 | 0.000 | 0: 2.574 | 0: 2.574 |
| replace | random | A | fullLifecycle | 50,000 | 363,166 | 2.754 | 2.754 | 2.754 | 0.000 | 0: 2.754 | 0: 2.754 |
| replace | tail | A | scaleUp | 25,000 | 469,195 | 2.131 | 2.131 | 2.131 | 0.000 | 0: 2.131 | 0: 2.131 |
| replace | tail | A | scaleDown | 25,000 | 203,510 | 4.914 | 4.914 | 4.914 | 0.000 | 0: 4.914 | 0: 4.914 |
| replace | tail | A | fullLifecycle | 50,000 | 283,887 | 3.523 | 3.523 | 3.523 | 0.000 | 0: 3.523 | 0: 3.523 |
| sequence | — | A | scaleUp | 6 | 67 | 14833.433 | 14833.433 | 14833.433 | 0.000 | 0: 14833.433 | 0: 14833.433 |
| sequence | — | A | scaleDown | 6 | 99 | 10114.983 | 10114.983 | 10114.983 | 0.000 | 0: 10114.983 | 0: 10114.983 |
| sequence | — | A | fullLifecycle | 12 | 80 | 12474.208 | 12474.208 | 12474.208 | 0.000 | 0: 12474.208 | 0: 12474.208 |
| value | head | A | scaleUp | 25,000 | 3,013,936 | 0.332 | 0.332 | 0.332 | 0.000 | 0: 0.332 | 0: 0.332 |
| value | head | A | scaleDown | 25,000 | 2,482,745 | 0.403 | 0.403 | 0.403 | 0.000 | 0: 0.403 | 0: 0.403 |
| value | head | A | fullLifecycle | 50,000 | 2,722,674 | 0.367 | 0.367 | 0.367 | 0.000 | 0: 0.367 | 0: 0.367 |
| value | random | A | scaleUp | 25,000 | 829,958 | 1.205 | 1.205 | 1.205 | 0.000 | 0: 1.205 | 0: 1.205 |
| value | random | A | scaleDown | 25,000 | 998,076 | 1.002 | 1.002 | 1.002 | 0.000 | 0: 1.002 | 0: 1.002 |
| value | random | A | fullLifecycle | 50,000 | 906,286 | 1.103 | 1.103 | 1.103 | 0.000 | 0: 1.103 | 0: 1.103 |
| value | tail | A | scaleUp | 25,000 | 6,403,032 | 0.156 | 0.156 | 0.156 | 0.000 | 0: 0.156 | 0: 0.156 |
| value | tail | A | scaleDown | 25,000 | 4,426,424 | 0.226 | 0.226 | 0.226 | 0.000 | 0: 0.226 | 0: 0.226 |
| value | tail | A | fullLifecycle | 50,000 | 5,234,341 | 0.191 | 0.191 | 0.191 | 0.000 | 0: 0.191 | 0: 0.191 |
| values | — | A | scaleUp | 6 | 66 | 15038.683 | 15038.683 | 15038.683 | 0.000 | 0: 15038.683 | 0: 15038.683 |
| values | — | A | scaleDown | 6 | 246 | 4066.117 | 4066.117 | 4066.117 | 0.000 | 0: 4066.117 | 0: 4066.117 |
| values | — | A | fullLifecycle | 12 | 105 | 9552.400 | 9552.400 | 9552.400 | 0.000 | 0: 9552.400 | 0: 9552.400 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5428540.000 | 428.569 | 8.477 |
| A | scaleDown | 5 | 4409840.000 | 432.337 | 8.548 |
| A | fullLifecycle | 11 | 4965494.545 | 430.082 | 8.506 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3126055.667 | 246.794 | 4.882 |
| A | scaleDown | 5 | 2596615.600 | 254.570 | 5.033 |
| A | fullLifecycle | 11 | 2885401.091 | 249.917 | 4.943 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 234,176 | 4.270 | 1.800 | 511.600 |
| apply | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 312,832 | 3.197 | 1.600 | 533.900 |
| apply | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 291,474 | 3.431 | 1.400 | 753.900 |
| apply | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 290,928 | 3.437 | 1.400 | 753.900 |
| apply | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 293,829 | 3.403 | 1.400 | 1165.800 |
| apply | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 295,529 | 3.384 | 1.400 | 1583.600 |
| apply | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 300,645 | 3.326 | 1.400 | 1583.600 |
| apply | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 305,895 | 3.269 | 1.400 | 1583.600 |
| apply | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 310,536 | 3.220 | 1.400 | 1583.600 |
| apply | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 315,380 | 3.171 | 1.400 | 1583.600 |
| apply | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 321,696 | 3.109 | 1.400 | 1583.600 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 323,507 | 3.091 | 1.200 | 1583.600 |
| insert | head | 0 | up | 1,000 | 51,204 | A | 500 | 924,556 | 1.082 | 0.400 | 65.500 |
| insert | head | 0 | up | 5,000 | 250,037 | A | 2,500 | 1,154,095 | 0.866 | 0.400 | 65.500 |
| insert | head | 0 | up | 10,000 | 506,154 | A | 5,000 | 1,199,156 | 0.834 | 0.300 | 65.500 |
| insert | head | 0 | up | 15,000 | 762,134 | A | 7,500 | 1,207,380 | 0.828 | 0.300 | 65.500 |
| insert | head | 0 | up | 20,000 | 1,012,964 | A | 10,000 | 1,231,739 | 0.812 | 0.300 | 65.500 |
| insert | head | 0 | up | 25,000 | 1,259,727 | A | 12,500 | 1,255,133 | 0.797 | 0.300 | 65.500 |
| insert | head | 0 | down | 20,000 | 1,009,630 | A | 12,500 | 1,255,133 | 0.797 | 0.300 | 65.500 |
| insert | head | 0 | down | 15,000 | 759,633 | A | 12,500 | 1,255,133 | 0.797 | 0.300 | 65.500 |
| insert | head | 0 | down | 10,000 | 507,941 | A | 12,500 | 1,255,133 | 0.797 | 0.300 | 65.500 |
| insert | head | 0 | down | 5,000 | 250,794 | A | 12,500 | 1,255,133 | 0.797 | 0.300 | 65.500 |
| insert | head | 0 | down | 1,000 | 51,447 | A | 12,500 | 1,255,133 | 0.797 | 0.300 | 65.500 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,255,133 | 0.797 | 0.300 | 65.500 |
| insert | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 547,975 | 1.825 | 0.500 | 309.100 |
| insert | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 578,878 | 1.727 | 0.500 | 790.600 |
| insert | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 542,114 | 1.845 | 0.500 | 790.600 |
| insert | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 535,661 | 1.867 | 0.500 | 790.600 |
| insert | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 539,973 | 1.852 | 0.500 | 790.600 |
| insert | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 547,204 | 1.827 | 0.400 | 790.600 |
| insert | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 548,022 | 1.825 | 0.400 | 790.600 |
| insert | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 536,802 | 1.863 | 0.400 | 1471.600 |
| insert | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 551,133 | 1.814 | 0.400 | 1471.600 |
| insert | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 558,073 | 1.792 | 0.400 | 1471.600 |
| insert | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 568,111 | 1.760 | 0.400 | 1471.600 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 572,990 | 1.745 | 0.400 | 1471.600 |
| insert | tail | 0 | up | 1,000 | 51,204 | A | 500 | 1,072,271 | 0.933 | 0.300 | 28.500 |
| insert | tail | 0 | up | 5,000 | 250,037 | A | 2,500 | 1,325,416 | 0.754 | 0.300 | 46.400 |
| insert | tail | 0 | up | 10,000 | 506,154 | A | 5,000 | 1,319,575 | 0.758 | 0.300 | 118.700 |
| insert | tail | 0 | up | 15,000 | 762,134 | A | 7,500 | 1,308,375 | 0.764 | 0.300 | 209.700 |
| insert | tail | 0 | up | 20,000 | 1,012,964 | A | 10,000 | 1,217,360 | 0.821 | 0.300 | 755.600 |
| insert | tail | 0 | up | 25,000 | 1,259,727 | A | 12,500 | 1,239,256 | 0.807 | 0.300 | 755.600 |
| insert | tail | 0 | down | 20,000 | 1,009,630 | A | 12,500 | 1,239,256 | 0.807 | 0.300 | 755.600 |
| insert | tail | 0 | down | 15,000 | 759,633 | A | 12,500 | 1,239,256 | 0.807 | 0.300 | 755.600 |
| insert | tail | 0 | down | 10,000 | 507,941 | A | 12,500 | 1,239,256 | 0.807 | 0.300 | 755.600 |
| insert | tail | 0 | down | 5,000 | 250,794 | A | 12,500 | 1,239,256 | 0.807 | 0.300 | 755.600 |
| insert | tail | 0 | down | 1,000 | 51,447 | A | 12,500 | 1,239,256 | 0.807 | 0.300 | 755.600 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,239,256 | 0.807 | 0.300 | 755.600 |
| remove | head | 0 | up | 1,000 | 51,204 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 250,037 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 506,154 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 762,134 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,012,964 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,259,727 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,009,630 | A | 2,500 | 722,335 | 1.384 | 0.800 | 41.100 |
| remove | head | 0 | down | 15,000 | 759,633 | A | 5,000 | 687,380 | 1.455 | 0.800 | 351.000 |
| remove | head | 0 | down | 10,000 | 507,941 | A | 7,500 | 683,440 | 1.463 | 0.800 | 618.100 |
| remove | head | 0 | down | 5,000 | 250,794 | A | 10,000 | 699,320 | 1.430 | 0.800 | 618.100 |
| remove | head | 0 | down | 1,000 | 51,447 | A | 12,000 | 720,292 | 1.388 | 0.800 | 618.100 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 724,671 | 1.380 | 0.700 | 618.100 |
| remove | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 460,596 | 2.171 | 0.800 | 410.500 |
| remove | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 534,456 | 1.871 | 0.800 | 410.500 |
| remove | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 459,876 | 2.175 | 0.800 | 410.500 |
| remove | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 447,277 | 2.236 | 0.800 | 492.800 |
| remove | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 452,835 | 2.208 | 0.800 | 492.800 |
| remove | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 457,315 | 2.187 | 0.800 | 539.400 |
| remove | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 463,886 | 2.156 | 0.800 | 539.400 |
| remove | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 468,673 | 2.134 | 0.800 | 539.400 |
| remove | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 476,787 | 2.097 | 0.800 | 539.400 |
| remove | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 483,649 | 2.068 | 0.800 | 539.400 |
| remove | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 493,254 | 2.027 | 0.800 | 539.400 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 496,996 | 2.012 | 0.700 | 539.400 |
| remove | tail | 0 | up | 1,000 | 51,204 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 250,037 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 506,154 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 762,134 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,012,964 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,259,727 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,009,630 | A | 2,500 | 781,152 | 1.280 | 0.800 | 60.700 |
| remove | tail | 0 | down | 15,000 | 759,633 | A | 5,000 | 519,529 | 1.925 | 0.800 | 3413.000 |
| remove | tail | 0 | down | 10,000 | 507,941 | A | 7,500 | 603,559 | 1.657 | 0.800 | 3413.000 |
| remove | tail | 0 | down | 5,000 | 250,794 | A | 10,000 | 653,629 | 1.530 | 0.700 | 3413.000 |
| remove | tail | 0 | down | 1,000 | 51,447 | A | 12,000 | 684,342 | 1.461 | 0.700 | 3413.000 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 693,066 | 1.443 | 0.700 | 3413.000 |
| replace | head | 0 | up | 1,000 | 51,204 | A | 1,000 | 420,592 | 2.378 | 1.200 | 116.500 |
| replace | head | 0 | up | 5,000 | 250,037 | A | 5,000 | 493,286 | 2.027 | 1.200 | 235.300 |
| replace | head | 0 | up | 10,000 | 506,154 | A | 10,000 | 491,333 | 2.035 | 1.100 | 280.900 |
| replace | head | 0 | up | 15,000 | 762,134 | A | 15,000 | 491,082 | 2.036 | 1.100 | 387.000 |
| replace | head | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 500,383 | 1.998 | 1.100 | 387.000 |
| replace | head | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 504,168 | 1.983 | 1.100 | 724.700 |
| replace | head | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 504,739 | 1.981 | 1.100 | 724.700 |
| replace | head | 0 | down | 15,000 | 759,633 | A | 35,000 | 504,497 | 1.982 | 1.100 | 724.700 |
| replace | head | 0 | down | 10,000 | 507,941 | A | 40,000 | 507,815 | 1.969 | 1.100 | 724.700 |
| replace | head | 0 | down | 5,000 | 250,794 | A | 45,000 | 508,602 | 1.966 | 1.000 | 724.700 |
| replace | head | 0 | down | 1,000 | 51,447 | A | 49,000 | 512,268 | 1.952 | 1.000 | 724.700 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 513,982 | 1.946 | 1.000 | 724.700 |
| replace | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 389,955 | 2.564 | 1.200 | 56.300 |
| replace | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 395,307 | 2.530 | 1.200 | 368.400 |
| replace | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 353,557 | 2.828 | 1.200 | 368.400 |
| replace | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 334,322 | 2.991 | 1.200 | 1005.300 |
| replace | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 338,248 | 2.956 | 1.200 | 1005.300 |
| replace | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 340,980 | 2.933 | 1.200 | 1005.300 |
| replace | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 345,617 | 2.893 | 1.200 | 1005.300 |
| replace | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 346,573 | 2.885 | 1.200 | 1005.300 |
| replace | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 350,202 | 2.855 | 1.200 | 1042.000 |
| replace | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 352,934 | 2.833 | 1.200 | 1042.000 |
| replace | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 360,359 | 2.775 | 1.100 | 1042.000 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 363,166 | 2.754 | 0.900 | 1042.000 |
| replace | tail | 0 | up | 1,000 | 51,204 | A | 1,000 | 464,166 | 2.154 | 1.100 | 114.000 |
| replace | tail | 0 | up | 5,000 | 250,037 | A | 5,000 | 532,833 | 1.877 | 1.100 | 229.400 |
| replace | tail | 0 | up | 10,000 | 506,154 | A | 10,000 | 502,013 | 1.992 | 1.100 | 960.300 |
| replace | tail | 0 | up | 15,000 | 762,134 | A | 15,000 | 508,909 | 1.965 | 1.100 | 960.300 |
| replace | tail | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 450,844 | 2.218 | 1.100 | 5143.400 |
| replace | tail | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 469,195 | 2.131 | 1.100 | 5143.400 |
| replace | tail | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 420,840 | 2.376 | 1.100 | 5143.400 |
| replace | tail | 0 | down | 15,000 | 759,633 | A | 35,000 | 282,919 | 3.535 | 1.100 | 5143.400 |
| replace | tail | 0 | down | 10,000 | 507,941 | A | 40,000 | 293,191 | 3.411 | 1.000 | 5143.400 |
| replace | tail | 0 | down | 5,000 | 250,794 | A | 45,000 | 276,337 | 3.619 | 1.000 | 5143.400 |
| replace | tail | 0 | down | 1,000 | 51,447 | A | 49,000 | 281,018 | 3.558 | 0.900 | 5143.400 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 283,887 | 3.523 | 0.900 | 5143.400 |
| value | head | 0 | up | 1,000 | 51,204 | A | 1,000 | 1,496,110 | 0.668 | 0.100 | 261.400 |
| value | head | 0 | up | 5,000 | 250,037 | A | 5,000 | 2,697,454 | 0.371 | 0.100 | 261.400 |
| value | head | 0 | up | 10,000 | 506,154 | A | 10,000 | 2,828,134 | 0.354 | 0.100 | 261.400 |
| value | head | 0 | up | 15,000 | 762,134 | A | 15,000 | 2,857,034 | 0.350 | 0.100 | 261.400 |
| value | head | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 2,946,810 | 0.339 | 0.100 | 261.400 |
| value | head | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 3,013,936 | 0.332 | 0.100 | 261.400 |
| value | head | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 2,898,075 | 0.345 | 0.100 | 261.400 |
| value | head | 0 | down | 15,000 | 759,633 | A | 35,000 | 2,807,772 | 0.356 | 0.100 | 261.400 |
| value | head | 0 | down | 10,000 | 507,941 | A | 40,000 | 2,777,778 | 0.360 | 0.100 | 261.400 |
| value | head | 0 | down | 5,000 | 250,794 | A | 45,000 | 2,739,709 | 0.365 | 0.100 | 261.400 |
| value | head | 0 | down | 1,000 | 51,447 | A | 49,000 | 2,720,862 | 0.368 | 0.100 | 261.400 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,722,674 | 0.367 | 0.100 | 261.400 |
| value | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 1,330,141 | 0.752 | 0.100 | 44.000 |
| value | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 1,084,716 | 0.922 | 0.100 | 98.500 |
| value | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 842,417 | 1.187 | 0.100 | 98.500 |
| value | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 800,935 | 1.249 | 0.100 | 98.500 |
| value | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 821,008 | 1.218 | 0.100 | 98.500 |
| value | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 829,958 | 1.205 | 0.100 | 98.500 |
| value | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 839,835 | 1.191 | 0.100 | 98.500 |
| value | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 848,483 | 1.179 | 0.100 | 98.500 |
| value | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 867,133 | 1.153 | 0.100 | 98.500 |
| value | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 878,508 | 1.138 | 0.100 | 98.500 |
| value | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 898,048 | 1.114 | 0.100 | 103.000 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 906,286 | 1.103 | 0.100 | 103.000 |
| value | tail | 0 | up | 1,000 | 51,204 | A | 1,000 | 5,611,672 | 0.178 | 0.100 | 3.700 |
| value | tail | 0 | up | 5,000 | 250,037 | A | 5,000 | 5,960,186 | 0.168 | 0.100 | 3.700 |
| value | tail | 0 | up | 10,000 | 506,154 | A | 10,000 | 6,125,574 | 0.163 | 0.100 | 3.700 |
| value | tail | 0 | up | 15,000 | 762,134 | A | 15,000 | 6,094,093 | 0.164 | 0.000 | 9.700 |
| value | tail | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 6,234,803 | 0.160 | 0.000 | 9.700 |
| value | tail | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 6,403,032 | 0.156 | 0.000 | 13.100 |
| value | tail | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 5,977,644 | 0.167 | 0.000 | 13.100 |
| value | tail | 0 | down | 15,000 | 759,633 | A | 35,000 | 5,699,305 | 0.175 | 0.000 | 13.100 |
| value | tail | 0 | down | 10,000 | 507,941 | A | 40,000 | 5,517,470 | 0.181 | 0.000 | 13.100 |
| value | tail | 0 | down | 5,000 | 250,794 | A | 45,000 | 5,313,308 | 0.188 | 0.000 | 59.200 |
| value | tail | 0 | down | 1,000 | 51,447 | A | 49,000 | 5,233,924 | 0.191 | 0.000 | 59.200 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,234,341 | 0.191 | 0.000 | 59.200 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,557 | 391.100 |
| create | — | 0 | up | 5,000 | A | 1 | 908 | 1101.200 |
| create | — | 0 | up | 10,000 | A | 1 | 455 | 2199.400 |
| create | — | 0 | up | 15,000 | A | 1 | 369 | 2707.000 |
| create | — | 0 | up | 20,000 | A | 1 | 302 | 3307.400 |
| create | — | 0 | up | 25,000 | A | 1 | 259 | 3859.400 |
| create | — | 0 | down | 20,000 | A | 1 | 302 | 3313.100 |
| create | — | 0 | down | 15,000 | A | 1 | 390 | 2565.300 |
| create | — | 0 | down | 10,000 | A | 1 | 565 | 1770.600 |
| create | — | 0 | down | 5,000 | A | 1 | 1,164 | 859.200 |
| create | — | 0 | down | 1,000 | A | 1 | 6,645 | 150.500 |
| create | — | 0 | down | 0 | A | 1 | 63,291 | 15.800 |
| sequence | — | 0 | up | 1,000 | A | 1 | 374 | 2670.600 |
| sequence | — | 0 | up | 5,000 | A | 1 | 128 | 7834.100 |
| sequence | — | 0 | up | 10,000 | A | 1 | 54 | 18552.000 |
| sequence | — | 0 | up | 15,000 | A | 1 | 56 | 17754.400 |
| sequence | — | 0 | up | 20,000 | A | 1 | 49 | 20488.700 |
| sequence | — | 0 | up | 25,000 | A | 1 | 46 | 21700.800 |
| sequence | — | 0 | down | 20,000 | A | 1 | 54 | 18656.400 |
| sequence | — | 0 | down | 15,000 | A | 1 | 66 | 15135.100 |
| sequence | — | 0 | down | 10,000 | A | 1 | 87 | 11447.800 |
| sequence | — | 0 | down | 5,000 | A | 1 | 116 | 8627.600 |
| sequence | — | 0 | down | 1,000 | A | 1 | 182 | 5481.000 |
| sequence | — | 0 | down | 0 | A | 1 | 745 | 1342.000 |
| values | — | 0 | up | 1,000 | A | 1 | 466 | 2144.000 |
| values | — | 0 | up | 5,000 | A | 1 | 205 | 4870.700 |
| values | — | 0 | up | 10,000 | A | 1 | 34 | 29476.100 |
| values | — | 0 | up | 15,000 | A | 1 | 30 | 33001.900 |
| values | — | 0 | up | 20,000 | A | 1 | 107 | 9361.400 |
| values | — | 0 | up | 25,000 | A | 1 | 88 | 11378.000 |
| values | — | 0 | down | 20,000 | A | 1 | 112 | 8895.200 |
| values | — | 0 | down | 15,000 | A | 1 | 145 | 6884.800 |
| values | — | 0 | down | 10,000 | A | 1 | 170 | 5868.300 |
| values | — | 0 | down | 5,000 | A | 1 | 438 | 2281.400 |
| values | — | 0 | down | 1,000 | A | 1 | 2,191 | 456.400 |
| values | — | 0 | down | 0 | A | 1 | 94,340 | 10.600 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.622 | 0.232 | 0.391 |
| 0 | up | 5000 | 3.076 | 1.168 | 1.908 |
| 0 | up | 10000 | 6.205 | 2.343 | 3.862 |
| 0 | up | 15000 | 9.457 | 3.643 | 5.815 |
| 0 | up | 20000 | 12.841 | 5.112 | 7.728 |
| 0 | up | 25000 | 16.247 | 6.636 | 9.611 |
| 0 | down | 20000 | 13.315 | 5.612 | 7.703 |
| 0 | down | 15000 | 9.926 | 4.131 | 5.796 |
| 0 | down | 10000 | 7.170 | 3.295 | 3.875 |
| 0 | down | 5000 | 4.075 | 2.161 | 1.913 |
| 0 | down | 1000 | 1.812 | 1.420 | 0.393 |
| 0 | down | 0 | 1.230 | 1.230 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 51,204 | 0.411 | 430.756 | 8.413 | 122.344 | 15.553 |
| 0 | up | A | 5,000 | 5,000 | 250,037 | 2.010 | 421.606 | 8.431 | 154.645 | 19.568 |
| 0 | up | A | 10,000 | 10,000 | 506,154 | 4.075 | 427.300 | 8.442 | 196.656 | 24.485 |
| 0 | up | A | 15,000 | 15,000 | 762,134 | 6.154 | 430.176 | 8.467 | 209.574 | 29.400 |
| 0 | up | A | 20,000 | 20,000 | 1,012,964 | 8.198 | 429.835 | 8.487 | 281.297 | 34.222 |
| 0 | up | A | 25,000 | 25,000 | 1,259,727 | 10.214 | 428.405 | 8.502 | 295.594 | 38.952 |
| 0 | down | A | 20,000 | 20,000 | 1,009,630 | 8.241 | 432.089 | 8.559 | 297.266 | 34.197 |
| 0 | down | A | 15,000 | 15,000 | 759,633 | 6.201 | 433.508 | 8.560 | 301.000 | 29.433 |
| 0 | down | A | 10,000 | 10,000 | 507,941 | 4.136 | 433.718 | 8.539 | 301.488 | 24.661 |
| 0 | down | A | 5,000 | 5,000 | 250,794 | 2.034 | 426.570 | 8.504 | 297.742 | 19.805 |
| 0 | down | A | 1,000 | 1,000 | 51,447 | 0.415 | 434.772 | 8.451 | 296.055 | 16.007 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 297.180 | 14.916 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 51204 | 187497 | 187.497 | 3.662 | 277.53 | 14.54 | 165.41 | 12.36 |
| 0 | up | A | 5000 | 250037 | 1195941 | 239.188 | 4.783 | 1610.38 | 73.38 | 813.25 | 61.61 |
| 0 | up | A | 10000 | 506154 | 2435808 | 243.581 | 4.812 | 3265.74 | 148.71 | 1649.99 | 124.72 |
| 0 | up | A | 15000 | 762134 | 3716482 | 247.765 | 4.876 | 4950.79 | 226.25 | 3565.22 | 200.28 |
| 0 | up | A | 20000 | 1012964 | 4982573 | 249.129 | 4.919 | 7121.78 | 311.32 | 5144.59 | 263.55 |
| 0 | up | A | 25000 | 1259727 | 6238033 | 249.521 | 4.952 | 9237.87 | 392.58 | 6535.88 | 334.89 |
| 0 | down | A | 20000 | 1009630 | 5113545 | 255.677 | 5.065 | 7558.03 | 326.74 | 5304.48 | 278.22 |
| 0 | down | A | 15000 | 759633 | 3843527 | 256.235 | 5.060 | 5727.79 | 247.31 | 4004.31 | 209.86 |
| 0 | down | A | 10000 | 507941 | 2547329 | 254.733 | 5.015 | 3837.94 | 164.83 | 2677.99 | 139.88 |
| 0 | down | A | 5000 | 250794 | 1235293 | 247.059 | 4.926 | 1887.01 | 79.61 | 1318.78 | 67.84 |
| 0 | down | A | 1000 | 51447 | 243384 | 243.384 | 4.731 | 382.91 | 15.90 | 268.58 | 13.64 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 428.569 | 8.477 | 246.794 | 4.882 |
| 0 | A | scaleDown | 432.337 | 8.548 | 254.570 | 5.033 |
| 0 | A | fullLifecycle | 430.082 | 8.506 | 249.917 | 4.943 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
