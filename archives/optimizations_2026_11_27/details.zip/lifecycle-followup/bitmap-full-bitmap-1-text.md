# Large string benchmarks

2026-11-27T20:46:19.913Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2658.67 | 0.00 |
| 1024 | insert.append | array | 12495.62 | 0.00 |
| 1024 | replace | array | 3118.60 | 0.00 |
| 1024 | remove | array | 1038.70 | 0.00 |
| 1024 | remove.middle | array | 1982.24 | 0.00 |
| 1024 | replace.middle | array | 2540.55 | 0.00 |
| 1024 | apply | array | 829.46 | 0.00 |
| 1024 | apply.array | array | 691.77 | 0.00 |
| 1024 | concurrent.apply | array | 68341.80 | 0.00 |
| 1024 | merge | array | 2980.19 | 0.00 |
| 1024 | create | array | 3065.64 | 0.00 |
| 1024 | value.random | array | 49.46 | 0.00 |
| 1024 | values.range | array | 110.18 | 0.00 |
| 1024 | values.array | array | 1296.90 | 0.00 |
| 1024 | values.text | array | 13837.52 | 0.00 |
| 1024 | sequence.array | array | 1741.92 | 0.00 |
| 1024 | sequence.text | array | 9573.28 | 0.00 |
| 1024 | sequence.edited.text | array | 9445.41 | 0.00 |
| 1024 | sequence.masked.text | array | 11025.97 | 0.00 |
| 1024 | insert | string | 398.34 | 0.00 |
| 1024 | insert.append | string | 4075.42 | 0.00 |
| 1024 | replace | string | 1289.83 | 0.00 |
| 1024 | remove | string | 899.71 | 0.00 |
| 1024 | remove.middle | string | 970.59 | 0.00 |
| 1024 | replace.middle | string | 1408.89 | 0.00 |
| 1024 | apply | string | 729.32 | 0.00 |
| 1024 | apply.array | string | 2412.11 | 0.00 |
| 1024 | concurrent.apply | string | 3883.75 | 0.00 |
| 1024 | merge | string | 1347.63 | 0.00 |
| 1024 | create | string | 1449.68 | 0.00 |
| 1024 | value.random | string | 65.91 | 0.00 |
| 1024 | values.range | string | 153.12 | 0.00 |
| 1024 | values.array | string | 1930.08 | 0.00 |
| 1024 | values.text | string | 79.83 | 0.00 |
| 1024 | sequence.array | string | 2129.24 | 0.00 |
| 1024 | sequence.text | string | 222.29 | 0.00 |
| 1024 | sequence.edited.text | string | 802.94 | 0.00 |
| 1024 | sequence.masked.text | string | 3635.14 | 0.00 |
| 65536 | insert | array | 267265.96 | 0.00 |
| 65536 | insert.append | array | 1086368.00 | 0.00 |
| 65536 | replace | array | 245610.78 | 0.00 |
| 65536 | remove | array | 2430.08 | 0.00 |
| 65536 | remove.middle | array | 244608.26 | 0.00 |
| 65536 | replace.middle | array | 237528.44 | 0.00 |
| 65536 | apply | array | 741.05 | 0.00 |
| 65536 | apply.array | array | 532.48 | 0.00 |
| 65536 | concurrent.apply | array | 4080314.29 | 0.00 |
| 65536 | merge | array | 215730.17 | 0.00 |
| 65536 | create | array | 218153.04 | 0.00 |
| 65536 | value.random | array | 46.85 | 0.00 |
| 65536 | values.range | array | 126.52 | 0.00 |
| 65536 | values.array | array | 204676.98 | 0.00 |
| 65536 | values.text | array | 785884.38 | 0.00 |
| 65536 | sequence.array | array | 201161.11 | 0.00 |
| 65536 | sequence.text | array | 866606.67 | 0.00 |
| 65536 | sequence.edited.text | array | 728405.71 | 0.00 |
| 65536 | sequence.masked.text | array | 758848.48 | 0.00 |
| 65536 | insert | string | 466.99 | 0.00 |
| 65536 | insert.append | string | 22344.33 | 0.00 |
| 65536 | replace | string | 1286.80 | 0.00 |
| 65536 | remove | string | 967.35 | 0.00 |
| 65536 | remove.middle | string | 960.49 | 0.00 |
| 65536 | replace.middle | string | 1320.73 | 0.00 |
| 65536 | apply | string | 724.66 | 0.00 |
| 65536 | apply.array | string | 198007.87 | 0.00 |
| 65536 | concurrent.apply | string | 135507.03 | 0.00 |
| 65536 | merge | string | 1122.50 | 0.00 |
| 65536 | create | string | 951.99 | 0.00 |
| 65536 | value.random | string | 52.09 | 0.00 |
| 65536 | values.range | string | 144.47 | 0.00 |
| 65536 | values.array | string | 264969.53 | 0.00 |
| 65536 | values.text | string | 61.46 | 0.00 |
| 65536 | sequence.array | string | 251807.81 | 0.00 |
| 65536 | sequence.text | string | 179.06 | 0.00 |
| 65536 | sequence.edited.text | string | 6027.68 | 0.00 |
| 65536 | sequence.masked.text | string | 3073.56 | 0.00 |
| 1048576 | insert | array | 3198400.00 | 0.00 |
| 1048576 | insert.append | array | 24974600.00 | 0.00 |
| 1048576 | replace | array | 3000377.78 | 0.00 |
| 1048576 | remove | array | 9860.54 | 0.00 |
| 1048576 | remove.middle | array | 3253288.89 | 0.00 |
| 1048576 | replace.middle | array | 2831188.89 | 0.00 |
| 1048576 | apply | array | 1101.50 | 0.00 |
| 1048576 | apply.array | array | 507.96 | 0.00 |
| 1048576 | concurrent.apply | array | 67134000.00 | 0.00 |
| 1048576 | merge | array | 3025977.78 | 0.00 |
| 1048576 | create | array | 2929455.56 | 0.00 |
| 1048576 | value.random | array | 39.39 | 0.00 |
| 1048576 | values.range | array | 97.50 | 0.00 |
| 1048576 | values.array | array | 2938922.22 | 0.00 |
| 1048576 | values.text | array | 13039150.00 | 0.00 |
| 1048576 | sequence.array | array | 2281109.09 | 0.00 |
| 1048576 | sequence.text | array | 60078800.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 57547450.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 57182250.00 | 0.00 |
| 1048576 | insert | string | 403.32 | 0.00 |
| 1048576 | insert.append | string | 535151.06 | 0.00 |
| 1048576 | replace | string | 1300.88 | 0.00 |
| 1048576 | remove | string | 917.50 | 0.00 |
| 1048576 | remove.middle | string | 1061.35 | 0.00 |
| 1048576 | replace.middle | string | 1299.48 | 0.00 |
| 1048576 | apply | string | 1200.76 | 0.00 |
| 1048576 | apply.array | string | 3485525.00 | 0.00 |
| 1048576 | concurrent.apply | string | 1333589.47 | 0.00 |
| 1048576 | merge | string | 1149.90 | 0.00 |
| 1048576 | create | string | 950.85 | 0.00 |
| 1048576 | value.random | string | 39.84 | 0.00 |
| 1048576 | values.range | string | 132.53 | 0.00 |
| 1048576 | values.array | string | 3419600.00 | 0.00 |
| 1048576 | values.text | string | 76.10 | 0.00 |
| 1048576 | sequence.array | string | 3366212.50 | 0.00 |
| 1048576 | sequence.text | string | 210.11 | 0.00 |
| 1048576 | sequence.edited.text | string | 89363.21 | 0.00 |
| 1048576 | sequence.masked.text | string | 3194.10 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
