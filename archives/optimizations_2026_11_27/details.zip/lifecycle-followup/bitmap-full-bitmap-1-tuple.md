# Tuple benchmarks

2026-11-27T20:46:04.534Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 3,007,034 | 2,619,010 | 0.87× |
| 2 | create.sequence | 1,072,630 | 610,743 | 0.57× |
| 2 | replace.random | 1,211,189 | 1,621,270 | 1.34× |
| 2 | apply.replace | 735,298 | 885,263 | 1.20× |
| 2 | apply.duplicate | 1,590,414 | 1,684,620 | 1.06× |
| 2 | merge.duplicate | 1,544,924 | 1,558,739 | 1.01× |
| 2 | length | 119,576,061 | 122,169,241 | 1.02× |
| 2 | value.random | 22,410,791 | 24,324,485 | 1.09× |
| 2 | values | 8,601,376 | 3,655,107 | 0.42× |
| 2 | sequence | 599,740 | 633,723 | 1.06× |
| 4 | create.empty | 1,284,818 | 1,675,346 | 1.30× |
| 4 | create.sequence | 483,340 | 525,906 | 1.09× |
| 4 | replace.random | 862,876 | 1,330,002 | 1.54× |
| 4 | apply.replace | 620,076 | 958,444 | 1.55× |
| 4 | apply.duplicate | 1,764,418 | 1,700,015 | 0.96× |
| 4 | merge.duplicate | 1,352,679 | 1,310,193 | 0.97× |
| 4 | length | 119,756,567 | 122,865,867 | 1.03× |
| 4 | value.random | 24,645,840 | 56,609,016 | 2.30× |
| 4 | values | 7,041,360 | 8,905,822 | 1.26× |
| 4 | sequence | 2,600,857 | 2,322,386 | 0.89× |
| 8 | create.empty | 2,605,416 | 2,508,153 | 0.96× |
| 8 | create.sequence | 476,289 | 556,727 | 1.17× |
| 8 | replace.random | 1,022,005 | 1,461,683 | 1.43× |
| 8 | apply.replace | 614,934 | 1,011,270 | 1.64× |
| 8 | apply.duplicate | 1,735,740 | 1,769,643 | 1.02× |
| 8 | merge.duplicate | 939,918 | 898,235 | 0.96× |
| 8 | length | 35,454,707 | 30,740,654 | 0.87× |
| 8 | value.random | 19,362,068 | 57,614,411 | 2.98× |
| 8 | values | 4,681,438 | 4,879,986 | 1.04× |
| 8 | sequence | 1,740,878 | 1,875,559 | 1.08× |
| 100 | create.empty | 2,470,417 | 2,256,874 | 0.91× |
| 100 | create.sequence | 71,070 | 88,264 | 1.24× |
| 100 | replace.random | 1,058,167 | 1,644,772 | 1.55× |
| 100 | apply.replace | 674,680 | 606,659 | 0.90× |
| 100 | apply.duplicate | 1,545,571 | 1,585,152 | 1.03× |
| 100 | merge.duplicate | 103,324 | 72,162 | 0.70× |
| 100 | length | 30,104,216 | 36,256,382 | 1.20× |
| 100 | value.random | 12,106,903 | 57,567,828 | 4.75× |
| 100 | values | 520,441 | 690,510 | 1.33× |
| 100 | sequence | 186,684 | 184,024 | 0.99× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
