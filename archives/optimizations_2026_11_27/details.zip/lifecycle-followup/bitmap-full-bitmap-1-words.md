# Words benchmarks

2026-11-27T20:46:43.037Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 29,737 | 204,684 | 286 |
| append | packed | 5.90 | 3.61 | 13.98 | 32,319 | 217,301 | 266 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,647 | 838 | 249 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 31,340 | 1,586 | 253 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 442 | 245 | 88 |
| random | packed | 49.58 | 35.38 | 23.45 | 14,323 | 517 | 124 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 618 | 224 | 95 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 15,244 | 422 | 139 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 542.05 | 0.00 |
| append | numeric | encode | 33628.20 | 0.00 |
| append | numeric | decode | 2767.03 | 0.00 |
| append | numeric | create | 1808.46 | 0.00 |
| append | numeric | load | 4885.59 | 0.00 |
| append | numeric | apply | 3196693.75 | 0.00 |
| append | numeric | receive | 3500420.00 | 0.00 |
| append | binary | sequence | 513.04 | 0.00 |
| append | binary | encode | 30941.15 | 0.00 |
| append | binary | decode | 2357.66 | 0.00 |
| append | binary | create | 1944.55 | 0.00 |
| append | binary | load | 4601.91 | 0.00 |
| append | binary | apply | 1598931.25 | 0.00 |
| append | binary | receive | 3757042.86 | 0.00 |
| prepend | numeric | sequence | 549631.87 | 0.00 |
| prepend | numeric | encode | 607315.66 | 0.00 |
| prepend | numeric | decode | 170738.91 | 0.00 |
| prepend | numeric | create | 609860.98 | 0.00 |
| prepend | numeric | load | 1193176.19 | 0.00 |
| prepend | numeric | apply | 2241565.22 | 0.00 |
| prepend | numeric | receive | 4009876.92 | 0.00 |
| prepend | binary | sequence | 350523.08 | 0.00 |
| prepend | binary | encode | 31908.36 | 0.00 |
| prepend | binary | decode | 2263.70 | 0.00 |
| prepend | binary | create | 625668.75 | 0.00 |
| prepend | binary | load | 630460.00 | 0.00 |
| prepend | binary | apply | 2812233.33 | 0.00 |
| prepend | binary | receive | 3955946.15 | 0.00 |
| random | numeric | sequence | 949483.02 | 0.00 |
| random | numeric | encode | 2259969.57 | 0.00 |
| random | numeric | decode | 1049058.33 | 0.00 |
| random | numeric | create | 1802703.57 | 0.00 |
| random | numeric | load | 4075084.62 | 0.00 |
| random | numeric | apply | 8072157.14 | 0.00 |
| random | numeric | receive | 11306020.00 | 0.00 |
| random | binary | sequence | 860579.66 | 0.00 |
| random | binary | encode | 69815.90 | 0.00 |
| random | binary | decode | 1606.38 | 0.00 |
| random | binary | create | 1837532.14 | 0.00 |
| random | binary | load | 1933203.85 | 0.00 |
| random | binary | apply | 6552812.50 | 0.00 |
| random | binary | receive | 8044985.71 | 0.00 |
| concurrent | numeric | sequence | 791864.06 | 0.00 |
| concurrent | numeric | encode | 1618506.45 | 0.00 |
| concurrent | numeric | decode | 747613.43 | 0.00 |
| concurrent | numeric | create | 2258469.57 | 0.00 |
| concurrent | numeric | load | 4462875.00 | 0.00 |
| concurrent | numeric | apply | 5835588.89 | 0.00 |
| concurrent | numeric | receive | 10497260.00 | 0.00 |
| concurrent | binary | sequence | 730755.07 | 0.00 |
| concurrent | binary | encode | 65600.13 | 0.00 |
| concurrent | binary | decode | 2772.18 | 0.00 |
| concurrent | binary | create | 2296713.64 | 0.00 |
| concurrent | binary | load | 2369545.45 | 0.00 |
| concurrent | binary | apply | 5368250.00 | 0.00 |
| concurrent | binary | receive | 7199742.86 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
