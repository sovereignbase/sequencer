# Batch benchmarks

2026-11-27T20:51:52.959Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 1,746,623 | 1,087,686 | 594,542 | 76.05 | 5.99 | 0.012 |
| append | batch | 1,870,441 | 225,563,910 | 215,053,763 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,074,845 | 1,571,133 | 855,127 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 1,758,757 | 2,287,632 | 2,206,856 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 1,025,974 | 1,235,483 | 854,603 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 1,100,050 | 1,549,187 | 1,517,220 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 1,090,354 | 1,092,120 | 763,456 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 1,153,114 | 1,827,819 | 1,613,988 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,338,240 | 1,228,501 | 855,286 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,423,336 | 1,783,352 | 1,629,372 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,328,403 | 1,271,914 | 921,709 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,275,537 | 1,566,355 | 1,549,627 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 717,026 | 984,672 | 654,604 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 941,730 | 1,102,273 | 1,209,019 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,052,475 | 1,422,998 | 867,804 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 1,215,079 | 1,816,310 | 1,521,491 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,096,471 | 1,300,743 | 824,272 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 1,278,323 | 1,621,644 | 1,374,492 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 652,486 | 970,505 | 709,476 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 861,970 | 1,168,167 | 1,134,151 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 3.435 | 0.000 |
| append | individual | apply | 5.516 | 0.000 |
| append | individual | receive | 10.092 | 0.000 |
| append | individual | encode | 6.658 | 0.000 |
| append | individual | decode | 8.229 | 0.000 |
| append | batch | author | 3.208 | 0.000 |
| append | batch | apply | 0.027 | 0.000 |
| append | batch | receive | 0.028 | 0.000 |
| append | batch | encode | 0.197 | 0.000 |
| append | batch | decode | 0.102 | 0.000 |
| prepend | individual | author | 5.582 | 0.000 |
| prepend | individual | apply | 3.819 | 0.000 |
| prepend | individual | receive | 7.017 | 0.000 |
| prepend | individual | encode | 8.967 | 0.000 |
| prepend | individual | decode | 8.980 | 0.000 |
| prepend | batch | author | 3.411 | 0.000 |
| prepend | batch | apply | 2.623 | 0.000 |
| prepend | batch | receive | 2.719 | 0.000 |
| prepend | batch | encode | 0.191 | 0.000 |
| prepend | batch | decode | 0.115 | 0.000 |
| random.characters | individual | author | 5.848 | 0.000 |
| random.characters | individual | apply | 4.856 | 0.000 |
| random.characters | individual | receive | 7.021 | 0.000 |
| random.characters | individual | encode | 7.560 | 0.000 |
| random.characters | individual | decode | 6.916 | 0.000 |
| random.characters | batch | author | 5.454 | 0.000 |
| random.characters | batch | apply | 3.873 | 0.000 |
| random.characters | batch | receive | 3.955 | 0.000 |
| random.characters | batch | encode | 0.202 | 0.000 |
| random.characters | batch | decode | 0.118 | 0.000 |
| random.words | individual | author | 5.503 | 0.000 |
| random.words | individual | apply | 5.494 | 0.000 |
| random.words | individual | receive | 7.859 | 0.000 |
| random.words | individual | encode | 4.390 | 0.000 |
| random.words | individual | decode | 7.397 | 0.000 |
| random.words | batch | author | 5.203 | 0.000 |
| random.words | batch | apply | 3.283 | 0.000 |
| random.words | batch | receive | 3.717 | 0.000 |
| random.words | batch | encode | 0.419 | 0.000 |
| random.words | batch | decode | 0.106 | 0.000 |
| concurrent.characters | individual | author | 8.967 | 0.000 |
| concurrent.characters | individual | apply | 9.768 | 0.000 |
| concurrent.characters | individual | receive | 14.030 | 0.000 |
| concurrent.characters | individual | encode | 7.846 | 0.000 |
| concurrent.characters | individual | decode | 10.760 | 0.000 |
| concurrent.characters | batch | author | 8.431 | 0.000 |
| concurrent.characters | batch | apply | 6.729 | 0.000 |
| concurrent.characters | batch | receive | 7.365 | 0.000 |
| concurrent.characters | batch | encode | 0.434 | 0.000 |
| concurrent.characters | batch | decode | 0.162 | 0.000 |
| concurrent.words | individual | author | 9.033 | 0.000 |
| concurrent.words | individual | apply | 9.435 | 0.000 |
| concurrent.words | individual | receive | 13.019 | 0.000 |
| concurrent.words | individual | encode | 7.771 | 0.000 |
| concurrent.words | individual | decode | 12.538 | 0.000 |
| concurrent.words | batch | author | 9.408 | 0.000 |
| concurrent.words | batch | apply | 7.661 | 0.000 |
| concurrent.words | batch | receive | 7.744 | 0.000 |
| concurrent.words | batch | encode | 0.832 | 0.000 |
| concurrent.words | batch | decode | 0.119 | 0.000 |
| concurrent.mixed | individual | author | 16.736 | 0.000 |
| concurrent.mixed | individual | apply | 12.187 | 0.000 |
| concurrent.mixed | individual | receive | 18.332 | 0.000 |
| concurrent.mixed | individual | encode | 8.318 | 0.000 |
| concurrent.mixed | individual | decode | 9.906 | 0.000 |
| concurrent.mixed | batch | author | 12.742 | 0.000 |
| concurrent.mixed | batch | apply | 10.887 | 0.000 |
| concurrent.mixed | batch | receive | 9.925 | 0.000 |
| concurrent.mixed | batch | encode | 0.520 | 0.000 |
| concurrent.mixed | batch | decode | 0.118 | 0.000 |
| causal.characters | individual | author | 11.402 | 0.000 |
| causal.characters | individual | apply | 8.433 | 0.000 |
| causal.characters | individual | receive | 13.828 | 0.000 |
| causal.characters | individual | encode | 8.148 | 0.000 |
| causal.characters | individual | decode | 12.567 | 0.000 |
| causal.characters | batch | author | 9.876 | 0.000 |
| causal.characters | batch | apply | 6.607 | 0.000 |
| causal.characters | batch | receive | 7.887 | 0.000 |
| causal.characters | batch | encode | 0.204 | 0.000 |
| causal.characters | batch | decode | 0.117 | 0.000 |
| causal.words | individual | author | 10.944 | 0.000 |
| causal.words | individual | apply | 9.226 | 0.000 |
| causal.words | individual | receive | 14.558 | 0.000 |
| causal.words | individual | encode | 8.769 | 0.000 |
| causal.words | individual | decode | 10.168 | 0.000 |
| causal.words | batch | author | 9.387 | 0.000 |
| causal.words | batch | apply | 7.400 | 0.000 |
| causal.words | batch | receive | 8.730 | 0.000 |
| causal.words | batch | encode | 0.538 | 0.000 |
| causal.words | batch | decode | 0.115 | 0.000 |
| causal.mixed | individual | author | 18.391 | 0.000 |
| causal.mixed | individual | apply | 12.365 | 0.000 |
| causal.mixed | individual | receive | 16.914 | 0.000 |
| causal.mixed | individual | encode | 8.816 | 0.000 |
| causal.mixed | individual | decode | 10.019 | 0.000 |
| causal.mixed | batch | author | 13.922 | 0.000 |
| causal.mixed | batch | apply | 10.273 | 0.000 |
| causal.mixed | batch | receive | 10.581 | 0.000 |
| causal.mixed | batch | encode | 1.115 | 0.000 |
| causal.mixed | batch | decode | 0.273 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
