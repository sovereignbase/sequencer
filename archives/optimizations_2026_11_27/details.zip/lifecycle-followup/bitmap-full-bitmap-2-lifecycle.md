# Sequencer dynamic lifecycle benchmark

2026-11-27T20:50:19.981Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 202.54 | 165.86 | 56.93 |
| CommonJS | 202.72 | 167.48 | 57.14 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 312,623 | 3.199 | 3.199 | 3.199 | 0.000 | 0: 3.199 | 0: 3.199 |
| apply | random | A | scaleDown | 24,999 | 346,059 | 2.890 | 2.890 | 2.890 | 0.000 | 0: 2.890 | 0: 2.890 |
| apply | random | A | fullLifecycle | 49,999 | 328,492 | 3.044 | 3.044 | 3.044 | 0.000 | 0: 3.044 | 0: 3.044 |
| create | — | A | scaleUp | 7 | 542 | 1843.886 | 1843.886 | 1843.886 | 0.000 | 0: 1843.886 | 0: 1843.886 |
| create | — | A | scaleDown | 6 | 678 | 1475.583 | 1475.583 | 1475.583 | 0.000 | 0: 1475.583 | 0: 1475.583 |
| create | — | A | fullLifecycle | 13 | 597 | 1673.900 | 1673.900 | 1673.900 | 0.000 | 0: 1673.900 | 0: 1673.900 |
| insert | head | A | scaleUp | 12,500 | 1,298,971 | 0.770 | 0.770 | 0.770 | 0.000 | 0: 0.770 | 0: 0.770 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,298,971 | 0.770 | 0.770 | 0.770 | 0.000 | 0: 0.770 | 0: 0.770 |
| insert | random | A | scaleUp | 25,000 | 561,564 | 1.781 | 1.781 | 1.781 | 0.000 | 0: 1.781 | 0: 1.781 |
| insert | random | A | scaleDown | 25,000 | 605,738 | 1.651 | 1.651 | 1.651 | 0.000 | 0: 1.651 | 0: 1.651 |
| insert | random | A | fullLifecycle | 50,000 | 582,815 | 1.716 | 1.716 | 1.716 | 0.000 | 0: 1.716 | 0: 1.716 |
| insert | tail | A | scaleUp | 12,500 | 1,395,853 | 0.716 | 0.716 | 0.716 | 0.000 | 0: 0.716 | 0: 0.716 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,395,853 | 0.716 | 0.716 | 0.716 | 0.000 | 0: 0.716 | 0: 0.716 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 743,340 | 1.345 | 1.345 | 1.345 | 0.000 | 0: 1.345 | 0: 1.345 |
| remove | head | A | fullLifecycle | 12,500 | 743,340 | 1.345 | 1.345 | 1.345 | 0.000 | 0: 1.345 | 0: 1.345 |
| remove | random | A | scaleUp | 25,000 | 473,309 | 2.113 | 2.113 | 2.113 | 0.000 | 0: 2.113 | 0: 2.113 |
| remove | random | A | scaleDown | 25,000 | 533,982 | 1.873 | 1.873 | 1.873 | 0.000 | 0: 1.873 | 0: 1.873 |
| remove | random | A | fullLifecycle | 50,000 | 501,818 | 1.993 | 1.993 | 1.993 | 0.000 | 0: 1.993 | 0: 1.993 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 813,040 | 1.230 | 1.230 | 1.230 | 0.000 | 0: 1.230 | 0: 1.230 |
| remove | tail | A | fullLifecycle | 12,500 | 813,040 | 1.230 | 1.230 | 1.230 | 0.000 | 0: 1.230 | 0: 1.230 |
| replace | head | A | scaleUp | 25,000 | 506,545 | 1.974 | 1.974 | 1.974 | 0.000 | 0: 1.974 | 0: 1.974 |
| replace | head | A | scaleDown | 25,000 | 529,891 | 1.887 | 1.887 | 1.887 | 0.000 | 0: 1.887 | 0: 1.887 |
| replace | head | A | fullLifecycle | 50,000 | 517,955 | 1.931 | 1.931 | 1.931 | 0.000 | 0: 1.931 | 0: 1.931 |
| replace | random | A | scaleUp | 25,000 | 303,397 | 3.296 | 3.296 | 3.296 | 0.000 | 0: 3.296 | 0: 3.296 |
| replace | random | A | scaleDown | 25,000 | 388,954 | 2.571 | 2.571 | 2.571 | 0.000 | 0: 2.571 | 0: 2.571 |
| replace | random | A | fullLifecycle | 50,000 | 340,889 | 2.934 | 2.934 | 2.934 | 0.000 | 0: 2.934 | 0: 2.934 |
| replace | tail | A | scaleUp | 25,000 | 515,712 | 1.939 | 1.939 | 1.939 | 0.000 | 0: 1.939 | 0: 1.939 |
| replace | tail | A | scaleDown | 25,000 | 199,595 | 5.010 | 5.010 | 5.010 | 0.000 | 0: 5.010 | 0: 5.010 |
| replace | tail | A | fullLifecycle | 50,000 | 287,803 | 3.475 | 3.475 | 3.475 | 0.000 | 0: 3.475 | 0: 3.475 |
| sequence | — | A | scaleUp | 6 | 76 | 13140.283 | 13140.283 | 13140.283 | 0.000 | 0: 13140.283 | 0: 13140.283 |
| sequence | — | A | scaleDown | 6 | 93 | 10733.550 | 10733.550 | 10733.550 | 0.000 | 0: 10733.550 | 0: 10733.550 |
| sequence | — | A | fullLifecycle | 12 | 84 | 11936.917 | 11936.917 | 11936.917 | 0.000 | 0: 11936.917 | 0: 11936.917 |
| value | head | A | scaleUp | 25,000 | 2,969,685 | 0.337 | 0.337 | 0.337 | 0.000 | 0: 0.337 | 0: 0.337 |
| value | head | A | scaleDown | 25,000 | 2,375,229 | 0.421 | 0.421 | 0.421 | 0.000 | 0: 0.421 | 0: 0.421 |
| value | head | A | fullLifecycle | 50,000 | 2,639,400 | 0.379 | 0.379 | 0.379 | 0.000 | 0: 0.379 | 0: 0.379 |
| value | random | A | scaleUp | 25,000 | 889,360 | 1.124 | 1.124 | 1.124 | 0.000 | 0: 1.124 | 0: 1.124 |
| value | random | A | scaleDown | 25,000 | 989,934 | 1.010 | 1.010 | 1.010 | 0.000 | 0: 1.010 | 0: 1.010 |
| value | random | A | fullLifecycle | 50,000 | 936,956 | 1.067 | 1.067 | 1.067 | 0.000 | 0: 1.067 | 0: 1.067 |
| value | tail | A | scaleUp | 25,000 | 6,528,949 | 0.153 | 0.153 | 0.153 | 0.000 | 0: 0.153 | 0: 0.153 |
| value | tail | A | scaleDown | 25,000 | 4,277,014 | 0.234 | 0.234 | 0.234 | 0.000 | 0: 0.234 | 0: 0.234 |
| value | tail | A | fullLifecycle | 50,000 | 5,168,333 | 0.193 | 0.193 | 0.193 | 0.000 | 0: 0.193 | 0: 0.193 |
| values | — | A | scaleUp | 6 | 114 | 8810.517 | 8810.517 | 8810.517 | 0.000 | 0: 8810.517 | 0: 8810.517 |
| values | — | A | scaleDown | 6 | 267 | 3752.300 | 3752.300 | 3752.300 | 0.000 | 0: 3752.300 | 0: 3752.300 |
| values | — | A | fullLifecycle | 12 | 159 | 6281.408 | 6281.408 | 6281.408 | 0.000 | 0: 6281.408 | 0: 6281.408 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5410752.667 | 427.165 | 8.478 |
| A | scaleDown | 5 | 4407357.600 | 432.094 | 8.548 |
| A | fullLifecycle | 11 | 4954664.000 | 429.144 | 8.506 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3116296.167 | 246.023 | 4.883 |
| A | scaleDown | 5 | 2595337.600 | 254.445 | 5.034 |
| A | fullLifecycle | 11 | 2879496.818 | 249.405 | 4.944 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 277,670 | 3.601 | 1.800 | 53.900 |
| apply | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 314,750 | 3.177 | 1.800 | 210.400 |
| apply | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 313,436 | 3.190 | 1.500 | 690.800 |
| apply | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 313,367 | 3.191 | 1.500 | 690.800 |
| apply | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 308,597 | 3.240 | 1.500 | 690.800 |
| apply | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 312,623 | 3.199 | 1.500 | 690.800 |
| apply | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 316,968 | 3.155 | 1.500 | 690.800 |
| apply | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 320,797 | 3.117 | 1.500 | 690.800 |
| apply | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 323,463 | 3.092 | 1.500 | 690.800 |
| apply | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 324,574 | 3.081 | 1.500 | 789.100 |
| apply | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 326,501 | 3.063 | 1.400 | 814.800 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 328,492 | 3.044 | 1.200 | 814.800 |
| insert | head | 0 | up | 1,000 | 50,007 | A | 500 | 1,114,579 | 0.897 | 0.300 | 27.600 |
| insert | head | 0 | up | 5,000 | 256,206 | A | 2,500 | 1,163,115 | 0.860 | 0.300 | 27.600 |
| insert | head | 0 | up | 10,000 | 508,328 | A | 5,000 | 1,278,969 | 0.782 | 0.300 | 81.900 |
| insert | head | 0 | up | 15,000 | 756,035 | A | 7,500 | 1,272,804 | 0.786 | 0.300 | 238.200 |
| insert | head | 0 | up | 20,000 | 1,005,850 | A | 10,000 | 1,265,727 | 0.790 | 0.300 | 238.200 |
| insert | head | 0 | up | 25,000 | 1,252,902 | A | 12,500 | 1,298,971 | 0.770 | 0.300 | 238.200 |
| insert | head | 0 | down | 20,000 | 1,007,225 | A | 12,500 | 1,298,971 | 0.770 | 0.300 | 238.200 |
| insert | head | 0 | down | 15,000 | 759,799 | A | 12,500 | 1,298,971 | 0.770 | 0.300 | 238.200 |
| insert | head | 0 | down | 10,000 | 506,363 | A | 12,500 | 1,298,971 | 0.770 | 0.300 | 238.200 |
| insert | head | 0 | down | 5,000 | 254,264 | A | 12,500 | 1,298,971 | 0.770 | 0.300 | 238.200 |
| insert | head | 0 | down | 1,000 | 50,210 | A | 12,500 | 1,298,971 | 0.770 | 0.300 | 238.200 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,298,971 | 0.770 | 0.300 | 238.200 |
| insert | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 567,601 | 1.762 | 0.500 | 337.500 |
| insert | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 563,355 | 1.775 | 0.500 | 642.800 |
| insert | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 555,799 | 1.799 | 0.400 | 1200.100 |
| insert | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 563,802 | 1.774 | 0.400 | 1200.100 |
| insert | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 553,613 | 1.806 | 0.400 | 1200.100 |
| insert | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 561,564 | 1.781 | 0.400 | 1200.100 |
| insert | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 555,759 | 1.799 | 0.400 | 1200.100 |
| insert | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 557,150 | 1.795 | 0.400 | 1200.100 |
| insert | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 560,004 | 1.786 | 0.400 | 1200.100 |
| insert | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 567,425 | 1.762 | 0.400 | 1200.100 |
| insert | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 578,346 | 1.729 | 0.400 | 1200.100 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 582,815 | 1.716 | 0.400 | 1200.100 |
| insert | tail | 0 | up | 1,000 | 50,007 | A | 500 | 1,349,892 | 0.741 | 0.300 | 10.800 |
| insert | tail | 0 | up | 5,000 | 256,206 | A | 2,500 | 1,272,977 | 0.786 | 0.300 | 46.900 |
| insert | tail | 0 | up | 10,000 | 508,328 | A | 5,000 | 1,392,680 | 0.718 | 0.300 | 76.200 |
| insert | tail | 0 | up | 15,000 | 756,035 | A | 7,500 | 1,410,570 | 0.709 | 0.300 | 152.700 |
| insert | tail | 0 | up | 20,000 | 1,005,850 | A | 10,000 | 1,426,310 | 0.701 | 0.300 | 152.700 |
| insert | tail | 0 | up | 25,000 | 1,252,902 | A | 12,500 | 1,395,853 | 0.716 | 0.300 | 324.200 |
| insert | tail | 0 | down | 20,000 | 1,007,225 | A | 12,500 | 1,395,853 | 0.716 | 0.300 | 324.200 |
| insert | tail | 0 | down | 15,000 | 759,799 | A | 12,500 | 1,395,853 | 0.716 | 0.300 | 324.200 |
| insert | tail | 0 | down | 10,000 | 506,363 | A | 12,500 | 1,395,853 | 0.716 | 0.300 | 324.200 |
| insert | tail | 0 | down | 5,000 | 254,264 | A | 12,500 | 1,395,853 | 0.716 | 0.300 | 324.200 |
| insert | tail | 0 | down | 1,000 | 50,210 | A | 12,500 | 1,395,853 | 0.716 | 0.300 | 324.200 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,395,853 | 0.716 | 0.300 | 324.200 |
| remove | head | 0 | up | 1,000 | 50,007 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 256,206 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 508,328 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 756,035 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,005,850 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,252,902 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,007,225 | A | 2,500 | 742,655 | 1.347 | 0.800 | 62.900 |
| remove | head | 0 | down | 15,000 | 759,799 | A | 5,000 | 737,713 | 1.356 | 0.800 | 62.900 |
| remove | head | 0 | down | 10,000 | 506,363 | A | 7,500 | 697,713 | 1.433 | 0.800 | 675.200 |
| remove | head | 0 | down | 5,000 | 254,264 | A | 10,000 | 721,782 | 1.385 | 0.800 | 675.200 |
| remove | head | 0 | down | 1,000 | 50,210 | A | 12,000 | 739,103 | 1.353 | 0.700 | 675.200 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 743,340 | 1.345 | 0.700 | 675.200 |
| remove | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 415,231 | 2.408 | 0.800 | 497.100 |
| remove | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 493,029 | 2.028 | 0.800 | 497.100 |
| remove | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 489,376 | 2.043 | 0.800 | 497.100 |
| remove | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 487,230 | 2.052 | 0.800 | 497.100 |
| remove | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 466,954 | 2.142 | 0.800 | 684.700 |
| remove | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 473,309 | 2.113 | 0.800 | 684.700 |
| remove | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 477,006 | 2.096 | 0.800 | 684.700 |
| remove | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 480,506 | 2.081 | 0.800 | 684.700 |
| remove | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 482,639 | 2.072 | 0.800 | 684.700 |
| remove | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 491,036 | 2.037 | 0.800 | 684.700 |
| remove | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 498,204 | 2.007 | 0.800 | 684.700 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 501,818 | 1.993 | 0.800 | 684.700 |
| remove | tail | 0 | up | 1,000 | 50,007 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 256,206 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 508,328 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 756,035 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,005,850 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,252,902 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,007,225 | A | 2,500 | 838,251 | 1.193 | 0.800 | 11.800 |
| remove | tail | 0 | down | 15,000 | 759,799 | A | 5,000 | 813,021 | 1.230 | 0.800 | 29.800 |
| remove | tail | 0 | down | 10,000 | 506,363 | A | 7,500 | 771,851 | 1.296 | 0.800 | 513.100 |
| remove | tail | 0 | down | 5,000 | 254,264 | A | 10,000 | 794,142 | 1.259 | 0.800 | 513.100 |
| remove | tail | 0 | down | 1,000 | 50,210 | A | 12,000 | 807,358 | 1.239 | 0.700 | 513.100 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 813,040 | 1.230 | 0.700 | 513.100 |
| replace | head | 0 | up | 1,000 | 50,007 | A | 1,000 | 356,799 | 2.803 | 1.200 | 519.200 |
| replace | head | 0 | up | 5,000 | 256,206 | A | 5,000 | 400,609 | 2.496 | 1.100 | 1383.000 |
| replace | head | 0 | up | 10,000 | 508,328 | A | 10,000 | 471,611 | 2.120 | 1.000 | 1383.000 |
| replace | head | 0 | up | 15,000 | 756,035 | A | 15,000 | 492,302 | 2.031 | 1.000 | 1383.000 |
| replace | head | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 503,755 | 1.985 | 1.000 | 1383.000 |
| replace | head | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 506,545 | 1.974 | 1.000 | 1383.000 |
| replace | head | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 508,234 | 1.968 | 1.000 | 1383.000 |
| replace | head | 0 | down | 15,000 | 759,799 | A | 35,000 | 507,555 | 1.970 | 1.000 | 1383.000 |
| replace | head | 0 | down | 10,000 | 506,363 | A | 40,000 | 509,015 | 1.965 | 1.000 | 1383.000 |
| replace | head | 0 | down | 5,000 | 254,264 | A | 45,000 | 511,561 | 1.955 | 0.900 | 1383.000 |
| replace | head | 0 | down | 1,000 | 50,210 | A | 49,000 | 515,589 | 1.940 | 0.900 | 1383.000 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 517,955 | 1.931 | 0.900 | 1383.000 |
| replace | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 299,115 | 3.343 | 1.300 | 361.800 |
| replace | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 363,000 | 2.755 | 1.300 | 413.600 |
| replace | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 368,729 | 2.712 | 1.200 | 413.600 |
| replace | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 351,410 | 2.846 | 1.200 | 742.800 |
| replace | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 298,401 | 3.351 | 1.200 | 7490.500 |
| replace | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 303,397 | 3.296 | 1.200 | 7490.500 |
| replace | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 313,463 | 3.190 | 1.200 | 7490.500 |
| replace | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 314,368 | 3.181 | 1.200 | 7490.500 |
| replace | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 322,558 | 3.100 | 1.200 | 7490.500 |
| replace | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 330,481 | 3.026 | 1.000 | 7490.500 |
| replace | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 337,697 | 2.961 | 1.000 | 7490.500 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 340,889 | 2.934 | 0.900 | 7490.500 |
| replace | tail | 0 | up | 1,000 | 50,007 | A | 1,000 | 440,917 | 2.268 | 1.100 | 104.500 |
| replace | tail | 0 | up | 5,000 | 256,206 | A | 5,000 | 534,205 | 1.872 | 1.100 | 198.400 |
| replace | tail | 0 | up | 10,000 | 508,328 | A | 10,000 | 550,409 | 1.817 | 1.000 | 198.400 |
| replace | tail | 0 | up | 15,000 | 756,035 | A | 15,000 | 505,132 | 1.980 | 1.000 | 2578.900 |
| replace | tail | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 504,734 | 1.981 | 1.000 | 2578.900 |
| replace | tail | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 515,712 | 1.939 | 1.000 | 2578.900 |
| replace | tail | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 439,331 | 2.276 | 1.000 | 2905.600 |
| replace | tail | 0 | down | 15,000 | 759,799 | A | 35,000 | 295,078 | 3.389 | 1.000 | 2905.600 |
| replace | tail | 0 | down | 10,000 | 506,363 | A | 40,000 | 304,269 | 3.287 | 1.000 | 2905.600 |
| replace | tail | 0 | down | 5,000 | 254,264 | A | 45,000 | 281,366 | 3.554 | 0.900 | 2905.600 |
| replace | tail | 0 | down | 1,000 | 50,210 | A | 49,000 | 284,890 | 3.510 | 0.900 | 2905.600 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 287,803 | 3.475 | 0.900 | 2905.600 |
| value | head | 0 | up | 1,000 | 50,007 | A | 1,000 | 908,183 | 1.101 | 0.100 | 654.800 |
| value | head | 0 | up | 5,000 | 256,206 | A | 5,000 | 2,054,654 | 0.487 | 0.100 | 654.800 |
| value | head | 0 | up | 10,000 | 508,328 | A | 10,000 | 2,566,735 | 0.390 | 0.100 | 654.800 |
| value | head | 0 | up | 15,000 | 756,035 | A | 15,000 | 2,769,418 | 0.361 | 0.100 | 654.800 |
| value | head | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 2,870,965 | 0.348 | 0.100 | 654.800 |
| value | head | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 2,969,685 | 0.337 | 0.100 | 654.800 |
| value | head | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 2,881,623 | 0.347 | 0.100 | 654.800 |
| value | head | 0 | down | 15,000 | 759,799 | A | 35,000 | 2,676,537 | 0.374 | 0.100 | 654.800 |
| value | head | 0 | down | 10,000 | 506,363 | A | 40,000 | 2,658,072 | 0.376 | 0.100 | 654.800 |
| value | head | 0 | down | 5,000 | 254,264 | A | 45,000 | 2,638,399 | 0.379 | 0.100 | 654.800 |
| value | head | 0 | down | 1,000 | 50,210 | A | 49,000 | 2,635,726 | 0.379 | 0.100 | 654.800 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,639,400 | 0.379 | 0.100 | 654.800 |
| value | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 1,372,119 | 0.729 | 0.100 | 13.000 |
| value | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 1,100,037 | 0.909 | 0.100 | 13.000 |
| value | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 998,752 | 1.001 | 0.100 | 17.500 |
| value | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 920,183 | 1.087 | 0.100 | 43.900 |
| value | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 895,688 | 1.116 | 0.100 | 43.900 |
| value | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 889,360 | 1.124 | 0.100 | 44.900 |
| value | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 896,025 | 1.116 | 0.100 | 65.200 |
| value | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 898,046 | 1.114 | 0.100 | 65.200 |
| value | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 902,053 | 1.109 | 0.100 | 71.100 |
| value | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 914,032 | 1.094 | 0.100 | 71.100 |
| value | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 928,653 | 1.077 | 0.100 | 71.100 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 936,956 | 1.067 | 0.100 | 71.100 |
| value | tail | 0 | up | 1,000 | 50,007 | A | 1,000 | 5,599,104 | 0.179 | 0.100 | 5.300 |
| value | tail | 0 | up | 5,000 | 256,206 | A | 5,000 | 5,591,590 | 0.179 | 0.100 | 41.700 |
| value | tail | 0 | up | 10,000 | 508,328 | A | 10,000 | 5,992,689 | 0.167 | 0.100 | 41.700 |
| value | tail | 0 | up | 15,000 | 756,035 | A | 15,000 | 6,217,874 | 0.161 | 0.000 | 41.700 |
| value | tail | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 6,328,113 | 0.158 | 0.000 | 41.700 |
| value | tail | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 6,528,949 | 0.153 | 0.000 | 41.700 |
| value | tail | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 6,087,909 | 0.164 | 0.000 | 41.700 |
| value | tail | 0 | down | 15,000 | 759,799 | A | 35,000 | 5,765,398 | 0.173 | 0.000 | 41.700 |
| value | tail | 0 | down | 10,000 | 506,363 | A | 40,000 | 5,527,458 | 0.181 | 0.000 | 48.200 |
| value | tail | 0 | down | 5,000 | 254,264 | A | 45,000 | 5,265,005 | 0.190 | 0.000 | 64.400 |
| value | tail | 0 | down | 1,000 | 50,210 | A | 49,000 | 5,164,309 | 0.194 | 0.000 | 64.400 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,168,333 | 0.193 | 0.000 | 64.400 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,277 | 439.100 |
| create | — | 0 | up | 5,000 | A | 1 | 1,003 | 996.900 |
| create | — | 0 | up | 10,000 | A | 1 | 607 | 1647.000 |
| create | — | 0 | up | 15,000 | A | 1 | 428 | 2334.200 |
| create | — | 0 | up | 20,000 | A | 1 | 290 | 3443.800 |
| create | — | 0 | up | 25,000 | A | 1 | 257 | 3891.800 |
| create | — | 0 | down | 20,000 | A | 1 | 289 | 3454.700 |
| create | — | 0 | down | 15,000 | A | 1 | 379 | 2637.600 |
| create | — | 0 | down | 10,000 | A | 1 | 568 | 1759.500 |
| create | — | 0 | down | 5,000 | A | 1 | 1,179 | 848.400 |
| create | — | 0 | down | 1,000 | A | 1 | 7,097 | 140.900 |
| create | — | 0 | down | 0 | A | 1 | 80,645 | 12.400 |
| sequence | — | 0 | up | 1,000 | A | 1 | 391 | 2559.400 |
| sequence | — | 0 | up | 5,000 | A | 1 | 125 | 7999.000 |
| sequence | — | 0 | up | 10,000 | A | 1 | 94 | 10639.100 |
| sequence | — | 0 | up | 15,000 | A | 1 | 70 | 14286.900 |
| sequence | — | 0 | up | 20,000 | A | 1 | 49 | 20265.100 |
| sequence | — | 0 | up | 25,000 | A | 1 | 43 | 23092.200 |
| sequence | — | 0 | down | 20,000 | A | 1 | 50 | 19911.600 |
| sequence | — | 0 | down | 15,000 | A | 1 | 60 | 16742.600 |
| sequence | — | 0 | down | 10,000 | A | 1 | 84 | 11879.600 |
| sequence | — | 0 | down | 5,000 | A | 1 | 107 | 9360.400 |
| sequence | — | 0 | down | 1,000 | A | 1 | 189 | 5289.900 |
| sequence | — | 0 | down | 0 | A | 1 | 822 | 1217.200 |
| values | — | 0 | up | 1,000 | A | 1 | 554 | 1803.900 |
| values | — | 0 | up | 5,000 | A | 1 | 204 | 4897.200 |
| values | — | 0 | up | 10,000 | A | 1 | 51 | 19741.700 |
| values | — | 0 | up | 15,000 | A | 1 | 146 | 6871.600 |
| values | — | 0 | up | 20,000 | A | 1 | 108 | 9266.600 |
| values | — | 0 | up | 25,000 | A | 1 | 97 | 10282.100 |
| values | — | 0 | down | 20,000 | A | 1 | 110 | 9093.200 |
| values | — | 0 | down | 15,000 | A | 1 | 154 | 6498.900 |
| values | — | 0 | down | 10,000 | A | 1 | 245 | 4086.000 |
| values | — | 0 | down | 5,000 | A | 1 | 418 | 2392.400 |
| values | — | 0 | down | 1,000 | A | 1 | 2,303 | 434.300 |
| values | — | 0 | down | 0 | A | 1 | 111,111 | 9.000 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.613 | 0.232 | 0.382 |
| 0 | up | 5000 | 3.122 | 1.167 | 1.955 |
| 0 | up | 10000 | 6.220 | 2.342 | 3.878 |
| 0 | up | 15000 | 9.408 | 3.640 | 5.768 |
| 0 | up | 20000 | 12.780 | 5.106 | 7.674 |
| 0 | up | 25000 | 16.189 | 6.630 | 9.559 |
| 0 | down | 20000 | 13.291 | 5.606 | 7.685 |
| 0 | down | 15000 | 9.922 | 4.125 | 5.797 |
| 0 | down | 10000 | 7.152 | 3.289 | 3.863 |
| 0 | down | 5000 | 4.095 | 2.155 | 1.940 |
| 0 | down | 1000 | 1.797 | 1.414 | 0.383 |
| 0 | down | 0 | 1.224 | 1.224 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 50,007 | 0.402 | 421.580 | 8.430 | 121.742 | 15.534 |
| 0 | up | A | 5,000 | 5,000 | 256,206 | 2.057 | 431.302 | 8.417 | 154.172 | 19.662 |
| 0 | up | A | 10,000 | 10,000 | 508,328 | 4.090 | 428.881 | 8.437 | 195.574 | 24.533 |
| 0 | up | A | 15,000 | 15,000 | 756,035 | 6.108 | 426.991 | 8.472 | 209.691 | 29.303 |
| 0 | up | A | 20,000 | 20,000 | 1,005,850 | 8.143 | 426.916 | 8.489 | 282.004 | 34.112 |
| 0 | up | A | 25,000 | 25,000 | 1,252,902 | 10.161 | 426.177 | 8.504 | 295.031 | 38.847 |
| 0 | down | A | 20,000 | 20,000 | 1,007,225 | 8.223 | 431.124 | 8.561 | 295.664 | 34.160 |
| 0 | down | A | 15,000 | 15,000 | 759,799 | 6.203 | 433.606 | 8.560 | 302.020 | 29.434 |
| 0 | down | A | 10,000 | 10,000 | 506,363 | 4.124 | 432.479 | 8.541 | 298.785 | 24.636 |
| 0 | down | A | 5,000 | 5,000 | 254,264 | 2.060 | 431.993 | 8.495 | 296.852 | 19.858 |
| 0 | down | A | 1,000 | 1,000 | 50,210 | 0.406 | 425.476 | 8.474 | 295.160 | 15.987 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 296.063 | 14.915 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 50007 | 184507 | 184.507 | 3.690 | 272.03 | 14.52 | 162.13 | 12.30 |
| 0 | up | A | 5000 | 256206 | 1218174 | 243.635 | 4.755 | 1644.25 | 73.50 | 830.68 | 61.66 |
| 0 | up | A | 10000 | 508328 | 2441689 | 244.169 | 4.803 | 3276.35 | 148.92 | 1655.21 | 124.79 |
| 0 | up | A | 15000 | 756035 | 3694120 | 246.275 | 4.886 | 4916.66 | 225.99 | 3545.68 | 200.14 |
| 0 | up | A | 20000 | 1005850 | 4950983 | 247.549 | 4.922 | 7073.44 | 311.23 | 5103.00 | 263.55 |
| 0 | up | A | 25000 | 1252902 | 6208304 | 248.332 | 4.955 | 9192.05 | 392.29 | 6496.81 | 335.16 |
| 0 | down | A | 20000 | 1007225 | 5103545 | 255.177 | 5.067 | 7538.07 | 326.43 | 5289.65 | 278.22 |
| 0 | down | A | 15000 | 759799 | 3844421 | 256.295 | 5.060 | 5730.74 | 247.34 | 4004.94 | 209.82 |
| 0 | down | A | 10000 | 506363 | 2541344 | 254.134 | 5.019 | 3828.12 | 165.02 | 2670.80 | 139.89 |
| 0 | down | A | 5000 | 254264 | 1247949 | 249.590 | 4.908 | 1909.46 | 79.58 | 1334.90 | 67.69 |
| 0 | down | A | 1000 | 50210 | 239429 | 239.429 | 4.769 | 375.26 | 16.04 | 262.97 | 13.69 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 427.165 | 8.478 | 246.023 | 4.883 |
| 0 | A | scaleDown | 432.094 | 8.548 | 254.445 | 5.034 |
| 0 | A | fullLifecycle | 429.144 | 8.506 | 249.405 | 4.944 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
