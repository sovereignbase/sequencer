# Large string benchmarks

2026-11-27T20:51:24.005Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2602.23 | 0.00 |
| 1024 | insert.append | array | 14353.67 | 0.00 |
| 1024 | replace | array | 3469.40 | 0.00 |
| 1024 | remove | array | 1179.39 | 0.00 |
| 1024 | remove.middle | array | 1973.46 | 0.00 |
| 1024 | replace.middle | array | 2457.25 | 0.00 |
| 1024 | apply | array | 1179.66 | 0.00 |
| 1024 | apply.array | array | 638.89 | 0.00 |
| 1024 | concurrent.apply | array | 68939.94 | 0.00 |
| 1024 | merge | array | 3233.29 | 0.00 |
| 1024 | create | array | 3117.39 | 0.00 |
| 1024 | value.random | array | 46.30 | 0.00 |
| 1024 | values.range | array | 117.05 | 0.00 |
| 1024 | values.array | array | 1357.96 | 0.00 |
| 1024 | values.text | array | 13264.03 | 0.00 |
| 1024 | sequence.array | array | 1628.82 | 0.00 |
| 1024 | sequence.text | array | 12110.36 | 0.00 |
| 1024 | sequence.edited.text | array | 11005.05 | 0.00 |
| 1024 | sequence.masked.text | array | 11988.35 | 0.00 |
| 1024 | insert | string | 440.97 | 0.00 |
| 1024 | insert.append | string | 4002.99 | 0.00 |
| 1024 | replace | string | 1200.06 | 0.00 |
| 1024 | remove | string | 926.29 | 0.00 |
| 1024 | remove.middle | string | 1016.05 | 0.00 |
| 1024 | replace.middle | string | 1380.69 | 0.00 |
| 1024 | apply | string | 781.56 | 0.00 |
| 1024 | apply.array | string | 2345.74 | 0.00 |
| 1024 | concurrent.apply | string | 4043.19 | 0.00 |
| 1024 | merge | string | 1488.62 | 0.00 |
| 1024 | create | string | 960.17 | 0.00 |
| 1024 | value.random | string | 85.72 | 0.00 |
| 1024 | values.range | string | 164.13 | 0.00 |
| 1024 | values.array | string | 1973.96 | 0.00 |
| 1024 | values.text | string | 69.90 | 0.00 |
| 1024 | sequence.array | string | 2062.27 | 0.00 |
| 1024 | sequence.text | string | 280.51 | 0.00 |
| 1024 | sequence.edited.text | string | 804.43 | 0.00 |
| 1024 | sequence.masked.text | string | 3948.84 | 0.00 |
| 65536 | insert | array | 291280.85 | 0.00 |
| 65536 | insert.append | array | 1588481.25 | 0.00 |
| 65536 | replace | array | 347493.06 | 0.00 |
| 65536 | remove | array | 3879.13 | 0.00 |
| 65536 | remove.middle | array | 230192.66 | 0.00 |
| 65536 | replace.middle | array | 237363.30 | 0.00 |
| 65536 | apply | array | 833.01 | 0.00 |
| 65536 | apply.array | array | 531.38 | 0.00 |
| 65536 | concurrent.apply | array | 4202816.67 | 0.00 |
| 65536 | merge | array | 298470.24 | 0.00 |
| 65536 | create | array | 213138.14 | 0.00 |
| 65536 | value.random | array | 50.28 | 0.00 |
| 65536 | values.range | array | 142.23 | 0.00 |
| 65536 | values.array | array | 203380.16 | 0.00 |
| 65536 | values.text | array | 783496.88 | 0.00 |
| 65536 | sequence.array | array | 202496.03 | 0.00 |
| 65536 | sequence.text | array | 696247.22 | 0.00 |
| 65536 | sequence.edited.text | array | 690205.41 | 0.00 |
| 65536 | sequence.masked.text | array | 626790.00 | 0.00 |
| 65536 | insert | string | 380.47 | 0.00 |
| 65536 | insert.append | string | 20819.73 | 0.00 |
| 65536 | replace | string | 1336.88 | 0.00 |
| 65536 | remove | string | 957.48 | 0.00 |
| 65536 | remove.middle | string | 947.07 | 0.00 |
| 65536 | replace.middle | string | 1282.26 | 0.00 |
| 65536 | apply | string | 904.44 | 0.00 |
| 65536 | apply.array | string | 246136.72 | 0.00 |
| 65536 | concurrent.apply | string | 140679.21 | 0.00 |
| 65536 | merge | string | 1134.68 | 0.00 |
| 65536 | create | string | 967.86 | 0.00 |
| 65536 | value.random | string | 67.93 | 0.00 |
| 65536 | values.range | string | 145.00 | 0.00 |
| 65536 | values.array | string | 256375.78 | 0.00 |
| 65536 | values.text | string | 70.04 | 0.00 |
| 65536 | sequence.array | string | 241590.62 | 0.00 |
| 65536 | sequence.text | string | 221.55 | 0.00 |
| 65536 | sequence.edited.text | string | 6231.95 | 0.00 |
| 65536 | sequence.masked.text | string | 3201.84 | 0.00 |
| 1048576 | insert | array | 3353175.00 | 0.00 |
| 1048576 | insert.append | array | 23991250.00 | 0.00 |
| 1048576 | replace | array | 3275362.50 | 0.00 |
| 1048576 | remove | array | 13398.71 | 0.00 |
| 1048576 | remove.middle | array | 3107222.22 | 0.00 |
| 1048576 | replace.middle | array | 2541760.00 | 0.00 |
| 1048576 | apply | array | 887.89 | 0.00 |
| 1048576 | apply.array | array | 828.98 | 0.00 |
| 1048576 | concurrent.apply | array | 68612200.00 | 0.00 |
| 1048576 | merge | array | 3243575.00 | 0.00 |
| 1048576 | create | array | 3258000.00 | 0.00 |
| 1048576 | value.random | array | 43.76 | 0.00 |
| 1048576 | values.range | array | 112.64 | 0.00 |
| 1048576 | values.array | array | 2978466.67 | 0.00 |
| 1048576 | values.text | array | 12558166.67 | 0.00 |
| 1048576 | sequence.array | array | 3473100.00 | 0.00 |
| 1048576 | sequence.text | array | 76605700.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 79337100.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 186439250.00 | 0.00 |
| 1048576 | insert | string | 571.02 | 0.00 |
| 1048576 | insert.append | string | 621192.68 | 0.00 |
| 1048576 | replace | string | 1630.70 | 0.00 |
| 1048576 | remove | string | 1138.22 | 0.00 |
| 1048576 | remove.middle | string | 946.23 | 0.00 |
| 1048576 | replace.middle | string | 1406.62 | 0.00 |
| 1048576 | apply | string | 994.18 | 0.00 |
| 1048576 | apply.array | string | 3149175.00 | 0.00 |
| 1048576 | concurrent.apply | string | 1400977.78 | 0.00 |
| 1048576 | merge | string | 1253.12 | 0.00 |
| 1048576 | create | string | 929.33 | 0.00 |
| 1048576 | value.random | string | 39.01 | 0.00 |
| 1048576 | values.range | string | 137.91 | 0.00 |
| 1048576 | values.array | string | 3164437.50 | 0.00 |
| 1048576 | values.text | string | 83.99 | 0.00 |
| 1048576 | sequence.array | string | 3249512.50 | 0.00 |
| 1048576 | sequence.text | string | 172.27 | 0.00 |
| 1048576 | sequence.edited.text | string | 87170.73 | 0.00 |
| 1048576 | sequence.masked.text | string | 3244.12 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
