# Tuple benchmarks

2026-11-27T20:51:09.355Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 2,958,703 | 2,476,173 | 0.84× |
| 2 | create.sequence | 1,015,385 | 814,045 | 0.80× |
| 2 | replace.random | 1,194,933 | 1,274,893 | 1.07× |
| 2 | apply.replace | 692,218 | 898,385 | 1.30× |
| 2 | apply.duplicate | 1,650,114 | 1,630,301 | 0.99× |
| 2 | merge.duplicate | 1,583,846 | 1,597,314 | 1.01× |
| 2 | length | 136,159,658 | 137,718,339 | 1.01× |
| 2 | value.random | 32,639,701 | 52,996,111 | 1.62× |
| 2 | values | 12,822,306 | 11,860,396 | 0.92× |
| 2 | sequence | 3,274,920 | 2,958,711 | 0.90× |
| 4 | create.empty | 2,402,000 | 2,214,701 | 0.92× |
| 4 | create.sequence | 693,018 | 690,768 | 1.00× |
| 4 | replace.random | 1,097,594 | 1,589,609 | 1.45× |
| 4 | apply.replace | 625,140 | 977,428 | 1.56× |
| 4 | apply.duplicate | 1,789,961 | 1,734,898 | 0.97× |
| 4 | merge.duplicate | 1,365,068 | 1,332,680 | 0.98× |
| 4 | length | 29,960,170 | 36,572,595 | 1.22× |
| 4 | value.random | 23,453,552 | 43,662,757 | 1.86× |
| 4 | values | 5,429,309 | 5,800,399 | 1.07× |
| 4 | sequence | 2,129,669 | 2,322,390 | 1.09× |
| 8 | create.empty | 2,452,827 | 2,274,780 | 0.93× |
| 8 | create.sequence | 466,717 | 478,273 | 1.02× |
| 8 | replace.random | 886,248 | 783,586 | 0.88× |
| 8 | apply.replace | 394,052 | 563,284 | 1.43× |
| 8 | apply.duplicate | 1,020,454 | 1,339,061 | 1.31× |
| 8 | merge.duplicate | 771,664 | 798,739 | 1.04× |
| 8 | length | 34,483,363 | 37,428,682 | 1.09× |
| 8 | value.random | 19,059,993 | 54,185,654 | 2.84× |
| 8 | values | 4,609,079 | 4,514,911 | 0.98× |
| 8 | sequence | 1,700,116 | 1,903,987 | 1.12× |
| 100 | create.empty | 2,315,095 | 2,160,286 | 0.93× |
| 100 | create.sequence | 71,789 | 86,066 | 1.20× |
| 100 | replace.random | 1,012,102 | 1,550,091 | 1.53× |
| 100 | apply.replace | 662,253 | 1,042,866 | 1.57× |
| 100 | apply.duplicate | 1,688,618 | 1,698,853 | 1.01× |
| 100 | merge.duplicate | 111,479 | 75,323 | 0.68× |
| 100 | length | 35,641,327 | 35,775,646 | 1.00× |
| 100 | value.random | 11,647,904 | 50,569,364 | 4.34× |
| 100 | values | 465,653 | 605,614 | 1.30× |
| 100 | sequence | 162,954 | 162,413 | 1.00× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
