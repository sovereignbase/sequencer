# Words benchmarks

2026-11-27T20:51:45.240Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 30,057 | 51,252 | 108 |
| append | packed | 5.90 | 3.61 | 13.98 | 25,248 | 174,860 | 279 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,650 | 799 | 235 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 28,218 | 1,696 | 257 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 460 | 255 | 84 |
| random | packed | 49.58 | 35.38 | 23.45 | 14,212 | 526 | 65 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 473 | 173 | 19 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 13,515 | 335 | 128 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 610.32 | 0.00 |
| append | numeric | encode | 33269.63 | 0.00 |
| append | numeric | decode | 3131.96 | 0.00 |
| append | numeric | create | 1784.21 | 0.00 |
| append | numeric | load | 19511.31 | 0.00 |
| append | numeric | apply | 5120480.00 | 0.00 |
| append | numeric | receive | 9253383.33 | 0.00 |
| append | binary | sequence | 602.22 | 0.00 |
| append | binary | encode | 39606.57 | 0.00 |
| append | binary | decode | 2014.02 | 0.00 |
| append | binary | create | 2069.71 | 0.00 |
| append | binary | load | 5718.87 | 0.00 |
| append | binary | apply | 2237673.91 | 0.00 |
| append | binary | receive | 3581450.00 | 0.00 |
| prepend | numeric | sequence | 524831.96 | 0.00 |
| prepend | numeric | encode | 606085.54 | 0.00 |
| prepend | numeric | decode | 177065.02 | 0.00 |
| prepend | numeric | create | 622391.36 | 0.00 |
| prepend | numeric | load | 1252325.00 | 0.00 |
| prepend | numeric | apply | 2314527.27 | 0.00 |
| prepend | numeric | receive | 4263841.67 | 0.00 |
| prepend | binary | sequence | 361305.76 | 0.00 |
| prepend | binary | encode | 35437.85 | 0.00 |
| prepend | binary | decode | 2252.89 | 0.00 |
| prepend | binary | create | 563567.42 | 0.00 |
| prepend | binary | load | 589685.88 | 0.00 |
| prepend | binary | apply | 2539580.00 | 0.00 |
| prepend | binary | receive | 3892815.38 | 0.00 |
| random | numeric | sequence | 900464.29 | 0.00 |
| random | numeric | encode | 2175845.83 | 0.00 |
| random | numeric | decode | 1220958.54 | 0.00 |
| random | numeric | create | 1805892.86 | 0.00 |
| random | numeric | load | 3923676.92 | 0.00 |
| random | numeric | apply | 7732000.00 | 0.00 |
| random | numeric | receive | 11849040.00 | 0.00 |
| random | binary | sequence | 868981.03 | 0.00 |
| random | binary | encode | 70362.52 | 0.00 |
| random | binary | decode | 1677.77 | 0.00 |
| random | binary | create | 2024352.00 | 0.00 |
| random | binary | load | 1900207.41 | 0.00 |
| random | binary | apply | 6768675.00 | 0.00 |
| random | binary | receive | 15462300.00 | 0.00 |
| concurrent | numeric | sequence | 2294000.00 | 0.00 |
| concurrent | numeric | encode | 2114225.00 | 0.00 |
| concurrent | numeric | decode | 986527.45 | 0.00 |
| concurrent | numeric | create | 3177987.50 | 0.00 |
| concurrent | numeric | load | 5795277.78 | 0.00 |
| concurrent | numeric | apply | 10363933.33 | 0.00 |
| concurrent | numeric | receive | 51625000.00 | 0.00 |
| concurrent | binary | sequence | 1695983.33 | 0.00 |
| concurrent | binary | encode | 73993.94 | 0.00 |
| concurrent | binary | decode | 7188.33 | 0.00 |
| concurrent | binary | create | 3678635.71 | 0.00 |
| concurrent | binary | load | 2983835.29 | 0.00 |
| concurrent | binary | apply | 6539850.00 | 0.00 |
| concurrent | binary | receive | 7803357.14 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
