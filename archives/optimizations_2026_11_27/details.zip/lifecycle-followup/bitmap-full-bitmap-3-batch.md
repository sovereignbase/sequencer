# Batch benchmarks

2026-11-27T20:53:32.431Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 2,062,423 | 1,102,738 | 487,595 | 76.05 | 5.99 | 0.012 |
| append | batch | 2,894,496 | 250,000,000 | 225,563,910 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,655,492 | 1,633,631 | 884,956 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 2,026,479 | 2,178,649 | 2,059,237 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 1,156,203 | 902,649 | 741,107 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 1,103,672 | 1,520,874 | 1,371,178 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 1,118,735 | 1,203,780 | 775,595 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 1,106,562 | 1,765,952 | 1,482,323 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,325,820 | 1,245,731 | 835,242 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,355,304 | 1,749,118 | 1,561,890 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,356,024 | 1,312,006 | 834,353 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,378,391 | 1,681,096 | 1,641,564 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 574,828 | 889,950 | 671,941 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 995,330 | 1,143,227 | 1,067,207 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,145,913 | 1,378,186 | 945,850 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 1,273,845 | 1,669,333 | 1,634,699 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,139,644 | 1,351,869 | 918,829 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 1,315,501 | 1,679,896 | 1,642,216 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 654,682 | 942,381 | 675,699 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 910,982 | 1,324,226 | 1,145,760 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 2.909 | 0.000 |
| append | individual | apply | 5.441 | 0.000 |
| append | individual | receive | 12.305 | 0.000 |
| append | individual | encode | 6.789 | 0.000 |
| append | individual | decode | 7.536 | 0.000 |
| append | batch | author | 2.073 | 0.000 |
| append | batch | apply | 0.024 | 0.000 |
| append | batch | receive | 0.027 | 0.000 |
| append | batch | encode | 0.194 | 0.000 |
| append | batch | decode | 0.106 | 0.000 |
| prepend | individual | author | 3.624 | 0.000 |
| prepend | individual | apply | 3.673 | 0.000 |
| prepend | individual | receive | 6.780 | 0.000 |
| prepend | individual | encode | 6.072 | 0.000 |
| prepend | individual | decode | 7.710 | 0.000 |
| prepend | batch | author | 2.961 | 0.000 |
| prepend | batch | apply | 2.754 | 0.000 |
| prepend | batch | receive | 2.914 | 0.000 |
| prepend | batch | encode | 0.190 | 0.000 |
| prepend | batch | decode | 0.111 | 0.000 |
| random.characters | individual | author | 5.189 | 0.000 |
| random.characters | individual | apply | 6.647 | 0.000 |
| random.characters | individual | receive | 8.096 | 0.000 |
| random.characters | individual | encode | 6.237 | 0.000 |
| random.characters | individual | decode | 8.432 | 0.000 |
| random.characters | batch | author | 5.436 | 0.000 |
| random.characters | batch | apply | 3.945 | 0.000 |
| random.characters | batch | receive | 4.376 | 0.000 |
| random.characters | batch | encode | 0.190 | 0.000 |
| random.characters | batch | decode | 0.118 | 0.000 |
| random.words | individual | author | 5.363 | 0.000 |
| random.words | individual | apply | 4.984 | 0.000 |
| random.words | individual | receive | 7.736 | 0.000 |
| random.words | individual | encode | 4.286 | 0.000 |
| random.words | individual | decode | 9.662 | 0.000 |
| random.words | batch | author | 5.422 | 0.000 |
| random.words | batch | apply | 3.398 | 0.000 |
| random.words | batch | receive | 4.048 | 0.000 |
| random.words | batch | encode | 0.381 | 0.000 |
| random.words | batch | decode | 0.105 | 0.000 |
| concurrent.characters | individual | author | 9.051 | 0.000 |
| concurrent.characters | individual | apply | 9.633 | 0.000 |
| concurrent.characters | individual | receive | 14.367 | 0.000 |
| concurrent.characters | individual | encode | 7.763 | 0.000 |
| concurrent.characters | individual | decode | 12.072 | 0.000 |
| concurrent.characters | batch | author | 8.854 | 0.000 |
| concurrent.characters | batch | apply | 6.861 | 0.000 |
| concurrent.characters | batch | receive | 7.683 | 0.000 |
| concurrent.characters | batch | encode | 0.319 | 0.000 |
| concurrent.characters | batch | decode | 0.119 | 0.000 |
| concurrent.words | individual | author | 8.849 | 0.000 |
| concurrent.words | individual | apply | 9.146 | 0.000 |
| concurrent.words | individual | receive | 14.382 | 0.000 |
| concurrent.words | individual | encode | 8.006 | 0.000 |
| concurrent.words | individual | decode | 11.221 | 0.000 |
| concurrent.words | batch | author | 8.706 | 0.000 |
| concurrent.words | batch | apply | 7.138 | 0.000 |
| concurrent.words | batch | receive | 7.310 | 0.000 |
| concurrent.words | batch | encode | 0.756 | 0.000 |
| concurrent.words | batch | decode | 0.113 | 0.000 |
| concurrent.mixed | individual | author | 20.876 | 0.000 |
| concurrent.mixed | individual | apply | 13.484 | 0.000 |
| concurrent.mixed | individual | receive | 17.859 | 0.000 |
| concurrent.mixed | individual | encode | 10.516 | 0.000 |
| concurrent.mixed | individual | decode | 11.713 | 0.000 |
| concurrent.mixed | batch | author | 12.056 | 0.000 |
| concurrent.mixed | batch | apply | 10.497 | 0.000 |
| concurrent.mixed | batch | receive | 11.244 | 0.000 |
| concurrent.mixed | batch | encode | 0.561 | 0.000 |
| concurrent.mixed | batch | decode | 0.116 | 0.000 |
| causal.characters | individual | author | 10.472 | 0.000 |
| causal.characters | individual | apply | 8.707 | 0.000 |
| causal.characters | individual | receive | 12.687 | 0.000 |
| causal.characters | individual | encode | 7.379 | 0.000 |
| causal.characters | individual | decode | 8.666 | 0.000 |
| causal.characters | batch | author | 9.420 | 0.000 |
| causal.characters | batch | apply | 7.189 | 0.000 |
| causal.characters | batch | receive | 7.341 | 0.000 |
| causal.characters | batch | encode | 0.270 | 0.000 |
| causal.characters | batch | decode | 0.115 | 0.000 |
| causal.words | individual | author | 10.530 | 0.000 |
| causal.words | individual | apply | 8.877 | 0.000 |
| causal.words | individual | receive | 13.060 | 0.000 |
| causal.words | individual | encode | 8.550 | 0.000 |
| causal.words | individual | decode | 9.217 | 0.000 |
| causal.words | batch | author | 9.122 | 0.000 |
| causal.words | batch | apply | 7.143 | 0.000 |
| causal.words | batch | receive | 7.307 | 0.000 |
| causal.words | batch | encode | 0.521 | 0.000 |
| causal.words | batch | decode | 0.115 | 0.000 |
| causal.mixed | individual | author | 18.330 | 0.000 |
| causal.mixed | individual | apply | 12.734 | 0.000 |
| causal.mixed | individual | receive | 17.759 | 0.000 |
| causal.mixed | individual | encode | 11.306 | 0.000 |
| causal.mixed | individual | decode | 9.559 | 0.000 |
| causal.mixed | batch | author | 13.173 | 0.000 |
| causal.mixed | batch | apply | 9.062 | 0.000 |
| causal.mixed | batch | receive | 10.473 | 0.000 |
| causal.mixed | batch | encode | 0.466 | 0.000 |
| causal.mixed | batch | decode | 0.106 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
