# Sequencer dynamic lifecycle benchmark

2026-11-27T20:52:03.876Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 202.54 | 165.86 | 56.93 |
| CommonJS | 202.72 | 167.48 | 57.14 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 298,727 | 3.348 | 3.348 | 3.348 | 0.000 | 0: 3.348 | 0: 3.348 |
| apply | random | A | scaleDown | 24,999 | 327,195 | 3.056 | 3.056 | 3.056 | 0.000 | 0: 3.056 | 0: 3.056 |
| apply | random | A | fullLifecycle | 49,999 | 312,313 | 3.202 | 3.202 | 3.202 | 0.000 | 0: 3.202 | 0: 3.202 |
| create | — | A | scaleUp | 7 | 507 | 1971.857 | 1971.857 | 1971.857 | 0.000 | 0: 1971.857 | 0: 1971.857 |
| create | — | A | scaleDown | 6 | 639 | 1565.050 | 1565.050 | 1565.050 | 0.000 | 0: 1565.050 | 0: 1565.050 |
| create | — | A | fullLifecycle | 13 | 561 | 1784.100 | 1784.100 | 1784.100 | 0.000 | 0: 1784.100 | 0: 1784.100 |
| insert | head | A | scaleUp | 12,500 | 1,176,814 | 0.850 | 0.850 | 0.850 | 0.000 | 0: 0.850 | 0: 0.850 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,176,814 | 0.850 | 0.850 | 0.850 | 0.000 | 0: 0.850 | 0: 0.850 |
| insert | random | A | scaleUp | 25,000 | 528,362 | 1.893 | 1.893 | 1.893 | 0.000 | 0: 1.893 | 0: 1.893 |
| insert | random | A | scaleDown | 25,000 | 563,251 | 1.775 | 1.775 | 1.775 | 0.000 | 0: 1.775 | 0: 1.775 |
| insert | random | A | fullLifecycle | 50,000 | 545,249 | 1.834 | 1.834 | 1.834 | 0.000 | 0: 1.834 | 0: 1.834 |
| insert | tail | A | scaleUp | 12,500 | 1,244,190 | 0.804 | 0.804 | 0.804 | 0.000 | 0: 0.804 | 0: 0.804 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,244,190 | 0.804 | 0.804 | 0.804 | 0.000 | 0: 0.804 | 0: 0.804 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 682,102 | 1.466 | 1.466 | 1.466 | 0.000 | 0: 1.466 | 0: 1.466 |
| remove | head | A | fullLifecycle | 12,500 | 682,102 | 1.466 | 1.466 | 1.466 | 0.000 | 0: 1.466 | 0: 1.466 |
| remove | random | A | scaleUp | 25,000 | 462,505 | 2.162 | 2.162 | 2.162 | 0.000 | 0: 2.162 | 0: 2.162 |
| remove | random | A | scaleDown | 25,000 | 486,647 | 2.055 | 2.055 | 2.055 | 0.000 | 0: 2.055 | 0: 2.055 |
| remove | random | A | fullLifecycle | 50,000 | 474,269 | 2.109 | 2.109 | 2.109 | 0.000 | 0: 2.109 | 0: 2.109 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 754,098 | 1.326 | 1.326 | 1.326 | 0.000 | 0: 1.326 | 0: 1.326 |
| remove | tail | A | fullLifecycle | 12,500 | 754,098 | 1.326 | 1.326 | 1.326 | 0.000 | 0: 1.326 | 0: 1.326 |
| replace | head | A | scaleUp | 25,000 | 450,258 | 2.221 | 2.221 | 2.221 | 0.000 | 0: 2.221 | 0: 2.221 |
| replace | head | A | scaleDown | 25,000 | 472,177 | 2.118 | 2.118 | 2.118 | 0.000 | 0: 2.118 | 0: 2.118 |
| replace | head | A | fullLifecycle | 50,000 | 460,957 | 2.169 | 2.169 | 2.169 | 0.000 | 0: 2.169 | 0: 2.169 |
| replace | random | A | scaleUp | 25,000 | 334,963 | 2.985 | 2.985 | 2.985 | 0.000 | 0: 2.985 | 0: 2.985 |
| replace | random | A | scaleDown | 25,000 | 354,694 | 2.819 | 2.819 | 2.819 | 0.000 | 0: 2.819 | 0: 2.819 |
| replace | random | A | fullLifecycle | 50,000 | 344,546 | 2.902 | 2.902 | 2.902 | 0.000 | 0: 2.902 | 0: 2.902 |
| replace | tail | A | scaleUp | 25,000 | 498,688 | 2.005 | 2.005 | 2.005 | 0.000 | 0: 2.005 | 0: 2.005 |
| replace | tail | A | scaleDown | 25,000 | 177,475 | 5.635 | 5.635 | 5.635 | 0.000 | 0: 5.635 | 0: 5.635 |
| replace | tail | A | fullLifecycle | 50,000 | 261,785 | 3.820 | 3.820 | 3.820 | 0.000 | 0: 3.820 | 0: 3.820 |
| sequence | — | A | scaleUp | 6 | 68 | 14685.350 | 14685.350 | 14685.350 | 0.000 | 0: 14685.350 | 0: 14685.350 |
| sequence | — | A | scaleDown | 6 | 93 | 10724.350 | 10724.350 | 10724.350 | 0.000 | 0: 10724.350 | 0: 10724.350 |
| sequence | — | A | fullLifecycle | 12 | 79 | 12704.850 | 12704.850 | 12704.850 | 0.000 | 0: 12704.850 | 0: 12704.850 |
| value | head | A | scaleUp | 25,000 | 2,940,208 | 0.340 | 0.340 | 0.340 | 0.000 | 0: 0.340 | 0: 0.340 |
| value | head | A | scaleDown | 25,000 | 2,352,255 | 0.425 | 0.425 | 0.425 | 0.000 | 0: 0.425 | 0: 0.425 |
| value | head | A | fullLifecycle | 50,000 | 2,613,573 | 0.383 | 0.383 | 0.383 | 0.000 | 0: 0.383 | 0: 0.383 |
| value | random | A | scaleUp | 25,000 | 856,343 | 1.168 | 1.168 | 1.168 | 0.000 | 0: 1.168 | 0: 1.168 |
| value | random | A | scaleDown | 25,000 | 895,595 | 1.117 | 1.117 | 1.117 | 0.000 | 0: 1.117 | 0: 1.117 |
| value | random | A | fullLifecycle | 50,000 | 875,529 | 1.142 | 1.142 | 1.142 | 0.000 | 0: 1.142 | 0: 1.142 |
| value | tail | A | scaleUp | 25,000 | 5,896,226 | 0.170 | 0.170 | 0.170 | 0.000 | 0: 0.170 | 0: 0.170 |
| value | tail | A | scaleDown | 25,000 | 4,128,206 | 0.242 | 0.242 | 0.242 | 0.000 | 0: 0.242 | 0: 0.242 |
| value | tail | A | fullLifecycle | 50,000 | 4,856,302 | 0.206 | 0.206 | 0.206 | 0.000 | 0: 0.206 | 0: 0.206 |
| values | — | A | scaleUp | 6 | 71 | 14130.067 | 14130.067 | 14130.067 | 0.000 | 0: 14130.067 | 0: 14130.067 |
| values | — | A | scaleDown | 6 | 260 | 3853.500 | 3853.500 | 3853.500 | 0.000 | 0: 3853.500 | 0: 3853.500 |
| values | — | A | fullLifecycle | 12 | 111 | 8991.783 | 8991.783 | 8991.783 | 0.000 | 0: 8991.783 | 0: 8991.783 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5439899.333 | 429.466 | 8.475 |
| A | scaleDown | 5 | 4402917.600 | 431.659 | 8.549 |
| A | fullLifecycle | 11 | 4968544.000 | 430.346 | 8.505 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3131086.833 | 247.191 | 4.878 |
| A | scaleDown | 5 | 2593300.000 | 254.245 | 5.036 |
| A | fullLifecycle | 11 | 2886638.273 | 250.024 | 4.941 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 50,041 | A | 1,000 | 260,098 | 3.845 | 1.900 | 55.900 |
| apply | random | 0 | up | 5,000 | 253,849 | A | 5,000 | 304,807 | 3.281 | 1.800 | 278.800 |
| apply | random | 0 | up | 10,000 | 510,883 | A | 10,000 | 308,439 | 3.242 | 1.600 | 866.500 |
| apply | random | 0 | up | 15,000 | 762,464 | A | 15,000 | 291,391 | 3.432 | 1.600 | 866.500 |
| apply | random | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 290,420 | 3.443 | 1.600 | 866.500 |
| apply | random | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 298,727 | 3.348 | 1.600 | 866.500 |
| apply | random | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 297,334 | 3.363 | 1.600 | 866.500 |
| apply | random | 0 | down | 15,000 | 754,542 | A | 35,000 | 300,868 | 3.324 | 1.600 | 866.500 |
| apply | random | 0 | down | 10,000 | 504,420 | A | 40,000 | 301,807 | 3.313 | 1.600 | 866.500 |
| apply | random | 0 | down | 5,000 | 253,074 | A | 45,000 | 306,084 | 3.267 | 1.600 | 866.500 |
| apply | random | 0 | down | 1,000 | 48,660 | A | 49,000 | 310,246 | 3.223 | 1.500 | 866.500 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 312,313 | 3.202 | 1.300 | 866.500 |
| insert | head | 0 | up | 1,000 | 50,041 | A | 500 | 824,674 | 1.213 | 0.400 | 39.200 |
| insert | head | 0 | up | 5,000 | 253,849 | A | 2,500 | 1,097,213 | 0.911 | 0.400 | 39.200 |
| insert | head | 0 | up | 10,000 | 510,883 | A | 5,000 | 1,096,347 | 0.912 | 0.300 | 545.900 |
| insert | head | 0 | up | 15,000 | 762,464 | A | 7,500 | 1,110,387 | 0.901 | 0.300 | 545.900 |
| insert | head | 0 | up | 20,000 | 1,009,832 | A | 10,000 | 1,126,913 | 0.887 | 0.300 | 545.900 |
| insert | head | 0 | up | 25,000 | 1,264,057 | A | 12,500 | 1,176,814 | 0.850 | 0.300 | 545.900 |
| insert | head | 0 | down | 20,000 | 1,014,321 | A | 12,500 | 1,176,814 | 0.850 | 0.300 | 545.900 |
| insert | head | 0 | down | 15,000 | 754,542 | A | 12,500 | 1,176,814 | 0.850 | 0.300 | 545.900 |
| insert | head | 0 | down | 10,000 | 504,420 | A | 12,500 | 1,176,814 | 0.850 | 0.300 | 545.900 |
| insert | head | 0 | down | 5,000 | 253,074 | A | 12,500 | 1,176,814 | 0.850 | 0.300 | 545.900 |
| insert | head | 0 | down | 1,000 | 48,660 | A | 12,500 | 1,176,814 | 0.850 | 0.300 | 545.900 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,176,814 | 0.850 | 0.300 | 545.900 |
| insert | random | 0 | up | 1,000 | 50,041 | A | 1,000 | 468,187 | 2.136 | 0.500 | 280.300 |
| insert | random | 0 | up | 5,000 | 253,849 | A | 5,000 | 469,801 | 2.129 | 0.500 | 860.400 |
| insert | random | 0 | up | 10,000 | 510,883 | A | 10,000 | 548,652 | 1.823 | 0.500 | 860.400 |
| insert | random | 0 | up | 15,000 | 762,464 | A | 15,000 | 515,340 | 1.940 | 0.500 | 860.400 |
| insert | random | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 512,445 | 1.951 | 0.500 | 860.400 |
| insert | random | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 528,362 | 1.893 | 0.500 | 860.400 |
| insert | random | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 516,837 | 1.935 | 0.500 | 860.400 |
| insert | random | 0 | down | 15,000 | 754,542 | A | 35,000 | 517,751 | 1.931 | 0.500 | 860.400 |
| insert | random | 0 | down | 10,000 | 504,420 | A | 40,000 | 523,481 | 1.910 | 0.500 | 860.400 |
| insert | random | 0 | down | 5,000 | 253,074 | A | 45,000 | 529,566 | 1.888 | 0.500 | 860.400 |
| insert | random | 0 | down | 1,000 | 48,660 | A | 49,000 | 540,146 | 1.851 | 0.500 | 860.400 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 545,249 | 1.834 | 0.400 | 860.400 |
| insert | tail | 0 | up | 1,000 | 50,041 | A | 500 | 1,096,251 | 0.912 | 0.300 | 22.600 |
| insert | tail | 0 | up | 5,000 | 253,849 | A | 2,500 | 1,271,423 | 0.787 | 0.300 | 43.500 |
| insert | tail | 0 | up | 10,000 | 510,883 | A | 5,000 | 1,397,937 | 0.715 | 0.300 | 75.500 |
| insert | tail | 0 | up | 15,000 | 762,464 | A | 7,500 | 1,194,287 | 0.837 | 0.300 | 647.400 |
| insert | tail | 0 | up | 20,000 | 1,009,832 | A | 10,000 | 1,226,332 | 0.815 | 0.300 | 647.400 |
| insert | tail | 0 | up | 25,000 | 1,264,057 | A | 12,500 | 1,244,190 | 0.804 | 0.300 | 647.400 |
| insert | tail | 0 | down | 20,000 | 1,014,321 | A | 12,500 | 1,244,190 | 0.804 | 0.300 | 647.400 |
| insert | tail | 0 | down | 15,000 | 754,542 | A | 12,500 | 1,244,190 | 0.804 | 0.300 | 647.400 |
| insert | tail | 0 | down | 10,000 | 504,420 | A | 12,500 | 1,244,190 | 0.804 | 0.300 | 647.400 |
| insert | tail | 0 | down | 5,000 | 253,074 | A | 12,500 | 1,244,190 | 0.804 | 0.300 | 647.400 |
| insert | tail | 0 | down | 1,000 | 48,660 | A | 12,500 | 1,244,190 | 0.804 | 0.300 | 647.400 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,244,190 | 0.804 | 0.300 | 647.400 |
| remove | head | 0 | up | 1,000 | 50,041 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 253,849 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 510,883 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 762,464 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,009,832 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,264,057 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,014,321 | A | 2,500 | 635,922 | 1.573 | 0.900 | 123.800 |
| remove | head | 0 | down | 15,000 | 754,542 | A | 5,000 | 674,864 | 1.482 | 0.900 | 123.800 |
| remove | head | 0 | down | 10,000 | 504,420 | A | 7,500 | 635,302 | 1.574 | 0.900 | 775.900 |
| remove | head | 0 | down | 5,000 | 253,074 | A | 10,000 | 660,607 | 1.514 | 0.900 | 775.900 |
| remove | head | 0 | down | 1,000 | 48,660 | A | 12,000 | 675,436 | 1.481 | 0.900 | 775.900 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 682,102 | 1.466 | 0.800 | 775.900 |
| remove | random | 0 | up | 1,000 | 50,041 | A | 1,000 | 389,651 | 2.566 | 1.000 | 472.500 |
| remove | random | 0 | up | 5,000 | 253,849 | A | 5,000 | 494,819 | 2.021 | 0.900 | 472.500 |
| remove | random | 0 | up | 10,000 | 510,883 | A | 10,000 | 505,459 | 1.978 | 0.900 | 472.500 |
| remove | random | 0 | up | 15,000 | 762,464 | A | 15,000 | 460,793 | 2.170 | 0.900 | 472.500 |
| remove | random | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 451,302 | 2.216 | 0.900 | 472.500 |
| remove | random | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 462,505 | 2.162 | 0.900 | 472.500 |
| remove | random | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 454,789 | 2.199 | 0.900 | 472.500 |
| remove | random | 0 | down | 15,000 | 754,542 | A | 35,000 | 456,650 | 2.190 | 0.900 | 472.500 |
| remove | random | 0 | down | 10,000 | 504,420 | A | 40,000 | 456,374 | 2.191 | 0.900 | 472.500 |
| remove | random | 0 | down | 5,000 | 253,074 | A | 45,000 | 462,460 | 2.162 | 0.900 | 472.500 |
| remove | random | 0 | down | 1,000 | 48,660 | A | 49,000 | 470,301 | 2.126 | 0.800 | 472.500 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 474,269 | 2.109 | 0.700 | 472.500 |
| remove | tail | 0 | up | 1,000 | 50,041 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 253,849 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 510,883 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 762,464 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,009,832 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,264,057 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,014,321 | A | 2,500 | 723,296 | 1.383 | 0.800 | 20.200 |
| remove | tail | 0 | down | 15,000 | 754,542 | A | 5,000 | 693,953 | 1.441 | 0.800 | 370.400 |
| remove | tail | 0 | down | 10,000 | 504,420 | A | 7,500 | 721,258 | 1.386 | 0.800 | 370.400 |
| remove | tail | 0 | down | 5,000 | 253,074 | A | 10,000 | 731,181 | 1.368 | 0.800 | 370.400 |
| remove | tail | 0 | down | 1,000 | 48,660 | A | 12,000 | 747,226 | 1.338 | 0.800 | 370.400 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 754,098 | 1.326 | 0.700 | 370.400 |
| replace | head | 0 | up | 1,000 | 50,041 | A | 1,000 | 412,065 | 2.427 | 1.200 | 76.600 |
| replace | head | 0 | up | 5,000 | 253,849 | A | 5,000 | 486,869 | 2.054 | 1.200 | 153.800 |
| replace | head | 0 | up | 10,000 | 510,883 | A | 10,000 | 469,096 | 2.132 | 1.100 | 2414.900 |
| replace | head | 0 | up | 15,000 | 762,464 | A | 15,000 | 463,366 | 2.158 | 1.000 | 2414.900 |
| replace | head | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 471,135 | 2.123 | 1.000 | 2414.900 |
| replace | head | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 450,258 | 2.221 | 1.000 | 3415.900 |
| replace | head | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 449,196 | 2.226 | 1.000 | 3415.900 |
| replace | head | 0 | down | 15,000 | 754,542 | A | 35,000 | 452,377 | 2.211 | 1.000 | 3415.900 |
| replace | head | 0 | down | 10,000 | 504,420 | A | 40,000 | 448,313 | 2.231 | 1.000 | 3415.900 |
| replace | head | 0 | down | 5,000 | 253,074 | A | 45,000 | 452,128 | 2.212 | 1.000 | 3415.900 |
| replace | head | 0 | down | 1,000 | 48,660 | A | 49,000 | 458,114 | 2.183 | 1.000 | 3415.900 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 460,957 | 2.169 | 1.000 | 3415.900 |
| replace | random | 0 | up | 1,000 | 50,041 | A | 1,000 | 381,199 | 2.623 | 1.200 | 67.100 |
| replace | random | 0 | up | 5,000 | 253,849 | A | 5,000 | 372,831 | 2.682 | 1.200 | 304.600 |
| replace | random | 0 | up | 10,000 | 510,883 | A | 10,000 | 366,985 | 2.725 | 1.200 | 1251.900 |
| replace | random | 0 | up | 15,000 | 762,464 | A | 15,000 | 335,664 | 2.979 | 1.200 | 1251.900 |
| replace | random | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 334,755 | 2.987 | 1.200 | 1251.900 |
| replace | random | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 334,963 | 2.985 | 1.200 | 1634.100 |
| replace | random | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 330,850 | 3.023 | 1.200 | 1634.100 |
| replace | random | 0 | down | 15,000 | 754,542 | A | 35,000 | 328,263 | 3.046 | 1.200 | 1634.100 |
| replace | random | 0 | down | 10,000 | 504,420 | A | 40,000 | 330,535 | 3.025 | 1.200 | 1634.100 |
| replace | random | 0 | down | 5,000 | 253,074 | A | 45,000 | 334,378 | 2.991 | 1.200 | 1634.100 |
| replace | random | 0 | down | 1,000 | 48,660 | A | 49,000 | 341,344 | 2.930 | 1.100 | 1634.100 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 344,546 | 2.902 | 0.900 | 1634.100 |
| replace | tail | 0 | up | 1,000 | 50,041 | A | 1,000 | 475,534 | 2.103 | 1.100 | 116.100 |
| replace | tail | 0 | up | 5,000 | 253,849 | A | 5,000 | 522,947 | 1.912 | 1.100 | 116.100 |
| replace | tail | 0 | up | 10,000 | 510,883 | A | 10,000 | 541,712 | 1.846 | 1.000 | 190.500 |
| replace | tail | 0 | up | 15,000 | 762,464 | A | 15,000 | 511,919 | 1.953 | 1.000 | 190.500 |
| replace | tail | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 482,720 | 2.072 | 1.000 | 1668.400 |
| replace | tail | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 498,688 | 2.005 | 1.000 | 1668.400 |
| replace | tail | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 398,664 | 2.508 | 1.000 | 1668.400 |
| replace | tail | 0 | down | 15,000 | 754,542 | A | 35,000 | 264,655 | 3.779 | 1.000 | 1668.400 |
| replace | tail | 0 | down | 10,000 | 504,420 | A | 40,000 | 271,184 | 3.688 | 1.000 | 1668.400 |
| replace | tail | 0 | down | 5,000 | 253,074 | A | 45,000 | 254,348 | 3.932 | 1.000 | 1668.400 |
| replace | tail | 0 | down | 1,000 | 48,660 | A | 49,000 | 258,690 | 3.866 | 1.000 | 1668.400 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 261,785 | 3.820 | 0.900 | 1668.400 |
| value | head | 0 | up | 1,000 | 50,041 | A | 1,000 | 1,450,958 | 0.689 | 0.100 | 240.400 |
| value | head | 0 | up | 5,000 | 253,849 | A | 5,000 | 2,505,136 | 0.399 | 0.100 | 240.400 |
| value | head | 0 | up | 10,000 | 510,883 | A | 10,000 | 2,899,980 | 0.345 | 0.100 | 240.400 |
| value | head | 0 | up | 15,000 | 762,464 | A | 15,000 | 2,812,623 | 0.356 | 0.100 | 240.400 |
| value | head | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 2,827,654 | 0.354 | 0.100 | 240.400 |
| value | head | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 2,940,208 | 0.340 | 0.100 | 240.400 |
| value | head | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 2,805,757 | 0.356 | 0.100 | 240.400 |
| value | head | 0 | down | 15,000 | 754,542 | A | 35,000 | 2,722,909 | 0.367 | 0.100 | 240.400 |
| value | head | 0 | down | 10,000 | 504,420 | A | 40,000 | 2,660,105 | 0.376 | 0.100 | 240.400 |
| value | head | 0 | down | 5,000 | 253,074 | A | 45,000 | 2,621,553 | 0.381 | 0.100 | 240.400 |
| value | head | 0 | down | 1,000 | 48,660 | A | 49,000 | 2,604,817 | 0.384 | 0.100 | 240.400 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,613,573 | 0.383 | 0.100 | 240.400 |
| value | random | 0 | up | 1,000 | 50,041 | A | 1,000 | 1,315,443 | 0.760 | 0.100 | 21.900 |
| value | random | 0 | up | 5,000 | 253,849 | A | 5,000 | 1,073,330 | 0.932 | 0.100 | 30.000 |
| value | random | 0 | up | 10,000 | 510,883 | A | 10,000 | 1,035,776 | 0.965 | 0.100 | 30.000 |
| value | random | 0 | up | 15,000 | 762,464 | A | 15,000 | 858,993 | 1.164 | 0.100 | 50.700 |
| value | random | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 844,891 | 1.184 | 0.100 | 79.200 |
| value | random | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 856,343 | 1.168 | 0.100 | 79.200 |
| value | random | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 839,612 | 1.191 | 0.100 | 79.200 |
| value | random | 0 | down | 15,000 | 754,542 | A | 35,000 | 837,788 | 1.194 | 0.100 | 79.200 |
| value | random | 0 | down | 10,000 | 504,420 | A | 40,000 | 839,475 | 1.191 | 0.100 | 79.200 |
| value | random | 0 | down | 5,000 | 253,074 | A | 45,000 | 849,371 | 1.177 | 0.100 | 79.200 |
| value | random | 0 | down | 1,000 | 48,660 | A | 49,000 | 866,563 | 1.154 | 0.100 | 80.600 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 875,529 | 1.142 | 0.100 | 80.600 |
| value | tail | 0 | up | 1,000 | 50,041 | A | 1,000 | 4,504,505 | 0.222 | 0.100 | 37.100 |
| value | tail | 0 | up | 5,000 | 253,849 | A | 5,000 | 5,057,146 | 0.198 | 0.100 | 37.100 |
| value | tail | 0 | up | 10,000 | 510,883 | A | 10,000 | 5,560,807 | 0.180 | 0.100 | 37.100 |
| value | tail | 0 | up | 15,000 | 762,464 | A | 15,000 | 5,515,517 | 0.181 | 0.100 | 67.400 |
| value | tail | 0 | up | 20,000 | 1,009,832 | A | 20,000 | 5,701,904 | 0.175 | 0.000 | 67.400 |
| value | tail | 0 | up | 25,000 | 1,264,057 | A | 25,000 | 5,896,226 | 0.170 | 0.000 | 67.400 |
| value | tail | 0 | down | 20,000 | 1,014,321 | A | 30,000 | 5,447,216 | 0.184 | 0.000 | 67.400 |
| value | tail | 0 | down | 15,000 | 754,542 | A | 35,000 | 5,241,797 | 0.191 | 0.000 | 67.400 |
| value | tail | 0 | down | 10,000 | 504,420 | A | 40,000 | 5,048,975 | 0.198 | 0.000 | 67.400 |
| value | tail | 0 | down | 5,000 | 253,074 | A | 45,000 | 4,899,399 | 0.204 | 0.000 | 67.400 |
| value | tail | 0 | down | 1,000 | 48,660 | A | 49,000 | 4,847,358 | 0.206 | 0.000 | 67.400 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 4,856,302 | 0.206 | 0.000 | 67.400 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,173 | 460.200 |
| create | — | 0 | up | 5,000 | A | 1 | 977 | 1023.400 |
| create | — | 0 | up | 10,000 | A | 1 | 585 | 1709.500 |
| create | — | 0 | up | 15,000 | A | 1 | 377 | 2650.300 |
| create | — | 0 | up | 20,000 | A | 1 | 306 | 3263.000 |
| create | — | 0 | up | 25,000 | A | 1 | 218 | 4576.800 |
| create | — | 0 | down | 20,000 | A | 1 | 254 | 3937.100 |
| create | — | 0 | down | 15,000 | A | 1 | 375 | 2666.900 |
| create | — | 0 | down | 10,000 | A | 1 | 560 | 1785.500 |
| create | — | 0 | down | 5,000 | A | 1 | 1,179 | 848.200 |
| create | — | 0 | down | 1,000 | A | 1 | 7,241 | 138.100 |
| create | — | 0 | down | 0 | A | 1 | 68,966 | 14.500 |
| sequence | — | 0 | up | 1,000 | A | 1 | 379 | 2636.600 |
| sequence | — | 0 | up | 5,000 | A | 1 | 102 | 9842.300 |
| sequence | — | 0 | up | 10,000 | A | 1 | 70 | 14383.900 |
| sequence | — | 0 | up | 15,000 | A | 1 | 63 | 15853.300 |
| sequence | — | 0 | up | 20,000 | A | 1 | 46 | 21527.600 |
| sequence | — | 0 | up | 25,000 | A | 1 | 42 | 23868.400 |
| sequence | — | 0 | down | 20,000 | A | 1 | 55 | 18116.400 |
| sequence | — | 0 | down | 15,000 | A | 1 | 60 | 16748.500 |
| sequence | — | 0 | down | 10,000 | A | 1 | 76 | 13092.100 |
| sequence | — | 0 | down | 5,000 | A | 1 | 108 | 9302.200 |
| sequence | — | 0 | down | 1,000 | A | 1 | 168 | 5938.700 |
| sequence | — | 0 | down | 0 | A | 1 | 871 | 1148.200 |
| values | — | 0 | up | 1,000 | A | 1 | 557 | 1796.600 |
| values | — | 0 | up | 5,000 | A | 1 | 192 | 5219.800 |
| values | — | 0 | up | 10,000 | A | 1 | 44 | 22814.900 |
| values | — | 0 | up | 15,000 | A | 1 | 31 | 32709.200 |
| values | — | 0 | up | 20,000 | A | 1 | 87 | 11501.900 |
| values | — | 0 | up | 25,000 | A | 1 | 93 | 10738.000 |
| values | — | 0 | down | 20,000 | A | 1 | 119 | 8431.800 |
| values | — | 0 | down | 15,000 | A | 1 | 140 | 7162.600 |
| values | — | 0 | down | 10,000 | A | 1 | 230 | 4350.700 |
| values | — | 0 | down | 5,000 | A | 1 | 368 | 2720.500 |
| values | — | 0 | down | 1,000 | A | 1 | 2,350 | 425.600 |
| values | — | 0 | down | 0 | A | 1 | 33,557 | 29.800 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.614 | 0.232 | 0.382 |
| 0 | up | 5000 | 3.104 | 1.168 | 1.937 |
| 0 | up | 10000 | 6.240 | 2.342 | 3.898 |
| 0 | up | 15000 | 9.457 | 3.640 | 5.817 |
| 0 | up | 20000 | 12.811 | 5.107 | 7.704 |
| 0 | up | 25000 | 16.275 | 6.631 | 9.644 |
| 0 | down | 20000 | 13.346 | 5.607 | 7.739 |
| 0 | down | 15000 | 9.885 | 4.128 | 5.757 |
| 0 | down | 10000 | 7.141 | 3.292 | 3.848 |
| 0 | down | 5000 | 4.088 | 2.157 | 1.931 |
| 0 | down | 1000 | 1.786 | 1.414 | 0.371 |
| 0 | down | 0 | 1.225 | 1.225 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 50,041 | 0.402 | 421.672 | 8.427 | 121.070 | 15.536 |
| 0 | up | A | 5,000 | 5,000 | 253,849 | 2.039 | 427.629 | 8.423 | 154.484 | 19.626 |
| 0 | up | A | 10,000 | 10,000 | 510,883 | 4.110 | 430.944 | 8.435 | 196.258 | 24.558 |
| 0 | up | A | 15,000 | 15,000 | 762,464 | 6.157 | 430.382 | 8.467 | 209.602 | 29.405 |
| 0 | up | A | 20,000 | 20,000 | 1,009,832 | 8.173 | 428.522 | 8.487 | 281.598 | 34.174 |
| 0 | up | A | 25,000 | 25,000 | 1,264,057 | 10.246 | 429.759 | 8.500 | 297.109 | 39.018 |
| 0 | down | A | 20,000 | 20,000 | 1,014,321 | 8.275 | 433.859 | 8.555 | 296.945 | 34.269 |
| 0 | down | A | 15,000 | 15,000 | 754,542 | 6.164 | 430.905 | 8.566 | 300.496 | 29.355 |
| 0 | down | A | 10,000 | 10,000 | 504,420 | 4.110 | 430.931 | 8.543 | 299.395 | 24.607 |
| 0 | down | A | 5,000 | 5,000 | 253,074 | 2.052 | 430.392 | 8.503 | 298.945 | 19.840 |
| 0 | down | A | 1,000 | 1,000 | 48,660 | 0.393 | 412.560 | 8.478 | 296.082 | 15.964 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 297.020 | 14.916 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 50041 | 184359 | 184.359 | 3.684 | 272.12 | 14.48 | 162.13 | 12.35 |
| 0 | up | A | 5000 | 253849 | 1210131 | 242.026 | 4.767 | 1631.56 | 73.59 | 824.15 | 61.70 |
| 0 | up | A | 10000 | 510883 | 2452112 | 245.211 | 4.800 | 3291.52 | 148.51 | 1662.88 | 124.76 |
| 0 | up | A | 15000 | 762464 | 3718728 | 247.915 | 4.877 | 4953.57 | 226.18 | 3565.41 | 200.21 |
| 0 | up | A | 20000 | 1009832 | 4967551 | 248.378 | 4.919 | 7097.32 | 310.72 | 5120.56 | 263.24 |
| 0 | up | A | 25000 | 1264057 | 6253640 | 250.146 | 4.947 | 9263.03 | 392.29 | 6552.58 | 334.88 |
| 0 | down | A | 20000 | 1014321 | 5127975 | 256.399 | 5.056 | 7587.58 | 326.56 | 5325.66 | 277.90 |
| 0 | down | A | 15000 | 754542 | 3826315 | 255.088 | 5.071 | 5697.28 | 247.45 | 3981.92 | 209.66 |
| 0 | down | A | 10000 | 504420 | 2533733 | 253.373 | 5.023 | 3814.68 | 164.99 | 2660.13 | 140.01 |
| 0 | down | A | 5000 | 253074 | 1246106 | 249.221 | 4.924 | 1903.81 | 79.91 | 1330.40 | 67.87 |
| 0 | down | A | 1000 | 48660 | 232371 | 232.371 | 4.775 | 363.99 | 15.96 | 255.01 | 13.61 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 429.466 | 8.475 | 247.191 | 4.878 |
| 0 | A | scaleDown | 431.659 | 8.549 | 254.245 | 5.036 |
| 0 | A | fullLifecycle | 430.346 | 8.505 | 250.024 | 4.941 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
