# Large string benchmarks

2026-11-27T20:53:06.847Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2316.71 | 0.00 |
| 1024 | insert.append | array | 13488.57 | 0.00 |
| 1024 | replace | array | 3374.78 | 0.00 |
| 1024 | remove | array | 1141.60 | 0.00 |
| 1024 | remove.middle | array | 1917.27 | 0.00 |
| 1024 | replace.middle | array | 2380.30 | 0.00 |
| 1024 | apply | array | 1131.23 | 0.00 |
| 1024 | apply.array | array | 708.39 | 0.00 |
| 1024 | concurrent.apply | array | 65691.34 | 0.00 |
| 1024 | merge | array | 3662.06 | 0.00 |
| 1024 | create | array | 3604.97 | 0.00 |
| 1024 | value.random | array | 79.23 | 0.00 |
| 1024 | values.range | array | 137.28 | 0.00 |
| 1024 | values.array | array | 1500.85 | 0.00 |
| 1024 | values.text | array | 16316.50 | 0.00 |
| 1024 | sequence.array | array | 3129.42 | 0.00 |
| 1024 | sequence.text | array | 16167.10 | 0.00 |
| 1024 | sequence.edited.text | array | 16580.17 | 0.00 |
| 1024 | sequence.masked.text | array | 15502.85 | 0.00 |
| 1024 | insert | string | 723.56 | 0.00 |
| 1024 | insert.append | string | 7194.59 | 0.00 |
| 1024 | replace | string | 2017.38 | 0.00 |
| 1024 | remove | string | 1264.71 | 0.00 |
| 1024 | remove.middle | string | 1264.72 | 0.00 |
| 1024 | replace.middle | string | 1688.76 | 0.00 |
| 1024 | apply | string | 1294.79 | 0.00 |
| 1024 | apply.array | string | 3153.01 | 0.00 |
| 1024 | concurrent.apply | string | 5887.03 | 0.00 |
| 1024 | merge | string | 1672.19 | 0.00 |
| 1024 | create | string | 1265.21 | 0.00 |
| 1024 | value.random | string | 89.97 | 0.00 |
| 1024 | values.range | string | 324.37 | 0.00 |
| 1024 | values.array | string | 3404.38 | 0.00 |
| 1024 | values.text | string | 113.11 | 0.00 |
| 1024 | sequence.array | string | 2715.93 | 0.00 |
| 1024 | sequence.text | string | 321.92 | 0.00 |
| 1024 | sequence.edited.text | string | 1194.90 | 0.00 |
| 1024 | sequence.masked.text | string | 4417.14 | 0.00 |
| 65536 | insert | array | 301303.61 | 0.00 |
| 65536 | insert.append | array | 1160086.36 | 0.00 |
| 65536 | replace | array | 275202.20 | 0.00 |
| 65536 | remove | array | 2730.49 | 0.00 |
| 65536 | remove.middle | array | 244169.72 | 0.00 |
| 65536 | replace.middle | array | 241645.87 | 0.00 |
| 65536 | apply | array | 806.35 | 0.00 |
| 65536 | apply.array | array | 583.87 | 0.00 |
| 65536 | concurrent.apply | array | 4290866.67 | 0.00 |
| 65536 | merge | array | 238456.19 | 0.00 |
| 65536 | create | array | 212211.02 | 0.00 |
| 65536 | value.random | array | 51.48 | 0.00 |
| 65536 | values.range | array | 144.22 | 0.00 |
| 65536 | values.array | array | 203867.46 | 0.00 |
| 65536 | values.text | array | 828825.81 | 0.00 |
| 65536 | sequence.array | array | 209613.49 | 0.00 |
| 65536 | sequence.text | array | 809319.35 | 0.00 |
| 65536 | sequence.edited.text | array | 705402.78 | 0.00 |
| 65536 | sequence.masked.text | array | 724657.14 | 0.00 |
| 65536 | insert | string | 357.50 | 0.00 |
| 65536 | insert.append | string | 21697.48 | 0.00 |
| 65536 | replace | string | 1287.45 | 0.00 |
| 65536 | remove | string | 951.11 | 0.00 |
| 65536 | remove.middle | string | 987.19 | 0.00 |
| 65536 | replace.middle | string | 1377.64 | 0.00 |
| 65536 | apply | string | 804.98 | 0.00 |
| 65536 | apply.array | string | 279697.66 | 0.00 |
| 65536 | concurrent.apply | string | 138007.69 | 0.00 |
| 65536 | merge | string | 1109.24 | 0.00 |
| 65536 | create | string | 1018.84 | 0.00 |
| 65536 | value.random | string | 51.70 | 0.00 |
| 65536 | values.range | string | 150.92 | 0.00 |
| 65536 | values.array | string | 236662.26 | 0.00 |
| 65536 | values.text | string | 70.08 | 0.00 |
| 65536 | sequence.array | string | 262814.84 | 0.00 |
| 65536 | sequence.text | string | 205.76 | 0.00 |
| 65536 | sequence.edited.text | string | 6503.95 | 0.00 |
| 65536 | sequence.masked.text | string | 3247.13 | 0.00 |
| 1048576 | insert | array | 3278850.00 | 0.00 |
| 1048576 | insert.append | array | 25222200.00 | 0.00 |
| 1048576 | replace | array | 3175287.50 | 0.00 |
| 1048576 | remove | array | 21540.14 | 0.00 |
| 1048576 | remove.middle | array | 3000988.89 | 0.00 |
| 1048576 | replace.middle | array | 2950036.36 | 0.00 |
| 1048576 | apply | array | 1112.72 | 0.00 |
| 1048576 | apply.array | array | 795.73 | 0.00 |
| 1048576 | concurrent.apply | array | 68508200.00 | 0.00 |
| 1048576 | merge | array | 3167237.50 | 0.00 |
| 1048576 | create | array | 3165325.00 | 0.00 |
| 1048576 | value.random | array | 45.94 | 0.00 |
| 1048576 | values.range | array | 103.32 | 0.00 |
| 1048576 | values.array | array | 2191475.00 | 0.00 |
| 1048576 | values.text | array | 12960800.00 | 0.00 |
| 1048576 | sequence.array | array | 2339290.91 | 0.00 |
| 1048576 | sequence.text | array | 44608100.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 50866600.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 47191150.00 | 0.00 |
| 1048576 | insert | string | 422.50 | 0.00 |
| 1048576 | insert.append | string | 532497.87 | 0.00 |
| 1048576 | replace | string | 1586.94 | 0.00 |
| 1048576 | remove | string | 987.00 | 0.00 |
| 1048576 | remove.middle | string | 910.44 | 0.00 |
| 1048576 | replace.middle | string | 1306.76 | 0.00 |
| 1048576 | apply | string | 851.56 | 0.00 |
| 1048576 | apply.array | string | 3209825.00 | 0.00 |
| 1048576 | concurrent.apply | string | 1503305.88 | 0.00 |
| 1048576 | merge | string | 1135.25 | 0.00 |
| 1048576 | create | string | 878.21 | 0.00 |
| 1048576 | value.random | string | 48.37 | 0.00 |
| 1048576 | values.range | string | 154.84 | 0.00 |
| 1048576 | values.array | string | 3192137.50 | 0.00 |
| 1048576 | values.text | string | 86.61 | 0.00 |
| 1048576 | sequence.array | string | 3144825.00 | 0.00 |
| 1048576 | sequence.text | string | 166.19 | 0.00 |
| 1048576 | sequence.edited.text | string | 88010.53 | 0.00 |
| 1048576 | sequence.masked.text | string | 3341.33 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
