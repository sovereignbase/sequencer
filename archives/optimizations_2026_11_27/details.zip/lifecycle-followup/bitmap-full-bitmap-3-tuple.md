# Tuple benchmarks

2026-11-27T20:52:52.566Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 2,640,209 | 2,321,291 | 0.88× |
| 2 | create.sequence | 981,425 | 826,781 | 0.84× |
| 2 | replace.random | 1,259,283 | 1,456,773 | 1.16× |
| 2 | apply.replace | 671,753 | 874,324 | 1.30× |
| 2 | apply.duplicate | 1,617,396 | 1,529,127 | 0.95× |
| 2 | merge.duplicate | 1,234,467 | 1,268,367 | 1.03× |
| 2 | length | 83,792,567 | 108,141,391 | 1.29× |
| 2 | value.random | 32,236,897 | 54,073,776 | 1.68× |
| 2 | values | 13,338,794 | 12,960,890 | 0.97× |
| 2 | sequence | 3,040,808 | 2,891,045 | 0.95× |
| 4 | create.empty | 2,216,702 | 2,331,838 | 1.05× |
| 4 | create.sequence | 684,522 | 717,941 | 1.05× |
| 4 | replace.random | 936,075 | 1,491,804 | 1.59× |
| 4 | apply.replace | 634,192 | 909,527 | 1.43× |
| 4 | apply.duplicate | 1,543,141 | 1,670,424 | 1.08× |
| 4 | merge.duplicate | 1,251,891 | 1,212,966 | 0.97× |
| 4 | length | 30,061,811 | 32,764,598 | 1.09× |
| 4 | value.random | 23,464,189 | 43,610,202 | 1.86× |
| 4 | values | 6,523,137 | 6,839,885 | 1.05× |
| 4 | sequence | 2,539,347 | 2,316,092 | 0.91× |
| 8 | create.empty | 2,358,064 | 2,315,699 | 0.98× |
| 8 | create.sequence | 442,461 | 529,204 | 1.20× |
| 8 | replace.random | 1,003,916 | 1,326,847 | 1.32× |
| 8 | apply.replace | 647,429 | 983,205 | 1.52× |
| 8 | apply.duplicate | 1,723,830 | 1,735,590 | 1.01× |
| 8 | merge.duplicate | 931,565 | 849,559 | 0.91× |
| 8 | length | 38,125,230 | 40,150,097 | 1.05× |
| 8 | value.random | 19,298,566 | 54,725,064 | 2.84× |
| 8 | values | 4,285,432 | 4,767,319 | 1.11× |
| 8 | sequence | 1,715,281 | 1,859,213 | 1.08× |
| 100 | create.empty | 2,246,823 | 2,144,024 | 0.95× |
| 100 | create.sequence | 63,416 | 69,515 | 1.10× |
| 100 | replace.random | 911,319 | 1,442,824 | 1.58× |
| 100 | apply.replace | 673,485 | 1,027,811 | 1.53× |
| 100 | apply.duplicate | 1,794,892 | 1,658,984 | 0.92× |
| 100 | merge.duplicate | 112,123 | 75,734 | 0.68× |
| 100 | length | 34,057,196 | 38,914,169 | 1.14× |
| 100 | value.random | 11,831,055 | 51,601,423 | 4.36× |
| 100 | values | 537,101 | 671,896 | 1.25× |
| 100 | sequence | 181,496 | 175,385 | 0.97× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
