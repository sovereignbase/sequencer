# Words benchmarks

2026-11-27T20:53:25.108Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 33,925 | 145,357 | 153 |
| append | packed | 5.90 | 3.61 | 13.98 | 31,394 | 168,899 | 256 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,794 | 617 | 157 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 26,252 | 1,264 | 218 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 394 | 193 | 91 |
| random | packed | 49.58 | 35.38 | 23.45 | 13,925 | 492 | 123 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 587 | 209 | 94 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 16,901 | 430 | 139 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 443.07 | 0.00 |
| append | numeric | encode | 29476.43 | 0.00 |
| append | numeric | decode | 3147.40 | 0.00 |
| append | numeric | create | 3640.40 | 0.00 |
| append | numeric | load | 6879.62 | 0.00 |
| append | numeric | apply | 2832533.33 | 0.00 |
| append | numeric | receive | 6529737.50 | 0.00 |
| append | binary | sequence | 500.59 | 0.00 |
| append | binary | encode | 31853.50 | 0.00 |
| append | binary | decode | 1869.46 | 0.00 |
| append | binary | create | 3107.06 | 0.00 |
| append | binary | load | 5920.69 | 0.00 |
| append | binary | apply | 1860048.15 | 0.00 |
| append | binary | receive | 3906623.08 | 0.00 |
| prepend | numeric | sequence | 518231.96 | 0.00 |
| prepend | numeric | encode | 557467.78 | 0.00 |
| prepend | numeric | decode | 215900.00 | 0.00 |
| prepend | numeric | create | 744130.88 | 0.00 |
| prepend | numeric | load | 1619829.03 | 0.00 |
| prepend | numeric | apply | 4221983.33 | 0.00 |
| prepend | numeric | receive | 6383337.50 | 0.00 |
| prepend | binary | sequence | 489609.71 | 0.00 |
| prepend | binary | encode | 38091.77 | 0.00 |
| prepend | binary | decode | 2899.67 | 0.00 |
| prepend | binary | create | 745338.24 | 0.00 |
| prepend | binary | load | 791007.81 | 0.00 |
| prepend | binary | apply | 2788311.11 | 0.00 |
| prepend | binary | receive | 4596872.73 | 0.00 |
| random | numeric | sequence | 1038385.71 | 0.00 |
| random | numeric | encode | 2538160.00 | 0.00 |
| random | numeric | decode | 788201.56 | 0.00 |
| random | numeric | create | 1885774.07 | 0.00 |
| random | numeric | load | 5168660.00 | 0.00 |
| random | numeric | apply | 7804528.57 | 0.00 |
| random | numeric | receive | 10956700.00 | 0.00 |
| random | binary | sequence | 857738.98 | 0.00 |
| random | binary | encode | 71814.88 | 0.00 |
| random | binary | decode | 1602.05 | 0.00 |
| random | binary | create | 2058416.00 | 0.00 |
| random | binary | load | 2032860.00 | 0.00 |
| random | binary | apply | 6405112.50 | 0.00 |
| random | binary | receive | 8124285.71 | 0.00 |
| concurrent | numeric | sequence | 775646.15 | 0.00 |
| concurrent | numeric | encode | 1704003.33 | 0.00 |
| concurrent | numeric | decode | 800687.30 | 0.00 |
| concurrent | numeric | create | 2419480.95 | 0.00 |
| concurrent | numeric | load | 4782600.00 | 0.00 |
| concurrent | numeric | apply | 6332050.00 | 0.00 |
| concurrent | numeric | receive | 10681560.00 | 0.00 |
| concurrent | binary | sequence | 741645.59 | 0.00 |
| concurrent | binary | encode | 59168.68 | 0.00 |
| concurrent | binary | decode | 2764.79 | 0.00 |
| concurrent | binary | create | 2217908.70 | 0.00 |
| concurrent | binary | load | 2323590.91 | 0.00 |
| concurrent | binary | apply | 5004163.64 | 0.00 |
| concurrent | binary | receive | 7184771.43 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
