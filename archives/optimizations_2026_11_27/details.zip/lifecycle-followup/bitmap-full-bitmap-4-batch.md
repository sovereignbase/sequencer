# Batch benchmarks

2026-11-27T20:58:37.442Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 834,017 | 1,117,402 | 434,342 | 76.05 | 5.99 | 0.012 |
| append | batch | 2,537,212 | 145,985,401 | 198,019,802 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,452,187 | 1,290,378 | 782,095 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 1,185,958 | 1,113,276 | 1,247,505 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 652,543 | 963,732 | 707,197 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 1,258,125 | 1,278,772 | 1,479,874 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 859,488 | 651,579 | 597,479 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 1,049,428 | 1,655,081 | 1,432,870 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,230,365 | 1,024,223 | 753,244 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,107,297 | 1,464,468 | 1,408,798 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,159,555 | 1,204,710 | 857,731 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,281,709 | 1,658,696 | 1,378,186 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 692,821 | 901,659 | 535,899 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 884,819 | 1,069,728 | 1,134,559 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 972,227 | 1,166,396 | 864,946 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 989,299 | 1,719,518 | 1,539,152 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,164,924 | 1,341,877 | 877,116 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 1,065,331 | 1,755,952 | 1,437,522 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 762,951 | 864,516 | 686,189 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 812,634 | 1,216,977 | 1,065,814 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 7.194 | 0.000 |
| append | individual | apply | 5.370 | 0.000 |
| append | individual | receive | 13.814 | 0.000 |
| append | individual | encode | 7.736 | 0.000 |
| append | individual | decode | 9.149 | 0.000 |
| append | batch | author | 2.365 | 0.000 |
| append | batch | apply | 0.041 | 0.000 |
| append | batch | receive | 0.030 | 0.000 |
| append | batch | encode | 0.193 | 0.000 |
| append | batch | decode | 0.106 | 0.000 |
| prepend | individual | author | 4.132 | 0.000 |
| prepend | individual | apply | 4.650 | 0.000 |
| prepend | individual | receive | 7.672 | 0.000 |
| prepend | individual | encode | 6.644 | 0.000 |
| prepend | individual | decode | 7.883 | 0.000 |
| prepend | batch | author | 5.059 | 0.000 |
| prepend | batch | apply | 5.389 | 0.000 |
| prepend | batch | receive | 4.810 | 0.000 |
| prepend | batch | encode | 0.339 | 0.000 |
| prepend | batch | decode | 0.200 | 0.000 |
| random.characters | individual | author | 9.195 | 0.000 |
| random.characters | individual | apply | 6.226 | 0.000 |
| random.characters | individual | receive | 8.484 | 0.000 |
| random.characters | individual | encode | 6.318 | 0.000 |
| random.characters | individual | decode | 8.729 | 0.000 |
| random.characters | batch | author | 4.769 | 0.000 |
| random.characters | batch | apply | 4.692 | 0.000 |
| random.characters | batch | receive | 4.054 | 0.000 |
| random.characters | batch | encode | 0.191 | 0.000 |
| random.characters | batch | decode | 0.102 | 0.000 |
| random.words | individual | author | 6.981 | 0.000 |
| random.words | individual | apply | 9.208 | 0.000 |
| random.words | individual | receive | 10.042 | 0.000 |
| random.words | individual | encode | 6.846 | 0.000 |
| random.words | individual | decode | 9.907 | 0.000 |
| random.words | batch | author | 5.717 | 0.000 |
| random.words | batch | apply | 3.625 | 0.000 |
| random.words | batch | receive | 4.187 | 0.000 |
| random.words | batch | encode | 0.457 | 0.000 |
| random.words | batch | decode | 0.147 | 0.000 |
| concurrent.characters | individual | author | 9.753 | 0.000 |
| concurrent.characters | individual | apply | 11.716 | 0.000 |
| concurrent.characters | individual | receive | 15.931 | 0.000 |
| concurrent.characters | individual | encode | 8.783 | 0.000 |
| concurrent.characters | individual | decode | 11.551 | 0.000 |
| concurrent.characters | batch | author | 10.837 | 0.000 |
| concurrent.characters | batch | apply | 8.194 | 0.000 |
| concurrent.characters | batch | receive | 8.518 | 0.000 |
| concurrent.characters | batch | encode | 0.386 | 0.000 |
| concurrent.characters | batch | decode | 0.130 | 0.000 |
| concurrent.words | individual | author | 10.349 | 0.000 |
| concurrent.words | individual | apply | 9.961 | 0.000 |
| concurrent.words | individual | receive | 13.990 | 0.000 |
| concurrent.words | individual | encode | 8.821 | 0.000 |
| concurrent.words | individual | decode | 13.101 | 0.000 |
| concurrent.words | batch | author | 9.363 | 0.000 |
| concurrent.words | batch | apply | 7.235 | 0.000 |
| concurrent.words | batch | receive | 8.707 | 0.000 |
| concurrent.words | batch | encode | 0.823 | 0.000 |
| concurrent.words | batch | decode | 0.128 | 0.000 |
| concurrent.mixed | individual | author | 17.321 | 0.000 |
| concurrent.mixed | individual | apply | 13.309 | 0.000 |
| concurrent.mixed | individual | receive | 22.392 | 0.000 |
| concurrent.mixed | individual | encode | 8.863 | 0.000 |
| concurrent.mixed | individual | decode | 9.923 | 0.000 |
| concurrent.mixed | batch | author | 13.562 | 0.000 |
| concurrent.mixed | batch | apply | 11.218 | 0.000 |
| concurrent.mixed | batch | receive | 10.577 | 0.000 |
| concurrent.mixed | batch | encode | 0.687 | 0.000 |
| concurrent.mixed | batch | decode | 0.129 | 0.000 |
| causal.characters | individual | author | 12.343 | 0.000 |
| causal.characters | individual | apply | 10.288 | 0.000 |
| causal.characters | individual | receive | 13.874 | 0.000 |
| causal.characters | individual | encode | 7.380 | 0.000 |
| causal.characters | individual | decode | 14.025 | 0.000 |
| causal.characters | batch | author | 12.130 | 0.000 |
| causal.characters | batch | apply | 6.979 | 0.000 |
| causal.characters | batch | receive | 7.796 | 0.000 |
| causal.characters | batch | encode | 0.246 | 0.000 |
| causal.characters | batch | decode | 0.119 | 0.000 |
| causal.words | individual | author | 10.301 | 0.000 |
| causal.words | individual | apply | 8.943 | 0.000 |
| causal.words | individual | receive | 13.681 | 0.000 |
| causal.words | individual | encode | 7.753 | 0.000 |
| causal.words | individual | decode | 11.098 | 0.000 |
| causal.words | batch | author | 11.264 | 0.000 |
| causal.words | batch | apply | 6.834 | 0.000 |
| causal.words | batch | receive | 8.348 | 0.000 |
| causal.words | batch | encode | 0.535 | 0.000 |
| causal.words | batch | decode | 0.108 | 0.000 |
| causal.mixed | individual | author | 15.728 | 0.000 |
| causal.mixed | individual | apply | 13.881 | 0.000 |
| causal.mixed | individual | receive | 17.488 | 0.000 |
| causal.mixed | individual | encode | 7.966 | 0.000 |
| causal.mixed | individual | decode | 9.555 | 0.000 |
| causal.mixed | batch | author | 14.767 | 0.000 |
| causal.mixed | batch | apply | 9.861 | 0.000 |
| causal.mixed | batch | receive | 11.259 | 0.000 |
| causal.mixed | batch | encode | 0.483 | 0.000 |
| causal.mixed | batch | decode | 0.151 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
