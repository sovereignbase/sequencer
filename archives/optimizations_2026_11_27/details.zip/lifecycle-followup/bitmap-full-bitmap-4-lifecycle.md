# Sequencer dynamic lifecycle benchmark

2026-11-27T20:57:05.953Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 202.54 | 165.86 | 56.93 |
| CommonJS | 202.72 | 167.48 | 57.14 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 325,015 | 3.077 | 3.077 | 3.077 | 0.000 | 0: 3.077 | 0: 3.077 |
| apply | random | A | scaleDown | 24,999 | 342,372 | 2.921 | 2.921 | 2.921 | 0.000 | 0: 2.921 | 0: 2.921 |
| apply | random | A | fullLifecycle | 49,999 | 333,467 | 2.999 | 2.999 | 2.999 | 0.000 | 0: 2.999 | 0: 2.999 |
| create | — | A | scaleUp | 7 | 546 | 1832.614 | 1832.614 | 1832.614 | 0.000 | 0: 1832.614 | 0: 1832.614 |
| create | — | A | scaleDown | 6 | 614 | 1629.367 | 1629.367 | 1629.367 | 0.000 | 0: 1629.367 | 0: 1629.367 |
| create | — | A | fullLifecycle | 13 | 575 | 1738.808 | 1738.808 | 1738.808 | 0.000 | 0: 1738.808 | 0: 1738.808 |
| insert | head | A | scaleUp | 12,500 | 1,310,685 | 0.763 | 0.763 | 0.763 | 0.000 | 0: 0.763 | 0: 0.763 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,310,685 | 0.763 | 0.763 | 0.763 | 0.000 | 0: 0.763 | 0: 0.763 |
| insert | random | A | scaleUp | 25,000 | 579,862 | 1.725 | 1.725 | 1.725 | 0.000 | 0: 1.725 | 0: 1.725 |
| insert | random | A | scaleDown | 25,000 | 607,036 | 1.647 | 1.647 | 1.647 | 0.000 | 0: 1.647 | 0: 1.647 |
| insert | random | A | fullLifecycle | 50,000 | 593,138 | 1.686 | 1.686 | 1.686 | 0.000 | 0: 1.686 | 0: 1.686 |
| insert | tail | A | scaleUp | 12,500 | 1,373,053 | 0.728 | 0.728 | 0.728 | 0.000 | 0: 0.728 | 0: 0.728 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,373,053 | 0.728 | 0.728 | 0.728 | 0.000 | 0: 0.728 | 0: 0.728 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 769,056 | 1.300 | 1.300 | 1.300 | 0.000 | 0: 1.300 | 0: 1.300 |
| remove | head | A | fullLifecycle | 12,500 | 769,056 | 1.300 | 1.300 | 1.300 | 0.000 | 0: 1.300 | 0: 1.300 |
| remove | random | A | scaleUp | 25,000 | 512,421 | 1.952 | 1.952 | 1.952 | 0.000 | 0: 1.952 | 0: 1.952 |
| remove | random | A | scaleDown | 25,000 | 522,389 | 1.914 | 1.914 | 1.914 | 0.000 | 0: 1.914 | 0: 1.914 |
| remove | random | A | fullLifecycle | 50,000 | 517,357 | 1.933 | 1.933 | 1.933 | 0.000 | 0: 1.933 | 0: 1.933 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 807,807 | 1.238 | 1.238 | 1.238 | 0.000 | 0: 1.238 | 0: 1.238 |
| remove | tail | A | fullLifecycle | 12,500 | 807,807 | 1.238 | 1.238 | 1.238 | 0.000 | 0: 1.238 | 0: 1.238 |
| replace | head | A | scaleUp | 25,000 | 524,847 | 1.905 | 1.905 | 1.905 | 0.000 | 0: 1.905 | 0: 1.905 |
| replace | head | A | scaleDown | 25,000 | 508,221 | 1.968 | 1.968 | 1.968 | 0.000 | 0: 1.968 | 0: 1.968 |
| replace | head | A | fullLifecycle | 50,000 | 516,400 | 1.936 | 1.936 | 1.936 | 0.000 | 0: 1.936 | 0: 1.936 |
| replace | random | A | scaleUp | 25,000 | 367,725 | 2.719 | 2.719 | 2.719 | 0.000 | 0: 2.719 | 0: 2.719 |
| replace | random | A | scaleDown | 25,000 | 388,874 | 2.572 | 2.572 | 2.572 | 0.000 | 0: 2.572 | 0: 2.572 |
| replace | random | A | fullLifecycle | 50,000 | 378,004 | 2.645 | 2.645 | 2.645 | 0.000 | 0: 2.645 | 0: 2.645 |
| replace | tail | A | scaleUp | 25,000 | 494,989 | 2.020 | 2.020 | 2.020 | 0.000 | 0: 2.020 | 0: 2.020 |
| replace | tail | A | scaleDown | 25,000 | 188,548 | 5.304 | 5.304 | 5.304 | 0.000 | 0: 5.304 | 0: 5.304 |
| replace | tail | A | fullLifecycle | 50,000 | 273,077 | 3.662 | 3.662 | 3.662 | 0.000 | 0: 3.662 | 0: 3.662 |
| sequence | — | A | scaleUp | 6 | 76 | 13143.900 | 13143.900 | 13143.900 | 0.000 | 0: 13143.900 | 0: 13143.900 |
| sequence | — | A | scaleDown | 6 | 94 | 10685.817 | 10685.817 | 10685.817 | 0.000 | 0: 10685.817 | 0: 10685.817 |
| sequence | — | A | fullLifecycle | 12 | 84 | 11914.858 | 11914.858 | 11914.858 | 0.000 | 0: 11914.858 | 0: 11914.858 |
| value | head | A | scaleUp | 25,000 | 3,081,170 | 0.325 | 0.325 | 0.325 | 0.000 | 0: 0.325 | 0: 0.325 |
| value | head | A | scaleDown | 25,000 | 2,439,334 | 0.410 | 0.410 | 0.410 | 0.000 | 0: 0.410 | 0: 0.410 |
| value | head | A | fullLifecycle | 50,000 | 2,722,941 | 0.367 | 0.367 | 0.367 | 0.000 | 0: 0.367 | 0: 0.367 |
| value | random | A | scaleUp | 25,000 | 933,947 | 1.071 | 1.071 | 1.071 | 0.000 | 0: 1.071 | 0: 1.071 |
| value | random | A | scaleDown | 25,000 | 980,823 | 1.020 | 1.020 | 1.020 | 0.000 | 0: 1.020 | 0: 1.020 |
| value | random | A | fullLifecycle | 50,000 | 956,811 | 1.045 | 1.045 | 1.045 | 0.000 | 0: 1.045 | 0: 1.045 |
| value | tail | A | scaleUp | 25,000 | 6,408,942 | 0.156 | 0.156 | 0.156 | 0.000 | 0: 0.156 | 0: 0.156 |
| value | tail | A | scaleDown | 25,000 | 4,274,089 | 0.234 | 0.234 | 0.234 | 0.000 | 0: 0.234 | 0: 0.234 |
| value | tail | A | fullLifecycle | 50,000 | 5,128,205 | 0.195 | 0.195 | 0.195 | 0.000 | 0: 0.195 | 0: 0.195 |
| values | — | A | scaleUp | 6 | 102 | 9799.767 | 9799.767 | 9799.767 | 0.000 | 0: 9799.767 | 0: 9799.767 |
| values | — | A | scaleDown | 6 | 248 | 4037.483 | 4037.483 | 4037.483 | 0.000 | 0: 4037.483 | 0: 4037.483 |
| values | — | A | fullLifecycle | 12 | 145 | 6918.625 | 6918.625 | 6918.625 | 0.000 | 0: 6918.625 | 0: 6918.625 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5400606.000 | 426.364 | 8.479 |
| A | scaleDown | 5 | 4392724.800 | 430.659 | 8.550 |
| A | fullLifecycle | 11 | 4942478.182 | 428.089 | 8.507 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3111164.000 | 245.618 | 4.885 |
| A | scaleDown | 5 | 2587628.000 | 253.689 | 5.036 |
| A | fullLifecycle | 11 | 2873193.091 | 248.859 | 4.946 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 50,671 | A | 1,000 | 275,028 | 3.636 | 1.700 | 60.200 |
| apply | random | 0 | up | 5,000 | 252,715 | A | 5,000 | 314,798 | 3.177 | 1.600 | 445.100 |
| apply | random | 0 | up | 10,000 | 501,654 | A | 10,000 | 316,876 | 3.156 | 1.600 | 776.700 |
| apply | random | 0 | up | 15,000 | 750,657 | A | 15,000 | 328,450 | 3.045 | 1.500 | 776.700 |
| apply | random | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 325,210 | 3.075 | 1.500 | 776.700 |
| apply | random | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 325,015 | 3.077 | 1.500 | 776.700 |
| apply | random | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 325,802 | 3.069 | 1.500 | 776.700 |
| apply | random | 0 | down | 15,000 | 756,010 | A | 35,000 | 327,715 | 3.051 | 1.500 | 776.700 |
| apply | random | 0 | down | 10,000 | 503,964 | A | 40,000 | 327,943 | 3.049 | 1.500 | 776.700 |
| apply | random | 0 | down | 5,000 | 252,028 | A | 45,000 | 326,134 | 3.066 | 1.500 | 2057.200 |
| apply | random | 0 | down | 1,000 | 49,568 | A | 49,000 | 331,322 | 3.018 | 1.300 | 2057.200 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 333,467 | 2.999 | 1.100 | 2057.200 |
| insert | head | 0 | up | 1,000 | 50,671 | A | 500 | 843,739 | 1.185 | 0.300 | 65.900 |
| insert | head | 0 | up | 5,000 | 252,715 | A | 2,500 | 1,109,238 | 0.902 | 0.300 | 65.900 |
| insert | head | 0 | up | 10,000 | 501,654 | A | 5,000 | 1,241,372 | 0.806 | 0.300 | 65.900 |
| insert | head | 0 | up | 15,000 | 750,657 | A | 7,500 | 1,299,444 | 0.770 | 0.300 | 65.900 |
| insert | head | 0 | up | 20,000 | 1,008,112 | A | 10,000 | 1,302,779 | 0.768 | 0.300 | 65.900 |
| insert | head | 0 | up | 25,000 | 1,257,856 | A | 12,500 | 1,310,685 | 0.763 | 0.300 | 65.900 |
| insert | head | 0 | down | 20,000 | 1,007,326 | A | 12,500 | 1,310,685 | 0.763 | 0.300 | 65.900 |
| insert | head | 0 | down | 15,000 | 756,010 | A | 12,500 | 1,310,685 | 0.763 | 0.300 | 65.900 |
| insert | head | 0 | down | 10,000 | 503,964 | A | 12,500 | 1,310,685 | 0.763 | 0.300 | 65.900 |
| insert | head | 0 | down | 5,000 | 252,028 | A | 12,500 | 1,310,685 | 0.763 | 0.300 | 65.900 |
| insert | head | 0 | down | 1,000 | 49,568 | A | 12,500 | 1,310,685 | 0.763 | 0.300 | 65.900 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,310,685 | 0.763 | 0.300 | 65.900 |
| insert | random | 0 | up | 1,000 | 50,671 | A | 1,000 | 576,103 | 1.736 | 0.400 | 311.800 |
| insert | random | 0 | up | 5,000 | 252,715 | A | 5,000 | 632,111 | 1.582 | 0.400 | 311.800 |
| insert | random | 0 | up | 10,000 | 501,654 | A | 10,000 | 591,055 | 1.692 | 0.400 | 1090.700 |
| insert | random | 0 | up | 15,000 | 750,657 | A | 15,000 | 614,578 | 1.627 | 0.400 | 1090.700 |
| insert | random | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 601,256 | 1.663 | 0.400 | 1090.700 |
| insert | random | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 579,862 | 1.725 | 0.400 | 1495.600 |
| insert | random | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 572,776 | 1.746 | 0.400 | 1495.600 |
| insert | random | 0 | down | 15,000 | 756,010 | A | 35,000 | 560,284 | 1.785 | 0.400 | 1495.600 |
| insert | random | 0 | down | 10,000 | 503,964 | A | 40,000 | 570,175 | 1.754 | 0.400 | 1495.600 |
| insert | random | 0 | down | 5,000 | 252,028 | A | 45,000 | 576,803 | 1.734 | 0.400 | 1495.600 |
| insert | random | 0 | down | 1,000 | 49,568 | A | 49,000 | 587,928 | 1.701 | 0.400 | 1495.600 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 593,138 | 1.686 | 0.400 | 1495.600 |
| insert | tail | 0 | up | 1,000 | 50,671 | A | 500 | 606,134 | 1.650 | 0.300 | 426.600 |
| insert | tail | 0 | up | 5,000 | 252,715 | A | 2,500 | 1,109,632 | 0.901 | 0.300 | 426.600 |
| insert | tail | 0 | up | 10,000 | 501,654 | A | 5,000 | 1,268,971 | 0.788 | 0.300 | 426.600 |
| insert | tail | 0 | up | 15,000 | 750,657 | A | 7,500 | 1,349,601 | 0.741 | 0.300 | 426.600 |
| insert | tail | 0 | up | 20,000 | 1,008,112 | A | 10,000 | 1,393,359 | 0.718 | 0.300 | 426.600 |
| insert | tail | 0 | up | 25,000 | 1,257,856 | A | 12,500 | 1,373,053 | 0.728 | 0.300 | 426.600 |
| insert | tail | 0 | down | 20,000 | 1,007,326 | A | 12,500 | 1,373,053 | 0.728 | 0.300 | 426.600 |
| insert | tail | 0 | down | 15,000 | 756,010 | A | 12,500 | 1,373,053 | 0.728 | 0.300 | 426.600 |
| insert | tail | 0 | down | 10,000 | 503,964 | A | 12,500 | 1,373,053 | 0.728 | 0.300 | 426.600 |
| insert | tail | 0 | down | 5,000 | 252,028 | A | 12,500 | 1,373,053 | 0.728 | 0.300 | 426.600 |
| insert | tail | 0 | down | 1,000 | 49,568 | A | 12,500 | 1,373,053 | 0.728 | 0.300 | 426.600 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,373,053 | 0.728 | 0.300 | 426.600 |
| remove | head | 0 | up | 1,000 | 50,671 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 252,715 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 501,654 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 750,657 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,008,112 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,257,856 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,007,326 | A | 2,500 | 748,257 | 1.336 | 0.900 | 28.900 |
| remove | head | 0 | down | 15,000 | 756,010 | A | 5,000 | 746,146 | 1.340 | 0.800 | 52.800 |
| remove | head | 0 | down | 10,000 | 503,964 | A | 7,500 | 717,497 | 1.394 | 0.800 | 624.400 |
| remove | head | 0 | down | 5,000 | 252,028 | A | 10,000 | 742,523 | 1.347 | 0.800 | 624.400 |
| remove | head | 0 | down | 1,000 | 49,568 | A | 12,000 | 763,072 | 1.310 | 0.700 | 624.400 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 769,056 | 1.300 | 0.700 | 624.400 |
| remove | random | 0 | up | 1,000 | 50,671 | A | 1,000 | 444,781 | 2.248 | 0.800 | 326.600 |
| remove | random | 0 | up | 5,000 | 252,715 | A | 5,000 | 521,436 | 1.918 | 0.800 | 326.600 |
| remove | random | 0 | up | 10,000 | 501,654 | A | 10,000 | 505,784 | 1.977 | 0.800 | 347.900 |
| remove | random | 0 | up | 15,000 | 750,657 | A | 15,000 | 519,606 | 1.925 | 0.800 | 347.900 |
| remove | random | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 511,283 | 1.956 | 0.800 | 347.900 |
| remove | random | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 512,421 | 1.952 | 0.800 | 347.900 |
| remove | random | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 509,437 | 1.963 | 0.800 | 347.900 |
| remove | random | 0 | down | 15,000 | 756,010 | A | 35,000 | 506,513 | 1.974 | 0.800 | 347.900 |
| remove | random | 0 | down | 10,000 | 503,964 | A | 40,000 | 499,457 | 2.002 | 0.800 | 1238.500 |
| remove | random | 0 | down | 5,000 | 252,028 | A | 45,000 | 505,432 | 1.979 | 0.800 | 1238.500 |
| remove | random | 0 | down | 1,000 | 49,568 | A | 49,000 | 513,339 | 1.948 | 0.800 | 1238.500 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 517,357 | 1.933 | 0.700 | 1238.500 |
| remove | tail | 0 | up | 1,000 | 50,671 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 252,715 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 501,654 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 750,657 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,008,112 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,257,856 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,007,326 | A | 2,500 | 714,592 | 1.399 | 0.800 | 37.200 |
| remove | tail | 0 | down | 15,000 | 756,010 | A | 5,000 | 747,619 | 1.338 | 0.800 | 37.200 |
| remove | tail | 0 | down | 10,000 | 503,964 | A | 7,500 | 768,766 | 1.301 | 0.700 | 46.000 |
| remove | tail | 0 | down | 5,000 | 252,028 | A | 10,000 | 777,091 | 1.287 | 0.700 | 156.600 |
| remove | tail | 0 | down | 1,000 | 49,568 | A | 12,000 | 800,075 | 1.250 | 0.700 | 156.600 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 807,807 | 1.238 | 0.700 | 156.600 |
| replace | head | 0 | up | 1,000 | 50,671 | A | 1,000 | 426,967 | 2.342 | 1.100 | 85.300 |
| replace | head | 0 | up | 5,000 | 252,715 | A | 5,000 | 429,225 | 2.330 | 1.100 | 1350.400 |
| replace | head | 0 | up | 10,000 | 501,654 | A | 10,000 | 491,577 | 2.034 | 1.100 | 1350.400 |
| replace | head | 0 | up | 15,000 | 750,657 | A | 15,000 | 506,044 | 1.976 | 1.100 | 1350.400 |
| replace | head | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 519,222 | 1.926 | 1.100 | 1350.400 |
| replace | head | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 524,847 | 1.905 | 1.100 | 1350.400 |
| replace | head | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 522,624 | 1.913 | 1.100 | 1350.400 |
| replace | head | 0 | down | 15,000 | 756,010 | A | 35,000 | 518,985 | 1.927 | 1.100 | 1350.400 |
| replace | head | 0 | down | 10,000 | 503,964 | A | 40,000 | 519,786 | 1.924 | 1.100 | 1350.400 |
| replace | head | 0 | down | 5,000 | 252,028 | A | 45,000 | 511,659 | 1.954 | 1.100 | 1350.400 |
| replace | head | 0 | down | 1,000 | 49,568 | A | 49,000 | 513,918 | 1.946 | 1.000 | 1350.400 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 516,400 | 1.936 | 1.000 | 1350.400 |
| replace | random | 0 | up | 1,000 | 50,671 | A | 1,000 | 277,654 | 3.602 | 1.100 | 1052.200 |
| replace | random | 0 | up | 5,000 | 252,715 | A | 5,000 | 355,634 | 2.812 | 1.100 | 1052.200 |
| replace | random | 0 | up | 10,000 | 501,654 | A | 10,000 | 366,428 | 2.729 | 1.100 | 1052.200 |
| replace | random | 0 | up | 15,000 | 750,657 | A | 15,000 | 364,765 | 2.741 | 1.100 | 1052.200 |
| replace | random | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 366,286 | 2.730 | 1.100 | 1052.200 |
| replace | random | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 367,725 | 2.719 | 1.100 | 1052.200 |
| replace | random | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 362,671 | 2.757 | 1.100 | 1437.500 |
| replace | random | 0 | down | 15,000 | 756,010 | A | 35,000 | 360,426 | 2.774 | 1.100 | 1437.500 |
| replace | random | 0 | down | 10,000 | 503,964 | A | 40,000 | 364,828 | 2.741 | 1.100 | 1437.500 |
| replace | random | 0 | down | 5,000 | 252,028 | A | 45,000 | 367,863 | 2.718 | 1.100 | 1437.500 |
| replace | random | 0 | down | 1,000 | 49,568 | A | 49,000 | 374,852 | 2.668 | 1.000 | 1437.500 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 378,004 | 2.645 | 0.900 | 1437.500 |
| replace | tail | 0 | up | 1,000 | 50,671 | A | 1,000 | 478,286 | 2.091 | 1.100 | 107.100 |
| replace | tail | 0 | up | 5,000 | 252,715 | A | 5,000 | 474,798 | 2.106 | 1.100 | 1140.400 |
| replace | tail | 0 | up | 10,000 | 501,654 | A | 10,000 | 460,787 | 2.170 | 1.100 | 2260.000 |
| replace | tail | 0 | up | 15,000 | 750,657 | A | 15,000 | 489,208 | 2.044 | 1.000 | 2260.000 |
| replace | tail | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 479,886 | 2.084 | 1.000 | 2260.000 |
| replace | tail | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 494,989 | 2.020 | 1.000 | 2260.000 |
| replace | tail | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 419,767 | 2.382 | 1.000 | 2260.000 |
| replace | tail | 0 | down | 15,000 | 756,010 | A | 35,000 | 271,550 | 3.683 | 1.000 | 2260.000 |
| replace | tail | 0 | down | 10,000 | 503,964 | A | 40,000 | 281,579 | 3.551 | 1.000 | 2260.000 |
| replace | tail | 0 | down | 5,000 | 252,028 | A | 45,000 | 266,459 | 3.753 | 1.000 | 2260.000 |
| replace | tail | 0 | down | 1,000 | 49,568 | A | 49,000 | 270,180 | 3.701 | 0.800 | 2260.000 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 273,077 | 3.662 | 0.800 | 2260.000 |
| value | head | 0 | up | 1,000 | 50,671 | A | 1,000 | 1,109,878 | 0.901 | 0.100 | 531.200 |
| value | head | 0 | up | 5,000 | 252,715 | A | 5,000 | 2,265,108 | 0.441 | 0.100 | 531.200 |
| value | head | 0 | up | 10,000 | 501,654 | A | 10,000 | 2,644,733 | 0.378 | 0.100 | 531.200 |
| value | head | 0 | up | 15,000 | 750,657 | A | 15,000 | 2,888,615 | 0.346 | 0.100 | 531.200 |
| value | head | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 2,992,534 | 0.334 | 0.100 | 531.200 |
| value | head | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 3,081,170 | 0.325 | 0.100 | 531.200 |
| value | head | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 2,935,967 | 0.341 | 0.100 | 531.200 |
| value | head | 0 | down | 15,000 | 756,010 | A | 35,000 | 2,836,489 | 0.353 | 0.100 | 531.200 |
| value | head | 0 | down | 10,000 | 503,964 | A | 40,000 | 2,783,771 | 0.359 | 0.100 | 531.200 |
| value | head | 0 | down | 5,000 | 252,028 | A | 45,000 | 2,735,712 | 0.366 | 0.100 | 531.200 |
| value | head | 0 | down | 1,000 | 49,568 | A | 49,000 | 2,717,045 | 0.368 | 0.100 | 531.200 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,722,941 | 0.367 | 0.100 | 531.200 |
| value | random | 0 | up | 1,000 | 50,671 | A | 1,000 | 1,319,958 | 0.758 | 0.100 | 28.300 |
| value | random | 0 | up | 5,000 | 252,715 | A | 5,000 | 1,037,947 | 0.963 | 0.100 | 36.400 |
| value | random | 0 | up | 10,000 | 501,654 | A | 10,000 | 947,751 | 1.055 | 0.100 | 56.200 |
| value | random | 0 | up | 15,000 | 750,657 | A | 15,000 | 947,885 | 1.055 | 0.100 | 56.200 |
| value | random | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 946,602 | 1.056 | 0.100 | 56.200 |
| value | random | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 933,947 | 1.071 | 0.100 | 93.600 |
| value | random | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 929,645 | 1.076 | 0.100 | 93.600 |
| value | random | 0 | down | 15,000 | 756,010 | A | 35,000 | 920,418 | 1.086 | 0.100 | 93.600 |
| value | random | 0 | down | 10,000 | 503,964 | A | 40,000 | 925,018 | 1.081 | 0.100 | 93.600 |
| value | random | 0 | down | 5,000 | 252,028 | A | 45,000 | 931,691 | 1.073 | 0.100 | 93.600 |
| value | random | 0 | down | 1,000 | 49,568 | A | 49,000 | 948,042 | 1.055 | 0.100 | 93.600 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 956,811 | 1.045 | 0.100 | 93.600 |
| value | tail | 0 | up | 1,000 | 50,671 | A | 1,000 | 5,449,591 | 0.183 | 0.100 | 3.100 |
| value | tail | 0 | up | 5,000 | 252,715 | A | 5,000 | 5,609,783 | 0.178 | 0.100 | 4.800 |
| value | tail | 0 | up | 10,000 | 501,654 | A | 10,000 | 5,763,357 | 0.174 | 0.100 | 22.000 |
| value | tail | 0 | up | 15,000 | 750,657 | A | 15,000 | 6,098,553 | 0.164 | 0.000 | 43.100 |
| value | tail | 0 | up | 20,000 | 1,008,112 | A | 20,000 | 6,263,113 | 0.160 | 0.000 | 43.100 |
| value | tail | 0 | up | 25,000 | 1,257,856 | A | 25,000 | 6,408,942 | 0.156 | 0.000 | 43.100 |
| value | tail | 0 | down | 20,000 | 1,007,326 | A | 30,000 | 5,934,014 | 0.169 | 0.000 | 43.100 |
| value | tail | 0 | down | 15,000 | 756,010 | A | 35,000 | 5,584,096 | 0.179 | 0.000 | 43.100 |
| value | tail | 0 | down | 10,000 | 503,964 | A | 40,000 | 5,349,882 | 0.187 | 0.000 | 43.100 |
| value | tail | 0 | down | 5,000 | 252,028 | A | 45,000 | 5,180,512 | 0.193 | 0.000 | 43.100 |
| value | tail | 0 | down | 1,000 | 49,568 | A | 49,000 | 5,126,542 | 0.195 | 0.000 | 43.100 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,128,205 | 0.195 | 0.000 | 43.100 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,614 | 382.600 |
| create | — | 0 | up | 5,000 | A | 1 | 1,013 | 986.800 |
| create | — | 0 | up | 10,000 | A | 1 | 625 | 1599.900 |
| create | — | 0 | up | 15,000 | A | 1 | 419 | 2388.700 |
| create | — | 0 | up | 20,000 | A | 1 | 297 | 3366.400 |
| create | — | 0 | up | 25,000 | A | 1 | 251 | 3982.200 |
| create | — | 0 | down | 20,000 | A | 1 | 232 | 4314.600 |
| create | — | 0 | down | 15,000 | A | 1 | 376 | 2658.800 |
| create | — | 0 | down | 10,000 | A | 1 | 550 | 1816.600 |
| create | — | 0 | down | 5,000 | A | 1 | 1,193 | 838.000 |
| create | — | 0 | down | 1,000 | A | 1 | 7,474 | 133.800 |
| create | — | 0 | down | 0 | A | 1 | 69,444 | 14.400 |
| sequence | — | 0 | up | 1,000 | A | 1 | 453 | 2207.600 |
| sequence | — | 0 | up | 5,000 | A | 1 | 115 | 8672.100 |
| sequence | — | 0 | up | 10,000 | A | 1 | 89 | 11236.200 |
| sequence | — | 0 | up | 15,000 | A | 1 | 69 | 14437.200 |
| sequence | — | 0 | up | 20,000 | A | 1 | 53 | 18825.900 |
| sequence | — | 0 | up | 25,000 | A | 1 | 43 | 23484.400 |
| sequence | — | 0 | down | 20,000 | A | 1 | 51 | 19572.700 |
| sequence | — | 0 | down | 15,000 | A | 1 | 62 | 16076.100 |
| sequence | — | 0 | down | 10,000 | A | 1 | 81 | 12296.700 |
| sequence | — | 0 | down | 5,000 | A | 1 | 114 | 8759.900 |
| sequence | — | 0 | down | 1,000 | A | 1 | 166 | 6036.000 |
| sequence | — | 0 | down | 0 | A | 1 | 728 | 1373.500 |
| values | — | 0 | up | 1,000 | A | 1 | 588 | 1700.900 |
| values | — | 0 | up | 5,000 | A | 1 | 145 | 6884.500 |
| values | — | 0 | up | 10,000 | A | 1 | 48 | 20653.400 |
| values | — | 0 | up | 15,000 | A | 1 | 119 | 8374.500 |
| values | — | 0 | up | 20,000 | A | 1 | 101 | 9885.900 |
| values | — | 0 | up | 25,000 | A | 1 | 89 | 11299.400 |
| values | — | 0 | down | 20,000 | A | 1 | 115 | 8670.000 |
| values | — | 0 | down | 15,000 | A | 1 | 136 | 7362.400 |
| values | — | 0 | down | 10,000 | A | 1 | 196 | 5089.600 |
| values | — | 0 | down | 5,000 | A | 1 | 382 | 2619.100 |
| values | — | 0 | down | 1,000 | A | 1 | 2,121 | 471.400 |
| values | — | 0 | down | 0 | A | 1 | 80,645 | 12.400 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.619 | 0.232 | 0.387 |
| 0 | up | 5000 | 3.095 | 1.167 | 1.928 |
| 0 | up | 10000 | 6.171 | 2.343 | 3.827 |
| 0 | up | 15000 | 9.370 | 3.643 | 5.727 |
| 0 | up | 20000 | 12.804 | 5.113 | 7.691 |
| 0 | up | 25000 | 16.234 | 6.637 | 9.597 |
| 0 | down | 20000 | 13.299 | 5.613 | 7.685 |
| 0 | down | 15000 | 9.899 | 4.131 | 5.768 |
| 0 | down | 10000 | 7.140 | 3.295 | 3.845 |
| 0 | down | 5000 | 4.084 | 2.162 | 1.923 |
| 0 | down | 1000 | 1.799 | 1.420 | 0.378 |
| 0 | down | 0 | 1.231 | 1.231 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 50,671 | 0.407 | 426.984 | 8.427 | 122.090 | 15.545 |
| 0 | up | A | 5,000 | 5,000 | 252,715 | 2.030 | 425.641 | 8.421 | 155.590 | 19.607 |
| 0 | up | A | 10,000 | 10,000 | 501,654 | 4.041 | 423.725 | 8.447 | 193.945 | 24.432 |
| 0 | up | A | 15,000 | 15,000 | 750,657 | 6.065 | 423.942 | 8.471 | 207.859 | 29.221 |
| 0 | up | A | 20,000 | 20,000 | 1,008,112 | 8.161 | 427.874 | 8.489 | 279.680 | 34.148 |
| 0 | up | A | 25,000 | 25,000 | 1,257,856 | 10.199 | 427.784 | 8.502 | 294.180 | 38.923 |
| 0 | down | A | 20,000 | 20,000 | 1,007,326 | 8.225 | 431.205 | 8.561 | 295.527 | 34.162 |
| 0 | down | A | 15,000 | 15,000 | 756,010 | 6.173 | 431.547 | 8.562 | 297.094 | 29.377 |
| 0 | down | A | 10,000 | 10,000 | 503,964 | 4.105 | 430.448 | 8.541 | 296.359 | 24.600 |
| 0 | down | A | 5,000 | 5,000 | 252,028 | 2.043 | 428.418 | 8.499 | 294.352 | 19.824 |
| 0 | down | A | 1,000 | 1,000 | 49,568 | 0.400 | 419.744 | 8.468 | 292.980 | 15.978 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 294.133 | 14.916 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 50671 | 186687 | 186.687 | 3.684 | 275.58 | 14.63 | 164.19 | 12.39 |
| 0 | up | A | 5000 | 252715 | 1203749 | 240.750 | 4.763 | 1623.80 | 73.27 | 820.20 | 61.64 |
| 0 | up | A | 10000 | 501654 | 2417805 | 241.780 | 4.820 | 3239.34 | 148.63 | 1636.95 | 124.60 |
| 0 | up | A | 15000 | 750657 | 3667145 | 244.476 | 4.885 | 4881.17 | 225.50 | 3511.78 | 199.90 |
| 0 | up | A | 20000 | 1008112 | 4962378 | 248.119 | 4.922 | 7089.99 | 311.06 | 5113.11 | 263.47 |
| 0 | up | A | 25000 | 1257856 | 6229220 | 249.169 | 4.952 | 9217.18 | 392.27 | 6522.62 | 334.88 |
| 0 | down | A | 20000 | 1007326 | 5105481 | 255.274 | 5.068 | 7537.44 | 326.42 | 5290.22 | 278.28 |
| 0 | down | A | 15000 | 756010 | 3828153 | 255.210 | 5.064 | 5701.64 | 247.04 | 3986.59 | 209.82 |
| 0 | down | A | 10000 | 503964 | 2529609 | 252.961 | 5.019 | 3809.23 | 164.74 | 2657.43 | 139.77 |
| 0 | down | A | 5000 | 252028 | 1239034 | 247.807 | 4.916 | 1894.53 | 79.81 | 1324.48 | 67.85 |
| 0 | down | A | 1000 | 49568 | 235863 | 235.863 | 4.758 | 370.09 | 15.92 | 259.39 | 13.57 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 426.364 | 8.479 | 245.618 | 4.885 |
| 0 | A | scaleDown | 430.659 | 8.550 | 253.689 | 5.036 |
| 0 | A | fullLifecycle | 428.089 | 8.507 | 248.859 | 4.946 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
