# Large string benchmarks

2026-11-27T20:58:08.379Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2339.79 | 0.00 |
| 1024 | insert.append | array | 12823.03 | 0.00 |
| 1024 | replace | array | 3256.72 | 0.00 |
| 1024 | remove | array | 1205.42 | 0.00 |
| 1024 | remove.middle | array | 2058.18 | 0.00 |
| 1024 | replace.middle | array | 2552.08 | 0.00 |
| 1024 | apply | array | 809.33 | 0.00 |
| 1024 | apply.array | array | 633.94 | 0.00 |
| 1024 | concurrent.apply | array | 66469.76 | 0.00 |
| 1024 | merge | array | 3102.54 | 0.00 |
| 1024 | create | array | 2995.26 | 0.00 |
| 1024 | value.random | array | 49.84 | 0.00 |
| 1024 | values.range | array | 108.15 | 0.00 |
| 1024 | values.array | array | 1280.50 | 0.00 |
| 1024 | values.text | array | 13536.45 | 0.00 |
| 1024 | sequence.array | array | 1799.27 | 0.00 |
| 1024 | sequence.text | array | 12027.55 | 0.00 |
| 1024 | sequence.edited.text | array | 9574.20 | 0.00 |
| 1024 | sequence.masked.text | array | 11085.42 | 0.00 |
| 1024 | insert | string | 503.26 | 0.00 |
| 1024 | insert.append | string | 4308.56 | 0.00 |
| 1024 | replace | string | 1179.98 | 0.00 |
| 1024 | remove | string | 939.37 | 0.00 |
| 1024 | remove.middle | string | 1005.91 | 0.00 |
| 1024 | replace.middle | string | 1351.23 | 0.00 |
| 1024 | apply | string | 1022.45 | 0.00 |
| 1024 | apply.array | string | 2769.56 | 0.00 |
| 1024 | concurrent.apply | string | 3794.35 | 0.00 |
| 1024 | merge | string | 1428.88 | 0.00 |
| 1024 | create | string | 1090.41 | 0.00 |
| 1024 | value.random | string | 54.55 | 0.00 |
| 1024 | values.range | string | 161.01 | 0.00 |
| 1024 | values.array | string | 1823.38 | 0.00 |
| 1024 | values.text | string | 65.05 | 0.00 |
| 1024 | sequence.array | string | 1937.41 | 0.00 |
| 1024 | sequence.text | string | 190.13 | 0.00 |
| 1024 | sequence.edited.text | string | 720.18 | 0.00 |
| 1024 | sequence.masked.text | string | 3418.39 | 0.00 |
| 65536 | insert | array | 261036.46 | 0.00 |
| 65536 | insert.append | array | 1069604.00 | 0.00 |
| 65536 | replace | array | 238636.19 | 0.00 |
| 65536 | remove | array | 2778.39 | 0.00 |
| 65536 | remove.middle | array | 223860.71 | 0.00 |
| 65536 | replace.middle | array | 217906.96 | 0.00 |
| 65536 | apply | array | 778.81 | 0.00 |
| 65536 | apply.array | array | 597.06 | 0.00 |
| 65536 | concurrent.apply | array | 3986242.86 | 0.00 |
| 65536 | merge | array | 209230.00 | 0.00 |
| 65536 | create | array | 208824.17 | 0.00 |
| 65536 | value.random | array | 47.01 | 0.00 |
| 65536 | values.range | array | 255.95 | 0.00 |
| 65536 | values.array | array | 216215.08 | 0.00 |
| 65536 | values.text | array | 836900.00 | 0.00 |
| 65536 | sequence.array | array | 208329.37 | 0.00 |
| 65536 | sequence.text | array | 892726.67 | 0.00 |
| 65536 | sequence.edited.text | array | 898326.67 | 0.00 |
| 65536 | sequence.masked.text | array | 900544.83 | 0.00 |
| 65536 | insert | string | 437.16 | 0.00 |
| 65536 | insert.append | string | 19429.40 | 0.00 |
| 65536 | replace | string | 1575.06 | 0.00 |
| 65536 | remove | string | 1141.99 | 0.00 |
| 65536 | remove.middle | string | 1133.95 | 0.00 |
| 65536 | replace.middle | string | 1533.09 | 0.00 |
| 65536 | apply | string | 992.53 | 0.00 |
| 65536 | apply.array | string | 254007.81 | 0.00 |
| 65536 | concurrent.apply | string | 140731.46 | 0.00 |
| 65536 | merge | string | 1196.42 | 0.00 |
| 65536 | create | string | 879.94 | 0.00 |
| 65536 | value.random | string | 54.74 | 0.00 |
| 65536 | values.range | string | 142.52 | 0.00 |
| 65536 | values.array | string | 265325.00 | 0.00 |
| 65536 | values.text | string | 67.51 | 0.00 |
| 65536 | sequence.array | string | 198929.37 | 0.00 |
| 65536 | sequence.text | string | 297.20 | 0.00 |
| 65536 | sequence.edited.text | string | 8130.08 | 0.00 |
| 65536 | sequence.masked.text | string | 4417.03 | 0.00 |
| 1048576 | insert | array | 3609900.00 | 0.00 |
| 1048576 | insert.append | array | 31699800.00 | 0.00 |
| 1048576 | replace | array | 5640500.00 | 0.00 |
| 1048576 | remove | array | 12255.44 | 0.00 |
| 1048576 | remove.middle | array | 2907888.89 | 0.00 |
| 1048576 | replace.middle | array | 2934800.00 | 0.00 |
| 1048576 | apply | array | 1048.06 | 0.00 |
| 1048576 | apply.array | array | 740.37 | 0.00 |
| 1048576 | concurrent.apply | array | 66826900.00 | 0.00 |
| 1048576 | merge | array | 3187837.50 | 0.00 |
| 1048576 | create | array | 2931666.67 | 0.00 |
| 1048576 | value.random | array | 39.10 | 0.00 |
| 1048576 | values.range | array | 99.93 | 0.00 |
| 1048576 | values.array | array | 2218891.67 | 0.00 |
| 1048576 | values.text | array | 13355250.00 | 0.00 |
| 1048576 | sequence.array | array | 2430181.82 | 0.00 |
| 1048576 | sequence.text | array | 57909450.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 61175100.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 57667300.00 | 0.00 |
| 1048576 | insert | string | 444.29 | 0.00 |
| 1048576 | insert.append | string | 561808.89 | 0.00 |
| 1048576 | replace | string | 1411.73 | 0.00 |
| 1048576 | remove | string | 1060.01 | 0.00 |
| 1048576 | remove.middle | string | 924.24 | 0.00 |
| 1048576 | replace.middle | string | 1452.70 | 0.00 |
| 1048576 | apply | string | 953.59 | 0.00 |
| 1048576 | apply.array | string | 3336512.50 | 0.00 |
| 1048576 | concurrent.apply | string | 1295585.00 | 0.00 |
| 1048576 | merge | string | 1212.56 | 0.00 |
| 1048576 | create | string | 908.37 | 0.00 |
| 1048576 | value.random | string | 44.57 | 0.00 |
| 1048576 | values.range | string | 142.82 | 0.00 |
| 1048576 | values.array | string | 3370650.00 | 0.00 |
| 1048576 | values.text | string | 72.26 | 0.00 |
| 1048576 | sequence.array | string | 3027800.00 | 0.00 |
| 1048576 | sequence.text | string | 167.06 | 0.00 |
| 1048576 | sequence.edited.text | string | 88312.68 | 0.00 |
| 1048576 | sequence.masked.text | string | 3295.64 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
