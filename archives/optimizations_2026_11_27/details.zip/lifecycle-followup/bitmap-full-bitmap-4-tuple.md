# Tuple benchmarks

2026-11-27T20:57:53.953Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 3,028,411 | 2,406,005 | 0.79× |
| 2 | create.sequence | 935,832 | 801,238 | 0.86× |
| 2 | replace.random | 1,143,575 | 1,423,282 | 1.24× |
| 2 | apply.replace | 684,295 | 900,920 | 1.32× |
| 2 | apply.duplicate | 1,659,938 | 1,709,465 | 1.03× |
| 2 | merge.duplicate | 1,618,074 | 1,603,012 | 0.99× |
| 2 | length | 135,918,270 | 136,927,322 | 1.01× |
| 2 | value.random | 34,856,131 | 55,044,295 | 1.58× |
| 2 | values | 13,463,082 | 12,740,991 | 0.95× |
| 2 | sequence | 3,383,872 | 3,102,814 | 0.92× |
| 4 | create.empty | 2,612,469 | 2,246,245 | 0.86× |
| 4 | create.sequence | 694,456 | 612,801 | 0.88× |
| 4 | replace.random | 1,045,493 | 1,521,745 | 1.46× |
| 4 | apply.replace | 664,154 | 943,552 | 1.42× |
| 4 | apply.duplicate | 1,834,929 | 1,741,059 | 0.95× |
| 4 | merge.duplicate | 1,118,360 | 1,253,512 | 1.12× |
| 4 | length | 34,722,308 | 35,209,935 | 1.01× |
| 4 | value.random | 25,006,630 | 51,054,316 | 2.04× |
| 4 | values | 6,238,036 | 7,224,759 | 1.16× |
| 4 | sequence | 2,665,725 | 2,691,469 | 1.01× |
| 8 | create.empty | 2,607,596 | 2,437,493 | 0.93× |
| 8 | create.sequence | 469,680 | 513,374 | 1.09× |
| 8 | replace.random | 1,001,102 | 1,553,724 | 1.55× |
| 8 | apply.replace | 657,394 | 1,014,340 | 1.54× |
| 8 | apply.duplicate | 1,563,043 | 1,740,857 | 1.11× |
| 8 | merge.duplicate | 982,824 | 891,670 | 0.91× |
| 8 | length | 35,666,960 | 38,418,309 | 1.08× |
| 8 | value.random | 18,188,890 | 58,703,660 | 3.23× |
| 8 | values | 4,426,786 | 4,549,134 | 1.03× |
| 8 | sequence | 1,710,315 | 1,977,284 | 1.16× |
| 100 | create.empty | 2,318,531 | 578,704 | 0.25× |
| 100 | create.sequence | 64,947 | 77,758 | 1.20× |
| 100 | replace.random | 935,829 | 1,560,408 | 1.67× |
| 100 | apply.replace | 617,015 | 1,011,571 | 1.64× |
| 100 | apply.duplicate | 1,749,153 | 1,797,426 | 1.03× |
| 100 | merge.duplicate | 114,229 | 78,285 | 0.69× |
| 100 | length | 37,992,471 | 37,205,570 | 0.98× |
| 100 | value.random | 13,910,509 | 55,866,629 | 4.02× |
| 100 | values | 515,281 | 570,568 | 1.11× |
| 100 | sequence | 178,377 | 183,002 | 1.03× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
