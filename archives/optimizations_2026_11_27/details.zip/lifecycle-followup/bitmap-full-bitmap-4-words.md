# Words benchmarks

2026-11-27T20:58:30.148Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 31,613 | 125,258 | 199 |
| append | packed | 5.90 | 3.61 | 13.98 | 26,457 | 190,562 | 311 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,493 | 814 | 251 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 29,254 | 1,608 | 252 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 493 | 247 | 87 |
| random | packed | 49.58 | 35.38 | 23.45 | 10,948 | 398 | 106 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 599 | 211 | 97 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 15,704 | 444 | 145 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 569.16 | 0.00 |
| append | numeric | encode | 31632.26 | 0.00 |
| append | numeric | decode | 3259.28 | 0.00 |
| append | numeric | create | 1741.01 | 0.00 |
| append | numeric | load | 7983.52 | 0.00 |
| append | numeric | apply | 3574307.14 | 0.00 |
| append | numeric | receive | 5020620.00 | 0.00 |
| append | binary | sequence | 503.09 | 0.00 |
| append | binary | encode | 37797.88 | 0.00 |
| append | binary | decode | 2084.39 | 0.00 |
| append | binary | create | 2115.54 | 0.00 |
| append | binary | load | 5247.65 | 0.00 |
| append | binary | apply | 1639612.90 | 0.00 |
| append | binary | receive | 3220562.50 | 0.00 |
| prepend | numeric | sequence | 487674.76 | 0.00 |
| prepend | numeric | encode | 669802.67 | 0.00 |
| prepend | numeric | decode | 234155.61 | 0.00 |
| prepend | numeric | create | 609919.51 | 0.00 |
| prepend | numeric | load | 1228768.29 | 0.00 |
| prepend | numeric | apply | 2307404.55 | 0.00 |
| prepend | numeric | receive | 3981200.00 | 0.00 |
| prepend | binary | sequence | 351395.80 | 0.00 |
| prepend | binary | encode | 34182.84 | 0.00 |
| prepend | binary | decode | 2717.90 | 0.00 |
| prepend | binary | create | 618718.29 | 0.00 |
| prepend | binary | load | 621828.40 | 0.00 |
| prepend | binary | apply | 2460323.81 | 0.00 |
| prepend | binary | receive | 3968030.77 | 0.00 |
| random | numeric | sequence | 959092.45 | 0.00 |
| random | numeric | encode | 2027856.00 | 0.00 |
| random | numeric | decode | 1111995.56 | 0.00 |
| random | numeric | create | 1811175.00 | 0.00 |
| random | numeric | load | 4049015.38 | 0.00 |
| random | numeric | apply | 7936685.71 | 0.00 |
| random | numeric | receive | 11500960.00 | 0.00 |
| random | binary | sequence | 855291.53 | 0.00 |
| random | binary | encode | 91339.96 | 0.00 |
| random | binary | decode | 3863.23 | 0.00 |
| random | binary | create | 4751490.91 | 0.00 |
| random | binary | load | 2509542.86 | 0.00 |
| random | binary | apply | 8005100.00 | 0.00 |
| random | binary | receive | 9441683.33 | 0.00 |
| concurrent | numeric | sequence | 865044.83 | 0.00 |
| concurrent | numeric | encode | 1669320.00 | 0.00 |
| concurrent | numeric | decode | 835183.33 | 0.00 |
| concurrent | numeric | create | 2341540.91 | 0.00 |
| concurrent | numeric | load | 4746009.09 | 0.00 |
| concurrent | numeric | apply | 6211622.22 | 0.00 |
| concurrent | numeric | receive | 10273920.00 | 0.00 |
| concurrent | binary | sequence | 744202.94 | 0.00 |
| concurrent | binary | encode | 63678.37 | 0.00 |
| concurrent | binary | decode | 2658.63 | 0.00 |
| concurrent | binary | create | 2265973.91 | 0.00 |
| concurrent | binary | load | 2252126.09 | 0.00 |
| concurrent | binary | apply | 5277080.00 | 0.00 |
| concurrent | binary | receive | 6909087.50 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
