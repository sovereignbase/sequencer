[![npm version](https://img.shields.io/npm/v/@sovereignbase/sequencer)](https://www.npmjs.com/package/@sovereignbase/sequencer)
[![JSR](https://jsr.io/badges/@sovereignbase/sequencer)](https://jsr.io/@sovereignbase/sequencer)
[![CI](https://github.com/sovereignbase/sequencer/actions/workflows/ci.yaml/badge.svg?branch=master)](https://github.com/sovereignbase/sequencer/actions/workflows/ci.yaml)
[![codecov](https://codecov.io/gh/sovereignbase/sequencer/branch/master/graph/badge.svg)](https://codecov.io/gh/sovereignbase/sequencer)
[![license](https://img.shields.io/npm/l/@sovereignbase/sequencer)](https://github.com/sovereignbase/sequencer/blob/master/LICENSE)

# Sequencer

Sequencer provides a total order guarantee for distributed editing. It allows independently operating actors to make concurrent edits and eventually converge on the same state without relying on network arrival order or perfectly synchronized clocks.

## Contents

- [Projection](#projection) · [Usage](#projection-usage) · [Benchmarks](#projection-benchmarks)
- [Tuple mode](#tuple-mode) · [Usage](#tuple-usage) · [Benchmarks](#tuple-benchmarks)
- [Text mode](#text-mode) · [Usage](#text-usage) · [Benchmarks](#text-benchmarks)
- [Packed words](#packed-words) · [Usage](#packed-words-usage) · [Benchmarks](#packed-words-benchmarks)
- [Batch](#batch) · [Usage](#batch-usage) · [Benchmarks](#batch-benchmarks)
- [Errors](#errors) · [Tests](#tests)
- [Credits](#credits) · [License](#license)

## Projection

<a id="projection-usage"></a>

### Usage

```ts
import { Projection } from '@sovereignbase/sequencer'

const projectionA = new Projection<string>(1)

const projectionB = new Projection<string>(2)

const insertDelta = projectionA.insert(['Hello World'], 0)
console.log(projectionA.value(0)) // "Hello World"

projectionB.apply(insertDelta)
console.log(projectionB.value(0)) // "Hello World"

const replaceDelta = projectionA.replace(['Hello Dude'], 0, 0)
console.log(projectionA.value(0)) // "Hello Dude"

const replaceAcknowledgement = projectionB.apply(replaceDelta)
console.log(projectionB.value(0)) // "Hello Dude"

projectionA.apply(replaceAcknowledgement?.[1])

const removeDelta = projectionA.remove(0, 0)
console.log(projectionA.value(0)) // undefined

const removeAcknowledgement = projectionB.apply(removeDelta)
console.log(projectionB.value(0)) // undefined

projectionA.apply(removeAcknowledgement?.[1])

const serializable = projectionA.sequence()

const acknowledgements = projectionB.merge(serializable)
projectionA.apply(acknowledgements?.[1])

projectionA.destroy()
projectionB.destroy()
```

<a id="projection-benchmarks"></a>

### Benchmarks

<!-- BEGIN GENERATED:projection:benchmarks -->

2026-11-27T21:07:12.624Z · local run

#### Moderate bundle size

| Format   | Raw (KiB) | Minified (KiB) | Minified + gzip (KiB) |
| -------- | --------: | -------------: | --------------------: |
| ESM      |    202.54 |         165.86 |                 56.93 |
| CommonJS |    202.72 |         167.48 |                 57.14 |

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

#### Average throughput during editing to checkpoint

Arithmetic means of 1 runs, in ops/s, from each phase's start to checkpoint.
Strips contain 1–100 Frames (visible entries). Headers show Strip counts and mean Frame counts.

**↑ Scale up (0 → 25,000 Strips)**

| Method / case  | 1,000 Strips<br>50,671 Frames | 5,000 Strips<br>252,715 Frames | 10,000 Strips<br>501,654 Frames | 15,000 Strips<br>750,657 Frames | 20,000 Strips<br>1,008,112 Frames | 25,000 Strips<br>1,257,856 Frames |
| -------------- | ----------------------------: | -----------------------------: | ------------------------------: | ------------------------------: | --------------------------------: | --------------------------------: |
| apply.random   |                       280,371 |                        324,048 |                         329,274 |                         340,051 |                           331,837 |                           302,007 |
| insert.head    |                       930,752 |                      1,210,595 |                       1,357,368 |                       1,401,502 |                         1,397,233 |                         1,406,043 |
| insert.random  |                       579,475 |                        625,939 |                         608,969 |                         631,701 |                           606,730 |                           581,545 |
| insert.tail    |                       522,739 |                      1,079,121 |                       1,265,791 |                       1,364,405 |                         1,409,920 |                         1,388,704 |
| remove.head    |                             — |                              — |                               — |                               — |                                 — |                                 — |
| remove.random  |                       470,721 |                        532,107 |                         521,613 |                         537,644 |                           518,337 |                           520,725 |
| remove.tail    |                             — |                              — |                               — |                               — |                                 — |                                 — |
| replace.head   |                       417,885 |                        504,119 |                         542,897 |                         546,878 |                           552,535 |                           552,329 |
| replace.random |                       398,979 |                        324,680 |                         359,194 |                         362,830 |                           363,737 |                           366,275 |
| replace.tail   |                       476,077 |                        488,959 |                         529,866 |                         541,886 |                           520,772 |                           533,362 |
| value.head     |                     1,700,102 |                      2,608,242 |                       2,925,688 |                       3,094,953 |                         3,163,606 |                         3,206,320 |
| value.random   |                     1,202,501 |                      1,054,964 |                       1,000,020 |                         987,076 |                           955,918 |                           954,118 |
| value.tail     |                     5,178,664 |                      5,611,043 |                       5,902,839 |                       6,229,236 |                         6,376,331 |                         6,472,827 |

**↓ Scale down (25,000 → 0 Strips)**

| Method / case  | 20,000 Strips<br>1,007,326 Frames | 15,000 Strips<br>756,010 Frames | 10,000 Strips<br>503,964 Frames | 5,000 Strips<br>252,028 Frames | 1,000 Strips<br>49,568 Frames | 0 Strips<br>0 Frames |
| -------------- | --------------------------------: | ------------------------------: | ------------------------------: | -----------------------------: | ----------------------------: | -------------------: |
| apply.random   |                           341,967 |                         346,119 |                         344,398 |                        348,840 |                       353,804 |              357,409 |
| insert.head    |                                 — |                               — |                               — |                              — |                             — |                    — |
| insert.random  |                           572,141 |                         531,005 |                         563,141 |                        587,251 |                       603,924 |              614,225 |
| insert.tail    |                                 — |                               — |                               — |                              — |                             — |                    — |
| remove.head    |                           753,148 |                         765,931 |                         729,466 |                        748,783 |                       761,948 |              767,974 |
| remove.random  |                           500,992 |                         502,391 |                         494,390 |                        509,787 |                       520,569 |              528,674 |
| remove.tail    |                           734,387 |                         767,106 |                         786,056 |                        802,343 |                       813,080 |              818,872 |
| replace.head   |                           531,904 |                         531,282 |                         534,258 |                        522,128 |                       521,253 |              525,794 |
| replace.random |                           352,517 |                         353,011 |                         367,962 |                        362,992 |                       376,664 |              383,370 |
| replace.tail   |                           239,387 |                         131,742 |                         167,534 |                        173,658 |                       186,036 |              191,318 |
| value.head     |                         2,412,429 |                       2,431,847 |                       2,476,310 |                      2,485,738 |                     2,458,513 |            2,479,126 |
| value.random   |                           982,956 |                         953,743 |                         959,582 |                        970,695 |                       986,720 |            1,004,081 |
| value.tail     |                         4,354,642 |                       4,282,288 |                       4,246,525 |                      4,179,379 |                     4,198,447 |            4,236,642 |

#### API throughput at checkpoint

Checkpoint calls, in ops/s, averaged across runs.

**↑ Scale up (0 → 25,000 Strips)**

| Method                            | 1,000 Strips<br>50,671 Frames | 5,000 Strips<br>252,715 Frames | 10,000 Strips<br>501,654 Frames | 15,000 Strips<br>750,657 Frames | 20,000 Strips<br>1,008,112 Frames | 25,000 Strips<br>1,257,856 Frames |
| --------------------------------- | ----------------------------: | -----------------------------: | ------------------------------: | ------------------------------: | --------------------------------: | --------------------------------: |
| new Projection(actorID, sequence) |                         2,466 |                            989 |                             604 |                             403 |                               294 |                               237 |
| sequence()                        |                           408 |                            119 |                              86 |                              69 |                                51 |                                36 |
| values()                          |                           569 |                            190 |                              46 |                             139 |                               105 |                               100 |

**↓ Scale down (25,000 → 0 Strips)**

| Method                            | 20,000 Strips<br>1,007,326 Frames | 15,000 Strips<br>756,010 Frames | 10,000 Strips<br>503,964 Frames | 5,000 Strips<br>252,028 Frames | 1,000 Strips<br>49,568 Frames | 0 Strips<br>0 Frames |
| --------------------------------- | --------------------------------: | ------------------------------: | ------------------------------: | -----------------------------: | ----------------------------: | -------------------: |
| new Projection(actorID, sequence) |                               294 |                             390 |                             555 |                          1,201 |                         7,337 |               80,645 |
| sequence()                        |                                57 |                              68 |                              88 |                            105 |                           186 |                  837 |
| values()                          |                               127 |                             149 |                             187 |                            393 |                         2,349 |              111,111 |

#### Sequence disk size at checkpoint

Complete exported Sequences, including Footage and acknowledgements. Sizes are in KiB.

**↑ Scale up (0 → 25,000 Strips)**

| Encoding           | 1,000 Strips<br>50,671 Frames | 5,000 Strips<br>252,715 Frames | 10,000 Strips<br>501,654 Frames | 15,000 Strips<br>750,657 Frames | 20,000 Strips<br>1,008,112 Frames | 25,000 Strips<br>1,257,856 Frames |
| ------------------ | ----------------------------: | -----------------------------: | ------------------------------: | ------------------------------: | --------------------------------: | --------------------------------: |
| JSON               |                        275.58 |                       1,623.80 |                        3,239.34 |                        4,881.17 |                          7,089.99 |                          9,217.18 |
| JSON + gzip        |                         14.63 |                          73.27 |                          148.63 |                          225.50 |                            311.06 |                            392.27 |
| MessagePack        |                        164.19 |                         820.20 |                        1,636.95 |                        3,511.78 |                          5,113.11 |                          6,522.62 |
| MessagePack + gzip |                         12.39 |                          61.64 |                          124.60 |                          199.90 |                            263.47 |                            334.88 |

**↓ Scale down (25,000 → 0 Strips)**

| Encoding           | 20,000 Strips<br>1,007,326 Frames | 15,000 Strips<br>756,010 Frames | 10,000 Strips<br>503,964 Frames | 5,000 Strips<br>252,028 Frames | 1,000 Strips<br>49,568 Frames | 0 Strips<br>0 Frames |
| ------------------ | --------------------------------: | ------------------------------: | ------------------------------: | -----------------------------: | ----------------------------: | -------------------: |
| JSON               |                          7,537.44 |                        5,701.64 |                        3,809.23 |                       1,894.53 |                        370.09 |                 0.02 |
| JSON + gzip        |                            326.42 |                          247.04 |                          164.74 |                          79.81 |                         15.92 |                 0.03 |
| MessagePack        |                          5,290.22 |                        3,986.59 |                        2,657.43 |                       1,324.48 |                        259.39 |                 0.01 |
| MessagePack + gzip |                            278.28 |                          209.82 |                          139.77 |                          67.85 |                         13.57 |                 0.03 |

#### Memory usage at checkpoint

One instance after checkpoint compaction and recreation: live native allocation plus retained JS array slots and string code units, in MiB (1,048,576 bytes). Unused WASM capacity is excluded.

**↑ Scale up (0 → 25,000 Strips)**

| Measurement            | 1,000 Strips<br>50,671 Frames | 5,000 Strips<br>252,715 Frames | 10,000 Strips<br>501,654 Frames | 15,000 Strips<br>750,657 Frames | 20,000 Strips<br>1,008,112 Frames | 25,000 Strips<br>1,257,856 Frames |
| ---------------------- | ----------------------------: | -----------------------------: | ------------------------------: | ------------------------------: | --------------------------------: | --------------------------------: |
| Estimated memory (MiB) |                          0.62 |                           3.09 |                            6.17 |                            9.37 |                             12.80 |                             16.23 |

**↓ Scale down (25,000 → 0 Strips)**

| Measurement            | 20,000 Strips<br>1,007,326 Frames | 15,000 Strips<br>756,010 Frames | 10,000 Strips<br>503,964 Frames | 5,000 Strips<br>252,028 Frames | 1,000 Strips<br>49,568 Frames | 0 Strips<br>0 Frames |
| ---------------------- | --------------------------------: | ------------------------------: | ------------------------------: | -----------------------------: | ----------------------------: | -------------------: |
| Estimated memory (MiB) |                             13.30 |                            9.90 |                            7.14 |                           4.08 |                          1.80 |                 1.23 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49,
win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.
Peer synchronization, encoding and explicit JS process garbage collection are outside API timings.
[Full lifecycle results](../indices-target-bitmap-4-lifecycle.md) · [Throughput results](benchmark/.results/throughput.md).

<!-- END GENERATED:projection:benchmarks -->

## Tuple mode

<a id="tuple-usage"></a>

### Usage

Each index represents an independent slot. Adding or removing values
never shifts other values. Empty slots return `undefined`.

Omit `maxLength` to allow dynamic growth.

```ts
const tuple = new Projection<string>(1, undefined, { enabled: 1, maxLength: 4 })
tuple.insert(['hello'], 2)
tuple.replace(['world'], 2, 2)
tuple.remove(2, 2)
```

<a id="tuple-benchmarks"></a>

### Benchmarks

<!-- BEGIN GENERATED:tuple:benchmarks -->

2026-11-27T20:57:53.953Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

#### Throughput (ops/s)

| Indices | Method / case   | Projection | Static tuple | Tuple / Projection |
| ------: | --------------- | ---------: | -----------: | -----------------: |
|       2 | create.sequence |    935,832 |      801,238 |              0.86× |
|       2 | replace.random  |  1,143,575 |    1,423,282 |              1.24× |
|       2 | apply.replace   |    684,295 |      900,920 |              1.32× |
|       2 | value.random    | 34,856,131 |   55,044,295 |              1.58× |
|       4 | create.sequence |    694,456 |      612,801 |              0.88× |
|       4 | replace.random  |  1,045,493 |    1,521,745 |              1.46× |
|       4 | apply.replace   |    664,154 |      943,552 |              1.42× |
|       4 | value.random    | 25,006,630 |   51,054,316 |              2.04× |
|       8 | create.sequence |    469,680 |      513,374 |              1.09× |
|       8 | replace.random  |  1,001,102 |    1,553,724 |              1.55× |
|       8 | apply.replace   |    657,394 |    1,014,340 |              1.54× |
|       8 | value.random    | 18,188,890 |   58,703,660 |              3.23× |
|     100 | create.sequence |     64,947 |       77,758 |              1.20× |
|     100 | replace.random  |    935,829 |    1,560,408 |              1.67× |
|     100 | apply.replace   |    617,015 |    1,011,571 |              1.64× |
|     100 | value.random    | 13,910,509 |   55,866,629 |              4.02× |

#### Memory and encoded size

| Indices | Mode         | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ------: | ------------ | -------------------------------: | ----------------: | -----------------------: |
|       2 | Projection   |                           0.0006 |              0.03 |                     0.04 |
|       2 | Static tuple |                           0.0007 |              0.04 |                     0.05 |
|       4 | Projection   |                           0.0013 |              0.06 |                     0.05 |
|       4 | Static tuple |                           0.0009 |              0.06 |                     0.07 |
|       8 | Projection   |                           0.0022 |              0.12 |                     0.08 |
|       8 | Static tuple |                           0.0013 |              0.10 |                     0.09 |
|     100 | Projection   |                           0.0196 |              0.67 |                     0.57 |
|     100 | Static tuple |                           0.0110 |              0.51 |                     0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.

[Full tuple results](../bitmap-full-bitmap-4-tuple.md).

<!-- END GENERATED:tuple:benchmarks -->

## Text mode

<a id="text-usage"></a>

### Usage

String inputs retain UTF-16 code units without creating character arrays.
Array results remain the default; `true` requests string Footage.

```ts
const text = new Projection<string>(1)
const gossip = text.insert('Hello', 0)
const replica = new Projection<string>(2)
replica.apply(gossip, true)
const visibleText = replica.values(undefined, undefined, true)
const snapshot = replica.sequence(true)
const restored = new Projection<string>(3, snapshot, undefined, true)
text.destroy()
replica.destroy()
restored.destroy()
```

<a id="text-benchmarks"></a>

### Benchmarks

<!-- BEGIN GENERATED:text:benchmarks -->

2026-11-27T20:58:08.379Z · local run

1 runs; median throughput in ops/s. Sizes are UTF-16 code units.

| Operation            | 1,024 array | 1,024 string | 65,536 array | 65,536 string | 1,048,576 array | 1,048,576 string |
| -------------------- | ----------: | -----------: | -----------: | ------------: | --------------: | ---------------: |
| insert               |     427,388 |    1,987,047 |        3,831 |     2,287,501 |             277 |        2,250,797 |
| insert.append        |      77,985 |      232,096 |          935 |        51,468 |              32 |            1,780 |
| replace              |     307,057 |      847,472 |        4,190 |       634,896 |             177 |          708,350 |
| remove               |     829,586 |    1,064,546 |      359,920 |       875,663 |          81,596 |          943,388 |
| remove.middle        |     485,866 |      994,126 |        4,467 |       881,875 |             344 |        1,081,966 |
| replace.middle       |     391,838 |      740,065 |        4,589 |       652,276 |             341 |          688,374 |
| apply                |   1,235,596 |      978,044 |    1,284,013 |     1,007,527 |         954,145 |        1,048,670 |
| apply.array          |   1,577,447 |      361,069 |    1,674,879 |         3,937 |       1,350,678 |              300 |
| concurrent.apply     |      15,044 |      263,549 |          251 |         7,106 |              15 |              772 |
| merge                |     322,316 |      699,848 |        4,779 |       835,825 |             314 |          824,701 |
| create               |     333,860 |      917,090 |        4,789 |     1,136,436 |             341 |        1,100,868 |
| value.random         |  20,064,293 |   18,333,287 |   21,270,326 |    18,267,875 |      25,573,527 |       22,435,384 |
| values.range         |   9,246,180 |    6,210,825 |    3,907,023 |     7,016,740 |      10,006,948 |        7,001,896 |
| values.array         |     780,948 |      548,431 |        4,625 |         3,769 |             451 |              297 |
| values.text          |      73,875 |   15,372,310 |        1,195 |    14,812,739 |              75 |       13,838,861 |
| sequence.array       |     555,782 |      516,154 |        4,800 |         5,027 |             411 |              330 |
| sequence.text        |      83,142 |    5,259,563 |        1,120 |     3,364,694 |              17 |        5,985,843 |
| sequence.edited.text |     104,447 |    1,388,543 |        1,113 |       123,000 |              16 |           11,323 |
| sequence.masked.text |      90,209 |      292,536 |        1,110 |       226,396 |              17 |          303,431 |

Encoded snapshots use string Footage in both representations.

#### Memory and encoded size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ----------------: | -------------- | ------------: | -----------------------: | ----------------: | ---------------------: | --------------: |
|              1024 | array          |        0.0082 |                     1.02 |              0.04 |                   2.02 |            0.05 |
|              1024 | string         |        0.0023 |                     1.02 |              0.04 |                   1.02 |            0.05 |
|             65536 | array          |        0.5004 |                    64.02 |              0.12 |                 128.02 |            0.18 |
|             65536 | string         |        0.1254 |                    64.02 |              0.12 |                  64.02 |            0.12 |
|           1048576 | array          |        8.0004 |                  1024.02 |              1.05 |                2048.02 |            2.05 |
|           1048576 | string         |        2.0004 |                  1024.02 |              1.05 |                1024.02 |            1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.

[Full text results](../bitmap-full-bitmap-4-text.md).

<!-- END GENERATED:text:benchmarks -->

## Packed words

<a id="packed-words-usage"></a>

### Usage

Unpacked words remain the default. The optional final `binaryEncode` argument
returns `Uint8Array` metadata for binary serializers such as MessagePack.
Footage keeps its existing array or string representation.

```ts
const projection = new Projection<string>(1)
const gossip = projection.insert('Hello', 0, true)
const snapshot = projection.sequence(true, true)
const replica = new Projection<string>(2, snapshot, undefined, true)
replica.apply(projection.remove(0, 0, true), true, true)
projection.destroy()
replica.destroy()
```

<a id="packed-words-benchmarks"></a>

### Benchmarks

<!-- BEGIN GENERATED:words:benchmarks -->

2026-11-27T20:58:30.148Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload   | Words    | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| ---------- | -------- | -----------: | ----------------: | ------------: | -----------: | ---------: | ----------------: |
| append     | unpacked |         5.90 |              3.61 |         22.88 |       31,613 |    125,258 |               199 |
| append     | packed   |         5.90 |              3.61 |         13.98 |       26,457 |    190,562 |               311 |
| prepend    | unpacked |        40.07 |             18.06 |         22.94 |        1,493 |        814 |               251 |
| prepend    | packed   |         5.90 |              3.62 |         13.99 |       29,254 |      1,608 |               252 |
| random     | unpacked |       138.05 |             57.31 |         39.88 |          493 |        247 |                87 |
| random     | packed   |        49.58 |             35.38 |         23.45 |       10,948 |        398 |               106 |
| concurrent | unpacked |        92.24 |             42.76 |         32.34 |          599 |        211 |                97 |
| concurrent | packed   |        38.94 |             28.15 |         20.71 |       15,704 |        444 |               145 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.

[Full words results](../bitmap-full-bitmap-4-words.md).

<!-- END GENERATED:words:benchmarks -->

## Batch

Collect local edits into one packed Gossip. Edits are immediately visible;
Footage stays in JavaScript.

<a id="batch-usage"></a>

### Usage

```ts
const projection = new Projection<string>(1)
const peer = new Projection<string>(2)
projection.apply([[1], [2]])
peer.apply([[1], [2]])
const gossip = projection.batch((edit) => {
  edit.insert('hello', 0)
  edit.replace('H', 0, 0)
})
const result = peer.apply(gossip, true, true)
projection.apply(result?.[1] ?? [])
projection.destroy()
peer.destroy()
```

<a id="batch-benchmarks"></a>

### Benchmarks

<!-- BEGIN GENERATED:batch:benchmarks -->

2026-11-27T20:58:37.442Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload              | Mode       | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --------------------- | ---------- | -------------: | ------------: | --------------: | ----------------: | -----------: | ---------: |
| append                | individual |        834,017 |     1,117,402 |         434,342 |             76.05 |         5.99 |      0.012 |
| append                | batch      |      2,537,212 |   145,985,401 |     198,019,802 |              5.88 |         5.99 |      0.012 |
| prepend               | individual |      1,452,187 |     1,290,378 |         782,095 |             76.11 |         5.99 |      0.896 |
| prepend               | batch      |      1,185,958 |     1,113,276 |       1,247,505 |              5.89 |         5.99 |      0.896 |
| random.characters     | individual |        652,543 |       963,732 |         707,197 |             82.09 |        28.31 |      0.917 |
| random.characters     | batch      |      1,258,125 |     1,278,772 |       1,479,874 |             22.95 |        28.31 |      0.917 |
| random.words          | individual |        859,488 |       651,579 |         597,479 |            125.68 |        73.88 |      0.991 |
| random.words          | batch      |      1,049,428 |     1,655,081 |       1,432,870 |             59.71 |        73.88 |      0.991 |
| concurrent.characters | individual |      1,230,365 |     1,024,223 |         753,244 |             82.04 |        56.41 |      1.834 |
| concurrent.characters | batch      |      1,107,297 |     1,464,468 |       1,408,798 |             22.92 |        56.41 |      1.834 |
| concurrent.words      | individual |      1,159,555 |     1,204,710 |         857,731 |            125.74 |       147.81 |      1.981 |
| concurrent.words      | batch      |      1,281,709 |     1,658,696 |       1,378,186 |             59.79 |       147.81 |      1.981 |
| concurrent.mixed      | individual |        692,821 |       901,659 |         535,899 |            154.61 |        97.82 |      1.505 |
| concurrent.mixed      | batch      |        884,819 |     1,069,728 |       1,134,559 |             56.88 |        97.82 |      1.505 |
| causal.characters     | individual |        972,227 |     1,166,396 |         864,946 |             88.96 |        63.81 |      1.842 |
| causal.characters     | batch      |        989,299 |     1,719,518 |       1,539,152 |             23.18 |        63.81 |      1.842 |
| causal.words          | individual |      1,164,924 |     1,341,877 |         877,116 |            135.13 |       156.41 |      1.989 |
| causal.words          | batch      |      1,065,331 |     1,755,952 |       1,437,522 |             60.68 |       156.41 |      1.989 |
| causal.mixed          | individual |        762,951 |       864,516 |         686,189 |            161.05 |       103.75 |      1.509 |
| causal.mixed          | batch      |        812,634 |     1,216,977 |       1,065,814 |             57.34 |       103.75 |      1.509 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.

[Full batch results](../bitmap-full-bitmap-4-batch.md).

<!-- END GENERATED:batch:benchmarks -->

## Errors

| Code                      | Meaning                                                             |
| ------------------------- | ------------------------------------------------------------------- |
| `PROJECTION_DESTROYED`    | An operation was called after the Projection was destroyed.         |
| `BATCH_CLOSED`            | An editor was used after its batch callback finished.               |
| `NATIVE_OPERATION_FAILED` | The native runtime reported an initialization or operation failure. |
| `STRING_ENCODING_FAILED`  | Footage concatenation as text failed.                               |
| `UNKNOWN_ERROR`           | All other errors.                                                   |

Invalid input to `apply()` or `merge()` returns `undefined` instead of throwing.

## Tests

### Behaviour guaranteed by excessive tests

2026-11-27T17:16:47.794Z · local run

The latest verification passed 403 Vitest tests and 153 compatibility checks.
The configured 100% coverage threshold is met (100% statements, 100% branches, 100% functions, 100% lines).
See the [test suites](test/README.md) and
[automated test report](https://sovereignbase.dev/sequencer/tests/).

### Works everywhere where JavaScript and Wasm works

2026-11-27T16:45:59.804Z · [CI run](https://github.com/sovereignbase/sequencer/actions/runs/46035866481)

Runtimes covered by the latest compatibility verification:

- Node.js, ESM: passed
- Node.js, CommonJS: passed
- Deno: passed
- Bun: passed
- Edge Runtime: passed
- Cloudflare Workers through workerd: passed
- Chromium browser windows: passed
- Firefox browser windows: passed
- WebKit browser windows: passed

### Tested realtime and offline text editing behaviour examples

- [Online and offline editors](test/convergence/delivery/offline_realtime_editing/README.md): six editors converge through delayed, reversed and shuffled delivery, including offline changes arriving during online editing.
- [Concurrent replacements](test/convergence/delivery/concurrent_replacement_delivery/README.md): independent replacement histories retain the same surviving content across delivery orders.
- [Restart and redelivery](test/convergence/persistence/restart_redelivery/README.md): stored Sequences preserve visible content through hydration, duplicate delivery and further edits.
- [Peer-to-peer fanout](test/integration/fanout_peer_to_peer/README.md): independently editing browser peers synchronize through BroadcastChannel.
- [WebSocket fanout](test/integration/fanout_websocket/README.md): three browser peers converge through a stateless JSON Gossip relay.

## Credits

This could not have been made without years of work from many great engineers of many great projects, to mention a few:

- [AUTOMERGE](https://github.com/automerge)

- [YJS](https://github.com/yjs)

- [DIAMOND TYPES](https://github.com/josephg/diamond-types)

## License

Licensed under the Apache License, Version 2.0.

Copyright © 2026 Sovereignbase.
