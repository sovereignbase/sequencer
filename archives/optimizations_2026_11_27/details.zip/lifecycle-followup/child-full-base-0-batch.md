# Batch benchmarks

2026-11-27T17:21:16.025Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 1,450,011 | 1,121,978 | 532,548 | 76.05 | 5.99 | 0.012 |
| append | batch | 2,177,621 | 234,375,000 | 208,333,333 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,530,183 | 1,326,201 | 771,972 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 1,634,610 | 1,974,789 | 1,771,688 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 757,079 | 1,036,448 | 804,128 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 1,259,261 | 1,515,955 | 1,491,387 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 1,041,594 | 1,140,338 | 774,853 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 1,092,260 | 1,703,142 | 1,620,964 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,315,256 | 1,193,947 | 802,804 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,407,443 | 1,631,210 | 1,669,588 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,272,534 | 1,323,948 | 884,206 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,300,616 | 1,491,554 | 1,441,805 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 696,755 | 976,904 | 699,492 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 753,542 | 1,190,913 | 1,154,235 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,110,463 | 1,394,846 | 965,927 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 1,171,132 | 1,795,601 | 1,555,230 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,106,960 | 1,284,893 | 902,935 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 1,288,203 | 1,469,688 | 1,474,020 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 706,323 | 922,410 | 684,967 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 866,946 | 1,284,013 | 1,153,536 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 4.138 | 0.000 |
| append | individual | apply | 5.348 | 0.000 |
| append | individual | receive | 11.267 | 0.000 |
| append | individual | encode | 8.106 | 0.000 |
| append | individual | decode | 7.664 | 0.000 |
| append | batch | author | 2.755 | 0.000 |
| append | batch | apply | 0.026 | 0.000 |
| append | batch | receive | 0.029 | 0.000 |
| append | batch | encode | 0.225 | 0.000 |
| append | batch | decode | 0.107 | 0.000 |
| prepend | individual | author | 3.921 | 0.000 |
| prepend | individual | apply | 4.524 | 0.000 |
| prepend | individual | receive | 7.772 | 0.000 |
| prepend | individual | encode | 5.703 | 0.000 |
| prepend | individual | decode | 6.904 | 0.000 |
| prepend | batch | author | 3.671 | 0.000 |
| prepend | batch | apply | 3.038 | 0.000 |
| prepend | batch | receive | 3.387 | 0.000 |
| prepend | batch | encode | 0.247 | 0.000 |
| prepend | batch | decode | 0.122 | 0.000 |
| random.characters | individual | author | 7.925 | 0.000 |
| random.characters | individual | apply | 5.789 | 0.000 |
| random.characters | individual | receive | 7.462 | 0.000 |
| random.characters | individual | encode | 4.992 | 0.000 |
| random.characters | individual | decode | 8.659 | 0.000 |
| random.characters | batch | author | 4.765 | 0.000 |
| random.characters | batch | apply | 3.958 | 0.000 |
| random.characters | batch | receive | 4.023 | 0.000 |
| random.characters | batch | encode | 0.175 | 0.000 |
| random.characters | batch | decode | 0.112 | 0.000 |
| random.words | individual | author | 5.760 | 0.000 |
| random.words | individual | apply | 5.262 | 0.000 |
| random.words | individual | receive | 7.743 | 0.000 |
| random.words | individual | encode | 4.196 | 0.000 |
| random.words | individual | decode | 8.143 | 0.000 |
| random.words | batch | author | 5.493 | 0.000 |
| random.words | batch | apply | 3.523 | 0.000 |
| random.words | batch | receive | 3.702 | 0.000 |
| random.words | batch | encode | 0.462 | 0.000 |
| random.words | batch | decode | 0.106 | 0.000 |
| concurrent.characters | individual | author | 9.124 | 0.000 |
| concurrent.characters | individual | apply | 10.051 | 0.000 |
| concurrent.characters | individual | receive | 14.948 | 0.000 |
| concurrent.characters | individual | encode | 8.115 | 0.000 |
| concurrent.characters | individual | decode | 10.790 | 0.000 |
| concurrent.characters | batch | author | 8.526 | 0.000 |
| concurrent.characters | batch | apply | 7.357 | 0.000 |
| concurrent.characters | batch | receive | 7.187 | 0.000 |
| concurrent.characters | batch | encode | 0.345 | 0.000 |
| concurrent.characters | batch | decode | 0.114 | 0.000 |
| concurrent.words | individual | author | 9.430 | 0.000 |
| concurrent.words | individual | apply | 9.064 | 0.000 |
| concurrent.words | individual | receive | 13.572 | 0.000 |
| concurrent.words | individual | encode | 8.361 | 0.000 |
| concurrent.words | individual | decode | 10.885 | 0.000 |
| concurrent.words | batch | author | 9.226 | 0.000 |
| concurrent.words | batch | apply | 8.045 | 0.000 |
| concurrent.words | batch | receive | 8.323 | 0.000 |
| concurrent.words | batch | encode | 0.719 | 0.000 |
| concurrent.words | batch | decode | 0.122 | 0.000 |
| concurrent.mixed | individual | author | 17.223 | 0.000 |
| concurrent.mixed | individual | apply | 12.284 | 0.000 |
| concurrent.mixed | individual | receive | 17.155 | 0.000 |
| concurrent.mixed | individual | encode | 8.377 | 0.000 |
| concurrent.mixed | individual | decode | 9.750 | 0.000 |
| concurrent.mixed | batch | author | 15.925 | 0.000 |
| concurrent.mixed | batch | apply | 10.076 | 0.000 |
| concurrent.mixed | batch | receive | 10.397 | 0.000 |
| concurrent.mixed | batch | encode | 0.626 | 0.000 |
| concurrent.mixed | batch | decode | 0.129 | 0.000 |
| causal.characters | individual | author | 10.806 | 0.000 |
| causal.characters | individual | apply | 8.603 | 0.000 |
| causal.characters | individual | receive | 12.423 | 0.000 |
| causal.characters | individual | encode | 7.561 | 0.000 |
| causal.characters | individual | decode | 8.963 | 0.000 |
| causal.characters | batch | author | 10.247 | 0.000 |
| causal.characters | batch | apply | 6.683 | 0.000 |
| causal.characters | batch | receive | 7.716 | 0.000 |
| causal.characters | batch | encode | 0.273 | 0.000 |
| causal.characters | batch | decode | 0.119 | 0.000 |
| causal.words | individual | author | 10.840 | 0.000 |
| causal.words | individual | apply | 9.339 | 0.000 |
| causal.words | individual | receive | 13.290 | 0.000 |
| causal.words | individual | encode | 8.864 | 0.000 |
| causal.words | individual | decode | 10.393 | 0.000 |
| causal.words | batch | author | 9.315 | 0.000 |
| causal.words | batch | apply | 8.165 | 0.000 |
| causal.words | batch | receive | 8.141 | 0.000 |
| causal.words | batch | encode | 0.569 | 0.000 |
| causal.words | batch | decode | 0.121 | 0.000 |
| causal.mixed | individual | author | 16.989 | 0.000 |
| causal.mixed | individual | apply | 13.009 | 0.000 |
| causal.mixed | individual | receive | 17.519 | 0.000 |
| causal.mixed | individual | encode | 8.978 | 0.000 |
| causal.mixed | individual | decode | 9.964 | 0.000 |
| causal.mixed | batch | author | 13.842 | 0.000 |
| causal.mixed | batch | apply | 9.346 | 0.000 |
| causal.mixed | batch | receive | 10.403 | 0.000 |
| causal.mixed | batch | encode | 0.426 | 0.000 |
| causal.mixed | batch | decode | 0.106 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
