# Sequencer dynamic lifecycle benchmark

2026-11-27T17:19:44.077Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.23 | 162.89 | 56.49 |
| CommonJS | 199.41 | 164.51 | 56.69 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 325,272 | 3.074 | 3.074 | 3.074 | 0.000 | 0: 3.074 | 0: 3.074 |
| apply | random | A | scaleDown | 24,999 | 346,857 | 2.883 | 2.883 | 2.883 | 0.000 | 0: 2.883 | 0: 2.883 |
| apply | random | A | fullLifecycle | 49,999 | 335,718 | 2.979 | 2.979 | 2.979 | 0.000 | 0: 2.979 | 0: 2.979 |
| create | — | A | scaleUp | 7 | 472 | 2116.429 | 2116.429 | 2116.429 | 0.000 | 0: 2116.429 | 0: 2116.429 |
| create | — | A | scaleDown | 6 | 678 | 1474.467 | 1474.467 | 1474.467 | 0.000 | 0: 1474.467 | 0: 1474.467 |
| create | — | A | fullLifecycle | 13 | 549 | 1820.138 | 1820.138 | 1820.138 | 0.000 | 0: 1820.138 | 0: 1820.138 |
| insert | head | A | scaleUp | 12,500 | 1,317,662 | 0.759 | 0.759 | 0.759 | 0.000 | 0: 0.759 | 0: 0.759 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,317,662 | 0.759 | 0.759 | 0.759 | 0.000 | 0: 0.759 | 0: 0.759 |
| insert | random | A | scaleUp | 25,000 | 575,080 | 1.739 | 1.739 | 1.739 | 0.000 | 0: 1.739 | 0: 1.739 |
| insert | random | A | scaleDown | 25,000 | 587,103 | 1.703 | 1.703 | 1.703 | 0.000 | 0: 1.703 | 0: 1.703 |
| insert | random | A | fullLifecycle | 50,000 | 581,029 | 1.721 | 1.721 | 1.721 | 0.000 | 0: 1.721 | 0: 1.721 |
| insert | tail | A | scaleUp | 12,500 | 1,421,246 | 0.704 | 0.704 | 0.704 | 0.000 | 0: 0.704 | 0: 0.704 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,421,246 | 0.704 | 0.704 | 0.704 | 0.000 | 0: 0.704 | 0: 0.704 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 717,154 | 1.394 | 1.394 | 1.394 | 0.000 | 0: 1.394 | 0: 1.394 |
| remove | head | A | fullLifecycle | 12,500 | 717,154 | 1.394 | 1.394 | 1.394 | 0.000 | 0: 1.394 | 0: 1.394 |
| remove | random | A | scaleUp | 25,000 | 503,538 | 1.986 | 1.986 | 1.986 | 0.000 | 0: 1.986 | 0: 1.986 |
| remove | random | A | scaleDown | 25,000 | 514,787 | 1.943 | 1.943 | 1.943 | 0.000 | 0: 1.943 | 0: 1.943 |
| remove | random | A | fullLifecycle | 50,000 | 509,100 | 1.964 | 1.964 | 1.964 | 0.000 | 0: 1.964 | 0: 1.964 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 813,124 | 1.230 | 1.230 | 1.230 | 0.000 | 0: 1.230 | 0: 1.230 |
| remove | tail | A | fullLifecycle | 12,500 | 813,124 | 1.230 | 1.230 | 1.230 | 0.000 | 0: 1.230 | 0: 1.230 |
| replace | head | A | scaleUp | 25,000 | 490,303 | 2.040 | 2.040 | 2.040 | 0.000 | 0: 2.040 | 0: 2.040 |
| replace | head | A | scaleDown | 25,000 | 491,219 | 2.036 | 2.036 | 2.036 | 0.000 | 0: 2.036 | 0: 2.036 |
| replace | head | A | fullLifecycle | 50,000 | 490,760 | 2.038 | 2.038 | 2.038 | 0.000 | 0: 2.038 | 0: 2.038 |
| replace | random | A | scaleUp | 25,000 | 347,121 | 2.881 | 2.881 | 2.881 | 0.000 | 0: 2.881 | 0: 2.881 |
| replace | random | A | scaleDown | 25,000 | 396,392 | 2.523 | 2.523 | 2.523 | 0.000 | 0: 2.523 | 0: 2.523 |
| replace | random | A | fullLifecycle | 50,000 | 370,124 | 2.702 | 2.702 | 2.702 | 0.000 | 0: 2.702 | 0: 2.702 |
| replace | tail | A | scaleUp | 25,000 | 516,311 | 1.937 | 1.937 | 1.937 | 0.000 | 0: 1.937 | 0: 1.937 |
| replace | tail | A | scaleDown | 25,000 | 55,857 | 17.903 | 17.903 | 17.903 | 0.000 | 0: 17.903 | 0: 17.903 |
| replace | tail | A | fullLifecycle | 50,000 | 100,808 | 9.920 | 9.920 | 9.920 | 0.000 | 0: 9.920 | 0: 9.920 |
| sequence | — | A | scaleUp | 6 | 66 | 15143.683 | 15143.683 | 15143.683 | 0.000 | 0: 15143.683 | 0: 15143.683 |
| sequence | — | A | scaleDown | 6 | 98 | 10195.017 | 10195.017 | 10195.017 | 0.000 | 0: 10195.017 | 0: 10195.017 |
| sequence | — | A | fullLifecycle | 12 | 79 | 12669.350 | 12669.350 | 12669.350 | 0.000 | 0: 12669.350 | 0: 12669.350 |
| value | head | A | scaleUp | 25,000 | 3,228,014 | 0.310 | 0.310 | 0.310 | 0.000 | 0: 0.310 | 0: 0.310 |
| value | head | A | scaleDown | 25,000 | 2,374,733 | 0.421 | 0.421 | 0.421 | 0.000 | 0: 0.421 | 0: 0.421 |
| value | head | A | fullLifecycle | 50,000 | 2,736,397 | 0.365 | 0.365 | 0.365 | 0.000 | 0: 0.365 | 0: 0.365 |
| value | random | A | scaleUp | 25,000 | 926,616 | 1.079 | 1.079 | 1.079 | 0.000 | 0: 1.079 | 0: 1.079 |
| value | random | A | scaleDown | 25,000 | 984,896 | 1.015 | 1.015 | 1.015 | 0.000 | 0: 1.015 | 0: 1.015 |
| value | random | A | fullLifecycle | 50,000 | 954,867 | 1.047 | 1.047 | 1.047 | 0.000 | 0: 1.047 | 0: 1.047 |
| value | tail | A | scaleUp | 25,000 | 6,412,394 | 0.156 | 0.156 | 0.156 | 0.000 | 0: 0.156 | 0: 0.156 |
| value | tail | A | scaleDown | 25,000 | 4,174,668 | 0.240 | 0.240 | 0.240 | 0.000 | 0: 0.240 | 0: 0.240 |
| value | tail | A | fullLifecycle | 50,000 | 5,057,043 | 0.198 | 0.198 | 0.198 | 0.000 | 0: 0.198 | 0: 0.198 |
| values | — | A | scaleUp | 6 | 103 | 9738.717 | 9738.717 | 9738.717 | 0.000 | 0: 9738.717 | 0: 9738.717 |
| values | — | A | scaleDown | 6 | 267 | 3748.300 | 3748.300 | 3748.300 | 0.000 | 0: 3748.300 | 0: 3748.300 |
| values | — | A | fullLifecycle | 12 | 148 | 6743.508 | 6743.508 | 6743.508 | 0.000 | 0: 6743.508 | 0: 6743.508 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5448434.000 | 430.140 | 8.475 |
| A | scaleDown | 5 | 4404655.200 | 431.829 | 8.549 |
| A | fullLifecycle | 11 | 4973989.091 | 430.818 | 8.505 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3135629.000 | 247.550 | 4.877 |
| A | scaleDown | 5 | 2594145.800 | 254.328 | 5.035 |
| A | fullLifecycle | 11 | 2889500.273 | 250.272 | 4.940 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 260,261 | 3.842 | 1.700 | 240.900 |
| apply | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 322,939 | 3.097 | 1.500 | 240.900 |
| apply | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 317,689 | 3.148 | 1.500 | 978.200 |
| apply | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 330,615 | 3.025 | 1.500 | 978.200 |
| apply | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 323,608 | 3.090 | 1.500 | 978.200 |
| apply | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 325,272 | 3.074 | 1.500 | 978.200 |
| apply | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 325,530 | 3.072 | 1.500 | 978.200 |
| apply | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 328,076 | 3.048 | 1.500 | 978.200 |
| apply | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 327,121 | 3.057 | 1.500 | 978.200 |
| apply | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 330,964 | 3.021 | 1.500 | 978.200 |
| apply | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 334,008 | 2.994 | 1.400 | 978.200 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 335,718 | 2.979 | 1.200 | 978.200 |
| insert | head | 0 | up | 1,000 | 49,966 | A | 500 | 810,504 | 1.234 | 0.300 | 118.800 |
| insert | head | 0 | up | 5,000 | 254,523 | A | 2,500 | 1,053,652 | 0.949 | 0.300 | 162.500 |
| insert | head | 0 | up | 10,000 | 509,098 | A | 5,000 | 1,221,956 | 0.818 | 0.300 | 162.500 |
| insert | head | 0 | up | 15,000 | 765,837 | A | 7,500 | 1,306,552 | 0.765 | 0.300 | 162.500 |
| insert | head | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 1,301,880 | 0.768 | 0.300 | 162.500 |
| insert | head | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 1,317,662 | 0.759 | 0.300 | 162.500 |
| insert | head | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 1,317,662 | 0.759 | 0.300 | 162.500 |
| insert | head | 0 | down | 15,000 | 757,461 | A | 12,500 | 1,317,662 | 0.759 | 0.300 | 162.500 |
| insert | head | 0 | down | 10,000 | 505,565 | A | 12,500 | 1,317,662 | 0.759 | 0.300 | 162.500 |
| insert | head | 0 | down | 5,000 | 249,719 | A | 12,500 | 1,317,662 | 0.759 | 0.300 | 162.500 |
| insert | head | 0 | down | 1,000 | 50,567 | A | 12,500 | 1,317,662 | 0.759 | 0.300 | 162.500 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,317,662 | 0.759 | 0.300 | 162.500 |
| insert | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 388,636 | 2.573 | 0.500 | 649.600 |
| insert | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 512,873 | 1.950 | 0.400 | 787.800 |
| insert | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 576,136 | 1.736 | 0.400 | 787.800 |
| insert | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 595,607 | 1.679 | 0.400 | 787.800 |
| insert | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 570,288 | 1.754 | 0.400 | 787.800 |
| insert | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 575,080 | 1.739 | 0.400 | 787.800 |
| insert | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 569,989 | 1.754 | 0.400 | 787.800 |
| insert | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 571,139 | 1.751 | 0.400 | 787.800 |
| insert | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 576,269 | 1.735 | 0.400 | 787.800 |
| insert | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 570,261 | 1.754 | 0.400 | 2033.100 |
| insert | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 576,942 | 1.733 | 0.400 | 2033.100 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 581,029 | 1.721 | 0.400 | 2033.100 |
| insert | tail | 0 | up | 1,000 | 49,966 | A | 500 | 1,146,263 | 0.872 | 0.300 | 20.900 |
| insert | tail | 0 | up | 5,000 | 254,523 | A | 2,500 | 1,313,991 | 0.761 | 0.300 | 85.600 |
| insert | tail | 0 | up | 10,000 | 509,098 | A | 5,000 | 1,432,008 | 0.698 | 0.300 | 85.600 |
| insert | tail | 0 | up | 15,000 | 765,837 | A | 7,500 | 1,459,911 | 0.685 | 0.300 | 179.800 |
| insert | tail | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 1,455,562 | 0.687 | 0.300 | 179.800 |
| insert | tail | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 1,421,246 | 0.704 | 0.300 | 310.800 |
| insert | tail | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 1,421,246 | 0.704 | 0.300 | 310.800 |
| insert | tail | 0 | down | 15,000 | 757,461 | A | 12,500 | 1,421,246 | 0.704 | 0.300 | 310.800 |
| insert | tail | 0 | down | 10,000 | 505,565 | A | 12,500 | 1,421,246 | 0.704 | 0.300 | 310.800 |
| insert | tail | 0 | down | 5,000 | 249,719 | A | 12,500 | 1,421,246 | 0.704 | 0.300 | 310.800 |
| insert | tail | 0 | down | 1,000 | 50,567 | A | 12,500 | 1,421,246 | 0.704 | 0.300 | 310.800 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,421,246 | 0.704 | 0.300 | 310.800 |
| remove | head | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 683,976 | 1.462 | 0.900 | 13.400 |
| remove | head | 0 | down | 15,000 | 757,461 | A | 5,000 | 703,898 | 1.421 | 0.900 | 39.000 |
| remove | head | 0 | down | 10,000 | 505,565 | A | 7,500 | 673,401 | 1.485 | 0.800 | 634.700 |
| remove | head | 0 | down | 5,000 | 249,719 | A | 10,000 | 699,971 | 1.429 | 0.700 | 634.700 |
| remove | head | 0 | down | 1,000 | 50,567 | A | 12,000 | 711,486 | 1.406 | 0.700 | 634.700 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 717,154 | 1.394 | 0.600 | 634.700 |
| remove | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 450,288 | 2.221 | 0.800 | 280.600 |
| remove | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 527,510 | 1.896 | 0.800 | 280.600 |
| remove | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 515,754 | 1.939 | 0.800 | 438.000 |
| remove | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 533,440 | 1.875 | 0.800 | 438.000 |
| remove | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 503,175 | 1.987 | 0.800 | 438.000 |
| remove | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 503,538 | 1.986 | 0.800 | 438.000 |
| remove | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 496,264 | 2.015 | 0.800 | 438.000 |
| remove | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 497,598 | 2.010 | 0.800 | 438.000 |
| remove | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 496,626 | 2.014 | 0.800 | 438.000 |
| remove | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 503,698 | 1.985 | 0.800 | 438.000 |
| remove | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 505,213 | 1.979 | 0.800 | 438.000 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 509,100 | 1.964 | 0.700 | 438.000 |
| remove | tail | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 776,470 | 1.288 | 0.900 | 47.700 |
| remove | tail | 0 | down | 15,000 | 757,461 | A | 5,000 | 810,031 | 1.235 | 0.800 | 47.700 |
| remove | tail | 0 | down | 10,000 | 505,565 | A | 7,500 | 807,868 | 1.238 | 0.800 | 47.700 |
| remove | tail | 0 | down | 5,000 | 249,719 | A | 10,000 | 812,645 | 1.231 | 0.700 | 91.500 |
| remove | tail | 0 | down | 1,000 | 50,567 | A | 12,000 | 807,793 | 1.238 | 0.700 | 91.500 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 813,124 | 1.230 | 0.700 | 91.500 |
| replace | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 358,192 | 2.792 | 1.100 | 544.900 |
| replace | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 484,684 | 2.063 | 1.000 | 544.900 |
| replace | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 522,665 | 1.913 | 1.000 | 544.900 |
| replace | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 543,384 | 1.840 | 1.000 | 544.900 |
| replace | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 522,189 | 1.915 | 1.000 | 1203.500 |
| replace | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 490,303 | 2.040 | 1.000 | 3148.100 |
| replace | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 492,132 | 2.032 | 1.000 | 3148.100 |
| replace | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 481,624 | 2.076 | 1.000 | 3148.100 |
| replace | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 481,860 | 2.075 | 1.000 | 3148.100 |
| replace | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 486,123 | 2.057 | 1.000 | 3148.100 |
| replace | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 488,289 | 2.048 | 1.000 | 3148.100 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 490,760 | 2.038 | 0.900 | 3148.100 |
| replace | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 364,950 | 2.740 | 1.100 | 138.600 |
| replace | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 349,379 | 2.862 | 1.100 | 888.900 |
| replace | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 370,124 | 2.702 | 1.100 | 888.900 |
| replace | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 371,530 | 2.692 | 1.100 | 888.900 |
| replace | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 343,414 | 2.912 | 1.100 | 2931.500 |
| replace | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 347,121 | 2.881 | 1.100 | 2931.500 |
| replace | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 350,433 | 2.854 | 1.100 | 2931.500 |
| replace | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 353,484 | 2.829 | 1.100 | 2931.500 |
| replace | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 357,115 | 2.800 | 1.100 | 2931.500 |
| replace | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 362,906 | 2.756 | 1.100 | 2931.500 |
| replace | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 367,391 | 2.722 | 1.100 | 2931.500 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 370,124 | 2.702 | 0.900 | 2931.500 |
| replace | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 459,031 | 2.179 | 1.000 | 93.400 |
| replace | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 539,165 | 1.855 | 1.000 | 107.900 |
| replace | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 552,151 | 1.811 | 1.000 | 166.200 |
| replace | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 556,826 | 1.796 | 1.000 | 572.600 |
| replace | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 536,125 | 1.865 | 1.000 | 572.600 |
| replace | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 516,311 | 1.937 | 1.000 | 1725.100 |
| replace | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 131,118 | 7.627 | 1.000 | 1725.100 |
| replace | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 98,583 | 10.144 | 1.000 | 1725.100 |
| replace | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 98,945 | 10.107 | 1.000 | 1725.100 |
| replace | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 96,691 | 10.342 | 1.000 | 1725.100 |
| replace | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 99,232 | 10.077 | 1.000 | 1725.100 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 100,808 | 9.920 | 0.800 | 1725.100 |
| value | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 1,530,690 | 0.653 | 0.100 | 288.100 |
| value | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 2,580,778 | 0.387 | 0.100 | 288.100 |
| value | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 2,976,722 | 0.336 | 0.100 | 288.100 |
| value | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 3,180,055 | 0.314 | 0.100 | 288.100 |
| value | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 3,169,472 | 0.316 | 0.100 | 288.100 |
| value | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 3,228,014 | 0.310 | 0.100 | 288.100 |
| value | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 3,027,092 | 0.330 | 0.100 | 288.100 |
| value | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 2,915,889 | 0.343 | 0.100 | 288.100 |
| value | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 2,822,009 | 0.354 | 0.100 | 288.100 |
| value | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 2,780,180 | 0.360 | 0.100 | 288.100 |
| value | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 2,743,561 | 0.364 | 0.100 | 288.100 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,736,397 | 0.365 | 0.100 | 288.100 |
| value | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 1,332,090 | 0.751 | 0.100 | 24.800 |
| value | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 1,092,968 | 0.915 | 0.100 | 24.800 |
| value | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 1,022,286 | 0.978 | 0.100 | 24.800 |
| value | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 1,002,446 | 0.998 | 0.100 | 62.600 |
| value | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 937,959 | 1.066 | 0.100 | 62.600 |
| value | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 926,616 | 1.079 | 0.100 | 119.300 |
| value | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 928,005 | 1.078 | 0.100 | 119.300 |
| value | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 929,798 | 1.076 | 0.100 | 119.300 |
| value | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 926,172 | 1.080 | 0.100 | 119.300 |
| value | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 941,507 | 1.062 | 0.100 | 119.300 |
| value | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 946,147 | 1.057 | 0.100 | 119.300 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 954,867 | 1.047 | 0.100 | 119.300 |
| value | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 5,458,515 | 0.183 | 0.100 | 3.100 |
| value | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 5,628,729 | 0.178 | 0.100 | 18.800 |
| value | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 5,809,563 | 0.172 | 0.100 | 54.400 |
| value | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 6,065,753 | 0.165 | 0.000 | 54.400 |
| value | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 6,271,362 | 0.159 | 0.000 | 54.400 |
| value | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 6,412,394 | 0.156 | 0.000 | 54.400 |
| value | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 5,774,561 | 0.173 | 0.000 | 94.300 |
| value | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 5,500,031 | 0.182 | 0.000 | 94.300 |
| value | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 5,279,552 | 0.189 | 0.000 | 94.300 |
| value | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 5,169,977 | 0.193 | 0.000 | 94.300 |
| value | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 5,049,724 | 0.198 | 0.000 | 94.300 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,057,043 | 0.198 | 0.000 | 94.300 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 3,035 | 329.500 |
| create | — | 0 | up | 5,000 | A | 1 | 833 | 1201.100 |
| create | — | 0 | up | 10,000 | A | 1 | 629 | 1590.600 |
| create | — | 0 | up | 15,000 | A | 1 | 315 | 3179.500 |
| create | — | 0 | up | 20,000 | A | 1 | 309 | 3240.900 |
| create | — | 0 | up | 25,000 | A | 1 | 194 | 5156.900 |
| create | — | 0 | down | 20,000 | A | 1 | 288 | 3468.400 |
| create | — | 0 | down | 15,000 | A | 1 | 384 | 2603.500 |
| create | — | 0 | down | 10,000 | A | 1 | 560 | 1784.200 |
| create | — | 0 | down | 5,000 | A | 1 | 1,209 | 827.400 |
| create | — | 0 | down | 1,000 | A | 1 | 6,631 | 150.800 |
| create | — | 0 | down | 0 | A | 1 | 80,000 | 12.500 |
| sequence | — | 0 | up | 1,000 | A | 1 | 446 | 2244.400 |
| sequence | — | 0 | up | 5,000 | A | 1 | 98 | 10215.600 |
| sequence | — | 0 | up | 10,000 | A | 1 | 84 | 11900.100 |
| sequence | — | 0 | up | 15,000 | A | 1 | 41 | 24172.200 |
| sequence | — | 0 | up | 20,000 | A | 1 | 52 | 19398.600 |
| sequence | — | 0 | up | 25,000 | A | 1 | 44 | 22931.200 |
| sequence | — | 0 | down | 20,000 | A | 1 | 56 | 17894.200 |
| sequence | — | 0 | down | 15,000 | A | 1 | 66 | 15040.900 |
| sequence | — | 0 | down | 10,000 | A | 1 | 82 | 12230.900 |
| sequence | — | 0 | down | 5,000 | A | 1 | 110 | 9050.100 |
| sequence | — | 0 | down | 1,000 | A | 1 | 174 | 5746.900 |
| sequence | — | 0 | down | 0 | A | 1 | 828 | 1207.100 |
| values | — | 0 | up | 1,000 | A | 1 | 582 | 1718.000 |
| values | — | 0 | up | 5,000 | A | 1 | 212 | 4720.400 |
| values | — | 0 | up | 10,000 | A | 1 | 51 | 19743.800 |
| values | — | 0 | up | 15,000 | A | 1 | 102 | 9774.800 |
| values | — | 0 | up | 20,000 | A | 1 | 84 | 11935.500 |
| values | — | 0 | up | 25,000 | A | 1 | 95 | 10539.800 |
| values | — | 0 | down | 20,000 | A | 1 | 124 | 8087.200 |
| values | — | 0 | down | 15,000 | A | 1 | 148 | 6763.200 |
| values | — | 0 | down | 10,000 | A | 1 | 227 | 4399.100 |
| values | — | 0 | down | 5,000 | A | 1 | 366 | 2731.400 |
| values | — | 0 | down | 1,000 | A | 1 | 2,003 | 499.300 |
| values | — | 0 | down | 0 | A | 1 | 104,167 | 9.600 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.613 | 0.232 | 0.381 |
| 0 | up | 5000 | 3.108 | 1.167 | 1.942 |
| 0 | up | 10000 | 6.228 | 2.343 | 3.884 |
| 0 | up | 15000 | 9.486 | 3.643 | 5.843 |
| 0 | up | 20000 | 12.852 | 5.113 | 7.739 |
| 0 | up | 25000 | 16.278 | 6.637 | 9.641 |
| 0 | down | 20000 | 13.340 | 5.613 | 7.727 |
| 0 | down | 15000 | 9.910 | 4.131 | 5.779 |
| 0 | down | 10000 | 7.153 | 3.295 | 3.857 |
| 0 | down | 5000 | 4.067 | 2.161 | 1.905 |
| 0 | down | 1000 | 1.807 | 1.421 | 0.386 |
| 0 | down | 0 | 1.231 | 1.231 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 49,966 | 0.402 | 421.140 | 8.429 | 121.598 | 15.524 |
| 0 | up | A | 5,000 | 5,000 | 254,523 | 2.043 | 428.454 | 8.417 | 155.324 | 19.626 |
| 0 | up | A | 10,000 | 10,000 | 509,098 | 4.098 | 429.682 | 8.440 | 194.504 | 24.536 |
| 0 | up | A | 15,000 | 15,000 | 765,837 | 6.183 | 432.249 | 8.466 | 209.098 | 29.444 |
| 0 | up | A | 20,000 | 20,000 | 1,014,350 | 8.209 | 430.368 | 8.486 | 280.098 | 34.234 |
| 0 | up | A | 25,000 | 25,000 | 1,263,607 | 10.242 | 429.572 | 8.499 | 295.582 | 39.002 |
| 0 | down | A | 20,000 | 20,000 | 1,012,792 | 8.267 | 433.443 | 8.559 | 294.902 | 34.236 |
| 0 | down | A | 15,000 | 15,000 | 757,461 | 6.185 | 432.337 | 8.562 | 298.398 | 29.390 |
| 0 | down | A | 10,000 | 10,000 | 505,565 | 4.118 | 431.804 | 8.541 | 298.820 | 24.615 |
| 0 | down | A | 5,000 | 5,000 | 249,719 | 2.025 | 424.661 | 8.503 | 295.117 | 19.779 |
| 0 | down | A | 1,000 | 1,000 | 50,567 | 0.408 | 428.020 | 8.464 | 293.574 | 15.984 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 294.539 | 14.906 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 49966 | 184228 | 184.228 | 3.687 | 271.76 | 14.53 | 161.92 | 12.35 |
| 0 | up | A | 5000 | 254523 | 1210131 | 242.026 | 4.755 | 1634.13 | 73.21 | 825.25 | 61.48 |
| 0 | up | A | 10000 | 509098 | 2448079 | 244.808 | 4.809 | 3283.48 | 149.01 | 1658.86 | 124.83 |
| 0 | up | A | 15000 | 765837 | 3734371 | 248.958 | 4.876 | 4974.88 | 226.26 | 3590.17 | 200.09 |
| 0 | up | A | 20000 | 1014350 | 4987172 | 249.359 | 4.917 | 7129.39 | 311.11 | 5143.68 | 263.60 |
| 0 | up | A | 25000 | 1263607 | 6249793 | 249.992 | 4.946 | 9254.82 | 392.21 | 6545.54 | 334.80 |
| 0 | down | A | 20000 | 1012792 | 5129580 | 256.479 | 5.065 | 7576.63 | 326.54 | 5319.60 | 278.20 |
| 0 | down | A | 15000 | 757461 | 3834350 | 255.623 | 5.062 | 5712.74 | 247.20 | 3993.54 | 209.87 |
| 0 | down | A | 10000 | 505565 | 2537356 | 253.736 | 5.019 | 3822.17 | 165.03 | 2665.76 | 139.77 |
| 0 | down | A | 5000 | 249719 | 1229097 | 245.819 | 4.922 | 1877.54 | 79.58 | 1312.05 | 67.88 |
| 0 | down | A | 1000 | 50567 | 240346 | 240.346 | 4.753 | 377.29 | 15.97 | 264.47 | 13.64 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 430.140 | 8.475 | 247.550 | 4.877 |
| 0 | A | scaleDown | 431.829 | 8.549 | 254.328 | 5.035 |
| 0 | A | fullLifecycle | 430.818 | 8.505 | 250.272 | 4.940 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
