# Large string benchmarks

2026-11-27T17:20:46.225Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2318.32 | 0.00 |
| 1024 | insert.append | array | 13175.59 | 0.00 |
| 1024 | replace | array | 3233.97 | 0.00 |
| 1024 | remove | array | 1061.40 | 0.00 |
| 1024 | remove.middle | array | 1901.94 | 0.00 |
| 1024 | replace.middle | array | 2295.02 | 0.00 |
| 1024 | apply | array | 756.35 | 0.00 |
| 1024 | apply.array | array | 630.08 | 0.00 |
| 1024 | concurrent.apply | array | 66245.77 | 0.00 |
| 1024 | merge | array | 3802.97 | 0.00 |
| 1024 | create | array | 3306.92 | 0.00 |
| 1024 | value.random | array | 47.39 | 0.00 |
| 1024 | values.range | array | 113.28 | 0.00 |
| 1024 | values.array | array | 1290.73 | 0.00 |
| 1024 | values.text | array | 14826.50 | 0.00 |
| 1024 | sequence.array | array | 2331.22 | 0.00 |
| 1024 | sequence.text | array | 10857.62 | 0.00 |
| 1024 | sequence.edited.text | array | 15357.49 | 0.00 |
| 1024 | sequence.masked.text | array | 11816.30 | 0.00 |
| 1024 | insert | string | 446.95 | 0.00 |
| 1024 | insert.append | string | 4217.02 | 0.00 |
| 1024 | replace | string | 1218.88 | 0.00 |
| 1024 | remove | string | 946.39 | 0.00 |
| 1024 | remove.middle | string | 1031.85 | 0.00 |
| 1024 | replace.middle | string | 1350.73 | 0.00 |
| 1024 | apply | string | 892.19 | 0.00 |
| 1024 | apply.array | string | 2561.49 | 0.00 |
| 1024 | concurrent.apply | string | 4069.32 | 0.00 |
| 1024 | merge | string | 1564.94 | 0.00 |
| 1024 | create | string | 1011.44 | 0.00 |
| 1024 | value.random | string | 53.69 | 0.00 |
| 1024 | values.range | string | 151.14 | 0.00 |
| 1024 | values.array | string | 1798.12 | 0.00 |
| 1024 | values.text | string | 70.02 | 0.00 |
| 1024 | sequence.array | string | 2624.55 | 0.00 |
| 1024 | sequence.text | string | 271.10 | 0.00 |
| 1024 | sequence.edited.text | string | 2705.38 | 0.00 |
| 1024 | sequence.masked.text | string | 3897.50 | 0.00 |
| 65536 | insert | array | 282176.60 | 0.00 |
| 65536 | insert.append | array | 1219571.43 | 0.00 |
| 65536 | replace | array | 263520.00 | 0.00 |
| 65536 | remove | array | 2453.14 | 0.00 |
| 65536 | remove.middle | array | 223594.64 | 0.00 |
| 65536 | replace.middle | array | 262518.35 | 0.00 |
| 65536 | apply | array | 1314.66 | 0.00 |
| 65536 | apply.array | array | 566.93 | 0.00 |
| 65536 | concurrent.apply | array | 3943585.71 | 0.00 |
| 65536 | merge | array | 207714.88 | 0.00 |
| 65536 | create | array | 207628.10 | 0.00 |
| 65536 | value.random | array | 52.72 | 0.00 |
| 65536 | values.range | array | 130.43 | 0.00 |
| 65536 | values.array | array | 209055.56 | 0.00 |
| 65536 | values.text | array | 775821.21 | 0.00 |
| 65536 | sequence.array | array | 195700.78 | 0.00 |
| 65536 | sequence.text | array | 717191.43 | 0.00 |
| 65536 | sequence.edited.text | array | 893200.00 | 0.00 |
| 65536 | sequence.masked.text | array | 717302.86 | 0.00 |
| 65536 | insert | string | 359.02 | 0.00 |
| 65536 | insert.append | string | 22938.72 | 0.00 |
| 65536 | replace | string | 1402.88 | 0.00 |
| 65536 | remove | string | 972.80 | 0.00 |
| 65536 | remove.middle | string | 961.51 | 0.00 |
| 65536 | replace.middle | string | 1314.61 | 0.00 |
| 65536 | apply | string | 875.94 | 0.00 |
| 65536 | apply.array | string | 261776.56 | 0.00 |
| 65536 | concurrent.apply | string | 147081.18 | 0.00 |
| 65536 | merge | string | 1718.87 | 0.00 |
| 65536 | create | string | 947.19 | 0.00 |
| 65536 | value.random | string | 69.99 | 0.00 |
| 65536 | values.range | string | 153.66 | 0.00 |
| 65536 | values.array | string | 270488.28 | 0.00 |
| 65536 | values.text | string | 67.87 | 0.00 |
| 65536 | sequence.array | string | 252492.97 | 0.00 |
| 65536 | sequence.text | string | 200.13 | 0.00 |
| 65536 | sequence.edited.text | string | 90682.61 | 0.00 |
| 65536 | sequence.masked.text | string | 3296.32 | 0.00 |
| 1048576 | insert | array | 3218725.00 | 0.00 |
| 1048576 | insert.append | array | 24085500.00 | 0.00 |
| 1048576 | replace | array | 3740014.29 | 0.00 |
| 1048576 | remove | array | 11288.10 | 0.00 |
| 1048576 | remove.middle | array | 5143740.00 | 0.00 |
| 1048576 | replace.middle | array | 3126475.00 | 0.00 |
| 1048576 | apply | array | 1685.21 | 0.00 |
| 1048576 | apply.array | array | 699.40 | 0.00 |
| 1048576 | concurrent.apply | array | 72589300.00 | 0.00 |
| 1048576 | merge | array | 3217950.00 | 0.00 |
| 1048576 | create | array | 3145887.50 | 0.00 |
| 1048576 | value.random | array | 37.81 | 0.00 |
| 1048576 | values.range | array | 103.45 | 0.00 |
| 1048576 | values.array | array | 2429781.82 | 0.00 |
| 1048576 | values.text | array | 13137350.00 | 0.00 |
| 1048576 | sequence.array | array | 2377227.27 | 0.00 |
| 1048576 | sequence.text | array | 63351600.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 67144450.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 72858650.00 | 0.00 |
| 1048576 | insert | string | 688.83 | 0.00 |
| 1048576 | insert.append | string | 834866.67 | 0.00 |
| 1048576 | replace | string | 1936.85 | 0.00 |
| 1048576 | remove | string | 1341.44 | 0.00 |
| 1048576 | remove.middle | string | 1235.08 | 0.00 |
| 1048576 | replace.middle | string | 2220.58 | 0.00 |
| 1048576 | apply | string | 1570.39 | 0.00 |
| 1048576 | apply.array | string | 3849612.50 | 0.00 |
| 1048576 | concurrent.apply | string | 1389283.33 | 0.00 |
| 1048576 | merge | string | 1191.97 | 0.00 |
| 1048576 | create | string | 1053.48 | 0.00 |
| 1048576 | value.random | string | 54.29 | 0.00 |
| 1048576 | values.range | string | 166.32 | 0.00 |
| 1048576 | values.array | string | 3521562.50 | 0.00 |
| 1048576 | values.text | string | 69.74 | 0.00 |
| 1048576 | sequence.array | string | 3562137.50 | 0.00 |
| 1048576 | sequence.text | string | 222.08 | 0.00 |
| 1048576 | sequence.edited.text | string | 1572356.25 | 0.00 |
| 1048576 | sequence.masked.text | string | 3390.73 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
