# Tuple benchmarks

2026-11-27T17:20:31.854Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 2,894,458 | 2,379,880 | 0.82× |
| 2 | create.sequence | 990,576 | 852,554 | 0.86× |
| 2 | replace.random | 1,192,054 | 1,465,538 | 1.23× |
| 2 | apply.replace | 528,711 | 776,027 | 1.47× |
| 2 | apply.duplicate | 1,670,752 | 1,605,456 | 0.96× |
| 2 | merge.duplicate | 1,479,372 | 1,484,502 | 1.00× |
| 2 | length | 127,337,377 | 134,913,934 | 1.06× |
| 2 | value.random | 35,283,594 | 55,517,490 | 1.57× |
| 2 | values | 12,362,750 | 11,288,817 | 0.91× |
| 2 | sequence | 2,978,464 | 2,275,176 | 0.76× |
| 4 | create.empty | 2,425,497 | 2,425,182 | 1.00× |
| 4 | create.sequence | 723,463 | 725,847 | 1.00× |
| 4 | replace.random | 1,026,531 | 1,496,687 | 1.46× |
| 4 | apply.replace | 619,179 | 933,756 | 1.51× |
| 4 | apply.duplicate | 1,728,870 | 1,700,486 | 0.98× |
| 4 | merge.duplicate | 1,273,360 | 1,220,377 | 0.96× |
| 4 | length | 36,202,020 | 37,114,056 | 1.03× |
| 4 | value.random | 24,463,955 | 57,323,041 | 2.34× |
| 4 | values | 6,941,266 | 6,492,158 | 0.94× |
| 4 | sequence | 2,452,107 | 2,519,505 | 1.03× |
| 8 | create.empty | 2,559,821 | 2,407,276 | 0.94× |
| 8 | create.sequence | 469,927 | 529,074 | 1.13× |
| 8 | replace.random | 1,020,143 | 1,492,087 | 1.46× |
| 8 | apply.replace | 571,130 | 970,944 | 1.70× |
| 8 | apply.duplicate | 1,668,891 | 1,677,507 | 1.01× |
| 8 | merge.duplicate | 892,467 | 877,886 | 0.98× |
| 8 | length | 35,331,897 | 34,076,335 | 0.96× |
| 8 | value.random | 17,737,258 | 56,271,202 | 3.17× |
| 8 | values | 4,648,846 | 5,028,474 | 1.08× |
| 8 | sequence | 1,829,878 | 1,751,731 | 0.96× |
| 100 | create.empty | 2,406,930 | 2,308,446 | 0.96× |
| 100 | create.sequence | 70,283 | 81,596 | 1.16× |
| 100 | replace.random | 1,025,272 | 1,614,588 | 1.57× |
| 100 | apply.replace | 675,936 | 918,494 | 1.36× |
| 100 | apply.duplicate | 1,664,052 | 1,641,358 | 0.99× |
| 100 | merge.duplicate | 109,312 | 75,859 | 0.69× |
| 100 | length | 37,939,319 | 32,175,355 | 0.85× |
| 100 | value.random | 11,891,896 | 51,984,128 | 4.37× |
| 100 | values | 545,879 | 678,382 | 1.24× |
| 100 | sequence | 190,462 | 188,401 | 0.99× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
