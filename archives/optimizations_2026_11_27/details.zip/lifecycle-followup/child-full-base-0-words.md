# Words benchmarks

2026-11-27T17:21:08.781Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 29,471 | 169,338 | 178 |
| append | packed | 5.90 | 3.61 | 13.98 | 31,812 | 191,929 | 283 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,791 | 834 | 247 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 29,087 | 1,612 | 244 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 371 | 154 | 76 |
| random | packed | 49.58 | 35.38 | 23.45 | 14,145 | 488 | 125 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 696 | 210 | 96 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 17,473 | 363 | 125 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 662.35 | 0.00 |
| append | numeric | encode | 33931.61 | 0.00 |
| append | numeric | decode | 3191.98 | 0.00 |
| append | numeric | create | 1789.28 | 0.00 |
| append | numeric | load | 5905.36 | 0.00 |
| append | numeric | apply | 3370626.67 | 0.00 |
| append | numeric | receive | 5623477.78 | 0.00 |
| append | binary | sequence | 558.43 | 0.00 |
| append | binary | encode | 31434.80 | 0.00 |
| append | binary | decode | 2308.31 | 0.00 |
| append | binary | create | 1904.37 | 0.00 |
| append | binary | load | 5210.26 | 0.00 |
| append | binary | apply | 1937907.69 | 0.00 |
| append | binary | receive | 3532393.33 | 0.00 |
| prepend | numeric | sequence | 510853.06 | 0.00 |
| prepend | numeric | encode | 558477.78 | 0.00 |
| prepend | numeric | decode | 169026.35 | 0.00 |
| prepend | numeric | create | 639758.23 | 0.00 |
| prepend | numeric | load | 1198388.10 | 0.00 |
| prepend | numeric | apply | 2339059.09 | 0.00 |
| prepend | numeric | receive | 4051653.85 | 0.00 |
| prepend | binary | sequence | 368435.29 | 0.00 |
| prepend | binary | encode | 34379.93 | 0.00 |
| prepend | binary | decode | 2653.34 | 0.00 |
| prepend | binary | create | 614337.80 | 0.00 |
| prepend | binary | load | 620187.65 | 0.00 |
| prepend | binary | apply | 2609305.00 | 0.00 |
| prepend | binary | receive | 4091453.85 | 0.00 |
| random | numeric | sequence | 1576381.25 | 0.00 |
| random | numeric | encode | 2695989.47 | 0.00 |
| random | numeric | decode | 924229.09 | 0.00 |
| random | numeric | create | 2241086.96 | 0.00 |
| random | numeric | load | 6479387.50 | 0.00 |
| random | numeric | apply | 9384666.67 | 0.00 |
| random | numeric | receive | 13140325.00 | 0.00 |
| random | binary | sequence | 930237.04 | 0.00 |
| random | binary | encode | 70697.13 | 0.00 |
| random | binary | decode | 1604.14 | 0.00 |
| random | binary | create | 1932200.00 | 0.00 |
| random | binary | load | 2047764.00 | 0.00 |
| random | binary | apply | 6770475.00 | 0.00 |
| random | binary | receive | 7970642.86 | 0.00 |
| concurrent | numeric | sequence | 803639.68 | 0.00 |
| concurrent | numeric | encode | 1437540.00 | 0.00 |
| concurrent | numeric | decode | 750662.69 | 0.00 |
| concurrent | numeric | create | 2495047.62 | 0.00 |
| concurrent | numeric | load | 4750609.09 | 0.00 |
| concurrent | numeric | apply | 6040122.22 | 0.00 |
| concurrent | numeric | receive | 10454240.00 | 0.00 |
| concurrent | binary | sequence | 769836.92 | 0.00 |
| concurrent | binary | encode | 57231.81 | 0.00 |
| concurrent | binary | decode | 2703.44 | 0.00 |
| concurrent | binary | create | 3572800.00 | 0.00 |
| concurrent | binary | load | 2752584.21 | 0.00 |
| concurrent | binary | apply | 6112844.44 | 0.00 |
| concurrent | binary | receive | 8017942.86 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
