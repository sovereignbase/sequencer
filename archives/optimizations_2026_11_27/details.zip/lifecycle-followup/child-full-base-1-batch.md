# Batch benchmarks

2026-11-27T17:26:20.518Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 1,253,656 | 1,066,098 | 556,834 | 76.05 | 5.99 | 0.012 |
| append | batch | 2,665,127 | 182,926,829 | 202,702,703 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,694,484 | 1,471,490 | 792,948 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 1,692,525 | 1,977,457 | 1,834,077 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 776,036 | 997,490 | 696,435 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 927,845 | 1,412,030 | 1,285,733 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 1,014,199 | 969,149 | 703,359 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 1,056,189 | 1,662,464 | 1,522,959 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,214,489 | 1,159,846 | 813,477 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,340,797 | 1,805,108 | 1,629,284 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,335,411 | 1,376,084 | 899,996 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,438,849 | 1,642,688 | 1,622,060 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 564,013 | 906,009 | 668,513 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 891,239 | 1,153,436 | 1,153,458 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,102,637 | 1,319,334 | 958,038 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 1,283,642 | 1,834,918 | 1,540,971 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,137,851 | 1,347,739 | 894,561 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 1,308,501 | 1,618,101 | 1,388,326 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 716,846 | 818,425 | 676,346 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 902,140 | 1,247,985 | 1,122,870 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 4.786 | 0.000 |
| append | individual | apply | 5.628 | 0.000 |
| append | individual | receive | 10.775 | 0.000 |
| append | individual | encode | 8.375 | 0.000 |
| append | individual | decode | 6.904 | 0.000 |
| append | batch | author | 2.251 | 0.000 |
| append | batch | apply | 0.033 | 0.000 |
| append | batch | receive | 0.030 | 0.000 |
| append | batch | encode | 0.195 | 0.000 |
| append | batch | decode | 0.096 | 0.000 |
| prepend | individual | author | 3.541 | 0.000 |
| prepend | individual | apply | 4.077 | 0.000 |
| prepend | individual | receive | 7.567 | 0.000 |
| prepend | individual | encode | 5.807 | 0.000 |
| prepend | individual | decode | 8.809 | 0.000 |
| prepend | batch | author | 3.545 | 0.000 |
| prepend | batch | apply | 3.034 | 0.000 |
| prepend | batch | receive | 3.271 | 0.000 |
| prepend | batch | encode | 0.257 | 0.000 |
| prepend | batch | decode | 0.109 | 0.000 |
| random.characters | individual | author | 7.732 | 0.000 |
| random.characters | individual | apply | 6.015 | 0.000 |
| random.characters | individual | receive | 8.615 | 0.000 |
| random.characters | individual | encode | 5.443 | 0.000 |
| random.characters | individual | decode | 10.028 | 0.000 |
| random.characters | batch | author | 6.467 | 0.000 |
| random.characters | batch | apply | 4.249 | 0.000 |
| random.characters | batch | receive | 4.667 | 0.000 |
| random.characters | batch | encode | 0.285 | 0.000 |
| random.characters | batch | decode | 0.118 | 0.000 |
| random.words | individual | author | 5.916 | 0.000 |
| random.words | individual | apply | 6.191 | 0.000 |
| random.words | individual | receive | 8.530 | 0.000 |
| random.words | individual | encode | 4.241 | 0.000 |
| random.words | individual | decode | 8.082 | 0.000 |
| random.words | batch | author | 5.681 | 0.000 |
| random.words | batch | apply | 3.609 | 0.000 |
| random.words | batch | receive | 3.940 | 0.000 |
| random.words | batch | encode | 0.411 | 0.000 |
| random.words | batch | decode | 0.107 | 0.000 |
| concurrent.characters | individual | author | 9.881 | 0.000 |
| concurrent.characters | individual | apply | 10.346 | 0.000 |
| concurrent.characters | individual | receive | 14.752 | 0.000 |
| concurrent.characters | individual | encode | 7.852 | 0.000 |
| concurrent.characters | individual | decode | 9.562 | 0.000 |
| concurrent.characters | batch | author | 8.950 | 0.000 |
| concurrent.characters | batch | apply | 6.648 | 0.000 |
| concurrent.characters | batch | receive | 7.365 | 0.000 |
| concurrent.characters | batch | encode | 0.316 | 0.000 |
| concurrent.characters | batch | decode | 0.108 | 0.000 |
| concurrent.words | individual | author | 8.986 | 0.000 |
| concurrent.words | individual | apply | 8.720 | 0.000 |
| concurrent.words | individual | receive | 13.333 | 0.000 |
| concurrent.words | individual | encode | 8.034 | 0.000 |
| concurrent.words | individual | decode | 11.703 | 0.000 |
| concurrent.words | batch | author | 8.340 | 0.000 |
| concurrent.words | batch | apply | 7.305 | 0.000 |
| concurrent.words | batch | receive | 7.398 | 0.000 |
| concurrent.words | batch | encode | 0.653 | 0.000 |
| concurrent.words | batch | decode | 0.119 | 0.000 |
| concurrent.mixed | individual | author | 21.276 | 0.000 |
| concurrent.mixed | individual | apply | 13.245 | 0.000 |
| concurrent.mixed | individual | receive | 17.950 | 0.000 |
| concurrent.mixed | individual | encode | 8.873 | 0.000 |
| concurrent.mixed | individual | decode | 10.233 | 0.000 |
| concurrent.mixed | batch | author | 13.464 | 0.000 |
| concurrent.mixed | batch | apply | 10.404 | 0.000 |
| concurrent.mixed | batch | receive | 10.403 | 0.000 |
| concurrent.mixed | batch | encode | 0.564 | 0.000 |
| concurrent.mixed | batch | decode | 0.118 | 0.000 |
| causal.characters | individual | author | 10.883 | 0.000 |
| causal.characters | individual | apply | 9.095 | 0.000 |
| causal.characters | individual | receive | 12.526 | 0.000 |
| causal.characters | individual | encode | 7.565 | 0.000 |
| causal.characters | individual | decode | 9.424 | 0.000 |
| causal.characters | batch | author | 9.348 | 0.000 |
| causal.characters | batch | apply | 6.540 | 0.000 |
| causal.characters | batch | receive | 7.787 | 0.000 |
| causal.characters | batch | encode | 0.214 | 0.000 |
| causal.characters | batch | decode | 0.119 | 0.000 |
| causal.words | individual | author | 10.546 | 0.000 |
| causal.words | individual | apply | 8.904 | 0.000 |
| causal.words | individual | receive | 13.414 | 0.000 |
| causal.words | individual | encode | 8.270 | 0.000 |
| causal.words | individual | decode | 9.474 | 0.000 |
| causal.words | batch | author | 9.171 | 0.000 |
| causal.words | batch | apply | 7.416 | 0.000 |
| causal.words | batch | receive | 8.644 | 0.000 |
| causal.words | batch | encode | 0.557 | 0.000 |
| causal.words | batch | decode | 0.120 | 0.000 |
| causal.mixed | individual | author | 16.740 | 0.000 |
| causal.mixed | individual | apply | 14.662 | 0.000 |
| causal.mixed | individual | receive | 17.742 | 0.000 |
| causal.mixed | individual | encode | 9.024 | 0.000 |
| causal.mixed | individual | decode | 13.340 | 0.000 |
| causal.mixed | batch | author | 13.302 | 0.000 |
| causal.mixed | batch | apply | 9.615 | 0.000 |
| causal.mixed | batch | receive | 10.687 | 0.000 |
| causal.mixed | batch | encode | 0.407 | 0.000 |
| causal.mixed | batch | decode | 0.110 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
