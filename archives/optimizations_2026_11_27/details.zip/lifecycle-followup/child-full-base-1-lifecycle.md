# Sequencer dynamic lifecycle benchmark

2026-11-27T17:24:49.946Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.23 | 162.89 | 56.49 |
| CommonJS | 199.41 | 164.51 | 56.69 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 294,766 | 3.393 | 3.393 | 3.393 | 0.000 | 0: 3.393 | 0: 3.393 |
| apply | random | A | scaleDown | 24,999 | 319,462 | 3.130 | 3.130 | 3.130 | 0.000 | 0: 3.130 | 0: 3.130 |
| apply | random | A | fullLifecycle | 49,999 | 306,617 | 3.261 | 3.261 | 3.261 | 0.000 | 0: 3.261 | 0: 3.261 |
| create | — | A | scaleUp | 7 | 522 | 1915.943 | 1915.943 | 1915.943 | 0.000 | 0: 1915.943 | 0: 1915.943 |
| create | — | A | scaleDown | 6 | 490 | 2040.283 | 2040.283 | 2040.283 | 0.000 | 0: 2040.283 | 0: 2040.283 |
| create | — | A | fullLifecycle | 13 | 507 | 1973.331 | 1973.331 | 1973.331 | 0.000 | 0: 1973.331 | 0: 1973.331 |
| insert | head | A | scaleUp | 12,500 | 1,280,174 | 0.781 | 0.781 | 0.781 | 0.000 | 0: 0.781 | 0: 0.781 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,280,174 | 0.781 | 0.781 | 0.781 | 0.000 | 0: 0.781 | 0: 0.781 |
| insert | random | A | scaleUp | 25,000 | 562,492 | 1.778 | 1.778 | 1.778 | 0.000 | 0: 1.778 | 0: 1.778 |
| insert | random | A | scaleDown | 25,000 | 536,983 | 1.862 | 1.862 | 1.862 | 0.000 | 0: 1.862 | 0: 1.862 |
| insert | random | A | fullLifecycle | 50,000 | 549,441 | 1.820 | 1.820 | 1.820 | 0.000 | 0: 1.820 | 0: 1.820 |
| insert | tail | A | scaleUp | 12,500 | 1,305,469 | 0.766 | 0.766 | 0.766 | 0.000 | 0: 0.766 | 0: 0.766 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,305,469 | 0.766 | 0.766 | 0.766 | 0.000 | 0: 0.766 | 0: 0.766 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 658,595 | 1.518 | 1.518 | 1.518 | 0.000 | 0: 1.518 | 0: 1.518 |
| remove | head | A | fullLifecycle | 12,500 | 658,595 | 1.518 | 1.518 | 1.518 | 0.000 | 0: 1.518 | 0: 1.518 |
| remove | random | A | scaleUp | 25,000 | 459,565 | 2.176 | 2.176 | 2.176 | 0.000 | 0: 2.176 | 0: 2.176 |
| remove | random | A | scaleDown | 25,000 | 471,111 | 2.123 | 2.123 | 2.123 | 0.000 | 0: 2.123 | 0: 2.123 |
| remove | random | A | fullLifecycle | 50,000 | 465,266 | 2.149 | 2.149 | 2.149 | 0.000 | 0: 2.149 | 0: 2.149 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 781,939 | 1.279 | 1.279 | 1.279 | 0.000 | 0: 1.279 | 0: 1.279 |
| remove | tail | A | fullLifecycle | 12,500 | 781,939 | 1.279 | 1.279 | 1.279 | 0.000 | 0: 1.279 | 0: 1.279 |
| replace | head | A | scaleUp | 25,000 | 522,606 | 1.913 | 1.913 | 1.913 | 0.000 | 0: 1.913 | 0: 1.913 |
| replace | head | A | scaleDown | 25,000 | 465,272 | 2.149 | 2.149 | 2.149 | 0.000 | 0: 2.149 | 0: 2.149 |
| replace | head | A | fullLifecycle | 50,000 | 492,275 | 2.031 | 2.031 | 2.031 | 0.000 | 0: 2.031 | 0: 2.031 |
| replace | random | A | scaleUp | 25,000 | 343,302 | 2.913 | 2.913 | 2.913 | 0.000 | 0: 2.913 | 0: 2.913 |
| replace | random | A | scaleDown | 25,000 | 362,010 | 2.762 | 2.762 | 2.762 | 0.000 | 0: 2.762 | 0: 2.762 |
| replace | random | A | fullLifecycle | 50,000 | 352,408 | 2.838 | 2.838 | 2.838 | 0.000 | 0: 2.838 | 0: 2.838 |
| replace | tail | A | scaleUp | 25,000 | 521,182 | 1.919 | 1.919 | 1.919 | 0.000 | 0: 1.919 | 0: 1.919 |
| replace | tail | A | scaleDown | 25,000 | 51,907 | 19.265 | 19.265 | 19.265 | 0.000 | 0: 19.265 | 0: 19.265 |
| replace | tail | A | fullLifecycle | 50,000 | 94,410 | 10.592 | 10.592 | 10.592 | 0.000 | 0: 10.592 | 0: 10.592 |
| sequence | — | A | scaleUp | 6 | 61 | 16298.567 | 16298.567 | 16298.567 | 0.000 | 0: 16298.567 | 0: 16298.567 |
| sequence | — | A | scaleDown | 6 | 73 | 13688.133 | 13688.133 | 13688.133 | 0.000 | 0: 13688.133 | 0: 13688.133 |
| sequence | — | A | fullLifecycle | 12 | 67 | 14993.350 | 14993.350 | 14993.350 | 0.000 | 0: 14993.350 | 0: 14993.350 |
| value | head | A | scaleUp | 25,000 | 3,070,574 | 0.326 | 0.326 | 0.326 | 0.000 | 0: 0.326 | 0: 0.326 |
| value | head | A | scaleDown | 25,000 | 2,341,284 | 0.427 | 0.427 | 0.427 | 0.000 | 0: 0.427 | 0: 0.427 |
| value | head | A | fullLifecycle | 50,000 | 2,656,790 | 0.376 | 0.376 | 0.376 | 0.000 | 0: 0.376 | 0: 0.376 |
| value | random | A | scaleUp | 25,000 | 852,213 | 1.173 | 1.173 | 1.173 | 0.000 | 0: 1.173 | 0: 1.173 |
| value | random | A | scaleDown | 25,000 | 880,421 | 1.136 | 1.136 | 1.136 | 0.000 | 0: 1.136 | 0: 1.136 |
| value | random | A | fullLifecycle | 50,000 | 866,087 | 1.155 | 1.155 | 1.155 | 0.000 | 0: 1.155 | 0: 1.155 |
| value | tail | A | scaleUp | 25,000 | 6,305,647 | 0.159 | 0.159 | 0.159 | 0.000 | 0: 0.159 | 0: 0.159 |
| value | tail | A | scaleDown | 25,000 | 3,909,610 | 0.256 | 0.256 | 0.256 | 0.000 | 0: 0.256 | 0: 0.256 |
| value | tail | A | fullLifecycle | 50,000 | 4,826,628 | 0.207 | 0.207 | 0.207 | 0.000 | 0: 0.207 | 0: 0.207 |
| values | — | A | scaleUp | 6 | 63 | 15886.450 | 15886.450 | 15886.450 | 0.000 | 0: 15886.450 | 0: 15886.450 |
| values | — | A | scaleDown | 6 | 254 | 3938.483 | 3938.483 | 3938.483 | 0.000 | 0: 3938.483 | 0: 3938.483 |
| values | — | A | fullLifecycle | 12 | 101 | 9912.467 | 9912.467 | 9912.467 | 0.000 | 0: 9912.467 | 0: 9912.467 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5428540.000 | 428.569 | 8.477 |
| A | scaleDown | 5 | 4409840.000 | 432.337 | 8.548 |
| A | fullLifecycle | 11 | 4965494.545 | 430.082 | 8.506 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3126055.667 | 246.794 | 4.882 |
| A | scaleDown | 5 | 2596615.600 | 254.570 | 5.033 |
| A | fullLifecycle | 11 | 2885401.091 | 249.917 | 4.943 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 242,996 | 4.115 | 1.900 | 247.100 |
| apply | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 279,925 | 3.572 | 1.500 | 886.900 |
| apply | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 291,777 | 3.427 | 1.500 | 886.900 |
| apply | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 286,124 | 3.495 | 1.500 | 886.900 |
| apply | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 291,185 | 3.434 | 1.500 | 1171.700 |
| apply | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 294,766 | 3.393 | 1.500 | 1616.900 |
| apply | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 299,115 | 3.343 | 1.500 | 1616.900 |
| apply | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 305,401 | 3.274 | 1.500 | 1616.900 |
| apply | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 307,904 | 3.248 | 1.500 | 1616.900 |
| apply | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 307,220 | 3.255 | 1.500 | 1616.900 |
| apply | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 309,177 | 3.234 | 1.400 | 1616.900 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 306,617 | 3.261 | 1.300 | 1616.900 |
| insert | head | 0 | up | 1,000 | 51,204 | A | 500 | 937,031 | 1.067 | 0.400 | 39.200 |
| insert | head | 0 | up | 5,000 | 250,037 | A | 2,500 | 1,089,847 | 0.918 | 0.400 | 39.200 |
| insert | head | 0 | up | 10,000 | 506,154 | A | 5,000 | 1,200,884 | 0.833 | 0.300 | 39.200 |
| insert | head | 0 | up | 15,000 | 762,134 | A | 7,500 | 1,195,695 | 0.836 | 0.300 | 39.200 |
| insert | head | 0 | up | 20,000 | 1,012,964 | A | 10,000 | 1,237,716 | 0.808 | 0.300 | 39.200 |
| insert | head | 0 | up | 25,000 | 1,259,727 | A | 12,500 | 1,280,174 | 0.781 | 0.300 | 39.200 |
| insert | head | 0 | down | 20,000 | 1,009,630 | A | 12,500 | 1,280,174 | 0.781 | 0.300 | 39.200 |
| insert | head | 0 | down | 15,000 | 759,633 | A | 12,500 | 1,280,174 | 0.781 | 0.300 | 39.200 |
| insert | head | 0 | down | 10,000 | 507,941 | A | 12,500 | 1,280,174 | 0.781 | 0.300 | 39.200 |
| insert | head | 0 | down | 5,000 | 250,794 | A | 12,500 | 1,280,174 | 0.781 | 0.300 | 39.200 |
| insert | head | 0 | down | 1,000 | 51,447 | A | 12,500 | 1,280,174 | 0.781 | 0.300 | 39.200 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,280,174 | 0.781 | 0.300 | 39.200 |
| insert | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 385,119 | 2.597 | 0.500 | 708.600 |
| insert | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 501,454 | 1.994 | 0.500 | 825.100 |
| insert | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 545,450 | 1.833 | 0.500 | 825.100 |
| insert | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 534,527 | 1.871 | 0.500 | 825.100 |
| insert | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 545,048 | 1.835 | 0.500 | 825.100 |
| insert | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 562,492 | 1.778 | 0.500 | 825.100 |
| insert | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 555,665 | 1.800 | 0.500 | 954.300 |
| insert | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 548,148 | 1.824 | 0.500 | 1489.400 |
| insert | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 560,121 | 1.785 | 0.500 | 1489.400 |
| insert | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 552,667 | 1.809 | 0.500 | 1489.400 |
| insert | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 551,677 | 1.813 | 0.500 | 1489.400 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 549,441 | 1.820 | 0.500 | 1489.400 |
| insert | tail | 0 | up | 1,000 | 51,204 | A | 500 | 1,042,535 | 0.959 | 0.300 | 20.000 |
| insert | tail | 0 | up | 5,000 | 250,037 | A | 2,500 | 1,207,963 | 0.828 | 0.300 | 46.500 |
| insert | tail | 0 | up | 10,000 | 506,154 | A | 5,000 | 1,309,655 | 0.764 | 0.300 | 96.700 |
| insert | tail | 0 | up | 15,000 | 762,134 | A | 7,500 | 1,266,614 | 0.790 | 0.300 | 173.300 |
| insert | tail | 0 | up | 20,000 | 1,012,964 | A | 10,000 | 1,283,318 | 0.779 | 0.300 | 250.500 |
| insert | tail | 0 | up | 25,000 | 1,259,727 | A | 12,500 | 1,305,469 | 0.766 | 0.300 | 315.000 |
| insert | tail | 0 | down | 20,000 | 1,009,630 | A | 12,500 | 1,305,469 | 0.766 | 0.300 | 315.000 |
| insert | tail | 0 | down | 15,000 | 759,633 | A | 12,500 | 1,305,469 | 0.766 | 0.300 | 315.000 |
| insert | tail | 0 | down | 10,000 | 507,941 | A | 12,500 | 1,305,469 | 0.766 | 0.300 | 315.000 |
| insert | tail | 0 | down | 5,000 | 250,794 | A | 12,500 | 1,305,469 | 0.766 | 0.300 | 315.000 |
| insert | tail | 0 | down | 1,000 | 51,447 | A | 12,500 | 1,305,469 | 0.766 | 0.300 | 315.000 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,305,469 | 0.766 | 0.300 | 315.000 |
| remove | head | 0 | up | 1,000 | 51,204 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 250,037 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 506,154 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 762,134 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,012,964 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,259,727 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,009,630 | A | 2,500 | 676,078 | 1.479 | 0.800 | 25.400 |
| remove | head | 0 | down | 15,000 | 759,633 | A | 5,000 | 655,136 | 1.526 | 0.800 | 419.700 |
| remove | head | 0 | down | 10,000 | 507,941 | A | 7,500 | 651,030 | 1.536 | 0.800 | 629.800 |
| remove | head | 0 | down | 5,000 | 250,794 | A | 10,000 | 659,461 | 1.516 | 0.700 | 629.800 |
| remove | head | 0 | down | 1,000 | 51,447 | A | 12,000 | 667,768 | 1.498 | 0.700 | 629.800 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 658,595 | 1.518 | 0.700 | 629.800 |
| remove | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 308,938 | 3.237 | 0.900 | 595.200 |
| remove | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 439,750 | 2.274 | 0.900 | 595.200 |
| remove | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 451,488 | 2.215 | 0.900 | 595.200 |
| remove | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 438,210 | 2.282 | 0.900 | 595.200 |
| remove | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 450,515 | 2.220 | 0.900 | 595.200 |
| remove | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 459,565 | 2.176 | 0.900 | 595.200 |
| remove | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 461,148 | 2.168 | 0.900 | 595.200 |
| remove | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 467,048 | 2.141 | 0.900 | 595.200 |
| remove | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 470,469 | 2.126 | 0.900 | 595.200 |
| remove | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 467,540 | 2.139 | 0.900 | 595.200 |
| remove | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 467,572 | 2.139 | 0.700 | 595.200 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 465,266 | 2.149 | 0.700 | 595.200 |
| remove | tail | 0 | up | 1,000 | 51,204 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 250,037 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 506,154 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 762,134 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,012,964 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,259,727 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,009,630 | A | 2,500 | 772,272 | 1.295 | 0.800 | 42.700 |
| remove | tail | 0 | down | 15,000 | 759,633 | A | 5,000 | 798,021 | 1.253 | 0.700 | 42.700 |
| remove | tail | 0 | down | 10,000 | 507,941 | A | 7,500 | 821,216 | 1.218 | 0.700 | 42.700 |
| remove | tail | 0 | down | 5,000 | 250,794 | A | 10,000 | 804,169 | 1.244 | 0.700 | 42.700 |
| remove | tail | 0 | down | 1,000 | 51,447 | A | 12,000 | 800,918 | 1.249 | 0.700 | 42.700 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 781,939 | 1.279 | 0.700 | 55.800 |
| replace | head | 0 | up | 1,000 | 51,204 | A | 1,000 | 404,204 | 2.474 | 1.200 | 76.900 |
| replace | head | 0 | up | 5,000 | 250,037 | A | 5,000 | 477,295 | 2.095 | 1.200 | 286.300 |
| replace | head | 0 | up | 10,000 | 506,154 | A | 10,000 | 500,068 | 2.000 | 1.100 | 314.500 |
| replace | head | 0 | up | 15,000 | 762,134 | A | 15,000 | 494,480 | 2.022 | 1.100 | 395.000 |
| replace | head | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 512,395 | 1.952 | 1.100 | 395.000 |
| replace | head | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 522,606 | 1.913 | 1.000 | 641.400 |
| replace | head | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 518,599 | 1.928 | 1.000 | 641.400 |
| replace | head | 0 | down | 15,000 | 759,633 | A | 35,000 | 517,361 | 1.933 | 1.000 | 641.400 |
| replace | head | 0 | down | 10,000 | 507,941 | A | 40,000 | 517,505 | 1.932 | 1.000 | 641.400 |
| replace | head | 0 | down | 5,000 | 250,794 | A | 45,000 | 499,222 | 2.003 | 1.000 | 1876.100 |
| replace | head | 0 | down | 1,000 | 51,447 | A | 49,000 | 497,661 | 2.009 | 1.000 | 1876.100 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 492,275 | 2.031 | 1.000 | 1876.100 |
| replace | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 365,938 | 2.733 | 1.300 | 60.300 |
| replace | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 333,763 | 2.996 | 1.300 | 775.200 |
| replace | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 342,080 | 2.923 | 1.100 | 775.200 |
| replace | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 325,886 | 3.069 | 1.100 | 789.700 |
| replace | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 335,049 | 2.985 | 1.100 | 789.700 |
| replace | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 343,302 | 2.913 | 1.100 | 789.700 |
| replace | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 347,581 | 2.877 | 1.100 | 789.700 |
| replace | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 351,119 | 2.848 | 1.100 | 789.700 |
| replace | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 355,180 | 2.815 | 1.100 | 789.700 |
| replace | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 351,959 | 2.841 | 1.100 | 789.700 |
| replace | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 353,872 | 2.826 | 1.100 | 789.700 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 352,408 | 2.838 | 1.000 | 789.700 |
| replace | tail | 0 | up | 1,000 | 51,204 | A | 1,000 | 431,034 | 2.320 | 1.200 | 119.200 |
| replace | tail | 0 | up | 5,000 | 250,037 | A | 5,000 | 488,429 | 2.047 | 1.200 | 265.000 |
| replace | tail | 0 | up | 10,000 | 506,154 | A | 10,000 | 493,342 | 2.027 | 1.100 | 904.600 |
| replace | tail | 0 | up | 15,000 | 762,134 | A | 15,000 | 499,792 | 2.001 | 1.100 | 904.600 |
| replace | tail | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 509,731 | 1.962 | 1.100 | 904.600 |
| replace | tail | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 521,182 | 1.919 | 1.100 | 904.600 |
| replace | tail | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 126,400 | 7.911 | 1.100 | 1178.000 |
| replace | tail | 0 | down | 15,000 | 759,633 | A | 35,000 | 94,818 | 10.546 | 1.000 | 1237.900 |
| replace | tail | 0 | down | 10,000 | 507,941 | A | 40,000 | 96,048 | 10.411 | 1.000 | 1237.900 |
| replace | tail | 0 | down | 5,000 | 250,794 | A | 45,000 | 91,572 | 10.920 | 1.000 | 1446.800 |
| replace | tail | 0 | down | 1,000 | 51,447 | A | 49,000 | 93,372 | 10.710 | 0.900 | 1446.800 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 94,410 | 10.592 | 0.900 | 1446.800 |
| value | head | 0 | up | 1,000 | 51,204 | A | 1,000 | 1,061,008 | 0.943 | 0.200 | 455.100 |
| value | head | 0 | up | 5,000 | 250,037 | A | 5,000 | 2,256,012 | 0.443 | 0.100 | 455.100 |
| value | head | 0 | up | 10,000 | 506,154 | A | 10,000 | 2,703,214 | 0.370 | 0.100 | 455.100 |
| value | head | 0 | up | 15,000 | 762,134 | A | 15,000 | 2,782,931 | 0.359 | 0.100 | 455.100 |
| value | head | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 2,962,173 | 0.338 | 0.100 | 455.100 |
| value | head | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 3,070,574 | 0.326 | 0.100 | 455.100 |
| value | head | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 2,920,390 | 0.342 | 0.100 | 455.100 |
| value | head | 0 | down | 15,000 | 759,633 | A | 35,000 | 2,859,500 | 0.350 | 0.100 | 455.100 |
| value | head | 0 | down | 10,000 | 507,941 | A | 40,000 | 2,815,930 | 0.355 | 0.100 | 455.100 |
| value | head | 0 | down | 5,000 | 250,794 | A | 45,000 | 2,732,207 | 0.366 | 0.100 | 455.100 |
| value | head | 0 | down | 1,000 | 51,447 | A | 49,000 | 2,692,811 | 0.371 | 0.100 | 455.100 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,656,790 | 0.376 | 0.100 | 455.100 |
| value | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 1,006,036 | 0.994 | 0.100 | 128.200 |
| value | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 972,365 | 1.028 | 0.100 | 128.200 |
| value | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 883,525 | 1.132 | 0.100 | 128.200 |
| value | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 804,488 | 1.243 | 0.100 | 128.200 |
| value | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 828,360 | 1.207 | 0.100 | 128.200 |
| value | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 852,213 | 1.173 | 0.100 | 128.200 |
| value | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 865,998 | 1.155 | 0.100 | 128.200 |
| value | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 876,501 | 1.141 | 0.100 | 128.200 |
| value | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 887,136 | 1.127 | 0.100 | 128.200 |
| value | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 870,839 | 1.148 | 0.100 | 128.200 |
| value | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 871,995 | 1.147 | 0.100 | 128.200 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 866,087 | 1.155 | 0.100 | 128.200 |
| value | tail | 0 | up | 1,000 | 51,204 | A | 1,000 | 5,464,481 | 0.183 | 0.100 | 3.800 |
| value | tail | 0 | up | 5,000 | 250,037 | A | 5,000 | 5,459,707 | 0.183 | 0.100 | 5.600 |
| value | tail | 0 | up | 10,000 | 506,154 | A | 10,000 | 5,749,439 | 0.174 | 0.100 | 7.700 |
| value | tail | 0 | up | 15,000 | 762,134 | A | 15,000 | 5,766,569 | 0.173 | 0.100 | 7.700 |
| value | tail | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 6,074,596 | 0.165 | 0.000 | 7.700 |
| value | tail | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 6,305,647 | 0.159 | 0.000 | 7.700 |
| value | tail | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 5,812,827 | 0.172 | 0.000 | 15.100 |
| value | tail | 0 | down | 15,000 | 759,633 | A | 35,000 | 5,464,054 | 0.183 | 0.000 | 60.100 |
| value | tail | 0 | down | 10,000 | 507,941 | A | 40,000 | 5,280,040 | 0.189 | 0.000 | 60.100 |
| value | tail | 0 | down | 5,000 | 250,794 | A | 45,000 | 5,019,520 | 0.199 | 0.000 | 60.100 |
| value | tail | 0 | down | 1,000 | 51,447 | A | 49,000 | 4,933,200 | 0.203 | 0.000 | 60.100 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 4,826,628 | 0.207 | 0.000 | 75.600 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,663 | 375.500 |
| create | — | 0 | up | 5,000 | A | 1 | 1,019 | 981.600 |
| create | — | 0 | up | 10,000 | A | 1 | 578 | 1729.500 |
| create | — | 0 | up | 15,000 | A | 1 | 323 | 3095.000 |
| create | — | 0 | up | 20,000 | A | 1 | 302 | 3311.400 |
| create | — | 0 | up | 25,000 | A | 1 | 260 | 3841.000 |
| create | — | 0 | down | 20,000 | A | 1 | 149 | 6696.700 |
| create | — | 0 | down | 15,000 | A | 1 | 384 | 2605.800 |
| create | — | 0 | down | 10,000 | A | 1 | 528 | 1895.100 |
| create | — | 0 | down | 5,000 | A | 1 | 1,118 | 894.400 |
| create | — | 0 | down | 1,000 | A | 1 | 7,457 | 134.100 |
| create | — | 0 | down | 0 | A | 1 | 64,103 | 15.600 |
| sequence | — | 0 | up | 1,000 | A | 1 | 391 | 2557.200 |
| sequence | — | 0 | up | 5,000 | A | 1 | 120 | 8356.600 |
| sequence | — | 0 | up | 10,000 | A | 1 | 43 | 23482.500 |
| sequence | — | 0 | up | 15,000 | A | 1 | 48 | 20688.700 |
| sequence | — | 0 | up | 20,000 | A | 1 | 48 | 20721.400 |
| sequence | — | 0 | up | 25,000 | A | 1 | 45 | 21985.000 |
| sequence | — | 0 | down | 20,000 | A | 1 | 34 | 29012.900 |
| sequence | — | 0 | down | 15,000 | A | 1 | 65 | 15284.600 |
| sequence | — | 0 | down | 10,000 | A | 1 | 68 | 14776.600 |
| sequence | — | 0 | down | 5,000 | A | 1 | 67 | 15003.900 |
| sequence | — | 0 | down | 1,000 | A | 1 | 149 | 6704.400 |
| sequence | — | 0 | down | 0 | A | 1 | 743 | 1346.400 |
| values | — | 0 | up | 1,000 | A | 1 | 544 | 1836.900 |
| values | — | 0 | up | 5,000 | A | 1 | 228 | 4390.200 |
| values | — | 0 | up | 10,000 | A | 1 | 45 | 21999.700 |
| values | — | 0 | up | 15,000 | A | 1 | 22 | 46295.000 |
| values | — | 0 | up | 20,000 | A | 1 | 105 | 9498.700 |
| values | — | 0 | up | 25,000 | A | 1 | 89 | 11298.200 |
| values | — | 0 | down | 20,000 | A | 1 | 108 | 9232.100 |
| values | — | 0 | down | 15,000 | A | 1 | 162 | 6184.400 |
| values | — | 0 | down | 10,000 | A | 1 | 230 | 4345.700 |
| values | — | 0 | down | 5,000 | A | 1 | 305 | 3280.300 |
| values | — | 0 | down | 1,000 | A | 1 | 1,738 | 575.500 |
| values | — | 0 | down | 0 | A | 1 | 77,519 | 12.900 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.622 | 0.232 | 0.391 |
| 0 | up | 5000 | 3.076 | 1.168 | 1.908 |
| 0 | up | 10000 | 6.205 | 2.343 | 3.862 |
| 0 | up | 15000 | 9.457 | 3.643 | 5.815 |
| 0 | up | 20000 | 12.841 | 5.112 | 7.728 |
| 0 | up | 25000 | 16.247 | 6.636 | 9.611 |
| 0 | down | 20000 | 13.315 | 5.612 | 7.703 |
| 0 | down | 15000 | 9.926 | 4.131 | 5.796 |
| 0 | down | 10000 | 7.170 | 3.295 | 3.875 |
| 0 | down | 5000 | 4.075 | 2.161 | 1.913 |
| 0 | down | 1000 | 1.812 | 1.420 | 0.393 |
| 0 | down | 0 | 1.230 | 1.230 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 51,204 | 0.411 | 430.756 | 8.413 | 120.945 | 15.544 |
| 0 | up | A | 5,000 | 5,000 | 250,037 | 2.010 | 421.606 | 8.431 | 153.895 | 19.559 |
| 0 | up | A | 10,000 | 10,000 | 506,154 | 4.075 | 427.300 | 8.442 | 196.078 | 24.476 |
| 0 | up | A | 15,000 | 15,000 | 762,134 | 6.154 | 430.176 | 8.467 | 208.648 | 29.391 |
| 0 | up | A | 20,000 | 20,000 | 1,012,964 | 8.198 | 429.835 | 8.487 | 280.195 | 34.213 |
| 0 | up | A | 25,000 | 25,000 | 1,259,727 | 10.214 | 428.405 | 8.502 | 294.504 | 38.943 |
| 0 | down | A | 20,000 | 20,000 | 1,009,630 | 8.241 | 432.089 | 8.559 | 295.895 | 34.188 |
| 0 | down | A | 15,000 | 15,000 | 759,633 | 6.201 | 433.508 | 8.560 | 298.828 | 29.424 |
| 0 | down | A | 10,000 | 10,000 | 507,941 | 4.136 | 433.718 | 8.539 | 297.492 | 24.653 |
| 0 | down | A | 5,000 | 5,000 | 250,794 | 2.034 | 426.570 | 8.504 | 295.188 | 19.796 |
| 0 | down | A | 1,000 | 1,000 | 51,447 | 0.415 | 434.772 | 8.451 | 294.191 | 15.997 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 294.926 | 14.907 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 51204 | 187497 | 187.497 | 3.662 | 277.53 | 14.54 | 165.41 | 12.36 |
| 0 | up | A | 5000 | 250037 | 1195941 | 239.188 | 4.783 | 1610.38 | 73.38 | 813.25 | 61.61 |
| 0 | up | A | 10000 | 506154 | 2435808 | 243.581 | 4.812 | 3265.74 | 148.71 | 1649.99 | 124.72 |
| 0 | up | A | 15000 | 762134 | 3716482 | 247.765 | 4.876 | 4950.79 | 226.25 | 3565.22 | 200.28 |
| 0 | up | A | 20000 | 1012964 | 4982573 | 249.129 | 4.919 | 7121.78 | 311.32 | 5144.59 | 263.55 |
| 0 | up | A | 25000 | 1259727 | 6238033 | 249.521 | 4.952 | 9237.87 | 392.58 | 6535.88 | 334.89 |
| 0 | down | A | 20000 | 1009630 | 5113545 | 255.677 | 5.065 | 7558.03 | 326.74 | 5304.48 | 278.22 |
| 0 | down | A | 15000 | 759633 | 3843527 | 256.235 | 5.060 | 5727.79 | 247.31 | 4004.31 | 209.86 |
| 0 | down | A | 10000 | 507941 | 2547329 | 254.733 | 5.015 | 3837.94 | 164.83 | 2677.99 | 139.88 |
| 0 | down | A | 5000 | 250794 | 1235293 | 247.059 | 4.926 | 1887.01 | 79.61 | 1318.78 | 67.84 |
| 0 | down | A | 1000 | 51447 | 243384 | 243.384 | 4.731 | 382.91 | 15.90 | 268.58 | 13.64 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 428.569 | 8.477 | 246.794 | 4.882 |
| 0 | A | scaleDown | 432.337 | 8.548 | 254.570 | 5.033 |
| 0 | A | fullLifecycle | 430.082 | 8.506 | 249.917 | 4.943 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
