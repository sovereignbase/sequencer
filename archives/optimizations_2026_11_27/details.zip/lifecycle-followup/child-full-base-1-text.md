# Large string benchmarks

2026-11-27T17:25:51.589Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2239.09 | 0.00 |
| 1024 | insert.append | array | 13656.47 | 0.00 |
| 1024 | replace | array | 3391.65 | 0.00 |
| 1024 | remove | array | 1123.22 | 0.00 |
| 1024 | remove.middle | array | 2075.63 | 0.00 |
| 1024 | replace.middle | array | 2373.72 | 0.00 |
| 1024 | apply | array | 836.00 | 0.00 |
| 1024 | apply.array | array | 674.23 | 0.00 |
| 1024 | concurrent.apply | array | 66920.32 | 0.00 |
| 1024 | merge | array | 3200.32 | 0.00 |
| 1024 | create | array | 3132.88 | 0.00 |
| 1024 | value.random | array | 49.62 | 0.00 |
| 1024 | values.range | array | 123.86 | 0.00 |
| 1024 | values.array | array | 1488.11 | 0.00 |
| 1024 | values.text | array | 13933.15 | 0.00 |
| 1024 | sequence.array | array | 1982.92 | 0.00 |
| 1024 | sequence.text | array | 10130.55 | 0.00 |
| 1024 | sequence.edited.text | array | 14272.77 | 0.00 |
| 1024 | sequence.masked.text | array | 11427.51 | 0.00 |
| 1024 | insert | string | 420.46 | 0.00 |
| 1024 | insert.append | string | 4325.43 | 0.00 |
| 1024 | replace | string | 1133.18 | 0.00 |
| 1024 | remove | string | 929.47 | 0.00 |
| 1024 | remove.middle | string | 998.21 | 0.00 |
| 1024 | replace.middle | string | 1351.42 | 0.00 |
| 1024 | apply | string | 931.69 | 0.00 |
| 1024 | apply.array | string | 2457.65 | 0.00 |
| 1024 | concurrent.apply | string | 3594.65 | 0.00 |
| 1024 | merge | string | 1414.60 | 0.00 |
| 1024 | create | string | 1115.08 | 0.00 |
| 1024 | value.random | string | 52.71 | 0.00 |
| 1024 | values.range | string | 229.43 | 0.00 |
| 1024 | values.array | string | 1816.71 | 0.00 |
| 1024 | values.text | string | 68.01 | 0.00 |
| 1024 | sequence.array | string | 2235.03 | 0.00 |
| 1024 | sequence.text | string | 254.42 | 0.00 |
| 1024 | sequence.edited.text | string | 2344.57 | 0.00 |
| 1024 | sequence.masked.text | string | 3611.96 | 0.00 |
| 65536 | insert | array | 259549.48 | 0.00 |
| 65536 | insert.append | array | 1088944.00 | 0.00 |
| 65536 | replace | array | 253920.20 | 0.00 |
| 65536 | remove | array | 4630.78 | 0.00 |
| 65536 | remove.middle | array | 597646.81 | 0.00 |
| 65536 | replace.middle | array | 322970.51 | 0.00 |
| 65536 | apply | array | 1662.77 | 0.00 |
| 65536 | apply.array | array | 749.50 | 0.00 |
| 65536 | concurrent.apply | array | 5023020.00 | 0.00 |
| 65536 | merge | array | 253994.95 | 0.00 |
| 65536 | create | array | 287500.00 | 0.00 |
| 65536 | value.random | array | 55.22 | 0.00 |
| 65536 | values.range | array | 143.14 | 0.00 |
| 65536 | values.array | array | 214523.08 | 0.00 |
| 65536 | values.text | array | 875637.93 | 0.00 |
| 65536 | sequence.array | array | 224039.68 | 0.00 |
| 65536 | sequence.text | array | 889130.00 | 0.00 |
| 65536 | sequence.edited.text | array | 984161.54 | 0.00 |
| 65536 | sequence.masked.text | array | 736547.06 | 0.00 |
| 65536 | insert | string | 440.47 | 0.00 |
| 65536 | insert.append | string | 20720.71 | 0.00 |
| 65536 | replace | string | 1495.57 | 0.00 |
| 65536 | remove | string | 932.69 | 0.00 |
| 65536 | remove.middle | string | 950.56 | 0.00 |
| 65536 | replace.middle | string | 1254.74 | 0.00 |
| 65536 | apply | string | 913.38 | 0.00 |
| 65536 | apply.array | string | 266309.38 | 0.00 |
| 65536 | concurrent.apply | string | 144220.11 | 0.00 |
| 65536 | merge | string | 1126.65 | 0.00 |
| 65536 | create | string | 1020.24 | 0.00 |
| 65536 | value.random | string | 54.16 | 0.00 |
| 65536 | values.range | string | 140.52 | 0.00 |
| 65536 | values.array | string | 261112.50 | 0.00 |
| 65536 | values.text | string | 62.38 | 0.00 |
| 65536 | sequence.array | string | 246691.41 | 0.00 |
| 65536 | sequence.text | string | 172.65 | 0.00 |
| 65536 | sequence.edited.text | string | 86173.54 | 0.00 |
| 65536 | sequence.masked.text | string | 3484.51 | 0.00 |
| 1048576 | insert | array | 3386475.00 | 0.00 |
| 1048576 | insert.append | array | 20060750.00 | 0.00 |
| 1048576 | replace | array | 3366750.00 | 0.00 |
| 1048576 | remove | array | 11218.60 | 0.00 |
| 1048576 | remove.middle | array | 3283744.44 | 0.00 |
| 1048576 | replace.middle | array | 2558410.00 | 0.00 |
| 1048576 | apply | array | 1059.17 | 0.00 |
| 1048576 | apply.array | array | 543.93 | 0.00 |
| 1048576 | concurrent.apply | array | 64470900.00 | 0.00 |
| 1048576 | merge | array | 3313912.50 | 0.00 |
| 1048576 | create | array | 3176000.00 | 0.00 |
| 1048576 | value.random | array | 46.68 | 0.00 |
| 1048576 | values.range | array | 106.73 | 0.00 |
| 1048576 | values.array | array | 2782044.44 | 0.00 |
| 1048576 | values.text | array | 12589133.33 | 0.00 |
| 1048576 | sequence.array | array | 2298963.64 | 0.00 |
| 1048576 | sequence.text | array | 52628250.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 52641600.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 47638250.00 | 0.00 |
| 1048576 | insert | string | 393.03 | 0.00 |
| 1048576 | insert.append | string | 567566.67 | 0.00 |
| 1048576 | replace | string | 1758.42 | 0.00 |
| 1048576 | remove | string | 1048.43 | 0.00 |
| 1048576 | remove.middle | string | 964.20 | 0.00 |
| 1048576 | replace.middle | string | 1295.20 | 0.00 |
| 1048576 | apply | string | 851.34 | 0.00 |
| 1048576 | apply.array | string | 3529537.50 | 0.00 |
| 1048576 | concurrent.apply | string | 1413011.11 | 0.00 |
| 1048576 | merge | string | 1154.74 | 0.00 |
| 1048576 | create | string | 1030.63 | 0.00 |
| 1048576 | value.random | string | 38.83 | 0.00 |
| 1048576 | values.range | string | 196.89 | 0.00 |
| 1048576 | values.array | string | 3953500.00 | 0.00 |
| 1048576 | values.text | string | 107.70 | 0.00 |
| 1048576 | sequence.array | string | 3798162.50 | 0.00 |
| 1048576 | sequence.text | string | 214.08 | 0.00 |
| 1048576 | sequence.edited.text | string | 1629806.25 | 0.00 |
| 1048576 | sequence.masked.text | string | 4116.15 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
