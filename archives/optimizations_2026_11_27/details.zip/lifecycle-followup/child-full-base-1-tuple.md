# Tuple benchmarks

2026-11-27T17:25:37.309Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 2,997,826 | 2,369,316 | 0.79× |
| 2 | create.sequence | 993,588 | 808,183 | 0.81× |
| 2 | replace.random | 1,254,405 | 1,519,475 | 1.21× |
| 2 | apply.replace | 642,283 | 870,081 | 1.35× |
| 2 | apply.duplicate | 1,607,920 | 1,599,975 | 1.00× |
| 2 | merge.duplicate | 1,540,008 | 1,467,677 | 0.95× |
| 2 | length | 116,872,278 | 134,971,910 | 1.15× |
| 2 | value.random | 23,464,469 | 52,102,637 | 2.22× |
| 2 | values | 12,966,438 | 11,035,980 | 0.85× |
| 2 | sequence | 2,981,171 | 2,726,913 | 0.91× |
| 4 | create.empty | 2,478,135 | 2,299,833 | 0.93× |
| 4 | create.sequence | 719,145 | 726,015 | 1.01× |
| 4 | replace.random | 1,046,261 | 1,569,066 | 1.50× |
| 4 | apply.replace | 617,387 | 915,664 | 1.48× |
| 4 | apply.duplicate | 1,706,467 | 1,652,898 | 0.97× |
| 4 | merge.duplicate | 1,304,861 | 1,264,376 | 0.97× |
| 4 | length | 37,554,008 | 33,783,453 | 0.90× |
| 4 | value.random | 24,185,837 | 53,875,116 | 2.23× |
| 4 | values | 6,756,873 | 6,285,892 | 0.93× |
| 4 | sequence | 2,551,970 | 2,502,942 | 0.98× |
| 8 | create.empty | 2,513,656 | 2,393,202 | 0.95× |
| 8 | create.sequence | 464,278 | 545,141 | 1.17× |
| 8 | replace.random | 1,077,194 | 1,637,038 | 1.52× |
| 8 | apply.replace | 640,786 | 945,585 | 1.48× |
| 8 | apply.duplicate | 1,616,729 | 1,651,397 | 1.02× |
| 8 | merge.duplicate | 927,741 | 901,787 | 0.97× |
| 8 | length | 32,862,987 | 37,048,315 | 1.13× |
| 8 | value.random | 17,431,443 | 50,517,423 | 2.90× |
| 8 | values | 4,457,345 | 4,897,988 | 1.10× |
| 8 | sequence | 1,712,726 | 1,919,921 | 1.12× |
| 100 | create.empty | 2,162,774 | 2,046,044 | 0.95× |
| 100 | create.sequence | 66,885 | 85,317 | 1.28× |
| 100 | replace.random | 1,030,386 | 1,509,607 | 1.47× |
| 100 | apply.replace | 652,732 | 862,204 | 1.32× |
| 100 | apply.duplicate | 1,574,628 | 1,427,913 | 0.91× |
| 100 | merge.duplicate | 98,642 | 72,444 | 0.73× |
| 100 | length | 17,972,021 | 36,495,856 | 2.03× |
| 100 | value.random | 11,811,651 | 53,832,969 | 4.56× |
| 100 | values | 463,344 | 674,293 | 1.46× |
| 100 | sequence | 172,226 | 188,102 | 1.09× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
