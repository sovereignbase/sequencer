# Words benchmarks

2026-11-27T17:26:13.145Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 28,137 | 190,613 | 178 |
| append | packed | 5.90 | 3.61 | 13.98 | 30,737 | 178,208 | 327 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,575 | 790 | 207 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 26,148 | 1,511 | 245 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 469 | 192 | 84 |
| random | packed | 49.58 | 35.38 | 23.45 | 14,470 | 495 | 119 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 645 | 193 | 91 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 16,960 | 336 | 54 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 836.20 | 0.00 |
| append | numeric | encode | 35540.63 | 0.00 |
| append | numeric | decode | 3215.21 | 0.00 |
| append | numeric | create | 1752.77 | 0.00 |
| append | numeric | load | 5246.24 | 0.00 |
| append | numeric | apply | 2656289.47 | 0.00 |
| append | numeric | receive | 5633111.11 | 0.00 |
| append | binary | sequence | 534.45 | 0.00 |
| append | binary | encode | 32533.96 | 0.00 |
| append | binary | decode | 1846.77 | 0.00 |
| append | binary | create | 2152.18 | 0.00 |
| append | binary | load | 5611.42 | 0.00 |
| append | binary | apply | 1938746.15 | 0.00 |
| append | binary | receive | 3058805.88 | 0.00 |
| prepend | numeric | sequence | 510805.10 | 0.00 |
| prepend | numeric | encode | 634868.35 | 0.00 |
| prepend | numeric | decode | 174399.65 | 0.00 |
| prepend | numeric | create | 631065.00 | 0.00 |
| prepend | numeric | load | 1265705.00 | 0.00 |
| prepend | numeric | apply | 2382695.24 | 0.00 |
| prepend | numeric | receive | 4820663.64 | 0.00 |
| prepend | binary | sequence | 622006.17 | 0.00 |
| prepend | binary | encode | 38244.04 | 0.00 |
| prepend | binary | decode | 2570.20 | 0.00 |
| prepend | binary | create | 676418.92 | 0.00 |
| prepend | binary | load | 662015.79 | 0.00 |
| prepend | binary | apply | 2648184.21 | 0.00 |
| prepend | binary | receive | 4080253.85 | 0.00 |
| random | numeric | sequence | 930446.30 | 0.00 |
| random | numeric | encode | 2133941.67 | 0.00 |
| random | numeric | decode | 1208607.14 | 0.00 |
| random | numeric | create | 1990588.46 | 0.00 |
| random | numeric | load | 5217270.00 | 0.00 |
| random | numeric | apply | 8160600.00 | 0.00 |
| random | numeric | receive | 11870240.00 | 0.00 |
| random | binary | sequence | 888863.16 | 0.00 |
| random | binary | encode | 69109.81 | 0.00 |
| random | binary | decode | 1837.11 | 0.00 |
| random | binary | create | 1978303.85 | 0.00 |
| random | binary | load | 2021236.00 | 0.00 |
| random | binary | apply | 7051712.50 | 0.00 |
| random | binary | receive | 8413183.33 | 0.00 |
| concurrent | numeric | sequence | 822496.72 | 0.00 |
| concurrent | numeric | encode | 1550736.36 | 0.00 |
| concurrent | numeric | decode | 773963.08 | 0.00 |
| concurrent | numeric | create | 2401066.67 | 0.00 |
| concurrent | numeric | load | 5171710.00 | 0.00 |
| concurrent | numeric | apply | 6262287.50 | 0.00 |
| concurrent | numeric | receive | 11039540.00 | 0.00 |
| concurrent | binary | sequence | 748523.88 | 0.00 |
| concurrent | binary | encode | 58962.62 | 0.00 |
| concurrent | binary | decode | 2804.29 | 0.00 |
| concurrent | binary | create | 2952970.59 | 0.00 |
| concurrent | binary | load | 2978094.12 | 0.00 |
| concurrent | binary | apply | 9449550.00 | 0.00 |
| concurrent | binary | receive | 18365766.67 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
