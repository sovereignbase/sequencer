# Batch benchmarks

2026-11-27T17:28:03.522Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 2,416,334 | 1,160,609 | 544,756 | 76.05 | 5.99 | 0.012 |
| append | batch | 1,451,660 | 188,087,774 | 196,721,311 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,331,056 | 1,052,336 | 653,410 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 1,731,352 | 1,932,305 | 1,780,363 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 1,035,679 | 880,747 | 834,341 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 1,107,236 | 1,409,774 | 1,401,443 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 1,133,723 | 1,140,923 | 786,493 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 1,119,236 | 1,782,478 | 1,600,768 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,359,696 | 1,186,556 | 873,566 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,457,460 | 1,841,762 | 1,671,170 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,382,600 | 1,306,336 | 947,231 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,502,611 | 1,711,572 | 1,572,987 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 689,164 | 953,751 | 706,439 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 960,023 | 1,214,624 | 1,195,457 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,236,081 | 1,433,503 | 1,007,701 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 1,364,070 | 1,826,706 | 1,544,223 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,251,134 | 1,441,113 | 971,920 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 1,330,731 | 1,585,603 | 1,494,191 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 748,853 | 979,560 | 702,975 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 928,275 | 1,252,623 | 1,179,906 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 2.483 | 0.000 |
| append | individual | apply | 5.170 | 0.000 |
| append | individual | receive | 11.014 | 0.000 |
| append | individual | encode | 5.988 | 0.000 |
| append | individual | decode | 6.998 | 0.000 |
| append | batch | author | 4.133 | 0.000 |
| append | batch | apply | 0.032 | 0.000 |
| append | batch | receive | 0.030 | 0.000 |
| append | batch | encode | 0.399 | 0.000 |
| append | batch | decode | 0.103 | 0.000 |
| prepend | individual | author | 4.508 | 0.000 |
| prepend | individual | apply | 5.702 | 0.000 |
| prepend | individual | receive | 9.183 | 0.000 |
| prepend | individual | encode | 7.132 | 0.000 |
| prepend | individual | decode | 9.853 | 0.000 |
| prepend | batch | author | 3.465 | 0.000 |
| prepend | batch | apply | 3.105 | 0.000 |
| prepend | batch | receive | 3.370 | 0.000 |
| prepend | batch | encode | 0.198 | 0.000 |
| prepend | batch | decode | 0.110 | 0.000 |
| random.characters | individual | author | 5.793 | 0.000 |
| random.characters | individual | apply | 6.812 | 0.000 |
| random.characters | individual | receive | 7.191 | 0.000 |
| random.characters | individual | encode | 5.352 | 0.000 |
| random.characters | individual | decode | 8.857 | 0.000 |
| random.characters | batch | author | 5.419 | 0.000 |
| random.characters | batch | apply | 4.256 | 0.000 |
| random.characters | batch | receive | 4.281 | 0.000 |
| random.characters | batch | encode | 0.188 | 0.000 |
| random.characters | batch | decode | 0.106 | 0.000 |
| random.words | individual | author | 5.292 | 0.000 |
| random.words | individual | apply | 5.259 | 0.000 |
| random.words | individual | receive | 7.629 | 0.000 |
| random.words | individual | encode | 3.918 | 0.000 |
| random.words | individual | decode | 7.728 | 0.000 |
| random.words | batch | author | 5.361 | 0.000 |
| random.words | batch | apply | 3.366 | 0.000 |
| random.words | batch | receive | 3.748 | 0.000 |
| random.words | batch | encode | 0.428 | 0.000 |
| random.words | batch | decode | 0.101 | 0.000 |
| concurrent.characters | individual | author | 8.826 | 0.000 |
| concurrent.characters | individual | apply | 10.113 | 0.000 |
| concurrent.characters | individual | receive | 13.737 | 0.000 |
| concurrent.characters | individual | encode | 7.721 | 0.000 |
| concurrent.characters | individual | decode | 9.641 | 0.000 |
| concurrent.characters | batch | author | 8.234 | 0.000 |
| concurrent.characters | batch | apply | 6.515 | 0.000 |
| concurrent.characters | batch | receive | 7.181 | 0.000 |
| concurrent.characters | batch | encode | 0.299 | 0.000 |
| concurrent.characters | batch | decode | 0.108 | 0.000 |
| concurrent.words | individual | author | 8.679 | 0.000 |
| concurrent.words | individual | apply | 9.186 | 0.000 |
| concurrent.words | individual | receive | 12.668 | 0.000 |
| concurrent.words | individual | encode | 7.559 | 0.000 |
| concurrent.words | individual | decode | 10.331 | 0.000 |
| concurrent.words | batch | author | 7.986 | 0.000 |
| concurrent.words | batch | apply | 7.011 | 0.000 |
| concurrent.words | batch | receive | 7.629 | 0.000 |
| concurrent.words | batch | encode | 0.711 | 0.000 |
| concurrent.words | batch | decode | 0.111 | 0.000 |
| concurrent.mixed | individual | author | 17.412 | 0.000 |
| concurrent.mixed | individual | apply | 12.582 | 0.000 |
| concurrent.mixed | individual | receive | 16.987 | 0.000 |
| concurrent.mixed | individual | encode | 9.057 | 0.000 |
| concurrent.mixed | individual | decode | 10.911 | 0.000 |
| concurrent.mixed | batch | author | 12.500 | 0.000 |
| concurrent.mixed | batch | apply | 9.880 | 0.000 |
| concurrent.mixed | batch | receive | 10.038 | 0.000 |
| concurrent.mixed | batch | encode | 0.555 | 0.000 |
| concurrent.mixed | batch | decode | 0.114 | 0.000 |
| causal.characters | individual | author | 9.708 | 0.000 |
| causal.characters | individual | apply | 8.371 | 0.000 |
| causal.characters | individual | receive | 11.908 | 0.000 |
| causal.characters | individual | encode | 7.337 | 0.000 |
| causal.characters | individual | decode | 10.202 | 0.000 |
| causal.characters | batch | author | 8.797 | 0.000 |
| causal.characters | batch | apply | 6.569 | 0.000 |
| causal.characters | batch | receive | 7.771 | 0.000 |
| causal.characters | batch | encode | 0.202 | 0.000 |
| causal.characters | batch | decode | 0.102 | 0.000 |
| causal.words | individual | author | 9.591 | 0.000 |
| causal.words | individual | apply | 8.327 | 0.000 |
| causal.words | individual | receive | 12.347 | 0.000 |
| causal.words | individual | encode | 8.108 | 0.000 |
| causal.words | individual | decode | 9.146 | 0.000 |
| causal.words | batch | author | 9.018 | 0.000 |
| causal.words | batch | apply | 7.568 | 0.000 |
| causal.words | batch | receive | 8.031 | 0.000 |
| causal.words | batch | encode | 0.594 | 0.000 |
| causal.words | batch | decode | 0.121 | 0.000 |
| causal.mixed | individual | author | 16.024 | 0.000 |
| causal.mixed | individual | apply | 12.250 | 0.000 |
| causal.mixed | individual | receive | 17.070 | 0.000 |
| causal.mixed | individual | encode | 10.426 | 0.000 |
| causal.mixed | individual | decode | 10.727 | 0.000 |
| causal.mixed | batch | author | 12.927 | 0.000 |
| causal.mixed | batch | apply | 9.580 | 0.000 |
| causal.mixed | batch | receive | 10.170 | 0.000 |
| causal.mixed | batch | encode | 0.440 | 0.000 |
| causal.mixed | batch | decode | 0.118 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
