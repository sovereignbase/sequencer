# Sequencer dynamic lifecycle benchmark

2026-11-27T17:26:31.838Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.23 | 162.89 | 56.49 |
| CommonJS | 199.41 | 164.51 | 56.69 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 295,492 | 3.384 | 3.384 | 3.384 | 0.000 | 0: 3.384 | 0: 3.384 |
| apply | random | A | scaleDown | 24,999 | 341,806 | 2.926 | 2.926 | 2.926 | 0.000 | 0: 2.926 | 0: 2.926 |
| apply | random | A | fullLifecycle | 49,999 | 316,966 | 3.155 | 3.155 | 3.155 | 0.000 | 0: 3.155 | 0: 3.155 |
| create | — | A | scaleUp | 7 | 476 | 2100.400 | 2100.400 | 2100.400 | 0.000 | 0: 2100.400 | 0: 2100.400 |
| create | — | A | scaleDown | 6 | 659 | 1517.933 | 1517.933 | 1517.933 | 0.000 | 0: 1517.933 | 0: 1517.933 |
| create | — | A | fullLifecycle | 13 | 546 | 1831.569 | 1831.569 | 1831.569 | 0.000 | 0: 1831.569 | 0: 1831.569 |
| insert | head | A | scaleUp | 12,500 | 1,177,379 | 0.849 | 0.849 | 0.849 | 0.000 | 0: 0.849 | 0: 0.849 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,177,379 | 0.849 | 0.849 | 0.849 | 0.000 | 0: 0.849 | 0: 0.849 |
| insert | random | A | scaleUp | 25,000 | 531,548 | 1.881 | 1.881 | 1.881 | 0.000 | 0: 1.881 | 0: 1.881 |
| insert | random | A | scaleDown | 25,000 | 607,790 | 1.645 | 1.645 | 1.645 | 0.000 | 0: 1.645 | 0: 1.645 |
| insert | random | A | fullLifecycle | 50,000 | 567,118 | 1.763 | 1.763 | 1.763 | 0.000 | 0: 1.763 | 0: 1.763 |
| insert | tail | A | scaleUp | 12,500 | 1,266,490 | 0.790 | 0.790 | 0.790 | 0.000 | 0: 0.790 | 0: 0.790 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,266,490 | 0.790 | 0.790 | 0.790 | 0.000 | 0: 0.790 | 0: 0.790 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 715,713 | 1.397 | 1.397 | 1.397 | 0.000 | 0: 1.397 | 0: 1.397 |
| remove | head | A | fullLifecycle | 12,500 | 715,713 | 1.397 | 1.397 | 1.397 | 0.000 | 0: 1.397 | 0: 1.397 |
| remove | random | A | scaleUp | 25,000 | 442,159 | 2.262 | 2.262 | 2.262 | 0.000 | 0: 2.262 | 0: 2.262 |
| remove | random | A | scaleDown | 25,000 | 520,625 | 1.921 | 1.921 | 1.921 | 0.000 | 0: 1.921 | 0: 1.921 |
| remove | random | A | fullLifecycle | 50,000 | 478,194 | 2.091 | 2.091 | 2.091 | 0.000 | 0: 2.091 | 0: 2.091 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 790,284 | 1.265 | 1.265 | 1.265 | 0.000 | 0: 1.265 | 0: 1.265 |
| remove | tail | A | fullLifecycle | 12,500 | 790,284 | 1.265 | 1.265 | 1.265 | 0.000 | 0: 1.265 | 0: 1.265 |
| replace | head | A | scaleUp | 25,000 | 409,117 | 2.444 | 2.444 | 2.444 | 0.000 | 0: 2.444 | 0: 2.444 |
| replace | head | A | scaleDown | 25,000 | 508,801 | 1.965 | 1.965 | 1.965 | 0.000 | 0: 1.965 | 0: 1.965 |
| replace | head | A | fullLifecycle | 50,000 | 453,546 | 2.205 | 2.205 | 2.205 | 0.000 | 0: 2.205 | 0: 2.205 |
| replace | random | A | scaleUp | 25,000 | 310,090 | 3.225 | 3.225 | 3.225 | 0.000 | 0: 3.225 | 0: 3.225 |
| replace | random | A | scaleDown | 25,000 | 380,614 | 2.627 | 2.627 | 2.627 | 0.000 | 0: 2.627 | 0: 2.627 |
| replace | random | A | fullLifecycle | 50,000 | 341,752 | 2.926 | 2.926 | 2.926 | 0.000 | 0: 2.926 | 0: 2.926 |
| replace | tail | A | scaleUp | 25,000 | 499,183 | 2.003 | 2.003 | 2.003 | 0.000 | 0: 2.003 | 0: 2.003 |
| replace | tail | A | scaleDown | 25,000 | 54,090 | 18.488 | 18.488 | 18.488 | 0.000 | 0: 18.488 | 0: 18.488 |
| replace | tail | A | fullLifecycle | 50,000 | 97,604 | 10.246 | 10.246 | 10.246 | 0.000 | 0: 10.246 | 0: 10.246 |
| sequence | — | A | scaleUp | 6 | 67 | 14893.567 | 14893.567 | 14893.567 | 0.000 | 0: 14893.567 | 0: 14893.567 |
| sequence | — | A | scaleDown | 6 | 91 | 11008.467 | 11008.467 | 11008.467 | 0.000 | 0: 11008.467 | 0: 11008.467 |
| sequence | — | A | fullLifecycle | 12 | 77 | 12951.017 | 12951.017 | 12951.017 | 0.000 | 0: 12951.017 | 0: 12951.017 |
| value | head | A | scaleUp | 25,000 | 2,787,161 | 0.359 | 0.359 | 0.359 | 0.000 | 0: 0.359 | 0: 0.359 |
| value | head | A | scaleDown | 25,000 | 2,401,122 | 0.416 | 0.416 | 0.416 | 0.000 | 0: 0.416 | 0: 0.416 |
| value | head | A | fullLifecycle | 50,000 | 2,579,780 | 0.388 | 0.388 | 0.388 | 0.000 | 0: 0.388 | 0: 0.388 |
| value | random | A | scaleUp | 25,000 | 833,100 | 1.200 | 1.200 | 1.200 | 0.000 | 0: 1.200 | 0: 1.200 |
| value | random | A | scaleDown | 25,000 | 1,003,653 | 0.996 | 0.996 | 0.996 | 0.000 | 0: 0.996 | 0: 0.996 |
| value | random | A | fullLifecycle | 50,000 | 910,458 | 1.098 | 1.098 | 1.098 | 0.000 | 0: 1.098 | 0: 1.098 |
| value | tail | A | scaleUp | 25,000 | 6,332,962 | 0.158 | 0.158 | 0.158 | 0.000 | 0: 0.158 | 0: 0.158 |
| value | tail | A | scaleDown | 25,000 | 4,518,998 | 0.221 | 0.221 | 0.221 | 0.000 | 0: 0.221 | 0: 0.221 |
| value | tail | A | fullLifecycle | 50,000 | 5,274,373 | 0.190 | 0.190 | 0.190 | 0.000 | 0: 0.190 | 0: 0.190 |
| values | — | A | scaleUp | 6 | 138 | 7245.383 | 7245.383 | 7245.383 | 0.000 | 0: 7245.383 | 0: 7245.383 |
| values | — | A | scaleDown | 6 | 245 | 4087.650 | 4087.650 | 4087.650 | 0.000 | 0: 4087.650 | 0: 4087.650 |
| values | — | A | fullLifecycle | 12 | 176 | 5666.517 | 5666.517 | 5666.517 | 0.000 | 0: 5666.517 | 0: 5666.517 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5410752.667 | 427.165 | 8.478 |
| A | scaleDown | 5 | 4407357.600 | 432.094 | 8.548 |
| A | fullLifecycle | 11 | 4954664.000 | 429.144 | 8.506 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3116296.167 | 246.023 | 4.883 |
| A | scaleDown | 5 | 2595337.600 | 254.445 | 5.034 |
| A | fullLifecycle | 11 | 2879496.818 | 249.405 | 4.944 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 235,128 | 4.253 | 2.000 | 85.100 |
| apply | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 215,565 | 4.639 | 2.000 | 462.200 |
| apply | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 249,723 | 4.004 | 1.800 | 741.600 |
| apply | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 278,292 | 3.593 | 1.700 | 741.600 |
| apply | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 287,985 | 3.472 | 1.700 | 741.600 |
| apply | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 295,492 | 3.384 | 1.700 | 741.600 |
| apply | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 299,152 | 3.343 | 1.700 | 741.600 |
| apply | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 304,325 | 3.286 | 1.700 | 741.600 |
| apply | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 308,681 | 3.240 | 1.600 | 741.600 |
| apply | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 311,861 | 3.207 | 1.500 | 741.600 |
| apply | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 315,443 | 3.170 | 1.400 | 741.600 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 316,966 | 3.155 | 1.400 | 741.600 |
| insert | head | 0 | up | 1,000 | 50,007 | A | 500 | 921,659 | 1.085 | 0.400 | 31.600 |
| insert | head | 0 | up | 5,000 | 256,206 | A | 2,500 | 850,224 | 1.176 | 0.400 | 31.600 |
| insert | head | 0 | up | 10,000 | 508,328 | A | 5,000 | 1,009,550 | 0.991 | 0.300 | 129.500 |
| insert | head | 0 | up | 15,000 | 756,035 | A | 7,500 | 1,087,729 | 0.919 | 0.300 | 301.700 |
| insert | head | 0 | up | 20,000 | 1,005,850 | A | 10,000 | 1,122,876 | 0.891 | 0.300 | 301.700 |
| insert | head | 0 | up | 25,000 | 1,252,902 | A | 12,500 | 1,177,379 | 0.849 | 0.300 | 301.700 |
| insert | head | 0 | down | 20,000 | 1,007,225 | A | 12,500 | 1,177,379 | 0.849 | 0.300 | 301.700 |
| insert | head | 0 | down | 15,000 | 759,799 | A | 12,500 | 1,177,379 | 0.849 | 0.300 | 301.700 |
| insert | head | 0 | down | 10,000 | 506,363 | A | 12,500 | 1,177,379 | 0.849 | 0.300 | 301.700 |
| insert | head | 0 | down | 5,000 | 254,264 | A | 12,500 | 1,177,379 | 0.849 | 0.300 | 301.700 |
| insert | head | 0 | down | 1,000 | 50,210 | A | 12,500 | 1,177,379 | 0.849 | 0.300 | 301.700 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,177,379 | 0.849 | 0.300 | 301.700 |
| insert | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 456,579 | 2.190 | 0.500 | 473.100 |
| insert | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 376,619 | 2.655 | 0.500 | 728.000 |
| insert | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 437,955 | 2.283 | 0.500 | 1028.000 |
| insert | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 497,461 | 2.010 | 0.500 | 1028.000 |
| insert | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 514,094 | 1.945 | 0.500 | 1028.000 |
| insert | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 531,548 | 1.881 | 0.500 | 1028.000 |
| insert | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 524,345 | 1.907 | 0.500 | 1028.000 |
| insert | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 530,472 | 1.885 | 0.500 | 1028.000 |
| insert | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 539,238 | 1.854 | 0.500 | 1028.000 |
| insert | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 550,501 | 1.817 | 0.500 | 1028.000 |
| insert | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 562,586 | 1.778 | 0.500 | 1028.000 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 567,118 | 1.763 | 0.400 | 1028.000 |
| insert | tail | 0 | up | 1,000 | 50,007 | A | 500 | 966,370 | 1.035 | 0.400 | 31.500 |
| insert | tail | 0 | up | 5,000 | 256,206 | A | 2,500 | 881,150 | 1.135 | 0.400 | 51.200 |
| insert | tail | 0 | up | 10,000 | 508,328 | A | 5,000 | 1,055,788 | 0.947 | 0.400 | 143.600 |
| insert | tail | 0 | up | 15,000 | 756,035 | A | 7,500 | 1,180,935 | 0.847 | 0.300 | 162.800 |
| insert | tail | 0 | up | 20,000 | 1,005,850 | A | 10,000 | 1,256,818 | 0.796 | 0.300 | 162.800 |
| insert | tail | 0 | up | 25,000 | 1,252,902 | A | 12,500 | 1,266,490 | 0.790 | 0.300 | 362.400 |
| insert | tail | 0 | down | 20,000 | 1,007,225 | A | 12,500 | 1,266,490 | 0.790 | 0.300 | 362.400 |
| insert | tail | 0 | down | 15,000 | 759,799 | A | 12,500 | 1,266,490 | 0.790 | 0.300 | 362.400 |
| insert | tail | 0 | down | 10,000 | 506,363 | A | 12,500 | 1,266,490 | 0.790 | 0.300 | 362.400 |
| insert | tail | 0 | down | 5,000 | 254,264 | A | 12,500 | 1,266,490 | 0.790 | 0.300 | 362.400 |
| insert | tail | 0 | down | 1,000 | 50,210 | A | 12,500 | 1,266,490 | 0.790 | 0.300 | 362.400 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,266,490 | 0.790 | 0.300 | 362.400 |
| remove | head | 0 | up | 1,000 | 50,007 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 256,206 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 508,328 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 756,035 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,005,850 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,252,902 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,007,225 | A | 2,500 | 681,088 | 1.468 | 0.800 | 18.600 |
| remove | head | 0 | down | 15,000 | 759,799 | A | 5,000 | 696,583 | 1.436 | 0.800 | 18.600 |
| remove | head | 0 | down | 10,000 | 506,363 | A | 7,500 | 673,443 | 1.485 | 0.800 | 624.600 |
| remove | head | 0 | down | 5,000 | 254,264 | A | 10,000 | 695,909 | 1.437 | 0.800 | 624.600 |
| remove | head | 0 | down | 1,000 | 50,210 | A | 12,000 | 710,938 | 1.407 | 0.800 | 624.600 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 715,713 | 1.397 | 0.700 | 624.600 |
| remove | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 320,420 | 3.121 | 0.900 | 669.600 |
| remove | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 313,022 | 3.195 | 0.900 | 669.600 |
| remove | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 367,824 | 2.719 | 0.900 | 669.600 |
| remove | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 415,512 | 2.407 | 0.900 | 669.600 |
| remove | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 429,525 | 2.328 | 0.900 | 669.600 |
| remove | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 442,159 | 2.262 | 0.900 | 669.600 |
| remove | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 444,915 | 2.248 | 0.900 | 669.600 |
| remove | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 450,655 | 2.219 | 0.900 | 669.600 |
| remove | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 458,010 | 2.183 | 0.900 | 669.600 |
| remove | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 465,859 | 2.147 | 0.900 | 669.600 |
| remove | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 475,012 | 2.105 | 0.800 | 669.600 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 478,194 | 2.091 | 0.700 | 669.600 |
| remove | tail | 0 | up | 1,000 | 50,007 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 256,206 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 508,328 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 756,035 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,005,850 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,252,902 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,007,225 | A | 2,500 | 799,335 | 1.251 | 0.800 | 15.000 |
| remove | tail | 0 | down | 15,000 | 759,799 | A | 5,000 | 777,690 | 1.286 | 0.800 | 22.400 |
| remove | tail | 0 | down | 10,000 | 506,363 | A | 7,500 | 750,841 | 1.332 | 0.700 | 507.800 |
| remove | tail | 0 | down | 5,000 | 254,264 | A | 10,000 | 770,072 | 1.299 | 0.700 | 507.800 |
| remove | tail | 0 | down | 1,000 | 50,210 | A | 12,000 | 784,981 | 1.274 | 0.700 | 507.800 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 790,284 | 1.265 | 0.700 | 507.800 |
| replace | head | 0 | up | 1,000 | 50,007 | A | 1,000 | 311,711 | 3.208 | 1.200 | 561.000 |
| replace | head | 0 | up | 5,000 | 256,206 | A | 5,000 | 266,742 | 3.749 | 1.200 | 3548.400 |
| replace | head | 0 | up | 10,000 | 508,328 | A | 10,000 | 329,967 | 3.031 | 1.200 | 3548.400 |
| replace | head | 0 | up | 15,000 | 756,035 | A | 15,000 | 357,378 | 2.798 | 1.100 | 3548.400 |
| replace | head | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 394,505 | 2.535 | 1.000 | 3548.400 |
| replace | head | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 409,117 | 2.444 | 1.000 | 3548.400 |
| replace | head | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 419,890 | 2.382 | 1.000 | 3548.400 |
| replace | head | 0 | down | 15,000 | 759,799 | A | 35,000 | 427,727 | 2.338 | 1.000 | 3548.400 |
| replace | head | 0 | down | 10,000 | 506,363 | A | 40,000 | 437,205 | 2.287 | 1.000 | 3548.400 |
| replace | head | 0 | down | 5,000 | 254,264 | A | 45,000 | 443,607 | 2.254 | 1.000 | 3548.400 |
| replace | head | 0 | down | 1,000 | 50,210 | A | 49,000 | 451,411 | 2.215 | 0.900 | 3548.400 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 453,546 | 2.205 | 0.900 | 3548.400 |
| replace | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 254,777 | 3.925 | 1.300 | 552.300 |
| replace | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 239,532 | 4.175 | 1.300 | 1362.700 |
| replace | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 283,799 | 3.524 | 1.300 | 1362.700 |
| replace | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 303,337 | 3.297 | 1.200 | 1362.700 |
| replace | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 307,277 | 3.254 | 1.200 | 1796.600 |
| replace | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 310,090 | 3.225 | 1.200 | 1796.600 |
| replace | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 317,659 | 3.148 | 1.200 | 1796.600 |
| replace | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 317,323 | 3.151 | 1.200 | 1796.600 |
| replace | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 326,065 | 3.067 | 1.200 | 1796.600 |
| replace | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 332,072 | 3.011 | 1.100 | 1796.600 |
| replace | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 339,179 | 2.948 | 1.100 | 1796.600 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 341,752 | 2.926 | 1.000 | 1796.600 |
| replace | tail | 0 | up | 1,000 | 50,007 | A | 1,000 | 383,966 | 2.604 | 1.100 | 139.300 |
| replace | tail | 0 | up | 5,000 | 256,206 | A | 5,000 | 381,185 | 2.623 | 1.100 | 242.700 |
| replace | tail | 0 | up | 10,000 | 508,328 | A | 10,000 | 433,841 | 2.305 | 1.100 | 242.700 |
| replace | tail | 0 | up | 15,000 | 756,035 | A | 15,000 | 473,841 | 2.110 | 1.100 | 242.700 |
| replace | tail | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 485,528 | 2.060 | 1.100 | 440.200 |
| replace | tail | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 499,183 | 2.003 | 1.100 | 440.200 |
| replace | tail | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 123,746 | 8.081 | 1.100 | 2874.100 |
| replace | tail | 0 | down | 15,000 | 759,799 | A | 35,000 | 94,032 | 10.635 | 1.100 | 2874.100 |
| replace | tail | 0 | down | 10,000 | 506,363 | A | 40,000 | 95,539 | 10.467 | 1.100 | 2874.100 |
| replace | tail | 0 | down | 5,000 | 254,264 | A | 45,000 | 93,445 | 10.701 | 1.000 | 2874.100 |
| replace | tail | 0 | down | 1,000 | 50,210 | A | 49,000 | 96,113 | 10.404 | 1.000 | 2874.100 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 97,604 | 10.246 | 0.900 | 2874.100 |
| value | head | 0 | up | 1,000 | 50,007 | A | 1,000 | 883,158 | 1.132 | 0.200 | 637.900 |
| value | head | 0 | up | 5,000 | 256,206 | A | 5,000 | 1,676,277 | 0.597 | 0.100 | 637.900 |
| value | head | 0 | up | 10,000 | 508,328 | A | 10,000 | 2,138,992 | 0.468 | 0.100 | 637.900 |
| value | head | 0 | up | 15,000 | 756,035 | A | 15,000 | 2,475,248 | 0.404 | 0.100 | 637.900 |
| value | head | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 2,668,268 | 0.375 | 0.100 | 637.900 |
| value | head | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 2,787,161 | 0.359 | 0.100 | 637.900 |
| value | head | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 2,680,678 | 0.373 | 0.100 | 637.900 |
| value | head | 0 | down | 15,000 | 759,799 | A | 35,000 | 2,636,019 | 0.379 | 0.100 | 637.900 |
| value | head | 0 | down | 10,000 | 506,363 | A | 40,000 | 2,615,969 | 0.382 | 0.100 | 637.900 |
| value | head | 0 | down | 5,000 | 254,264 | A | 45,000 | 2,595,216 | 0.385 | 0.100 | 637.900 |
| value | head | 0 | down | 1,000 | 50,210 | A | 49,000 | 2,576,913 | 0.388 | 0.100 | 637.900 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,579,780 | 0.388 | 0.100 | 637.900 |
| value | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 1,119,319 | 0.893 | 0.100 | 53.100 |
| value | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 672,106 | 1.488 | 0.100 | 53.100 |
| value | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 749,254 | 1.335 | 0.100 | 53.100 |
| value | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 806,634 | 1.240 | 0.100 | 86.500 |
| value | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 828,428 | 1.207 | 0.100 | 88.800 |
| value | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 833,100 | 1.200 | 0.100 | 88.800 |
| value | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 846,640 | 1.181 | 0.100 | 88.800 |
| value | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 856,129 | 1.168 | 0.100 | 88.800 |
| value | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 872,020 | 1.147 | 0.100 | 88.800 |
| value | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 884,387 | 1.131 | 0.100 | 88.800 |
| value | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 903,171 | 1.107 | 0.100 | 88.800 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 910,458 | 1.098 | 0.100 | 88.800 |
| value | tail | 0 | up | 1,000 | 50,007 | A | 1,000 | 4,743,833 | 0.211 | 0.100 | 9.000 |
| value | tail | 0 | up | 5,000 | 256,206 | A | 5,000 | 4,394,445 | 0.228 | 0.100 | 58.900 |
| value | tail | 0 | up | 10,000 | 508,328 | A | 10,000 | 4,954,665 | 0.202 | 0.100 | 62.000 |
| value | tail | 0 | up | 15,000 | 756,035 | A | 15,000 | 5,600,777 | 0.179 | 0.000 | 62.000 |
| value | tail | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 6,040,106 | 0.166 | 0.000 | 62.000 |
| value | tail | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 6,332,962 | 0.158 | 0.000 | 62.000 |
| value | tail | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 5,917,627 | 0.169 | 0.000 | 62.000 |
| value | tail | 0 | down | 15,000 | 759,799 | A | 35,000 | 5,670,220 | 0.176 | 0.000 | 62.000 |
| value | tail | 0 | down | 10,000 | 506,363 | A | 40,000 | 5,497,828 | 0.182 | 0.000 | 62.000 |
| value | tail | 0 | down | 5,000 | 254,264 | A | 45,000 | 5,360,270 | 0.187 | 0.000 | 62.000 |
| value | tail | 0 | down | 1,000 | 50,210 | A | 49,000 | 5,280,855 | 0.189 | 0.000 | 62.000 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,274,373 | 0.190 | 0.000 | 62.000 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,610 | 383.200 |
| create | — | 0 | up | 5,000 | A | 1 | 560 | 1784.700 |
| create | — | 0 | up | 10,000 | A | 1 | 499 | 2004.800 |
| create | — | 0 | up | 15,000 | A | 1 | 403 | 2481.300 |
| create | — | 0 | up | 20,000 | A | 1 | 294 | 3399.300 |
| create | — | 0 | up | 25,000 | A | 1 | 224 | 4471.200 |
| create | — | 0 | down | 20,000 | A | 1 | 285 | 3509.500 |
| create | — | 0 | down | 15,000 | A | 1 | 383 | 2609.700 |
| create | — | 0 | down | 10,000 | A | 1 | 516 | 1938.700 |
| create | — | 0 | down | 5,000 | A | 1 | 1,140 | 877.200 |
| create | — | 0 | down | 1,000 | A | 1 | 6,382 | 156.700 |
| create | — | 0 | down | 0 | A | 1 | 63,291 | 15.800 |
| sequence | — | 0 | up | 1,000 | A | 1 | 396 | 2522.500 |
| sequence | — | 0 | up | 5,000 | A | 1 | 63 | 15832.800 |
| sequence | — | 0 | up | 10,000 | A | 1 | 72 | 13878.800 |
| sequence | — | 0 | up | 15,000 | A | 1 | 70 | 14344.400 |
| sequence | — | 0 | up | 20,000 | A | 1 | 50 | 19856.400 |
| sequence | — | 0 | up | 25,000 | A | 1 | 44 | 22926.500 |
| sequence | — | 0 | down | 20,000 | A | 1 | 55 | 18094.900 |
| sequence | — | 0 | down | 15,000 | A | 1 | 64 | 15566.400 |
| sequence | — | 0 | down | 10,000 | A | 1 | 84 | 11911.800 |
| sequence | — | 0 | down | 5,000 | A | 1 | 83 | 12082.200 |
| sequence | — | 0 | down | 1,000 | A | 1 | 148 | 6777.500 |
| sequence | — | 0 | down | 0 | A | 1 | 618 | 1618.000 |
| values | — | 0 | up | 1,000 | A | 1 | 488 | 2050.900 |
| values | — | 0 | up | 5,000 | A | 1 | 165 | 6043.500 |
| values | — | 0 | up | 10,000 | A | 1 | 167 | 5995.500 |
| values | — | 0 | up | 15,000 | A | 1 | 125 | 8025.300 |
| values | — | 0 | up | 20,000 | A | 1 | 103 | 9700.900 |
| values | — | 0 | up | 25,000 | A | 1 | 86 | 11656.200 |
| values | — | 0 | down | 20,000 | A | 1 | 111 | 9021.800 |
| values | — | 0 | down | 15,000 | A | 1 | 140 | 7144.200 |
| values | — | 0 | down | 10,000 | A | 1 | 196 | 5097.900 |
| values | — | 0 | down | 5,000 | A | 1 | 368 | 2718.500 |
| values | — | 0 | down | 1,000 | A | 1 | 1,909 | 523.900 |
| values | — | 0 | down | 0 | A | 1 | 51,020 | 19.600 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.613 | 0.232 | 0.382 |
| 0 | up | 5000 | 3.122 | 1.167 | 1.955 |
| 0 | up | 10000 | 6.220 | 2.342 | 3.878 |
| 0 | up | 15000 | 9.408 | 3.640 | 5.768 |
| 0 | up | 20000 | 12.780 | 5.106 | 7.674 |
| 0 | up | 25000 | 16.189 | 6.630 | 9.559 |
| 0 | down | 20000 | 13.291 | 5.606 | 7.685 |
| 0 | down | 15000 | 9.922 | 4.125 | 5.797 |
| 0 | down | 10000 | 7.152 | 3.289 | 3.863 |
| 0 | down | 5000 | 4.095 | 2.155 | 1.940 |
| 0 | down | 1000 | 1.797 | 1.414 | 0.383 |
| 0 | down | 0 | 1.224 | 1.224 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 50,007 | 0.402 | 421.580 | 8.430 | 121.418 | 15.526 |
| 0 | up | A | 5,000 | 5,000 | 256,206 | 2.057 | 431.302 | 8.417 | 150.941 | 19.669 |
| 0 | up | A | 10,000 | 10,000 | 508,328 | 4.090 | 428.881 | 8.437 | 195.688 | 24.520 |
| 0 | up | A | 15,000 | 15,000 | 756,035 | 6.108 | 426.991 | 8.472 | 209.246 | 29.293 |
| 0 | up | A | 20,000 | 20,000 | 1,005,850 | 8.143 | 426.916 | 8.489 | 280.277 | 34.103 |
| 0 | up | A | 25,000 | 25,000 | 1,252,902 | 10.161 | 426.177 | 8.504 | 295.633 | 38.838 |
| 0 | down | A | 20,000 | 20,000 | 1,007,225 | 8.223 | 431.124 | 8.561 | 296.176 | 34.150 |
| 0 | down | A | 15,000 | 15,000 | 759,799 | 6.203 | 433.606 | 8.560 | 299.777 | 29.425 |
| 0 | down | A | 10,000 | 10,000 | 506,363 | 4.124 | 432.479 | 8.541 | 298.516 | 24.627 |
| 0 | down | A | 5,000 | 5,000 | 254,264 | 2.060 | 431.993 | 8.495 | 296.227 | 19.848 |
| 0 | down | A | 1,000 | 1,000 | 50,210 | 0.406 | 425.476 | 8.474 | 295.145 | 15.978 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 296.422 | 14.906 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 50007 | 184507 | 184.507 | 3.690 | 272.03 | 14.52 | 162.13 | 12.30 |
| 0 | up | A | 5000 | 256206 | 1218174 | 243.635 | 4.755 | 1644.25 | 73.50 | 830.68 | 61.66 |
| 0 | up | A | 10000 | 508328 | 2441689 | 244.169 | 4.803 | 3276.35 | 148.92 | 1655.21 | 124.79 |
| 0 | up | A | 15000 | 756035 | 3694120 | 246.275 | 4.886 | 4916.66 | 225.99 | 3545.68 | 200.14 |
| 0 | up | A | 20000 | 1005850 | 4950983 | 247.549 | 4.922 | 7073.44 | 311.23 | 5103.00 | 263.55 |
| 0 | up | A | 25000 | 1252902 | 6208304 | 248.332 | 4.955 | 9192.05 | 392.29 | 6496.81 | 335.16 |
| 0 | down | A | 20000 | 1007225 | 5103545 | 255.177 | 5.067 | 7538.07 | 326.43 | 5289.65 | 278.22 |
| 0 | down | A | 15000 | 759799 | 3844421 | 256.295 | 5.060 | 5730.74 | 247.34 | 4004.94 | 209.82 |
| 0 | down | A | 10000 | 506363 | 2541344 | 254.134 | 5.019 | 3828.12 | 165.02 | 2670.80 | 139.89 |
| 0 | down | A | 5000 | 254264 | 1247949 | 249.590 | 4.908 | 1909.46 | 79.58 | 1334.90 | 67.69 |
| 0 | down | A | 1000 | 50210 | 239429 | 239.429 | 4.769 | 375.26 | 16.04 | 262.97 | 13.69 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 427.165 | 8.478 | 246.023 | 4.883 |
| 0 | A | scaleDown | 432.094 | 8.548 | 254.445 | 5.034 |
| 0 | A | fullLifecycle | 429.144 | 8.506 | 249.405 | 4.944 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
