# Large string benchmarks

2026-11-27T17:27:32.727Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2603.75 | 0.00 |
| 1024 | insert.append | array | 14685.20 | 0.00 |
| 1024 | replace | array | 3742.24 | 0.00 |
| 1024 | remove | array | 1219.26 | 0.00 |
| 1024 | remove.middle | array | 2172.07 | 0.00 |
| 1024 | replace.middle | array | 2577.84 | 0.00 |
| 1024 | apply | array | 931.08 | 0.00 |
| 1024 | apply.array | array | 608.96 | 0.00 |
| 1024 | concurrent.apply | array | 68054.62 | 0.00 |
| 1024 | merge | array | 3331.39 | 0.00 |
| 1024 | create | array | 3100.76 | 0.00 |
| 1024 | value.random | array | 44.16 | 0.00 |
| 1024 | values.range | array | 131.86 | 0.00 |
| 1024 | values.array | array | 1300.03 | 0.00 |
| 1024 | values.text | array | 13145.37 | 0.00 |
| 1024 | sequence.array | array | 1904.88 | 0.00 |
| 1024 | sequence.text | array | 9668.14 | 0.00 |
| 1024 | sequence.edited.text | array | 14212.54 | 0.00 |
| 1024 | sequence.masked.text | array | 11103.24 | 0.00 |
| 1024 | insert | string | 433.39 | 0.00 |
| 1024 | insert.append | string | 4262.64 | 0.00 |
| 1024 | replace | string | 1489.59 | 0.00 |
| 1024 | remove | string | 1040.59 | 0.00 |
| 1024 | remove.middle | string | 1049.19 | 0.00 |
| 1024 | replace.middle | string | 1460.79 | 0.00 |
| 1024 | apply | string | 1487.70 | 0.00 |
| 1024 | apply.array | string | 2497.56 | 0.00 |
| 1024 | concurrent.apply | string | 3773.44 | 0.00 |
| 1024 | merge | string | 1684.81 | 0.00 |
| 1024 | create | string | 1013.27 | 0.00 |
| 1024 | value.random | string | 53.98 | 0.00 |
| 1024 | values.range | string | 152.70 | 0.00 |
| 1024 | values.array | string | 1816.75 | 0.00 |
| 1024 | values.text | string | 67.92 | 0.00 |
| 1024 | sequence.array | string | 1954.88 | 0.00 |
| 1024 | sequence.text | string | 188.56 | 0.00 |
| 1024 | sequence.edited.text | string | 2063.00 | 0.00 |
| 1024 | sequence.masked.text | string | 3455.58 | 0.00 |
| 65536 | insert | array | 274534.04 | 0.00 |
| 65536 | insert.append | array | 1073616.00 | 0.00 |
| 65536 | replace | array | 240844.23 | 0.00 |
| 65536 | remove | array | 2583.80 | 0.00 |
| 65536 | remove.middle | array | 236821.10 | 0.00 |
| 65536 | replace.middle | array | 251400.91 | 0.00 |
| 65536 | apply | array | 878.38 | 0.00 |
| 65536 | apply.array | array | 570.57 | 0.00 |
| 65536 | concurrent.apply | array | 3879971.43 | 0.00 |
| 65536 | merge | array | 199203.17 | 0.00 |
| 65536 | create | array | 207591.74 | 0.00 |
| 65536 | value.random | array | 53.08 | 0.00 |
| 65536 | values.range | array | 124.74 | 0.00 |
| 65536 | values.array | array | 202692.06 | 0.00 |
| 65536 | values.text | array | 772230.30 | 0.00 |
| 65536 | sequence.array | array | 205800.79 | 0.00 |
| 65536 | sequence.text | array | 933733.33 | 0.00 |
| 65536 | sequence.edited.text | array | 927555.56 | 0.00 |
| 65536 | sequence.masked.text | array | 841703.12 | 0.00 |
| 65536 | insert | string | 381.29 | 0.00 |
| 65536 | insert.append | string | 22627.96 | 0.00 |
| 65536 | replace | string | 1378.27 | 0.00 |
| 65536 | remove | string | 1004.70 | 0.00 |
| 65536 | remove.middle | string | 1033.13 | 0.00 |
| 65536 | replace.middle | string | 1348.96 | 0.00 |
| 65536 | apply | string | 1007.96 | 0.00 |
| 65536 | apply.array | string | 266121.09 | 0.00 |
| 65536 | concurrent.apply | string | 137485.79 | 0.00 |
| 65536 | merge | string | 1331.52 | 0.00 |
| 65536 | create | string | 871.94 | 0.00 |
| 65536 | value.random | string | 65.46 | 0.00 |
| 65536 | values.range | string | 144.76 | 0.00 |
| 65536 | values.array | string | 202672.58 | 0.00 |
| 65536 | values.text | string | 70.81 | 0.00 |
| 65536 | sequence.array | string | 253544.53 | 0.00 |
| 65536 | sequence.text | string | 196.56 | 0.00 |
| 65536 | sequence.edited.text | string | 88706.03 | 0.00 |
| 65536 | sequence.masked.text | string | 3270.53 | 0.00 |
| 1048576 | insert | array | 3480850.00 | 0.00 |
| 1048576 | insert.append | array | 26063350.00 | 0.00 |
| 1048576 | replace | array | 3428750.00 | 0.00 |
| 1048576 | remove | array | 10640.13 | 0.00 |
| 1048576 | remove.middle | array | 3361666.67 | 0.00 |
| 1048576 | replace.middle | array | 2634570.00 | 0.00 |
| 1048576 | apply | array | 1177.64 | 0.00 |
| 1048576 | apply.array | array | 684.51 | 0.00 |
| 1048576 | concurrent.apply | array | 70741700.00 | 0.00 |
| 1048576 | merge | array | 3347387.50 | 0.00 |
| 1048576 | create | array | 3203825.00 | 0.00 |
| 1048576 | value.random | array | 46.49 | 0.00 |
| 1048576 | values.range | array | 105.10 | 0.00 |
| 1048576 | values.array | array | 2329127.27 | 0.00 |
| 1048576 | values.text | array | 12892650.00 | 0.00 |
| 1048576 | sequence.array | array | 2326663.64 | 0.00 |
| 1048576 | sequence.text | array | 56982400.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 75662150.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 62966900.00 | 0.00 |
| 1048576 | insert | string | 621.88 | 0.00 |
| 1048576 | insert.append | string | 702900.00 | 0.00 |
| 1048576 | replace | string | 1937.23 | 0.00 |
| 1048576 | remove | string | 1643.77 | 0.00 |
| 1048576 | remove.middle | string | 1374.61 | 0.00 |
| 1048576 | replace.middle | string | 1490.73 | 0.00 |
| 1048576 | apply | string | 1111.15 | 0.00 |
| 1048576 | apply.array | string | 4582725.00 | 0.00 |
| 1048576 | concurrent.apply | string | 2474481.82 | 0.00 |
| 1048576 | merge | string | 2767.02 | 0.00 |
| 1048576 | create | string | 2219.79 | 0.00 |
| 1048576 | value.random | string | 145.83 | 0.00 |
| 1048576 | values.range | string | 2457.91 | 0.00 |
| 1048576 | values.array | string | 10843033.33 | 0.00 |
| 1048576 | values.text | string | 96.46 | 0.00 |
| 1048576 | sequence.array | string | 3813771.43 | 0.00 |
| 1048576 | sequence.text | string | 273.44 | 0.00 |
| 1048576 | sequence.edited.text | string | 3064088.89 | 0.00 |
| 1048576 | sequence.masked.text | string | 4630.61 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
