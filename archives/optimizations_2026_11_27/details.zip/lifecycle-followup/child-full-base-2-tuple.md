# Tuple benchmarks

2026-11-27T17:27:18.347Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 2,945,862 | 2,274,898 | 0.77× |
| 2 | create.sequence | 928,797 | 798,032 | 0.86× |
| 2 | replace.random | 1,173,677 | 1,443,185 | 1.23× |
| 2 | apply.replace | 643,351 | 883,803 | 1.37× |
| 2 | apply.duplicate | 1,683,845 | 1,661,147 | 0.99× |
| 2 | merge.duplicate | 1,563,111 | 1,468,717 | 0.94× |
| 2 | length | 129,950,012 | 128,231,028 | 0.99× |
| 2 | value.random | 35,319,452 | 53,922,610 | 1.53× |
| 2 | values | 12,005,623 | 12,692,853 | 1.06× |
| 2 | sequence | 3,066,925 | 2,775,250 | 0.90× |
| 4 | create.empty | 2,538,586 | 2,119,842 | 0.84× |
| 4 | create.sequence | 624,097 | 674,332 | 1.08× |
| 4 | replace.random | 1,018,804 | 1,385,852 | 1.36× |
| 4 | apply.replace | 562,209 | 912,903 | 1.62× |
| 4 | apply.duplicate | 1,707,846 | 1,702,434 | 1.00× |
| 4 | merge.duplicate | 1,265,797 | 1,167,774 | 0.92× |
| 4 | length | 30,743,177 | 38,689,263 | 1.26× |
| 4 | value.random | 25,207,123 | 53,672,468 | 2.13× |
| 4 | values | 6,693,811 | 6,916,596 | 1.03× |
| 4 | sequence | 2,710,075 | 2,594,021 | 0.96× |
| 8 | create.empty | 2,596,930 | 2,440,473 | 0.94× |
| 8 | create.sequence | 451,875 | 479,099 | 1.06× |
| 8 | replace.random | 992,740 | 1,552,320 | 1.56× |
| 8 | apply.replace | 644,204 | 942,523 | 1.46× |
| 8 | apply.duplicate | 1,721,140 | 1,744,227 | 1.01× |
| 8 | merge.duplicate | 962,611 | 930,740 | 0.97× |
| 8 | length | 35,754,524 | 35,702,559 | 1.00× |
| 8 | value.random | 19,138,196 | 54,332,293 | 2.84× |
| 8 | values | 4,557,052 | 4,369,576 | 0.96× |
| 8 | sequence | 1,707,110 | 1,864,659 | 1.09× |
| 100 | create.empty | 2,438,936 | 2,204,411 | 0.90× |
| 100 | create.sequence | 70,482 | 84,227 | 1.20× |
| 100 | replace.random | 980,861 | 1,532,985 | 1.56× |
| 100 | apply.replace | 670,866 | 990,705 | 1.48× |
| 100 | apply.duplicate | 1,660,736 | 1,719,196 | 1.04× |
| 100 | merge.duplicate | 105,940 | 77,087 | 0.73× |
| 100 | length | 35,042,710 | 34,959,725 | 1.00× |
| 100 | value.random | 12,567,863 | 30,359,247 | 2.42× |
| 100 | values | 498,011 | 585,858 | 1.18× |
| 100 | sequence | 160,389 | 181,314 | 1.13× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
