# Words benchmarks

2026-11-27T17:27:56.186Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 18,134 | 46,338 | 35 |
| append | packed | 5.90 | 3.61 | 13.98 | 22,592 | 152,199 | 348 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,759 | 785 | 212 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 31,235 | 1,735 | 231 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 475 | 252 | 86 |
| random | packed | 49.58 | 35.38 | 23.45 | 13,147 | 547 | 130 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 679 | 199 | 97 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 15,442 | 399 | 144 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 604.89 | 0.00 |
| append | numeric | encode | 55145.09 | 0.00 |
| append | numeric | decode | 6703.71 | 0.00 |
| append | numeric | create | 2565.90 | 0.00 |
| append | numeric | load | 21580.62 | 0.00 |
| append | numeric | apply | 14683150.00 | 0.00 |
| append | numeric | receive | 28392050.00 | 0.00 |
| append | binary | sequence | 968.52 | 0.00 |
| append | binary | encode | 44263.89 | 0.00 |
| append | binary | decode | 3851.97 | 0.00 |
| append | binary | create | 2673.71 | 0.00 |
| append | binary | load | 6570.35 | 0.00 |
| append | binary | apply | 2023116.00 | 0.00 |
| append | binary | receive | 2876444.44 | 0.00 |
| prepend | numeric | sequence | 467712.15 | 0.00 |
| prepend | numeric | encode | 568355.68 | 0.00 |
| prepend | numeric | decode | 203529.15 | 0.00 |
| prepend | numeric | create | 648641.03 | 0.00 |
| prepend | numeric | load | 1273800.00 | 0.00 |
| prepend | numeric | apply | 2333800.00 | 0.00 |
| prepend | numeric | receive | 4721600.00 | 0.00 |
| prepend | binary | sequence | 358525.00 | 0.00 |
| prepend | binary | encode | 32015.62 | 0.00 |
| prepend | binary | decode | 2284.70 | 0.00 |
| prepend | binary | create | 576779.31 | 0.00 |
| prepend | binary | load | 576517.24 | 0.00 |
| prepend | binary | apply | 2543435.00 | 0.00 |
| prepend | binary | receive | 4337233.33 | 0.00 |
| random | numeric | sequence | 985811.76 | 0.00 |
| random | numeric | encode | 2104137.50 | 0.00 |
| random | numeric | decode | 1089519.57 | 0.00 |
| random | numeric | create | 1756055.17 | 0.00 |
| random | numeric | load | 3970853.85 | 0.00 |
| random | numeric | apply | 7573871.43 | 0.00 |
| random | numeric | receive | 11581380.00 | 0.00 |
| random | binary | sequence | 919969.09 | 0.00 |
| random | binary | encode | 76060.94 | 0.00 |
| random | binary | decode | 1668.66 | 0.00 |
| random | binary | create | 1903125.93 | 0.00 |
| random | binary | load | 1828889.29 | 0.00 |
| random | binary | apply | 6417200.00 | 0.00 |
| random | binary | receive | 7674228.57 | 0.00 |
| concurrent | numeric | sequence | 762869.70 | 0.00 |
| concurrent | numeric | encode | 1473634.29 | 0.00 |
| concurrent | numeric | decode | 774203.08 | 0.00 |
| concurrent | numeric | create | 2516990.00 | 0.00 |
| concurrent | numeric | load | 5027840.00 | 0.00 |
| concurrent | numeric | apply | 5950222.22 | 0.00 |
| concurrent | numeric | receive | 10321740.00 | 0.00 |
| concurrent | binary | sequence | 716854.29 | 0.00 |
| concurrent | binary | encode | 64756.79 | 0.00 |
| concurrent | binary | decode | 2476.04 | 0.00 |
| concurrent | binary | create | 2255291.30 | 0.00 |
| concurrent | binary | load | 2506547.62 | 0.00 |
| concurrent | binary | apply | 5455160.00 | 0.00 |
| concurrent | binary | receive | 6927650.00 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
