# Batch benchmarks

2026-11-27T17:22:56.771Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 1,746,420 | 1,079,370 | 610,501 | 76.05 | 5.99 | 0.012 |
| append | batch | 2,408,865 | 221,402,214 | 211,267,606 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,677,524 | 1,604,707 | 869,490 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 1,942,816 | 2,104,599 | 2,008,301 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 1,013,890 | 973,457 | 822,650 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 1,111,482 | 1,508,675 | 1,448,296 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 979,336 | 1,096,992 | 584,197 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 1,124,332 | 1,679,214 | 1,572,451 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,183,012 | 1,125,661 | 778,432 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,352,097 | 1,719,863 | 1,611,409 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,339,002 | 1,350,895 | 899,928 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,370,536 | 1,608,558 | 1,527,534 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 671,915 | 993,608 | 706,972 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 816,110 | 1,086,897 | 1,198,298 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,129,114 | 1,376,257 | 985,464 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 1,353,394 | 1,750,802 | 1,661,682 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,253,342 | 1,307,788 | 811,046 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 1,337,152 | 1,530,749 | 1,542,000 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 739,846 | 979,000 | 716,277 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 857,872 | 1,248,582 | 1,164,223 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 3.436 | 0.000 |
| append | individual | apply | 5.559 | 0.000 |
| append | individual | receive | 9.828 | 0.000 |
| append | individual | encode | 6.353 | 0.000 |
| append | individual | decode | 6.360 | 0.000 |
| append | batch | author | 2.491 | 0.000 |
| append | batch | apply | 0.027 | 0.000 |
| append | batch | receive | 0.028 | 0.000 |
| append | batch | encode | 0.238 | 0.000 |
| append | batch | decode | 0.099 | 0.000 |
| prepend | individual | author | 3.577 | 0.000 |
| prepend | individual | apply | 3.739 | 0.000 |
| prepend | individual | receive | 6.901 | 0.000 |
| prepend | individual | encode | 5.295 | 0.000 |
| prepend | individual | decode | 7.273 | 0.000 |
| prepend | batch | author | 3.088 | 0.000 |
| prepend | batch | apply | 2.851 | 0.000 |
| prepend | batch | receive | 2.988 | 0.000 |
| prepend | batch | encode | 0.191 | 0.000 |
| prepend | batch | decode | 0.109 | 0.000 |
| random.characters | individual | author | 5.918 | 0.000 |
| random.characters | individual | apply | 6.164 | 0.000 |
| random.characters | individual | receive | 7.293 | 0.000 |
| random.characters | individual | encode | 6.045 | 0.000 |
| random.characters | individual | decode | 8.540 | 0.000 |
| random.characters | batch | author | 5.398 | 0.000 |
| random.characters | batch | apply | 3.977 | 0.000 |
| random.characters | batch | receive | 4.143 | 0.000 |
| random.characters | batch | encode | 0.218 | 0.000 |
| random.characters | batch | decode | 0.125 | 0.000 |
| random.words | individual | author | 6.127 | 0.000 |
| random.words | individual | apply | 5.470 | 0.000 |
| random.words | individual | receive | 10.270 | 0.000 |
| random.words | individual | encode | 6.164 | 0.000 |
| random.words | individual | decode | 11.163 | 0.000 |
| random.words | batch | author | 5.337 | 0.000 |
| random.words | batch | apply | 3.573 | 0.000 |
| random.words | batch | receive | 3.816 | 0.000 |
| random.words | batch | encode | 0.465 | 0.000 |
| random.words | batch | decode | 0.112 | 0.000 |
| concurrent.characters | individual | author | 10.144 | 0.000 |
| concurrent.characters | individual | apply | 10.660 | 0.000 |
| concurrent.characters | individual | receive | 15.416 | 0.000 |
| concurrent.characters | individual | encode | 8.357 | 0.000 |
| concurrent.characters | individual | decode | 10.195 | 0.000 |
| concurrent.characters | batch | author | 8.875 | 0.000 |
| concurrent.characters | batch | apply | 6.977 | 0.000 |
| concurrent.characters | batch | receive | 7.447 | 0.000 |
| concurrent.characters | batch | encode | 0.366 | 0.000 |
| concurrent.characters | batch | decode | 0.126 | 0.000 |
| concurrent.words | individual | author | 8.962 | 0.000 |
| concurrent.words | individual | apply | 8.883 | 0.000 |
| concurrent.words | individual | receive | 13.334 | 0.000 |
| concurrent.words | individual | encode | 8.276 | 0.000 |
| concurrent.words | individual | decode | 11.211 | 0.000 |
| concurrent.words | batch | author | 8.756 | 0.000 |
| concurrent.words | batch | apply | 7.460 | 0.000 |
| concurrent.words | batch | receive | 7.856 | 0.000 |
| concurrent.words | batch | encode | 0.714 | 0.000 |
| concurrent.words | batch | decode | 0.117 | 0.000 |
| concurrent.mixed | individual | author | 17.859 | 0.000 |
| concurrent.mixed | individual | apply | 12.077 | 0.000 |
| concurrent.mixed | individual | receive | 16.974 | 0.000 |
| concurrent.mixed | individual | encode | 8.492 | 0.000 |
| concurrent.mixed | individual | decode | 10.634 | 0.000 |
| concurrent.mixed | batch | author | 14.704 | 0.000 |
| concurrent.mixed | batch | apply | 11.041 | 0.000 |
| concurrent.mixed | batch | receive | 10.014 | 0.000 |
| concurrent.mixed | batch | encode | 0.506 | 0.000 |
| concurrent.mixed | batch | decode | 0.118 | 0.000 |
| causal.characters | individual | author | 10.628 | 0.000 |
| causal.characters | individual | apply | 8.719 | 0.000 |
| causal.characters | individual | receive | 12.177 | 0.000 |
| causal.characters | individual | encode | 7.167 | 0.000 |
| causal.characters | individual | decode | 10.915 | 0.000 |
| causal.characters | batch | author | 8.867 | 0.000 |
| causal.characters | batch | apply | 6.854 | 0.000 |
| causal.characters | batch | receive | 7.222 | 0.000 |
| causal.characters | batch | encode | 0.246 | 0.000 |
| causal.characters | batch | decode | 0.115 | 0.000 |
| causal.words | individual | author | 9.574 | 0.000 |
| causal.words | individual | apply | 9.176 | 0.000 |
| causal.words | individual | receive | 14.796 | 0.000 |
| causal.words | individual | encode | 8.676 | 0.000 |
| causal.words | individual | decode | 12.348 | 0.000 |
| causal.words | batch | author | 8.974 | 0.000 |
| causal.words | batch | apply | 7.839 | 0.000 |
| causal.words | batch | receive | 7.782 | 0.000 |
| causal.words | batch | encode | 0.714 | 0.000 |
| causal.words | batch | decode | 0.129 | 0.000 |
| causal.mixed | individual | author | 16.220 | 0.000 |
| causal.mixed | individual | apply | 12.257 | 0.000 |
| causal.mixed | individual | receive | 16.753 | 0.000 |
| causal.mixed | individual | encode | 9.816 | 0.000 |
| causal.mixed | individual | decode | 8.691 | 0.000 |
| causal.mixed | batch | author | 13.988 | 0.000 |
| causal.mixed | batch | apply | 9.611 | 0.000 |
| causal.mixed | batch | receive | 10.307 | 0.000 |
| causal.mixed | batch | encode | 0.434 | 0.000 |
| causal.mixed | batch | decode | 0.104 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
