# Sequencer dynamic lifecycle benchmark

2026-11-27T17:21:27.119Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.44 | 163.09 | 56.54 |
| CommonJS | 199.62 | 164.71 | 56.75 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 321,324 | 3.112 | 3.112 | 3.112 | 0.000 | 0: 3.112 | 0: 3.112 |
| apply | random | A | scaleDown | 24,999 | 284,233 | 3.518 | 3.518 | 3.518 | 0.000 | 0: 3.518 | 0: 3.518 |
| apply | random | A | fullLifecycle | 49,999 | 301,643 | 3.315 | 3.315 | 3.315 | 0.000 | 0: 3.315 | 0: 3.315 |
| create | — | A | scaleUp | 7 | 546 | 1832.343 | 1832.343 | 1832.343 | 0.000 | 0: 1832.343 | 0: 1832.343 |
| create | — | A | scaleDown | 6 | 546 | 1833.167 | 1833.167 | 1833.167 | 0.000 | 0: 1833.167 | 0: 1833.167 |
| create | — | A | fullLifecycle | 13 | 546 | 1832.723 | 1832.723 | 1832.723 | 0.000 | 0: 1832.723 | 0: 1832.723 |
| insert | head | A | scaleUp | 12,500 | 1,305,551 | 0.766 | 0.766 | 0.766 | 0.000 | 0: 0.766 | 0: 0.766 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,305,551 | 0.766 | 0.766 | 0.766 | 0.000 | 0: 0.766 | 0: 0.766 |
| insert | random | A | scaleUp | 25,000 | 584,910 | 1.710 | 1.710 | 1.710 | 0.000 | 0: 1.710 | 0: 1.710 |
| insert | random | A | scaleDown | 25,000 | 482,147 | 2.074 | 2.074 | 2.074 | 0.000 | 0: 2.074 | 0: 2.074 |
| insert | random | A | fullLifecycle | 50,000 | 528,580 | 1.892 | 1.892 | 1.892 | 0.000 | 0: 1.892 | 0: 1.892 |
| insert | tail | A | scaleUp | 12,500 | 1,353,385 | 0.739 | 0.739 | 0.739 | 0.000 | 0: 0.739 | 0: 0.739 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,353,385 | 0.739 | 0.739 | 0.739 | 0.000 | 0: 0.739 | 0: 0.739 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 609,848 | 1.640 | 1.640 | 1.640 | 0.000 | 0: 1.640 | 0: 1.640 |
| remove | head | A | fullLifecycle | 12,500 | 609,848 | 1.640 | 1.640 | 1.640 | 0.000 | 0: 1.640 | 0: 1.640 |
| remove | random | A | scaleUp | 25,000 | 481,229 | 2.078 | 2.078 | 2.078 | 0.000 | 0: 2.078 | 0: 2.078 |
| remove | random | A | scaleDown | 25,000 | 418,465 | 2.390 | 2.390 | 2.390 | 0.000 | 0: 2.390 | 0: 2.390 |
| remove | random | A | fullLifecycle | 50,000 | 447,658 | 2.234 | 2.234 | 2.234 | 0.000 | 0: 2.234 | 0: 2.234 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 662,937 | 1.508 | 1.508 | 1.508 | 0.000 | 0: 1.508 | 0: 1.508 |
| remove | tail | A | fullLifecycle | 12,500 | 662,937 | 1.508 | 1.508 | 1.508 | 0.000 | 0: 1.508 | 0: 1.508 |
| replace | head | A | scaleUp | 25,000 | 449,542 | 2.224 | 2.224 | 2.224 | 0.000 | 0: 2.224 | 0: 2.224 |
| replace | head | A | scaleDown | 25,000 | 410,067 | 2.439 | 2.439 | 2.439 | 0.000 | 0: 2.439 | 0: 2.439 |
| replace | head | A | fullLifecycle | 50,000 | 428,898 | 2.332 | 2.332 | 2.332 | 0.000 | 0: 2.332 | 0: 2.332 |
| replace | random | A | scaleUp | 25,000 | 337,972 | 2.959 | 2.959 | 2.959 | 0.000 | 0: 2.959 | 0: 2.959 |
| replace | random | A | scaleDown | 25,000 | 322,398 | 3.102 | 3.102 | 3.102 | 0.000 | 0: 3.102 | 0: 3.102 |
| replace | random | A | fullLifecycle | 50,000 | 330,001 | 3.030 | 3.030 | 3.030 | 0.000 | 0: 3.030 | 0: 3.030 |
| replace | tail | A | scaleUp | 25,000 | 496,104 | 2.016 | 2.016 | 2.016 | 0.000 | 0: 2.016 | 0: 2.016 |
| replace | tail | A | scaleDown | 25,000 | 158,024 | 6.328 | 6.328 | 6.328 | 0.000 | 0: 6.328 | 0: 6.328 |
| replace | tail | A | fullLifecycle | 50,000 | 239,697 | 4.172 | 4.172 | 4.172 | 0.000 | 0: 4.172 | 0: 4.172 |
| sequence | — | A | scaleUp | 6 | 75 | 13269.917 | 13269.917 | 13269.917 | 0.000 | 0: 13269.917 | 0: 13269.917 |
| sequence | — | A | scaleDown | 6 | 58 | 17152.067 | 17152.067 | 17152.067 | 0.000 | 0: 17152.067 | 0: 17152.067 |
| sequence | — | A | fullLifecycle | 12 | 66 | 15210.992 | 15210.992 | 15210.992 | 0.000 | 0: 15210.992 | 0: 15210.992 |
| value | head | A | scaleUp | 25,000 | 3,327,743 | 0.301 | 0.301 | 0.301 | 0.000 | 0: 0.301 | 0: 0.301 |
| value | head | A | scaleDown | 25,000 | 2,142,355 | 0.467 | 0.467 | 0.467 | 0.000 | 0: 0.467 | 0: 0.467 |
| value | head | A | fullLifecycle | 50,000 | 2,606,610 | 0.384 | 0.384 | 0.384 | 0.000 | 0: 0.384 | 0: 0.384 |
| value | random | A | scaleUp | 25,000 | 923,058 | 1.083 | 1.083 | 1.083 | 0.000 | 0: 1.083 | 0: 1.083 |
| value | random | A | scaleDown | 25,000 | 765,451 | 1.306 | 1.306 | 1.306 | 0.000 | 0: 1.306 | 0: 1.306 |
| value | random | A | fullLifecycle | 50,000 | 836,899 | 1.195 | 1.195 | 1.195 | 0.000 | 0: 1.195 | 0: 1.195 |
| value | tail | A | scaleUp | 25,000 | 6,527,074 | 0.153 | 0.153 | 0.153 | 0.000 | 0: 0.153 | 0: 0.153 |
| value | tail | A | scaleDown | 25,000 | 3,659,143 | 0.273 | 0.273 | 0.273 | 0.000 | 0: 0.273 | 0: 0.273 |
| value | tail | A | fullLifecycle | 50,000 | 4,689,376 | 0.213 | 0.213 | 0.213 | 0.000 | 0: 0.213 | 0: 0.213 |
| values | — | A | scaleUp | 6 | 105 | 9486.517 | 9486.517 | 9486.517 | 0.000 | 0: 9486.517 | 0: 9486.517 |
| values | — | A | scaleDown | 6 | 185 | 5405.867 | 5405.867 | 5405.867 | 0.000 | 0: 5405.867 | 0: 5405.867 |
| values | — | A | fullLifecycle | 12 | 134 | 7446.192 | 7446.192 | 7446.192 | 0.000 | 0: 7446.192 | 0: 7446.192 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5448434.000 | 430.140 | 8.475 |
| A | scaleDown | 5 | 4404655.200 | 431.829 | 8.549 |
| A | fullLifecycle | 11 | 4973989.091 | 430.818 | 8.505 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3135629.000 | 247.550 | 4.877 |
| A | scaleDown | 5 | 2594145.800 | 254.328 | 5.035 |
| A | fullLifecycle | 11 | 2889500.273 | 250.272 | 4.940 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 236,787 | 4.223 | 1.900 | 301.700 |
| apply | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 308,066 | 3.246 | 1.600 | 301.700 |
| apply | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 294,494 | 3.396 | 1.500 | 1122.800 |
| apply | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 308,486 | 3.242 | 1.500 | 1122.800 |
| apply | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 316,555 | 3.159 | 1.500 | 1122.800 |
| apply | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 321,324 | 3.112 | 1.500 | 1122.800 |
| apply | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 323,210 | 3.094 | 1.500 | 1122.800 |
| apply | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 325,305 | 3.074 | 1.500 | 1122.800 |
| apply | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 320,931 | 3.116 | 1.500 | 1122.800 |
| apply | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 307,460 | 3.252 | 1.500 | 1122.800 |
| apply | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 300,093 | 3.332 | 1.500 | 1122.800 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 301,643 | 3.315 | 1.500 | 1122.800 |
| insert | head | 0 | up | 1,000 | 49,966 | A | 500 | 860,585 | 1.162 | 0.400 | 71.700 |
| insert | head | 0 | up | 5,000 | 254,523 | A | 2,500 | 1,112,793 | 0.899 | 0.400 | 71.700 |
| insert | head | 0 | up | 10,000 | 509,098 | A | 5,000 | 1,185,902 | 0.843 | 0.300 | 71.700 |
| insert | head | 0 | up | 15,000 | 765,837 | A | 7,500 | 1,251,544 | 0.799 | 0.300 | 71.700 |
| insert | head | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 1,282,874 | 0.779 | 0.300 | 71.700 |
| insert | head | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 1,305,551 | 0.766 | 0.300 | 71.700 |
| insert | head | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 1,305,551 | 0.766 | 0.300 | 71.700 |
| insert | head | 0 | down | 15,000 | 757,461 | A | 12,500 | 1,305,551 | 0.766 | 0.300 | 71.700 |
| insert | head | 0 | down | 10,000 | 505,565 | A | 12,500 | 1,305,551 | 0.766 | 0.300 | 71.700 |
| insert | head | 0 | down | 5,000 | 249,719 | A | 12,500 | 1,305,551 | 0.766 | 0.300 | 71.700 |
| insert | head | 0 | down | 1,000 | 50,567 | A | 12,500 | 1,305,551 | 0.766 | 0.300 | 71.700 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,305,551 | 0.766 | 0.300 | 71.700 |
| insert | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 478,080 | 2.092 | 0.500 | 341.200 |
| insert | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 578,396 | 1.729 | 0.500 | 466.200 |
| insert | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 572,682 | 1.746 | 0.500 | 466.200 |
| insert | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 583,753 | 1.713 | 0.500 | 466.200 |
| insert | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 580,592 | 1.722 | 0.500 | 670.500 |
| insert | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 584,910 | 1.710 | 0.500 | 670.500 |
| insert | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 577,700 | 1.731 | 0.500 | 670.500 |
| insert | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 575,404 | 1.738 | 0.500 | 670.500 |
| insert | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 564,219 | 1.772 | 0.500 | 1088.000 |
| insert | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 537,656 | 1.860 | 0.500 | 1088.000 |
| insert | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 524,425 | 1.907 | 0.500 | 1088.000 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 528,580 | 1.892 | 0.500 | 1088.000 |
| insert | tail | 0 | up | 1,000 | 49,966 | A | 500 | 1,035,626 | 0.966 | 0.300 | 53.200 |
| insert | tail | 0 | up | 5,000 | 254,523 | A | 2,500 | 1,228,743 | 0.814 | 0.300 | 91.200 |
| insert | tail | 0 | up | 10,000 | 509,098 | A | 5,000 | 1,268,199 | 0.789 | 0.300 | 146.200 |
| insert | tail | 0 | up | 15,000 | 765,837 | A | 7,500 | 1,301,315 | 0.768 | 0.300 | 209.400 |
| insert | tail | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 1,361,878 | 0.734 | 0.300 | 209.400 |
| insert | tail | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 1,353,385 | 0.739 | 0.300 | 320.800 |
| insert | tail | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 1,353,385 | 0.739 | 0.300 | 320.800 |
| insert | tail | 0 | down | 15,000 | 757,461 | A | 12,500 | 1,353,385 | 0.739 | 0.300 | 320.800 |
| insert | tail | 0 | down | 10,000 | 505,565 | A | 12,500 | 1,353,385 | 0.739 | 0.300 | 320.800 |
| insert | tail | 0 | down | 5,000 | 249,719 | A | 12,500 | 1,353,385 | 0.739 | 0.300 | 320.800 |
| insert | tail | 0 | down | 1,000 | 50,567 | A | 12,500 | 1,353,385 | 0.739 | 0.300 | 320.800 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,353,385 | 0.739 | 0.300 | 320.800 |
| remove | head | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 721,792 | 1.385 | 0.900 | 35.400 |
| remove | head | 0 | down | 15,000 | 757,461 | A | 5,000 | 734,322 | 1.362 | 0.800 | 35.400 |
| remove | head | 0 | down | 10,000 | 505,565 | A | 7,500 | 672,145 | 1.488 | 0.800 | 622.200 |
| remove | head | 0 | down | 5,000 | 249,719 | A | 10,000 | 635,498 | 1.574 | 0.800 | 622.200 |
| remove | head | 0 | down | 1,000 | 50,567 | A | 12,000 | 604,437 | 1.654 | 0.800 | 622.200 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 609,848 | 1.640 | 0.800 | 622.200 |
| remove | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 424,160 | 2.358 | 0.900 | 274.300 |
| remove | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 499,401 | 2.002 | 0.900 | 274.300 |
| remove | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 442,180 | 2.262 | 0.900 | 1173.500 |
| remove | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 464,573 | 2.153 | 0.900 | 1173.500 |
| remove | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 471,471 | 2.121 | 0.900 | 1173.500 |
| remove | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 481,229 | 2.078 | 0.900 | 1173.500 |
| remove | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 482,186 | 2.074 | 0.900 | 1173.500 |
| remove | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 483,325 | 2.069 | 0.900 | 1173.500 |
| remove | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 478,189 | 2.091 | 0.900 | 1173.500 |
| remove | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 458,377 | 2.182 | 0.900 | 1173.500 |
| remove | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 444,341 | 2.251 | 0.900 | 1173.500 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 447,658 | 2.234 | 0.800 | 1173.500 |
| remove | tail | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 785,818 | 1.273 | 0.800 | 39.400 |
| remove | tail | 0 | down | 15,000 | 757,461 | A | 5,000 | 803,936 | 1.244 | 0.800 | 39.400 |
| remove | tail | 0 | down | 10,000 | 505,565 | A | 7,500 | 779,310 | 1.283 | 0.700 | 48.800 |
| remove | tail | 0 | down | 5,000 | 249,719 | A | 10,000 | 693,030 | 1.443 | 0.700 | 476.800 |
| remove | tail | 0 | down | 1,000 | 50,567 | A | 12,000 | 656,685 | 1.523 | 0.700 | 476.800 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 662,937 | 1.508 | 0.700 | 476.800 |
| replace | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 396,181 | 2.524 | 1.200 | 79.000 |
| replace | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 478,611 | 2.089 | 1.200 | 192.200 |
| replace | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 506,024 | 1.976 | 1.000 | 192.200 |
| replace | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 456,308 | 2.192 | 1.000 | 4046.600 |
| replace | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 463,540 | 2.157 | 1.000 | 4046.600 |
| replace | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 449,542 | 2.224 | 1.000 | 4046.600 |
| replace | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 458,418 | 2.181 | 1.000 | 4046.600 |
| replace | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 453,522 | 2.205 | 1.000 | 4046.600 |
| replace | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 452,284 | 2.211 | 1.000 | 4046.600 |
| replace | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 436,476 | 2.291 | 1.000 | 4046.600 |
| replace | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 426,956 | 2.342 | 1.000 | 4046.600 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 428,898 | 2.332 | 1.000 | 4046.600 |
| replace | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 343,442 | 2.912 | 1.100 | 158.800 |
| replace | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 329,761 | 3.033 | 1.100 | 1014.100 |
| replace | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 337,499 | 2.963 | 1.100 | 1014.100 |
| replace | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 341,218 | 2.931 | 1.100 | 1014.100 |
| replace | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 331,767 | 3.014 | 1.100 | 2878.300 |
| replace | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 337,972 | 2.959 | 1.100 | 2878.300 |
| replace | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 342,129 | 2.923 | 1.100 | 2878.300 |
| replace | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 344,605 | 2.902 | 1.100 | 2878.300 |
| replace | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 345,392 | 2.895 | 1.100 | 2878.300 |
| replace | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 333,681 | 2.997 | 1.100 | 2878.300 |
| replace | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 327,612 | 3.052 | 1.100 | 2878.300 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 330,001 | 3.030 | 1.100 | 2878.300 |
| replace | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 376,832 | 2.654 | 1.100 | 190.900 |
| replace | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 481,371 | 2.077 | 1.100 | 190.900 |
| replace | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 498,130 | 2.008 | 1.000 | 190.900 |
| replace | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 507,250 | 1.971 | 1.000 | 605.000 |
| replace | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 508,911 | 1.965 | 1.000 | 605.000 |
| replace | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 496,104 | 2.016 | 1.000 | 1617.900 |
| replace | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 438,695 | 2.279 | 1.000 | 1617.900 |
| replace | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 282,850 | 3.535 | 1.000 | 1617.900 |
| replace | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 288,284 | 3.469 | 1.000 | 1617.900 |
| replace | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 244,114 | 4.096 | 1.000 | 1617.900 |
| replace | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 237,088 | 4.218 | 1.000 | 1617.900 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 239,697 | 4.172 | 1.000 | 1617.900 |
| value | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 1,366,494 | 0.732 | 0.100 | 354.000 |
| value | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 2,480,036 | 0.403 | 0.100 | 354.000 |
| value | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 2,860,657 | 0.350 | 0.100 | 354.000 |
| value | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 3,102,250 | 0.322 | 0.100 | 354.000 |
| value | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 3,236,927 | 0.309 | 0.100 | 354.000 |
| value | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 3,327,743 | 0.301 | 0.100 | 354.000 |
| value | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 3,156,101 | 0.317 | 0.100 | 354.000 |
| value | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 3,046,233 | 0.328 | 0.100 | 354.000 |
| value | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 2,906,238 | 0.344 | 0.100 | 354.000 |
| value | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 2,743,902 | 0.364 | 0.100 | 354.000 |
| value | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 2,606,882 | 0.384 | 0.100 | 354.000 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,606,610 | 0.384 | 0.100 | 354.000 |
| value | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 1,308,729 | 0.764 | 0.100 | 31.300 |
| value | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 1,063,558 | 0.940 | 0.100 | 31.300 |
| value | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 937,102 | 1.067 | 0.100 | 31.700 |
| value | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 922,430 | 1.084 | 0.100 | 41.600 |
| value | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 928,091 | 1.077 | 0.100 | 43.400 |
| value | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 923,058 | 1.083 | 0.100 | 43.800 |
| value | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 918,591 | 1.089 | 0.100 | 78.700 |
| value | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 910,683 | 1.098 | 0.100 | 78.700 |
| value | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 901,337 | 1.109 | 0.100 | 78.700 |
| value | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 851,272 | 1.175 | 0.100 | 78.700 |
| value | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 829,801 | 1.205 | 0.100 | 78.700 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 836,899 | 1.195 | 0.100 | 78.700 |
| value | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 5,070,994 | 0.197 | 0.100 | 9.500 |
| value | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 5,580,980 | 0.179 | 0.100 | 9.500 |
| value | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 5,713,959 | 0.175 | 0.100 | 32.100 |
| value | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 6,123,449 | 0.163 | 0.000 | 32.100 |
| value | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 6,338,542 | 0.158 | 0.000 | 32.100 |
| value | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 6,527,074 | 0.153 | 0.000 | 32.100 |
| value | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 5,981,457 | 0.167 | 0.000 | 32.100 |
| value | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 5,687,912 | 0.176 | 0.000 | 32.100 |
| value | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 5,379,887 | 0.186 | 0.000 | 32.100 |
| value | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 4,977,160 | 0.201 | 0.000 | 45.300 |
| value | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 4,689,489 | 0.213 | 0.000 | 51.200 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 4,689,376 | 0.213 | 0.000 | 51.200 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,571 | 389.000 |
| create | — | 0 | up | 5,000 | A | 1 | 800 | 1250.700 |
| create | — | 0 | up | 10,000 | A | 1 | 640 | 1563.500 |
| create | — | 0 | up | 15,000 | A | 1 | 437 | 2287.500 |
| create | — | 0 | up | 20,000 | A | 1 | 303 | 3303.400 |
| create | — | 0 | up | 25,000 | A | 1 | 256 | 3908.200 |
| create | — | 0 | down | 20,000 | A | 1 | 279 | 3589.900 |
| create | — | 0 | down | 15,000 | A | 1 | 386 | 2590.100 |
| create | — | 0 | down | 10,000 | A | 1 | 284 | 3521.500 |
| create | — | 0 | down | 5,000 | A | 1 | 928 | 1077.100 |
| create | — | 0 | down | 1,000 | A | 1 | 4,876 | 205.100 |
| create | — | 0 | down | 0 | A | 1 | 65,359 | 15.300 |
| sequence | — | 0 | up | 1,000 | A | 1 | 385 | 2594.800 |
| sequence | — | 0 | up | 5,000 | A | 1 | 129 | 7753.800 |
| sequence | — | 0 | up | 10,000 | A | 1 | 81 | 12272.400 |
| sequence | — | 0 | up | 15,000 | A | 1 | 67 | 14947.500 |
| sequence | — | 0 | up | 20,000 | A | 1 | 51 | 19570.100 |
| sequence | — | 0 | up | 25,000 | A | 1 | 44 | 22480.900 |
| sequence | — | 0 | down | 20,000 | A | 1 | 48 | 20641.800 |
| sequence | — | 0 | down | 15,000 | A | 1 | 66 | 15179.500 |
| sequence | — | 0 | down | 10,000 | A | 1 | 26 | 38018.300 |
| sequence | — | 0 | down | 5,000 | A | 1 | 49 | 20263.000 |
| sequence | — | 0 | down | 1,000 | A | 1 | 136 | 7346.300 |
| sequence | — | 0 | down | 0 | A | 1 | 683 | 1463.500 |
| values | — | 0 | up | 1,000 | A | 1 | 561 | 1781.100 |
| values | — | 0 | up | 5,000 | A | 1 | 228 | 4378.700 |
| values | — | 0 | up | 10,000 | A | 1 | 49 | 20496.200 |
| values | — | 0 | up | 15,000 | A | 1 | 120 | 8310.500 |
| values | — | 0 | up | 20,000 | A | 1 | 97 | 10310.200 |
| values | — | 0 | up | 25,000 | A | 1 | 86 | 11642.400 |
| values | — | 0 | down | 20,000 | A | 1 | 109 | 9180.700 |
| values | — | 0 | down | 15,000 | A | 1 | 152 | 6595.400 |
| values | — | 0 | down | 10,000 | A | 1 | 111 | 8990.900 |
| values | — | 0 | down | 5,000 | A | 1 | 141 | 7089.500 |
| values | — | 0 | down | 1,000 | A | 1 | 1,759 | 568.400 |
| values | — | 0 | down | 0 | A | 1 | 97,087 | 10.300 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.613 | 0.232 | 0.381 |
| 0 | up | 5000 | 3.108 | 1.167 | 1.942 |
| 0 | up | 10000 | 6.228 | 2.343 | 3.884 |
| 0 | up | 15000 | 9.486 | 3.643 | 5.843 |
| 0 | up | 20000 | 12.852 | 5.113 | 7.739 |
| 0 | up | 25000 | 16.278 | 6.637 | 9.641 |
| 0 | down | 20000 | 13.340 | 5.613 | 7.727 |
| 0 | down | 15000 | 9.910 | 4.131 | 5.779 |
| 0 | down | 10000 | 7.153 | 3.295 | 3.857 |
| 0 | down | 5000 | 4.067 | 2.161 | 1.905 |
| 0 | down | 1000 | 1.807 | 1.421 | 0.386 |
| 0 | down | 0 | 1.231 | 1.231 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 49,966 | 0.402 | 421.140 | 8.429 | 121.430 | 15.526 |
| 0 | up | A | 5,000 | 5,000 | 254,523 | 2.043 | 428.454 | 8.417 | 155.715 | 19.627 |
| 0 | up | A | 10,000 | 10,000 | 509,098 | 4.098 | 429.682 | 8.440 | 194.879 | 24.538 |
| 0 | up | A | 15,000 | 15,000 | 765,837 | 6.183 | 432.249 | 8.466 | 209.328 | 29.445 |
| 0 | up | A | 20,000 | 20,000 | 1,014,350 | 8.209 | 430.368 | 8.486 | 279.805 | 34.235 |
| 0 | up | A | 25,000 | 25,000 | 1,263,607 | 10.242 | 429.572 | 8.499 | 294.465 | 39.003 |
| 0 | down | A | 20,000 | 20,000 | 1,012,792 | 8.267 | 433.443 | 8.559 | 297.918 | 34.238 |
| 0 | down | A | 15,000 | 15,000 | 757,461 | 6.185 | 432.337 | 8.562 | 301.574 | 29.392 |
| 0 | down | A | 10,000 | 10,000 | 505,565 | 4.118 | 431.804 | 8.541 | 300.625 | 24.617 |
| 0 | down | A | 5,000 | 5,000 | 249,719 | 2.025 | 424.661 | 8.503 | 298.566 | 19.781 |
| 0 | down | A | 1,000 | 1,000 | 50,567 | 0.408 | 428.020 | 8.464 | 296.723 | 15.985 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 297.664 | 14.908 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 49966 | 184228 | 184.228 | 3.687 | 271.76 | 14.53 | 161.92 | 12.35 |
| 0 | up | A | 5000 | 254523 | 1210131 | 242.026 | 4.755 | 1634.13 | 73.21 | 825.25 | 61.48 |
| 0 | up | A | 10000 | 509098 | 2448079 | 244.808 | 4.809 | 3283.48 | 149.01 | 1658.86 | 124.83 |
| 0 | up | A | 15000 | 765837 | 3734371 | 248.958 | 4.876 | 4974.88 | 226.26 | 3590.17 | 200.09 |
| 0 | up | A | 20000 | 1014350 | 4987172 | 249.359 | 4.917 | 7129.39 | 311.11 | 5143.68 | 263.60 |
| 0 | up | A | 25000 | 1263607 | 6249793 | 249.992 | 4.946 | 9254.82 | 392.21 | 6545.54 | 334.80 |
| 0 | down | A | 20000 | 1012792 | 5129580 | 256.479 | 5.065 | 7576.63 | 326.54 | 5319.60 | 278.20 |
| 0 | down | A | 15000 | 757461 | 3834350 | 255.623 | 5.062 | 5712.74 | 247.20 | 3993.54 | 209.87 |
| 0 | down | A | 10000 | 505565 | 2537356 | 253.736 | 5.019 | 3822.17 | 165.03 | 2665.76 | 139.77 |
| 0 | down | A | 5000 | 249719 | 1229097 | 245.819 | 4.922 | 1877.54 | 79.58 | 1312.05 | 67.88 |
| 0 | down | A | 1000 | 50567 | 240346 | 240.346 | 4.753 | 377.29 | 15.97 | 264.47 | 13.64 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 430.140 | 8.475 | 247.550 | 4.877 |
| 0 | A | scaleDown | 431.829 | 8.549 | 254.328 | 5.035 |
| 0 | A | fullLifecycle | 430.818 | 8.505 | 250.272 | 4.940 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
