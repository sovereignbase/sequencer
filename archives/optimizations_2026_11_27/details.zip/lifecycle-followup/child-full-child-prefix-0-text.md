# Large string benchmarks

2026-11-27T17:22:27.981Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2366.88 | 0.00 |
| 1024 | insert.append | array | 13389.03 | 0.00 |
| 1024 | replace | array | 3362.22 | 0.00 |
| 1024 | remove | array | 1198.51 | 0.00 |
| 1024 | remove.middle | array | 2088.72 | 0.00 |
| 1024 | replace.middle | array | 2531.87 | 0.00 |
| 1024 | apply | array | 771.98 | 0.00 |
| 1024 | apply.array | array | 594.90 | 0.00 |
| 1024 | concurrent.apply | array | 66969.25 | 0.00 |
| 1024 | merge | array | 3043.30 | 0.00 |
| 1024 | create | array | 3013.71 | 0.00 |
| 1024 | value.random | array | 66.74 | 0.00 |
| 1024 | values.range | array | 129.32 | 0.00 |
| 1024 | values.array | array | 1464.44 | 0.00 |
| 1024 | values.text | array | 14217.45 | 0.00 |
| 1024 | sequence.array | array | 2155.76 | 0.00 |
| 1024 | sequence.text | array | 10081.40 | 0.00 |
| 1024 | sequence.edited.text | array | 15103.14 | 0.00 |
| 1024 | sequence.masked.text | array | 11543.48 | 0.00 |
| 1024 | insert | string | 449.93 | 0.00 |
| 1024 | insert.append | string | 3974.86 | 0.00 |
| 1024 | replace | string | 1337.88 | 0.00 |
| 1024 | remove | string | 1060.71 | 0.00 |
| 1024 | remove.middle | string | 1080.41 | 0.00 |
| 1024 | replace.middle | string | 1507.74 | 0.00 |
| 1024 | apply | string | 729.96 | 0.00 |
| 1024 | apply.array | string | 2426.07 | 0.00 |
| 1024 | concurrent.apply | string | 4062.01 | 0.00 |
| 1024 | merge | string | 1684.13 | 0.00 |
| 1024 | create | string | 978.16 | 0.00 |
| 1024 | value.random | string | 54.45 | 0.00 |
| 1024 | values.range | string | 148.48 | 0.00 |
| 1024 | values.array | string | 1771.43 | 0.00 |
| 1024 | values.text | string | 69.12 | 0.00 |
| 1024 | sequence.array | string | 1924.03 | 0.00 |
| 1024 | sequence.text | string | 196.71 | 0.00 |
| 1024 | sequence.edited.text | string | 2177.35 | 0.00 |
| 1024 | sequence.masked.text | string | 3597.26 | 0.00 |
| 65536 | insert | array | 248993.07 | 0.00 |
| 65536 | insert.append | array | 1049545.83 | 0.00 |
| 65536 | replace | array | 278004.44 | 0.00 |
| 65536 | remove | array | 2656.68 | 0.00 |
| 65536 | remove.middle | array | 233682.57 | 0.00 |
| 65536 | replace.middle | array | 230882.57 | 0.00 |
| 65536 | apply | array | 1256.09 | 0.00 |
| 65536 | apply.array | array | 673.28 | 0.00 |
| 65536 | concurrent.apply | array | 4329850.00 | 0.00 |
| 65536 | merge | array | 208753.33 | 0.00 |
| 65536 | create | array | 250752.00 | 0.00 |
| 65536 | value.random | array | 62.37 | 0.00 |
| 65536 | values.range | array | 140.05 | 0.00 |
| 65536 | values.array | array | 202428.57 | 0.00 |
| 65536 | values.text | array | 807154.84 | 0.00 |
| 65536 | sequence.array | array | 205085.71 | 0.00 |
| 65536 | sequence.text | array | 728634.29 | 0.00 |
| 65536 | sequence.edited.text | array | 897303.57 | 0.00 |
| 65536 | sequence.masked.text | array | 772133.33 | 0.00 |
| 65536 | insert | string | 350.05 | 0.00 |
| 65536 | insert.append | string | 21590.67 | 0.00 |
| 65536 | replace | string | 1383.47 | 0.00 |
| 65536 | remove | string | 958.53 | 0.00 |
| 65536 | remove.middle | string | 928.91 | 0.00 |
| 65536 | replace.middle | string | 1280.22 | 0.00 |
| 65536 | apply | string | 895.09 | 0.00 |
| 65536 | apply.array | string | 256859.37 | 0.00 |
| 65536 | concurrent.apply | string | 154975.31 | 0.00 |
| 65536 | merge | string | 1158.37 | 0.00 |
| 65536 | create | string | 964.92 | 0.00 |
| 65536 | value.random | string | 56.34 | 0.00 |
| 65536 | values.range | string | 157.66 | 0.00 |
| 65536 | values.array | string | 257300.78 | 0.00 |
| 65536 | values.text | string | 89.99 | 0.00 |
| 65536 | sequence.array | string | 263398.44 | 0.00 |
| 65536 | sequence.text | string | 223.49 | 0.00 |
| 65536 | sequence.edited.text | string | 92653.70 | 0.00 |
| 65536 | sequence.masked.text | string | 3587.87 | 0.00 |
| 1048576 | insert | array | 3367037.50 | 0.00 |
| 1048576 | insert.append | array | 20486550.00 | 0.00 |
| 1048576 | replace | array | 4189866.67 | 0.00 |
| 1048576 | remove | array | 11422.43 | 0.00 |
| 1048576 | remove.middle | array | 3098800.00 | 0.00 |
| 1048576 | replace.middle | array | 2711270.00 | 0.00 |
| 1048576 | apply | array | 1200.21 | 0.00 |
| 1048576 | apply.array | array | 578.33 | 0.00 |
| 1048576 | concurrent.apply | array | 64238800.00 | 0.00 |
| 1048576 | merge | array | 3368937.50 | 0.00 |
| 1048576 | create | array | 3250762.50 | 0.00 |
| 1048576 | value.random | array | 81.18 | 0.00 |
| 1048576 | values.range | array | 102.10 | 0.00 |
| 1048576 | values.array | array | 2502870.00 | 0.00 |
| 1048576 | values.text | array | 13008950.00 | 0.00 |
| 1048576 | sequence.array | array | 2382000.00 | 0.00 |
| 1048576 | sequence.text | array | 60179650.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 49614100.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 46785350.00 | 0.00 |
| 1048576 | insert | string | 412.56 | 0.00 |
| 1048576 | insert.append | string | 589176.74 | 0.00 |
| 1048576 | replace | string | 1725.42 | 0.00 |
| 1048576 | remove | string | 1082.56 | 0.00 |
| 1048576 | remove.middle | string | 1206.93 | 0.00 |
| 1048576 | replace.middle | string | 1326.25 | 0.00 |
| 1048576 | apply | string | 1014.16 | 0.00 |
| 1048576 | apply.array | string | 3569112.50 | 0.00 |
| 1048576 | concurrent.apply | string | 1361094.74 | 0.00 |
| 1048576 | merge | string | 1231.91 | 0.00 |
| 1048576 | create | string | 959.05 | 0.00 |
| 1048576 | value.random | string | 54.54 | 0.00 |
| 1048576 | values.range | string | 158.55 | 0.00 |
| 1048576 | values.array | string | 3309312.50 | 0.00 |
| 1048576 | values.text | string | 67.76 | 0.00 |
| 1048576 | sequence.array | string | 3355962.50 | 0.00 |
| 1048576 | sequence.text | string | 183.32 | 0.00 |
| 1048576 | sequence.edited.text | string | 1414655.56 | 0.00 |
| 1048576 | sequence.masked.text | string | 3284.13 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
