# Tuple benchmarks

2026-11-27T17:22:13.720Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 3,128,141 | 2,469,029 | 0.79× |
| 2 | create.sequence | 937,414 | 794,392 | 0.85× |
| 2 | replace.random | 1,203,370 | 1,289,645 | 1.07× |
| 2 | apply.replace | 649,644 | 837,150 | 1.29× |
| 2 | apply.duplicate | 1,591,047 | 1,546,278 | 0.97× |
| 2 | merge.duplicate | 1,417,898 | 1,385,094 | 0.98× |
| 2 | length | 131,040,396 | 119,268,089 | 0.91× |
| 2 | value.random | 33,264,407 | 48,809,881 | 1.47× |
| 2 | values | 12,796,434 | 12,807,495 | 1.00× |
| 2 | sequence | 3,000,293 | 2,700,854 | 0.90× |
| 4 | create.empty | 2,371,804 | 2,194,652 | 0.93× |
| 4 | create.sequence | 691,040 | 706,623 | 1.02× |
| 4 | replace.random | 995,414 | 1,510,923 | 1.52× |
| 4 | apply.replace | 646,078 | 937,937 | 1.45× |
| 4 | apply.duplicate | 1,708,294 | 1,619,446 | 0.95× |
| 4 | merge.duplicate | 1,165,004 | 1,256,524 | 1.08× |
| 4 | length | 36,604,622 | 37,521,040 | 1.03× |
| 4 | value.random | 19,421,275 | 54,408,761 | 2.80× |
| 4 | values | 6,679,673 | 7,099,056 | 1.06× |
| 4 | sequence | 2,420,470 | 2,558,106 | 1.06× |
| 8 | create.empty | 2,498,010 | 2,258,699 | 0.90× |
| 8 | create.sequence | 437,297 | 536,164 | 1.23× |
| 8 | replace.random | 1,054,832 | 1,540,042 | 1.46× |
| 8 | apply.replace | 644,775 | 1,019,060 | 1.58× |
| 8 | apply.duplicate | 1,710,617 | 1,694,493 | 0.99× |
| 8 | merge.duplicate | 933,409 | 894,861 | 0.96× |
| 8 | length | 38,726,223 | 37,949,644 | 0.98× |
| 8 | value.random | 16,968,379 | 55,594,878 | 3.28× |
| 8 | values | 4,386,404 | 4,696,876 | 1.07× |
| 8 | sequence | 1,602,996 | 1,999,301 | 1.25× |
| 100 | create.empty | 2,327,356 | 2,020,557 | 0.87× |
| 100 | create.sequence | 68,143 | 85,498 | 1.25× |
| 100 | replace.random | 422,790 | 1,503,227 | 3.56× |
| 100 | apply.replace | 629,111 | 1,008,980 | 1.60× |
| 100 | apply.duplicate | 1,557,346 | 1,688,051 | 1.08× |
| 100 | merge.duplicate | 106,383 | 70,531 | 0.66× |
| 100 | length | 36,510,960 | 39,939,514 | 1.09× |
| 100 | value.random | 13,004,516 | 51,896,549 | 3.99× |
| 100 | values | 524,916 | 669,831 | 1.28× |
| 100 | sequence | 185,220 | 190,831 | 1.03× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
