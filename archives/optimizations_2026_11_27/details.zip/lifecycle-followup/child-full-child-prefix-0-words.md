# Words benchmarks

2026-11-27T17:22:49.680Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 29,506 | 143,158 | 267 |
| append | packed | 5.90 | 3.61 | 13.98 | 27,116 | 160,453 | 333 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,675 | 746 | 193 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 27,819 | 1,574 | 247 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 447 | 246 | 87 |
| random | packed | 49.58 | 35.38 | 23.45 | 13,983 | 504 | 120 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 626 | 188 | 91 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 15,354 | 423 | 137 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 648.43 | 0.00 |
| append | numeric | encode | 33891.55 | 0.00 |
| append | numeric | decode | 2965.59 | 0.00 |
| append | numeric | create | 1787.45 | 0.00 |
| append | numeric | load | 6985.28 | 0.00 |
| append | numeric | apply | 2537450.00 | 0.00 |
| append | numeric | receive | 3741685.71 | 0.00 |
| append | binary | sequence | 617.00 | 0.00 |
| append | binary | encode | 36878.24 | 0.00 |
| append | binary | decode | 1817.86 | 0.00 |
| append | binary | create | 2411.98 | 0.00 |
| append | binary | load | 6232.36 | 0.00 |
| append | binary | apply | 2067224.00 | 0.00 |
| append | binary | receive | 3007376.47 | 0.00 |
| prepend | numeric | sequence | 500013.00 | 0.00 |
| prepend | numeric | encode | 596955.95 | 0.00 |
| prepend | numeric | decode | 194907.36 | 0.00 |
| prepend | numeric | create | 605415.66 | 0.00 |
| prepend | numeric | load | 1341255.26 | 0.00 |
| prepend | numeric | apply | 6928100.00 | 0.00 |
| prepend | numeric | receive | 5174590.00 | 0.00 |
| prepend | binary | sequence | 391225.00 | 0.00 |
| prepend | binary | encode | 35946.62 | 0.00 |
| prepend | binary | decode | 2651.17 | 0.00 |
| prepend | binary | create | 628890.00 | 0.00 |
| prepend | binary | load | 635239.24 | 0.00 |
| prepend | binary | apply | 2405033.33 | 0.00 |
| prepend | binary | receive | 4046815.38 | 0.00 |
| random | numeric | sequence | 1002548.00 | 0.00 |
| random | numeric | encode | 2234952.17 | 0.00 |
| random | numeric | decode | 1288753.85 | 0.00 |
| random | numeric | create | 1812628.57 | 0.00 |
| random | numeric | load | 4063246.15 | 0.00 |
| random | numeric | apply | 7550428.57 | 0.00 |
| random | numeric | receive | 11462180.00 | 0.00 |
| random | binary | sequence | 851986.44 | 0.00 |
| random | binary | encode | 71514.77 | 0.00 |
| random | binary | decode | 1950.15 | 0.00 |
| random | binary | create | 2027656.00 | 0.00 |
| random | binary | load | 1985096.15 | 0.00 |
| random | binary | apply | 6692737.50 | 0.00 |
| random | binary | receive | 8342400.00 | 0.00 |
| concurrent | numeric | sequence | 784437.50 | 0.00 |
| concurrent | numeric | encode | 1596968.75 | 0.00 |
| concurrent | numeric | decode | 785026.56 | 0.00 |
| concurrent | numeric | create | 2287240.91 | 0.00 |
| concurrent | numeric | load | 5311720.00 | 0.00 |
| concurrent | numeric | apply | 6110433.33 | 0.00 |
| concurrent | numeric | receive | 10980100.00 | 0.00 |
| concurrent | binary | sequence | 757256.72 | 0.00 |
| concurrent | binary | encode | 65127.86 | 0.00 |
| concurrent | binary | decode | 2831.49 | 0.00 |
| concurrent | binary | create | 2306159.09 | 0.00 |
| concurrent | binary | load | 2361481.82 | 0.00 |
| concurrent | binary | apply | 5287410.00 | 0.00 |
| concurrent | binary | receive | 7295171.43 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
