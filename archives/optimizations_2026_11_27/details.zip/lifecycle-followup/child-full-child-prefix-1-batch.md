# Batch benchmarks

2026-11-27T17:24:38.283Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 1,888,039 | 1,049,593 | 514,597 | 76.05 | 5.99 | 0.012 |
| append | batch | 2,456,902 | 244,897,959 | 199,335,548 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,617,992 | 1,536,807 | 834,411 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 1,796,192 | 1,915,954 | 1,734,906 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 1,056,729 | 1,060,558 | 837,989 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 1,244,374 | 1,554,324 | 1,440,853 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 1,058,108 | 1,113,730 | 834,771 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 1,076,735 | 1,796,999 | 1,556,743 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,260,041 | 944,674 | 821,715 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,264,849 | 1,647,356 | 1,519,295 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,322,372 | 1,334,015 | 889,488 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,028,745 | 1,671,915 | 1,572,121 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 708,818 | 976,221 | 699,346 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 1,047,038 | 1,226,304 | 1,161,676 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,173,697 | 1,500,338 | 974,145 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 1,229,987 | 1,790,003 | 1,452,749 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,118,464 | 1,363,698 | 886,093 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 1,216,829 | 1,702,490 | 1,485,958 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 752,063 | 909,911 | 692,521 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 909,353 | 1,146,975 | 1,172,849 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 3.178 | 0.000 |
| append | individual | apply | 5.716 | 0.000 |
| append | individual | receive | 11.660 | 0.000 |
| append | individual | encode | 6.621 | 0.000 |
| append | individual | decode | 7.606 | 0.000 |
| append | batch | author | 2.442 | 0.000 |
| append | batch | apply | 0.024 | 0.000 |
| append | batch | receive | 0.030 | 0.000 |
| append | batch | encode | 0.229 | 0.000 |
| append | batch | decode | 0.096 | 0.000 |
| prepend | individual | author | 3.708 | 0.000 |
| prepend | individual | apply | 3.904 | 0.000 |
| prepend | individual | receive | 7.191 | 0.000 |
| prepend | individual | encode | 5.702 | 0.000 |
| prepend | individual | decode | 8.291 | 0.000 |
| prepend | batch | author | 3.340 | 0.000 |
| prepend | batch | apply | 3.132 | 0.000 |
| prepend | batch | receive | 3.458 | 0.000 |
| prepend | batch | encode | 0.205 | 0.000 |
| prepend | batch | decode | 0.106 | 0.000 |
| random.characters | individual | author | 5.678 | 0.000 |
| random.characters | individual | apply | 5.657 | 0.000 |
| random.characters | individual | receive | 7.160 | 0.000 |
| random.characters | individual | encode | 5.349 | 0.000 |
| random.characters | individual | decode | 7.425 | 0.000 |
| random.characters | batch | author | 4.822 | 0.000 |
| random.characters | batch | apply | 3.860 | 0.000 |
| random.characters | batch | receive | 4.164 | 0.000 |
| random.characters | batch | encode | 0.193 | 0.000 |
| random.characters | batch | decode | 0.106 | 0.000 |
| random.words | individual | author | 5.671 | 0.000 |
| random.words | individual | apply | 5.387 | 0.000 |
| random.words | individual | receive | 7.188 | 0.000 |
| random.words | individual | encode | 5.067 | 0.000 |
| random.words | individual | decode | 8.568 | 0.000 |
| random.words | batch | author | 5.572 | 0.000 |
| random.words | batch | apply | 3.339 | 0.000 |
| random.words | batch | receive | 3.854 | 0.000 |
| random.words | batch | encode | 0.407 | 0.000 |
| random.words | batch | decode | 0.102 | 0.000 |
| concurrent.characters | individual | author | 9.524 | 0.000 |
| concurrent.characters | individual | apply | 12.703 | 0.000 |
| concurrent.characters | individual | receive | 14.604 | 0.000 |
| concurrent.characters | individual | encode | 8.011 | 0.000 |
| concurrent.characters | individual | decode | 10.921 | 0.000 |
| concurrent.characters | batch | author | 9.487 | 0.000 |
| concurrent.characters | batch | apply | 7.284 | 0.000 |
| concurrent.characters | batch | receive | 7.898 | 0.000 |
| concurrent.characters | batch | encode | 0.502 | 0.000 |
| concurrent.characters | batch | decode | 0.144 | 0.000 |
| concurrent.words | individual | author | 9.075 | 0.000 |
| concurrent.words | individual | apply | 8.995 | 0.000 |
| concurrent.words | individual | receive | 13.491 | 0.000 |
| concurrent.words | individual | encode | 8.242 | 0.000 |
| concurrent.words | individual | decode | 11.865 | 0.000 |
| concurrent.words | batch | author | 11.665 | 0.000 |
| concurrent.words | batch | apply | 7.177 | 0.000 |
| concurrent.words | batch | receive | 7.633 | 0.000 |
| concurrent.words | batch | encode | 0.784 | 0.000 |
| concurrent.words | batch | decode | 0.126 | 0.000 |
| concurrent.mixed | individual | author | 16.930 | 0.000 |
| concurrent.mixed | individual | apply | 12.292 | 0.000 |
| concurrent.mixed | individual | receive | 17.159 | 0.000 |
| concurrent.mixed | individual | encode | 8.112 | 0.000 |
| concurrent.mixed | individual | decode | 9.760 | 0.000 |
| concurrent.mixed | batch | author | 11.461 | 0.000 |
| concurrent.mixed | batch | apply | 9.785 | 0.000 |
| concurrent.mixed | batch | receive | 10.330 | 0.000 |
| concurrent.mixed | batch | encode | 0.795 | 0.000 |
| concurrent.mixed | batch | decode | 0.144 | 0.000 |
| causal.characters | individual | author | 10.224 | 0.000 |
| causal.characters | individual | apply | 7.998 | 0.000 |
| causal.characters | individual | receive | 12.319 | 0.000 |
| causal.characters | individual | encode | 7.044 | 0.000 |
| causal.characters | individual | decode | 10.160 | 0.000 |
| causal.characters | batch | author | 9.756 | 0.000 |
| causal.characters | batch | apply | 6.704 | 0.000 |
| causal.characters | batch | receive | 8.260 | 0.000 |
| causal.characters | batch | encode | 0.259 | 0.000 |
| causal.characters | batch | decode | 0.115 | 0.000 |
| causal.words | individual | author | 10.729 | 0.000 |
| causal.words | individual | apply | 8.800 | 0.000 |
| causal.words | individual | receive | 13.543 | 0.000 |
| causal.words | individual | encode | 9.350 | 0.000 |
| causal.words | individual | decode | 10.672 | 0.000 |
| causal.words | batch | author | 9.862 | 0.000 |
| causal.words | batch | apply | 7.048 | 0.000 |
| causal.words | batch | receive | 8.076 | 0.000 |
| causal.words | batch | encode | 0.673 | 0.000 |
| causal.words | batch | decode | 0.119 | 0.000 |
| causal.mixed | individual | author | 15.956 | 0.000 |
| causal.mixed | individual | apply | 13.188 | 0.000 |
| causal.mixed | individual | receive | 17.328 | 0.000 |
| causal.mixed | individual | encode | 9.020 | 0.000 |
| causal.mixed | individual | decode | 9.241 | 0.000 |
| causal.mixed | batch | author | 13.196 | 0.000 |
| causal.mixed | batch | apply | 10.462 | 0.000 |
| causal.mixed | batch | receive | 10.231 | 0.000 |
| causal.mixed | batch | encode | 0.442 | 0.000 |
| causal.mixed | batch | decode | 0.115 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
