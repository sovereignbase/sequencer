# Sequencer dynamic lifecycle benchmark

2026-11-27T17:23:07.249Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.44 | 163.09 | 56.54 |
| CommonJS | 199.62 | 164.71 | 56.75 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 305,188 | 3.277 | 3.277 | 3.277 | 0.000 | 0: 3.277 | 0: 3.277 |
| apply | random | A | scaleDown | 24,999 | 351,689 | 2.843 | 2.843 | 2.843 | 0.000 | 0: 2.843 | 0: 2.843 |
| apply | random | A | fullLifecycle | 49,999 | 326,792 | 3.060 | 3.060 | 3.060 | 0.000 | 0: 3.060 | 0: 3.060 |
| create | — | A | scaleUp | 7 | 516 | 1938.271 | 1938.271 | 1938.271 | 0.000 | 0: 1938.271 | 0: 1938.271 |
| create | — | A | scaleDown | 6 | 655 | 1526.433 | 1526.433 | 1526.433 | 0.000 | 0: 1526.433 | 0: 1526.433 |
| create | — | A | fullLifecycle | 13 | 572 | 1748.192 | 1748.192 | 1748.192 | 0.000 | 0: 1748.192 | 0: 1748.192 |
| insert | head | A | scaleUp | 12,500 | 1,309,380 | 0.764 | 0.764 | 0.764 | 0.000 | 0: 0.764 | 0: 0.764 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,309,380 | 0.764 | 0.764 | 0.764 | 0.000 | 0: 0.764 | 0: 0.764 |
| insert | random | A | scaleUp | 25,000 | 585,466 | 1.708 | 1.708 | 1.708 | 0.000 | 0: 1.708 | 0: 1.708 |
| insert | random | A | scaleDown | 25,000 | 601,132 | 1.664 | 1.664 | 1.664 | 0.000 | 0: 1.664 | 0: 1.664 |
| insert | random | A | fullLifecycle | 50,000 | 593,196 | 1.686 | 1.686 | 1.686 | 0.000 | 0: 1.686 | 0: 1.686 |
| insert | tail | A | scaleUp | 12,500 | 1,333,661 | 0.750 | 0.750 | 0.750 | 0.000 | 0: 0.750 | 0: 0.750 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,333,661 | 0.750 | 0.750 | 0.750 | 0.000 | 0: 0.750 | 0: 0.750 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 723,786 | 1.382 | 1.382 | 1.382 | 0.000 | 0: 1.382 | 0: 1.382 |
| remove | head | A | fullLifecycle | 12,500 | 723,786 | 1.382 | 1.382 | 1.382 | 0.000 | 0: 1.382 | 0: 1.382 |
| remove | random | A | scaleUp | 25,000 | 488,192 | 2.048 | 2.048 | 2.048 | 0.000 | 0: 2.048 | 0: 2.048 |
| remove | random | A | scaleDown | 25,000 | 529,235 | 1.890 | 1.890 | 1.890 | 0.000 | 0: 1.890 | 0: 1.890 |
| remove | random | A | fullLifecycle | 50,000 | 507,885 | 1.969 | 1.969 | 1.969 | 0.000 | 0: 1.969 | 0: 1.969 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 831,073 | 1.203 | 1.203 | 1.203 | 0.000 | 0: 1.203 | 0: 1.203 |
| remove | tail | A | fullLifecycle | 12,500 | 831,073 | 1.203 | 1.203 | 1.203 | 0.000 | 0: 1.203 | 0: 1.203 |
| replace | head | A | scaleUp | 25,000 | 525,989 | 1.901 | 1.901 | 1.901 | 0.000 | 0: 1.901 | 0: 1.901 |
| replace | head | A | scaleDown | 25,000 | 524,161 | 1.908 | 1.908 | 1.908 | 0.000 | 0: 1.908 | 0: 1.908 |
| replace | head | A | fullLifecycle | 50,000 | 525,073 | 1.904 | 1.904 | 1.904 | 0.000 | 0: 1.904 | 0: 1.904 |
| replace | random | A | scaleUp | 25,000 | 358,720 | 2.788 | 2.788 | 2.788 | 0.000 | 0: 2.788 | 0: 2.788 |
| replace | random | A | scaleDown | 25,000 | 383,055 | 2.611 | 2.611 | 2.611 | 0.000 | 0: 2.611 | 0: 2.611 |
| replace | random | A | fullLifecycle | 50,000 | 370,488 | 2.699 | 2.699 | 2.699 | 0.000 | 0: 2.699 | 0: 2.699 |
| replace | tail | A | scaleUp | 25,000 | 529,893 | 1.887 | 1.887 | 1.887 | 0.000 | 0: 1.887 | 0: 1.887 |
| replace | tail | A | scaleDown | 25,000 | 201,854 | 4.954 | 4.954 | 4.954 | 0.000 | 0: 4.954 | 0: 4.954 |
| replace | tail | A | fullLifecycle | 50,000 | 292,345 | 3.421 | 3.421 | 3.421 | 0.000 | 0: 3.421 | 0: 3.421 |
| sequence | — | A | scaleUp | 6 | 74 | 13574.633 | 13574.633 | 13574.633 | 0.000 | 0: 13574.633 | 0: 13574.633 |
| sequence | — | A | scaleDown | 6 | 94 | 10632.383 | 10632.383 | 10632.383 | 0.000 | 0: 10632.383 | 0: 10632.383 |
| sequence | — | A | fullLifecycle | 12 | 83 | 12103.508 | 12103.508 | 12103.508 | 0.000 | 0: 12103.508 | 0: 12103.508 |
| value | head | A | scaleUp | 25,000 | 3,120,164 | 0.320 | 0.320 | 0.320 | 0.000 | 0: 0.320 | 0: 0.320 |
| value | head | A | scaleDown | 25,000 | 2,410,893 | 0.415 | 0.415 | 0.415 | 0.000 | 0: 0.415 | 0: 0.415 |
| value | head | A | fullLifecycle | 50,000 | 2,720,052 | 0.368 | 0.368 | 0.368 | 0.000 | 0: 0.368 | 0: 0.368 |
| value | random | A | scaleUp | 25,000 | 902,384 | 1.108 | 1.108 | 1.108 | 0.000 | 0: 1.108 | 0: 1.108 |
| value | random | A | scaleDown | 25,000 | 969,266 | 1.032 | 1.032 | 1.032 | 0.000 | 0: 1.032 | 0: 1.032 |
| value | random | A | fullLifecycle | 50,000 | 934,630 | 1.070 | 1.070 | 1.070 | 0.000 | 0: 1.070 | 0: 1.070 |
| value | tail | A | scaleUp | 25,000 | 6,381,947 | 0.157 | 0.157 | 0.157 | 0.000 | 0: 0.157 | 0: 0.157 |
| value | tail | A | scaleDown | 25,000 | 4,278,624 | 0.234 | 0.234 | 0.234 | 0.000 | 0: 0.234 | 0: 0.234 |
| value | tail | A | fullLifecycle | 50,000 | 5,122,793 | 0.195 | 0.195 | 0.195 | 0.000 | 0: 0.195 | 0: 0.195 |
| values | — | A | scaleUp | 6 | 79 | 12690.233 | 12690.233 | 12690.233 | 0.000 | 0: 12690.233 | 0: 12690.233 |
| values | — | A | scaleDown | 6 | 240 | 4170.017 | 4170.017 | 4170.017 | 0.000 | 0: 4170.017 | 0: 4170.017 |
| values | — | A | fullLifecycle | 12 | 119 | 8430.125 | 8430.125 | 8430.125 | 0.000 | 0: 8430.125 | 0: 8430.125 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5428540.000 | 428.569 | 8.477 |
| A | scaleDown | 5 | 4409840.000 | 432.337 | 8.548 |
| A | fullLifecycle | 11 | 4965494.545 | 430.082 | 8.506 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3126055.667 | 246.794 | 4.882 |
| A | scaleDown | 5 | 2596615.600 | 254.570 | 5.033 |
| A | fullLifecycle | 11 | 2885401.091 | 249.917 | 4.943 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 231,621 | 4.317 | 2.000 | 270.600 |
| apply | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 249,841 | 4.003 | 1.800 | 1281.800 |
| apply | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 287,032 | 3.484 | 1.600 | 1281.800 |
| apply | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 304,060 | 3.289 | 1.500 | 1281.800 |
| apply | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 306,152 | 3.266 | 1.500 | 1281.800 |
| apply | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 305,188 | 3.277 | 1.500 | 1662.600 |
| apply | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 309,011 | 3.236 | 1.500 | 1662.600 |
| apply | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 313,262 | 3.192 | 1.500 | 1662.600 |
| apply | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 315,025 | 3.174 | 1.500 | 1662.600 |
| apply | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 319,624 | 3.129 | 1.500 | 1662.600 |
| apply | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 324,903 | 3.078 | 1.300 | 1662.600 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 326,792 | 3.060 | 1.300 | 1662.600 |
| insert | head | 0 | up | 1,000 | 51,204 | A | 500 | 1,008,471 | 0.992 | 0.400 | 42.800 |
| insert | head | 0 | up | 5,000 | 250,037 | A | 2,500 | 987,986 | 1.012 | 0.400 | 42.800 |
| insert | head | 0 | up | 10,000 | 506,154 | A | 5,000 | 1,178,217 | 0.849 | 0.300 | 42.800 |
| insert | head | 0 | up | 15,000 | 762,134 | A | 7,500 | 1,259,108 | 0.794 | 0.300 | 42.800 |
| insert | head | 0 | up | 20,000 | 1,012,964 | A | 10,000 | 1,287,797 | 0.777 | 0.300 | 42.800 |
| insert | head | 0 | up | 25,000 | 1,259,727 | A | 12,500 | 1,309,380 | 0.764 | 0.300 | 42.800 |
| insert | head | 0 | down | 20,000 | 1,009,630 | A | 12,500 | 1,309,380 | 0.764 | 0.300 | 42.800 |
| insert | head | 0 | down | 15,000 | 759,633 | A | 12,500 | 1,309,380 | 0.764 | 0.300 | 42.800 |
| insert | head | 0 | down | 10,000 | 507,941 | A | 12,500 | 1,309,380 | 0.764 | 0.300 | 42.800 |
| insert | head | 0 | down | 5,000 | 250,794 | A | 12,500 | 1,309,380 | 0.764 | 0.300 | 42.800 |
| insert | head | 0 | down | 1,000 | 51,447 | A | 12,500 | 1,309,380 | 0.764 | 0.300 | 42.800 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,309,380 | 0.764 | 0.300 | 42.800 |
| insert | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 510,830 | 1.958 | 0.400 | 327.800 |
| insert | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 478,400 | 2.090 | 0.400 | 1018.100 |
| insert | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 555,454 | 1.800 | 0.400 | 1018.100 |
| insert | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 583,860 | 1.713 | 0.400 | 1018.100 |
| insert | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 579,660 | 1.725 | 0.400 | 1018.100 |
| insert | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 585,466 | 1.708 | 0.400 | 1018.100 |
| insert | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 576,666 | 1.734 | 0.400 | 1018.100 |
| insert | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 565,621 | 1.768 | 0.400 | 1448.300 |
| insert | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 573,364 | 1.744 | 0.400 | 1448.300 |
| insert | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 580,207 | 1.724 | 0.400 | 1448.300 |
| insert | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 588,086 | 1.700 | 0.400 | 1448.300 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 593,196 | 1.686 | 0.400 | 1448.300 |
| insert | tail | 0 | up | 1,000 | 51,204 | A | 500 | 1,003,412 | 0.997 | 0.400 | 33.400 |
| insert | tail | 0 | up | 5,000 | 250,037 | A | 2,500 | 1,083,846 | 0.923 | 0.400 | 84.500 |
| insert | tail | 0 | up | 10,000 | 506,154 | A | 5,000 | 1,299,984 | 0.769 | 0.300 | 84.500 |
| insert | tail | 0 | up | 15,000 | 762,134 | A | 7,500 | 1,351,424 | 0.740 | 0.300 | 154.800 |
| insert | tail | 0 | up | 20,000 | 1,012,964 | A | 10,000 | 1,350,804 | 0.740 | 0.300 | 279.500 |
| insert | tail | 0 | up | 25,000 | 1,259,727 | A | 12,500 | 1,333,661 | 0.750 | 0.300 | 343.800 |
| insert | tail | 0 | down | 20,000 | 1,009,630 | A | 12,500 | 1,333,661 | 0.750 | 0.300 | 343.800 |
| insert | tail | 0 | down | 15,000 | 759,633 | A | 12,500 | 1,333,661 | 0.750 | 0.300 | 343.800 |
| insert | tail | 0 | down | 10,000 | 507,941 | A | 12,500 | 1,333,661 | 0.750 | 0.300 | 343.800 |
| insert | tail | 0 | down | 5,000 | 250,794 | A | 12,500 | 1,333,661 | 0.750 | 0.300 | 343.800 |
| insert | tail | 0 | down | 1,000 | 51,447 | A | 12,500 | 1,333,661 | 0.750 | 0.300 | 343.800 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,333,661 | 0.750 | 0.300 | 343.800 |
| remove | head | 0 | up | 1,000 | 51,204 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 250,037 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 506,154 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 762,134 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,012,964 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,259,727 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,009,630 | A | 2,500 | 717,216 | 1.394 | 0.900 | 45.700 |
| remove | head | 0 | down | 15,000 | 759,633 | A | 5,000 | 697,194 | 1.434 | 0.800 | 336.400 |
| remove | head | 0 | down | 10,000 | 507,941 | A | 7,500 | 678,874 | 1.473 | 0.800 | 622.800 |
| remove | head | 0 | down | 5,000 | 250,794 | A | 10,000 | 700,884 | 1.427 | 0.800 | 622.800 |
| remove | head | 0 | down | 1,000 | 51,447 | A | 12,000 | 717,390 | 1.394 | 0.800 | 622.800 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 723,786 | 1.382 | 0.700 | 622.800 |
| remove | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 436,319 | 2.292 | 0.900 | 433.500 |
| remove | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 441,883 | 2.263 | 0.900 | 433.500 |
| remove | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 476,109 | 2.100 | 0.900 | 433.500 |
| remove | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 487,228 | 2.052 | 0.900 | 636.000 |
| remove | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 489,874 | 2.041 | 0.900 | 636.000 |
| remove | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 488,192 | 2.048 | 0.900 | 636.000 |
| remove | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 488,017 | 2.049 | 0.900 | 636.000 |
| remove | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 488,353 | 2.048 | 0.900 | 636.000 |
| remove | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 490,725 | 2.038 | 0.900 | 636.000 |
| remove | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 496,817 | 2.013 | 0.800 | 636.000 |
| remove | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 503,755 | 1.985 | 0.800 | 636.000 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 507,885 | 1.969 | 0.600 | 636.000 |
| remove | tail | 0 | up | 1,000 | 51,204 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 250,037 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 506,154 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 762,134 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,012,964 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,259,727 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,009,630 | A | 2,500 | 784,782 | 1.274 | 0.800 | 59.600 |
| remove | tail | 0 | down | 15,000 | 759,633 | A | 5,000 | 798,441 | 1.252 | 0.800 | 59.600 |
| remove | tail | 0 | down | 10,000 | 507,941 | A | 7,500 | 809,114 | 1.236 | 0.700 | 59.600 |
| remove | tail | 0 | down | 5,000 | 250,794 | A | 10,000 | 820,170 | 1.219 | 0.700 | 59.600 |
| remove | tail | 0 | down | 1,000 | 51,447 | A | 12,000 | 826,332 | 1.210 | 0.700 | 59.600 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 831,073 | 1.203 | 0.700 | 59.600 |
| replace | head | 0 | up | 1,000 | 51,204 | A | 1,000 | 393,747 | 2.540 | 1.200 | 275.700 |
| replace | head | 0 | up | 5,000 | 250,037 | A | 5,000 | 428,894 | 2.332 | 1.200 | 275.700 |
| replace | head | 0 | up | 10,000 | 506,154 | A | 10,000 | 481,257 | 2.078 | 1.100 | 402.900 |
| replace | head | 0 | up | 15,000 | 762,134 | A | 15,000 | 508,757 | 1.966 | 1.100 | 402.900 |
| replace | head | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 523,174 | 1.911 | 1.100 | 402.900 |
| replace | head | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 525,989 | 1.901 | 1.100 | 632.400 |
| replace | head | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 523,378 | 1.911 | 1.100 | 632.400 |
| replace | head | 0 | down | 15,000 | 759,633 | A | 35,000 | 522,326 | 1.915 | 1.100 | 632.400 |
| replace | head | 0 | down | 10,000 | 507,941 | A | 40,000 | 520,903 | 1.920 | 1.000 | 632.400 |
| replace | head | 0 | down | 5,000 | 250,794 | A | 45,000 | 521,314 | 1.918 | 1.000 | 632.400 |
| replace | head | 0 | down | 1,000 | 51,447 | A | 49,000 | 523,171 | 1.911 | 1.000 | 632.400 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 525,073 | 1.904 | 1.000 | 632.400 |
| replace | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 398,264 | 2.511 | 1.200 | 59.200 |
| replace | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 317,793 | 3.147 | 1.200 | 923.600 |
| replace | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 350,925 | 2.850 | 1.200 | 923.600 |
| replace | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 354,354 | 2.822 | 1.200 | 923.600 |
| replace | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 356,960 | 2.801 | 1.200 | 923.600 |
| replace | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 358,720 | 2.788 | 1.200 | 923.600 |
| replace | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 360,290 | 2.776 | 1.200 | 923.600 |
| replace | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 360,658 | 2.773 | 1.200 | 923.600 |
| replace | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 360,553 | 2.774 | 1.200 | 1174.000 |
| replace | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 362,399 | 2.759 | 1.100 | 1174.000 |
| replace | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 367,388 | 2.722 | 1.000 | 1174.000 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 370,488 | 2.699 | 1.000 | 1174.000 |
| replace | tail | 0 | up | 1,000 | 51,204 | A | 1,000 | 447,167 | 2.236 | 1.200 | 111.000 |
| replace | tail | 0 | up | 5,000 | 250,037 | A | 5,000 | 458,249 | 2.182 | 1.200 | 194.100 |
| replace | tail | 0 | up | 10,000 | 506,154 | A | 10,000 | 484,208 | 2.065 | 1.100 | 1177.700 |
| replace | tail | 0 | up | 15,000 | 762,134 | A | 15,000 | 521,210 | 1.919 | 1.000 | 1177.700 |
| replace | tail | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 523,652 | 1.910 | 1.000 | 1177.700 |
| replace | tail | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 529,893 | 1.887 | 1.000 | 1177.700 |
| replace | tail | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 458,873 | 2.179 | 1.000 | 1177.700 |
| replace | tail | 0 | down | 15,000 | 759,633 | A | 35,000 | 299,191 | 3.342 | 1.000 | 1177.700 |
| replace | tail | 0 | down | 10,000 | 507,941 | A | 40,000 | 307,773 | 3.249 | 1.000 | 1177.700 |
| replace | tail | 0 | down | 5,000 | 250,794 | A | 45,000 | 285,057 | 3.508 | 1.000 | 1177.700 |
| replace | tail | 0 | down | 1,000 | 51,447 | A | 49,000 | 289,371 | 3.456 | 0.900 | 1177.700 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 292,345 | 3.421 | 0.900 | 1177.700 |
| value | head | 0 | up | 1,000 | 51,204 | A | 1,000 | 1,596,424 | 0.626 | 0.100 | 210.100 |
| value | head | 0 | up | 5,000 | 250,037 | A | 5,000 | 2,334,158 | 0.428 | 0.100 | 210.100 |
| value | head | 0 | up | 10,000 | 506,154 | A | 10,000 | 2,797,907 | 0.357 | 0.100 | 210.100 |
| value | head | 0 | up | 15,000 | 762,134 | A | 15,000 | 2,976,958 | 0.336 | 0.100 | 210.100 |
| value | head | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 3,071,961 | 0.326 | 0.100 | 210.100 |
| value | head | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 3,120,164 | 0.320 | 0.100 | 210.100 |
| value | head | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 2,944,959 | 0.340 | 0.100 | 210.100 |
| value | head | 0 | down | 15,000 | 759,633 | A | 35,000 | 2,850,302 | 0.351 | 0.100 | 210.100 |
| value | head | 0 | down | 10,000 | 507,941 | A | 40,000 | 2,797,379 | 0.357 | 0.100 | 210.100 |
| value | head | 0 | down | 5,000 | 250,794 | A | 45,000 | 2,740,660 | 0.365 | 0.100 | 210.100 |
| value | head | 0 | down | 1,000 | 51,447 | A | 49,000 | 2,717,859 | 0.368 | 0.100 | 210.100 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,720,052 | 0.368 | 0.100 | 210.100 |
| value | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 1,112,842 | 0.899 | 0.100 | 55.400 |
| value | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 897,602 | 1.114 | 0.100 | 55.400 |
| value | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 922,577 | 1.084 | 0.100 | 55.400 |
| value | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 907,562 | 1.102 | 0.100 | 87.300 |
| value | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 904,867 | 1.105 | 0.100 | 87.300 |
| value | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 902,384 | 1.108 | 0.100 | 87.300 |
| value | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 897,878 | 1.114 | 0.100 | 87.300 |
| value | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 901,068 | 1.110 | 0.100 | 87.300 |
| value | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 904,523 | 1.106 | 0.100 | 87.300 |
| value | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 913,411 | 1.095 | 0.100 | 87.300 |
| value | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 925,865 | 1.080 | 0.100 | 131.000 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 934,630 | 1.070 | 0.100 | 131.000 |
| value | tail | 0 | up | 1,000 | 51,204 | A | 1,000 | 5,558,644 | 0.180 | 0.100 | 5.400 |
| value | tail | 0 | up | 5,000 | 250,037 | A | 5,000 | 4,979,088 | 0.201 | 0.100 | 5.400 |
| value | tail | 0 | up | 10,000 | 506,154 | A | 10,000 | 5,559,571 | 0.180 | 0.100 | 5.400 |
| value | tail | 0 | up | 15,000 | 762,134 | A | 15,000 | 5,936,362 | 0.168 | 0.000 | 7.200 |
| value | tail | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 6,238,692 | 0.160 | 0.000 | 7.200 |
| value | tail | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 6,381,947 | 0.157 | 0.000 | 7.200 |
| value | tail | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 5,904,814 | 0.169 | 0.000 | 14.000 |
| value | tail | 0 | down | 15,000 | 759,633 | A | 35,000 | 5,646,436 | 0.177 | 0.000 | 14.000 |
| value | tail | 0 | down | 10,000 | 507,941 | A | 40,000 | 5,420,568 | 0.184 | 0.000 | 14.000 |
| value | tail | 0 | down | 5,000 | 250,794 | A | 45,000 | 5,231,828 | 0.191 | 0.000 | 14.000 |
| value | tail | 0 | down | 1,000 | 51,447 | A | 49,000 | 5,129,601 | 0.195 | 0.000 | 37.500 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,122,793 | 0.195 | 0.000 | 37.500 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,053 | 487.100 |
| create | — | 0 | up | 5,000 | A | 1 | 877 | 1140.500 |
| create | — | 0 | up | 10,000 | A | 1 | 669 | 1494.600 |
| create | — | 0 | up | 15,000 | A | 1 | 419 | 2383.900 |
| create | — | 0 | up | 20,000 | A | 1 | 290 | 3448.400 |
| create | — | 0 | up | 25,000 | A | 1 | 247 | 4049.500 |
| create | — | 0 | down | 20,000 | A | 1 | 282 | 3550.000 |
| create | — | 0 | down | 15,000 | A | 1 | 365 | 2739.800 |
| create | — | 0 | down | 10,000 | A | 1 | 562 | 1779.500 |
| create | — | 0 | down | 5,000 | A | 1 | 1,234 | 810.700 |
| create | — | 0 | down | 1,000 | A | 1 | 3,828 | 261.200 |
| create | — | 0 | down | 0 | A | 1 | 57,471 | 17.400 |
| sequence | — | 0 | up | 1,000 | A | 1 | 415 | 2410.200 |
| sequence | — | 0 | up | 5,000 | A | 1 | 121 | 8252.900 |
| sequence | — | 0 | up | 10,000 | A | 1 | 84 | 11964.600 |
| sequence | — | 0 | up | 15,000 | A | 1 | 73 | 13739.600 |
| sequence | — | 0 | up | 20,000 | A | 1 | 45 | 22404.200 |
| sequence | — | 0 | up | 25,000 | A | 1 | 44 | 22676.300 |
| sequence | — | 0 | down | 20,000 | A | 1 | 54 | 18516.600 |
| sequence | — | 0 | down | 15,000 | A | 1 | 65 | 15471.000 |
| sequence | — | 0 | down | 10,000 | A | 1 | 84 | 11859.100 |
| sequence | — | 0 | down | 5,000 | A | 1 | 115 | 8671.300 |
| sequence | — | 0 | down | 1,000 | A | 1 | 130 | 7717.900 |
| sequence | — | 0 | down | 0 | A | 1 | 642 | 1558.400 |
| values | — | 0 | up | 1,000 | A | 1 | 530 | 1888.200 |
| values | — | 0 | up | 5,000 | A | 1 | 231 | 4322.800 |
| values | — | 0 | up | 10,000 | A | 1 | 50 | 20053.200 |
| values | — | 0 | up | 15,000 | A | 1 | 35 | 28446.900 |
| values | — | 0 | up | 20,000 | A | 1 | 97 | 10280.600 |
| values | — | 0 | up | 25,000 | A | 1 | 90 | 11149.700 |
| values | — | 0 | down | 20,000 | A | 1 | 96 | 10415.700 |
| values | — | 0 | down | 15,000 | A | 1 | 159 | 6294.700 |
| values | — | 0 | down | 10,000 | A | 1 | 193 | 5180.200 |
| values | — | 0 | down | 5,000 | A | 1 | 382 | 2621.200 |
| values | — | 0 | down | 1,000 | A | 1 | 2,006 | 498.500 |
| values | — | 0 | down | 0 | A | 1 | 102,041 | 9.800 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.622 | 0.232 | 0.391 |
| 0 | up | 5000 | 3.076 | 1.168 | 1.908 |
| 0 | up | 10000 | 6.205 | 2.343 | 3.862 |
| 0 | up | 15000 | 9.457 | 3.643 | 5.815 |
| 0 | up | 20000 | 12.841 | 5.112 | 7.728 |
| 0 | up | 25000 | 16.247 | 6.636 | 9.611 |
| 0 | down | 20000 | 13.315 | 5.612 | 7.703 |
| 0 | down | 15000 | 9.926 | 4.131 | 5.796 |
| 0 | down | 10000 | 7.170 | 3.295 | 3.875 |
| 0 | down | 5000 | 4.075 | 2.161 | 1.913 |
| 0 | down | 1000 | 1.812 | 1.420 | 0.393 |
| 0 | down | 0 | 1.230 | 1.230 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 51,204 | 0.411 | 430.756 | 8.413 | 120.785 | 15.545 |
| 0 | up | A | 5,000 | 5,000 | 250,037 | 2.010 | 421.606 | 8.431 | 149.672 | 19.561 |
| 0 | up | A | 10,000 | 10,000 | 506,154 | 4.075 | 427.300 | 8.442 | 195.605 | 24.478 |
| 0 | up | A | 15,000 | 15,000 | 762,134 | 6.154 | 430.176 | 8.467 | 209.359 | 29.392 |
| 0 | up | A | 20,000 | 20,000 | 1,012,964 | 8.198 | 429.835 | 8.487 | 279.949 | 34.214 |
| 0 | up | A | 25,000 | 25,000 | 1,259,727 | 10.214 | 428.405 | 8.502 | 293.133 | 38.944 |
| 0 | down | A | 20,000 | 20,000 | 1,009,630 | 8.241 | 432.089 | 8.559 | 299.199 | 34.190 |
| 0 | down | A | 15,000 | 15,000 | 759,633 | 6.201 | 433.508 | 8.560 | 303.246 | 29.425 |
| 0 | down | A | 10,000 | 10,000 | 507,941 | 4.136 | 433.718 | 8.539 | 300.199 | 24.654 |
| 0 | down | A | 5,000 | 5,000 | 250,794 | 2.034 | 426.570 | 8.504 | 298.234 | 19.798 |
| 0 | down | A | 1,000 | 1,000 | 51,447 | 0.415 | 434.772 | 8.451 | 296.973 | 15.999 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 298.074 | 14.908 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 51204 | 187497 | 187.497 | 3.662 | 277.53 | 14.54 | 165.41 | 12.36 |
| 0 | up | A | 5000 | 250037 | 1195941 | 239.188 | 4.783 | 1610.38 | 73.38 | 813.25 | 61.61 |
| 0 | up | A | 10000 | 506154 | 2435808 | 243.581 | 4.812 | 3265.74 | 148.71 | 1649.99 | 124.72 |
| 0 | up | A | 15000 | 762134 | 3716482 | 247.765 | 4.876 | 4950.79 | 226.25 | 3565.22 | 200.28 |
| 0 | up | A | 20000 | 1012964 | 4982573 | 249.129 | 4.919 | 7121.78 | 311.32 | 5144.59 | 263.55 |
| 0 | up | A | 25000 | 1259727 | 6238033 | 249.521 | 4.952 | 9237.87 | 392.58 | 6535.88 | 334.89 |
| 0 | down | A | 20000 | 1009630 | 5113545 | 255.677 | 5.065 | 7558.03 | 326.74 | 5304.48 | 278.22 |
| 0 | down | A | 15000 | 759633 | 3843527 | 256.235 | 5.060 | 5727.79 | 247.31 | 4004.31 | 209.86 |
| 0 | down | A | 10000 | 507941 | 2547329 | 254.733 | 5.015 | 3837.94 | 164.83 | 2677.99 | 139.88 |
| 0 | down | A | 5000 | 250794 | 1235293 | 247.059 | 4.926 | 1887.01 | 79.61 | 1318.78 | 67.84 |
| 0 | down | A | 1000 | 51447 | 243384 | 243.384 | 4.731 | 382.91 | 15.90 | 268.58 | 13.64 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 428.569 | 8.477 | 246.794 | 4.882 |
| 0 | A | scaleDown | 432.337 | 8.548 | 254.570 | 5.033 |
| 0 | A | fullLifecycle | 430.082 | 8.506 | 249.917 | 4.943 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
