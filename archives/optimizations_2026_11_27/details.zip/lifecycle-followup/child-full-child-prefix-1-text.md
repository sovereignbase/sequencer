# Large string benchmarks

2026-11-27T17:24:09.000Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2328.82 | 0.00 |
| 1024 | insert.append | array | 12446.49 | 0.00 |
| 1024 | replace | array | 3237.19 | 0.00 |
| 1024 | remove | array | 1048.72 | 0.00 |
| 1024 | remove.middle | array | 2505.90 | 0.00 |
| 1024 | replace.middle | array | 3159.02 | 0.00 |
| 1024 | apply | array | 910.36 | 0.00 |
| 1024 | apply.array | array | 692.32 | 0.00 |
| 1024 | concurrent.apply | array | 72358.96 | 0.00 |
| 1024 | merge | array | 3285.64 | 0.00 |
| 1024 | create | array | 3140.47 | 0.00 |
| 1024 | value.random | array | 50.26 | 0.00 |
| 1024 | values.range | array | 112.99 | 0.00 |
| 1024 | values.array | array | 1311.19 | 0.00 |
| 1024 | values.text | array | 13785.28 | 0.00 |
| 1024 | sequence.array | array | 1710.94 | 0.00 |
| 1024 | sequence.text | array | 9944.47 | 0.00 |
| 1024 | sequence.edited.text | array | 15030.35 | 0.00 |
| 1024 | sequence.masked.text | array | 15147.24 | 0.00 |
| 1024 | insert | string | 525.09 | 0.00 |
| 1024 | insert.append | string | 4729.97 | 0.00 |
| 1024 | replace | string | 1277.62 | 0.00 |
| 1024 | remove | string | 993.90 | 0.00 |
| 1024 | remove.middle | string | 982.46 | 0.00 |
| 1024 | replace.middle | string | 1380.53 | 0.00 |
| 1024 | apply | string | 779.63 | 0.00 |
| 1024 | apply.array | string | 2328.50 | 0.00 |
| 1024 | concurrent.apply | string | 3756.74 | 0.00 |
| 1024 | merge | string | 1389.34 | 0.00 |
| 1024 | create | string | 1049.39 | 0.00 |
| 1024 | value.random | string | 54.75 | 0.00 |
| 1024 | values.range | string | 159.58 | 0.00 |
| 1024 | values.array | string | 1950.12 | 0.00 |
| 1024 | values.text | string | 72.82 | 0.00 |
| 1024 | sequence.array | string | 2090.54 | 0.00 |
| 1024 | sequence.text | string | 209.45 | 0.00 |
| 1024 | sequence.edited.text | string | 2265.49 | 0.00 |
| 1024 | sequence.masked.text | string | 3571.05 | 0.00 |
| 65536 | insert | array | 276138.71 | 0.00 |
| 65536 | insert.append | array | 1086404.00 | 0.00 |
| 65536 | replace | array | 246152.94 | 0.00 |
| 65536 | remove | array | 2882.75 | 0.00 |
| 65536 | remove.middle | array | 238878.10 | 0.00 |
| 65536 | replace.middle | array | 271902.17 | 0.00 |
| 65536 | apply | array | 803.15 | 0.00 |
| 65536 | apply.array | array | 493.09 | 0.00 |
| 65536 | concurrent.apply | array | 4242066.67 | 0.00 |
| 65536 | merge | array | 213299.15 | 0.00 |
| 65536 | create | array | 202500.00 | 0.00 |
| 65536 | value.random | array | 49.33 | 0.00 |
| 65536 | values.range | array | 132.02 | 0.00 |
| 65536 | values.array | array | 206046.03 | 0.00 |
| 65536 | values.text | array | 784887.50 | 0.00 |
| 65536 | sequence.array | array | 203157.94 | 0.00 |
| 65536 | sequence.text | array | 728977.14 | 0.00 |
| 65536 | sequence.edited.text | array | 873858.62 | 0.00 |
| 65536 | sequence.masked.text | array | 725171.43 | 0.00 |
| 65536 | insert | string | 317.74 | 0.00 |
| 65536 | insert.append | string | 21318.16 | 0.00 |
| 65536 | replace | string | 1334.34 | 0.00 |
| 65536 | remove | string | 1028.36 | 0.00 |
| 65536 | remove.middle | string | 958.26 | 0.00 |
| 65536 | replace.middle | string | 1271.19 | 0.00 |
| 65536 | apply | string | 877.14 | 0.00 |
| 65536 | apply.array | string | 200280.00 | 0.00 |
| 65536 | concurrent.apply | string | 161770.97 | 0.00 |
| 65536 | merge | string | 1192.71 | 0.00 |
| 65536 | create | string | 972.80 | 0.00 |
| 65536 | value.random | string | 56.81 | 0.00 |
| 65536 | values.range | string | 156.43 | 0.00 |
| 65536 | values.array | string | 259089.84 | 0.00 |
| 65536 | values.text | string | 73.39 | 0.00 |
| 65536 | sequence.array | string | 253652.34 | 0.00 |
| 65536 | sequence.text | string | 181.92 | 0.00 |
| 65536 | sequence.edited.text | string | 87644.06 | 0.00 |
| 65536 | sequence.masked.text | string | 3420.74 | 0.00 |
| 1048576 | insert | array | 3335100.00 | 0.00 |
| 1048576 | insert.append | array | 23663400.00 | 0.00 |
| 1048576 | replace | array | 3310387.50 | 0.00 |
| 1048576 | remove | array | 11093.43 | 0.00 |
| 1048576 | remove.middle | array | 3168455.56 | 0.00 |
| 1048576 | replace.middle | array | 3029355.56 | 0.00 |
| 1048576 | apply | array | 1032.75 | 0.00 |
| 1048576 | apply.array | array | 518.24 | 0.00 |
| 1048576 | concurrent.apply | array | 64698300.00 | 0.00 |
| 1048576 | merge | array | 3337212.50 | 0.00 |
| 1048576 | create | array | 3188775.00 | 0.00 |
| 1048576 | value.random | array | 45.81 | 0.00 |
| 1048576 | values.range | array | 110.69 | 0.00 |
| 1048576 | values.array | array | 2364845.45 | 0.00 |
| 1048576 | values.text | array | 12690600.00 | 0.00 |
| 1048576 | sequence.array | array | 2449309.09 | 0.00 |
| 1048576 | sequence.text | array | 47247050.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 50321400.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 46450650.00 | 0.00 |
| 1048576 | insert | string | 421.26 | 0.00 |
| 1048576 | insert.append | string | 571784.09 | 0.00 |
| 1048576 | replace | string | 1282.25 | 0.00 |
| 1048576 | remove | string | 1126.48 | 0.00 |
| 1048576 | remove.middle | string | 964.18 | 0.00 |
| 1048576 | replace.middle | string | 1469.76 | 0.00 |
| 1048576 | apply | string | 1232.35 | 0.00 |
| 1048576 | apply.array | string | 3565812.50 | 0.00 |
| 1048576 | concurrent.apply | string | 1523441.18 | 0.00 |
| 1048576 | merge | string | 1284.44 | 0.00 |
| 1048576 | create | string | 897.40 | 0.00 |
| 1048576 | value.random | string | 44.84 | 0.00 |
| 1048576 | values.range | string | 136.30 | 0.00 |
| 1048576 | values.array | string | 3408975.00 | 0.00 |
| 1048576 | values.text | string | 57.21 | 0.00 |
| 1048576 | sequence.array | string | 3391412.50 | 0.00 |
| 1048576 | sequence.text | string | 186.64 | 0.00 |
| 1048576 | sequence.edited.text | string | 1541517.65 | 0.00 |
| 1048576 | sequence.masked.text | string | 3159.50 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
