# Tuple benchmarks

2026-11-27T17:23:54.770Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 2,969,101 | 2,358,083 | 0.79× |
| 2 | create.sequence | 953,740 | 804,871 | 0.84× |
| 2 | replace.random | 1,083,496 | 1,389,525 | 1.28× |
| 2 | apply.replace | 705,433 | 861,780 | 1.22× |
| 2 | apply.duplicate | 1,709,198 | 1,653,187 | 0.97× |
| 2 | merge.duplicate | 1,380,817 | 1,502,031 | 1.09× |
| 2 | length | 128,171,658 | 119,242,378 | 0.93× |
| 2 | value.random | 32,242,082 | 50,795,422 | 1.58× |
| 2 | values | 8,502,929 | 7,895,660 | 0.93× |
| 2 | sequence | 2,128,192 | 2,234,101 | 1.05× |
| 4 | create.empty | 1,765,355 | 1,981,183 | 1.12× |
| 4 | create.sequence | 304,195 | 507,156 | 1.67× |
| 4 | replace.random | 721,602 | 1,205,160 | 1.67× |
| 4 | apply.replace | 565,571 | 866,515 | 1.53× |
| 4 | apply.duplicate | 1,604,337 | 1,633,135 | 1.02× |
| 4 | merge.duplicate | 1,217,320 | 1,283,072 | 1.05× |
| 4 | length | 34,472,933 | 30,549,709 | 0.89× |
| 4 | value.random | 24,407,421 | 56,062,790 | 2.30× |
| 4 | values | 6,645,075 | 6,858,154 | 1.03× |
| 4 | sequence | 2,524,273 | 2,563,254 | 1.02× |
| 8 | create.empty | 2,585,399 | 2,480,408 | 0.96× |
| 8 | create.sequence | 475,304 | 582,416 | 1.23× |
| 8 | replace.random | 950,879 | 1,496,172 | 1.57× |
| 8 | apply.replace | 613,000 | 962,719 | 1.57× |
| 8 | apply.duplicate | 1,718,663 | 1,718,440 | 1.00× |
| 8 | merge.duplicate | 863,081 | 923,162 | 1.07× |
| 8 | length | 36,421,367 | 29,537,241 | 0.81× |
| 8 | value.random | 17,691,667 | 49,790,431 | 2.81× |
| 8 | values | 4,777,082 | 4,702,017 | 0.98× |
| 8 | sequence | 1,621,440 | 1,851,947 | 1.14× |
| 100 | create.empty | 2,360,770 | 2,218,783 | 0.94× |
| 100 | create.sequence | 68,344 | 87,410 | 1.28× |
| 100 | replace.random | 1,036,125 | 1,554,947 | 1.50× |
| 100 | apply.replace | 637,223 | 1,014,661 | 1.59× |
| 100 | apply.duplicate | 1,695,388 | 1,703,088 | 1.00× |
| 100 | merge.duplicate | 112,565 | 77,692 | 0.69× |
| 100 | length | 35,364,922 | 35,199,128 | 1.00× |
| 100 | value.random | 15,103,216 | 53,568,639 | 3.55× |
| 100 | values | 532,182 | 694,326 | 1.30× |
| 100 | sequence | 179,765 | 185,360 | 1.03× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
