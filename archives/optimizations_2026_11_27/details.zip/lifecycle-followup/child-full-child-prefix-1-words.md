# Words benchmarks

2026-11-27T17:24:30.891Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 31,437 | 141,820 | 156 |
| append | packed | 5.90 | 3.61 | 13.98 | 29,497 | 179,212 | 289 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,699 | 285 | 235 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 28,996 | 1,554 | 233 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 444 | 245 | 76 |
| random | packed | 49.58 | 35.38 | 23.45 | 13,914 | 527 | 132 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 618 | 256 | 97 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 11,732 | 315 | 99 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 483.48 | 0.00 |
| append | numeric | encode | 31810.05 | 0.00 |
| append | numeric | decode | 3224.21 | 0.00 |
| append | numeric | create | 1693.83 | 0.00 |
| append | numeric | load | 7051.21 | 0.00 |
| append | numeric | apply | 4863745.45 | 0.00 |
| append | numeric | receive | 6397675.00 | 0.00 |
| append | binary | sequence | 576.96 | 0.00 |
| append | binary | encode | 33901.83 | 0.00 |
| append | binary | decode | 2351.68 | 0.00 |
| append | binary | create | 2173.39 | 0.00 |
| append | binary | load | 5579.97 | 0.00 |
| append | binary | apply | 1759130.00 | 0.00 |
| append | binary | receive | 3457640.00 | 0.00 |
| prepend | numeric | sequence | 491867.65 | 0.00 |
| prepend | numeric | encode | 588411.76 | 0.00 |
| prepend | numeric | decode | 173726.39 | 0.00 |
| prepend | numeric | create | 638235.44 | 0.00 |
| prepend | numeric | load | 3511112.50 | 0.00 |
| prepend | numeric | apply | 2838777.78 | 0.00 |
| prepend | numeric | receive | 4260158.33 | 0.00 |
| prepend | binary | sequence | 383845.04 | 0.00 |
| prepend | binary | encode | 34487.31 | 0.00 |
| prepend | binary | decode | 1771.26 | 0.00 |
| prepend | binary | create | 615902.44 | 0.00 |
| prepend | binary | load | 643312.82 | 0.00 |
| prepend | binary | apply | 2922911.11 | 0.00 |
| prepend | binary | receive | 4298958.33 | 0.00 |
| random | numeric | sequence | 1021816.33 | 0.00 |
| random | numeric | encode | 2252965.22 | 0.00 |
| random | numeric | decode | 1118984.44 | 0.00 |
| random | numeric | create | 1765755.17 | 0.00 |
| random | numeric | load | 4074084.62 | 0.00 |
| random | numeric | apply | 8191157.14 | 0.00 |
| random | numeric | receive | 13156975.00 | 0.00 |
| random | binary | sequence | 935103.70 | 0.00 |
| random | binary | encode | 71870.26 | 0.00 |
| random | binary | decode | 1723.58 | 0.00 |
| random | binary | create | 1933061.54 | 0.00 |
| random | binary | load | 1898840.74 | 0.00 |
| random | binary | apply | 6531187.50 | 0.00 |
| random | binary | receive | 7594228.57 | 0.00 |
| concurrent | numeric | sequence | 837408.33 | 0.00 |
| concurrent | numeric | encode | 1617616.13 | 0.00 |
| concurrent | numeric | decode | 883545.61 | 0.00 |
| concurrent | numeric | create | 2401580.95 | 0.00 |
| concurrent | numeric | load | 3902784.62 | 0.00 |
| concurrent | numeric | apply | 5986811.11 | 0.00 |
| concurrent | numeric | receive | 10266200.00 | 0.00 |
| concurrent | binary | sequence | 724768.12 | 0.00 |
| concurrent | binary | encode | 85235.43 | 0.00 |
| concurrent | binary | decode | 3911.56 | 0.00 |
| concurrent | binary | create | 2759447.37 | 0.00 |
| concurrent | binary | load | 3170000.00 | 0.00 |
| concurrent | binary | apply | 6731362.50 | 0.00 |
| concurrent | binary | receive | 10104480.00 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
