# Batch benchmarks

2026-11-27T17:29:40.763Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload | Mode | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | individual | 2,452,283 | 1,092,578 | 556,426 | 76.05 | 5.99 | 0.012 |
| append | batch | 2,632,503 | 246,913,580 | 213,523,132 | 5.88 | 5.99 | 0.012 |
| prepend | individual | 1,696,977 | 1,584,200 | 844,535 | 76.11 | 5.99 | 0.896 |
| prepend | batch | 1,492,277 | 2,404,713 | 2,234,387 | 5.89 | 5.99 | 0.896 |
| random.characters | individual | 1,121,202 | 1,133,508 | 838,328 | 82.09 | 28.31 | 0.917 |
| random.characters | batch | 1,314,694 | 1,630,612 | 1,542,218 | 22.95 | 28.31 | 0.917 |
| random.words | individual | 1,143,140 | 1,216,644 | 825,105 | 125.68 | 73.88 | 0.991 |
| random.words | batch | 1,099,787 | 1,849,169 | 1,738,979 | 59.71 | 73.88 | 0.991 |
| concurrent.characters | individual | 1,260,570 | 991,531 | 783,162 | 82.04 | 56.41 | 1.834 |
| concurrent.characters | batch | 1,360,729 | 1,608,967 | 1,684,092 | 22.92 | 56.41 | 1.834 |
| concurrent.words | individual | 1,296,821 | 1,414,477 | 953,349 | 125.74 | 147.81 | 1.981 |
| concurrent.words | batch | 1,340,602 | 1,780,970 | 1,512,306 | 59.79 | 147.81 | 1.981 |
| concurrent.mixed | individual | 728,116 | 957,717 | 701,189 | 154.61 | 97.82 | 1.505 |
| concurrent.mixed | batch | 1,005,598 | 1,171,463 | 1,161,755 | 56.88 | 97.82 | 1.505 |
| causal.characters | individual | 1,238,173 | 1,424,620 | 1,049,860 | 88.96 | 63.81 | 1.842 |
| causal.characters | batch | 1,278,622 | 1,886,437 | 1,760,848 | 23.18 | 63.81 | 1.842 |
| causal.words | individual | 1,278,568 | 1,413,677 | 978,194 | 135.13 | 156.41 | 1.989 |
| causal.words | batch | 1,083,903 | 1,606,619 | 1,466,455 | 60.68 | 156.41 | 1.989 |
| causal.mixed | individual | 757,017 | 998,668 | 726,727 | 161.05 | 103.75 | 1.509 |
| causal.mixed | batch | 909,863 | 1,328,448 | 1,204,759 | 57.34 | 103.75 | 1.509 |

## Timing dispersion

| Workload | Mode | Operation | Median ms | IQR ms |
| --- | --- | --- | ---: | ---: |
| append | individual | author | 2.447 | 0.000 |
| append | individual | apply | 5.492 | 0.000 |
| append | individual | receive | 10.783 | 0.000 |
| append | individual | encode | 5.496 | 0.000 |
| append | individual | decode | 7.175 | 0.000 |
| append | batch | author | 2.279 | 0.000 |
| append | batch | apply | 0.024 | 0.000 |
| append | batch | receive | 0.028 | 0.000 |
| append | batch | encode | 0.184 | 0.000 |
| append | batch | decode | 0.095 | 0.000 |
| prepend | individual | author | 3.536 | 0.000 |
| prepend | individual | apply | 3.787 | 0.000 |
| prepend | individual | receive | 7.105 | 0.000 |
| prepend | individual | encode | 5.965 | 0.000 |
| prepend | individual | decode | 8.228 | 0.000 |
| prepend | batch | author | 4.021 | 0.000 |
| prepend | batch | apply | 2.495 | 0.000 |
| prepend | batch | receive | 2.685 | 0.000 |
| prepend | batch | encode | 0.204 | 0.000 |
| prepend | batch | decode | 0.102 | 0.000 |
| random.characters | individual | author | 5.351 | 0.000 |
| random.characters | individual | apply | 5.293 | 0.000 |
| random.characters | individual | receive | 7.157 | 0.000 |
| random.characters | individual | encode | 4.971 | 0.000 |
| random.characters | individual | decode | 7.068 | 0.000 |
| random.characters | batch | author | 4.564 | 0.000 |
| random.characters | batch | apply | 3.680 | 0.000 |
| random.characters | batch | receive | 3.890 | 0.000 |
| random.characters | batch | encode | 0.166 | 0.000 |
| random.characters | batch | decode | 0.098 | 0.000 |
| random.words | individual | author | 5.249 | 0.000 |
| random.words | individual | apply | 4.932 | 0.000 |
| random.words | individual | receive | 7.272 | 0.000 |
| random.words | individual | encode | 3.831 | 0.000 |
| random.words | individual | decode | 7.317 | 0.000 |
| random.words | batch | author | 5.456 | 0.000 |
| random.words | batch | apply | 3.245 | 0.000 |
| random.words | batch | receive | 3.450 | 0.000 |
| random.words | batch | encode | 0.354 | 0.000 |
| random.words | batch | decode | 0.100 | 0.000 |
| concurrent.characters | individual | author | 9.519 | 0.000 |
| concurrent.characters | individual | apply | 12.102 | 0.000 |
| concurrent.characters | individual | receive | 15.322 | 0.000 |
| concurrent.characters | individual | encode | 8.241 | 0.000 |
| concurrent.characters | individual | decode | 16.138 | 0.000 |
| concurrent.characters | batch | author | 8.819 | 0.000 |
| concurrent.characters | batch | apply | 7.458 | 0.000 |
| concurrent.characters | batch | receive | 7.126 | 0.000 |
| concurrent.characters | batch | encode | 0.317 | 0.000 |
| concurrent.characters | batch | decode | 0.121 | 0.000 |
| concurrent.words | individual | author | 9.253 | 0.000 |
| concurrent.words | individual | apply | 8.484 | 0.000 |
| concurrent.words | individual | receive | 12.587 | 0.000 |
| concurrent.words | individual | encode | 7.591 | 0.000 |
| concurrent.words | individual | decode | 12.039 | 0.000 |
| concurrent.words | batch | author | 8.951 | 0.000 |
| concurrent.words | batch | apply | 6.738 | 0.000 |
| concurrent.words | batch | receive | 7.935 | 0.000 |
| concurrent.words | batch | encode | 0.738 | 0.000 |
| concurrent.words | batch | decode | 0.115 | 0.000 |
| concurrent.mixed | individual | author | 16.481 | 0.000 |
| concurrent.mixed | individual | apply | 12.530 | 0.000 |
| concurrent.mixed | individual | receive | 17.114 | 0.000 |
| concurrent.mixed | individual | encode | 8.935 | 0.000 |
| concurrent.mixed | individual | decode | 10.113 | 0.000 |
| concurrent.mixed | batch | author | 11.933 | 0.000 |
| concurrent.mixed | batch | apply | 10.244 | 0.000 |
| concurrent.mixed | batch | receive | 10.329 | 0.000 |
| concurrent.mixed | batch | encode | 0.835 | 0.000 |
| concurrent.mixed | batch | decode | 0.123 | 0.000 |
| causal.characters | individual | author | 9.692 | 0.000 |
| causal.characters | individual | apply | 8.423 | 0.000 |
| causal.characters | individual | receive | 11.430 | 0.000 |
| causal.characters | individual | encode | 7.620 | 0.000 |
| causal.characters | individual | decode | 10.561 | 0.000 |
| causal.characters | batch | author | 9.385 | 0.000 |
| causal.characters | batch | apply | 6.361 | 0.000 |
| causal.characters | batch | receive | 6.815 | 0.000 |
| causal.characters | batch | encode | 0.262 | 0.000 |
| causal.characters | batch | decode | 0.113 | 0.000 |
| causal.words | individual | author | 9.386 | 0.000 |
| causal.words | individual | apply | 8.488 | 0.000 |
| causal.words | individual | receive | 12.267 | 0.000 |
| causal.words | individual | encode | 7.918 | 0.000 |
| causal.words | individual | decode | 9.075 | 0.000 |
| causal.words | batch | author | 11.071 | 0.000 |
| causal.words | batch | apply | 7.469 | 0.000 |
| causal.words | batch | receive | 8.183 | 0.000 |
| causal.words | batch | encode | 0.616 | 0.000 |
| causal.words | batch | decode | 0.130 | 0.000 |
| causal.mixed | individual | author | 15.852 | 0.000 |
| causal.mixed | individual | apply | 12.016 | 0.000 |
| causal.mixed | individual | receive | 16.512 | 0.000 |
| causal.mixed | individual | encode | 9.059 | 0.000 |
| causal.mixed | individual | decode | 8.907 | 0.000 |
| causal.mixed | batch | author | 13.189 | 0.000 |
| causal.mixed | batch | apply | 9.033 | 0.000 |
| causal.mixed | batch | receive | 9.960 | 0.000 |
| causal.mixed | batch | encode | 0.779 | 0.000 |
| causal.mixed | batch | decode | 0.120 | 0.000 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.
