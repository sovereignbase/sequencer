# Sequencer dynamic lifecycle benchmark

2026-11-27T17:28:13.184Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.44 | 163.09 | 56.54 |
| CommonJS | 199.62 | 164.71 | 56.75 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 361,186 | 2.769 | 2.769 | 2.769 | 0.000 | 0: 2.769 | 0: 2.769 |
| apply | random | A | scaleDown | 24,999 | 381,241 | 2.623 | 2.623 | 2.623 | 0.000 | 0: 2.623 | 0: 2.623 |
| apply | random | A | fullLifecycle | 49,999 | 370,942 | 2.696 | 2.696 | 2.696 | 0.000 | 0: 2.696 | 0: 2.696 |
| create | — | A | scaleUp | 7 | 559 | 1790.000 | 1790.000 | 1790.000 | 0.000 | 0: 1790.000 | 0: 1790.000 |
| create | — | A | scaleDown | 6 | 686 | 1457.933 | 1457.933 | 1457.933 | 0.000 | 0: 1457.933 | 0: 1457.933 |
| create | — | A | fullLifecycle | 13 | 611 | 1636.738 | 1636.738 | 1636.738 | 0.000 | 0: 1636.738 | 0: 1636.738 |
| insert | head | A | scaleUp | 12,500 | 1,320,906 | 0.757 | 0.757 | 0.757 | 0.000 | 0: 0.757 | 0: 0.757 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,320,906 | 0.757 | 0.757 | 0.757 | 0.000 | 0: 0.757 | 0: 0.757 |
| insert | random | A | scaleUp | 25,000 | 652,151 | 1.533 | 1.533 | 1.533 | 0.000 | 0: 1.533 | 0: 1.533 |
| insert | random | A | scaleDown | 25,000 | 665,759 | 1.502 | 1.502 | 1.502 | 0.000 | 0: 1.502 | 0: 1.502 |
| insert | random | A | fullLifecycle | 50,000 | 658,885 | 1.518 | 1.518 | 1.518 | 0.000 | 0: 1.518 | 0: 1.518 |
| insert | tail | A | scaleUp | 12,500 | 1,525,879 | 0.655 | 0.655 | 0.655 | 0.000 | 0: 0.655 | 0: 0.655 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,525,879 | 0.655 | 0.655 | 0.655 | 0.000 | 0: 0.655 | 0: 0.655 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 798,258 | 1.253 | 1.253 | 1.253 | 0.000 | 0: 1.253 | 0: 1.253 |
| remove | head | A | fullLifecycle | 12,500 | 798,258 | 1.253 | 1.253 | 1.253 | 0.000 | 0: 1.253 | 0: 1.253 |
| remove | random | A | scaleUp | 25,000 | 573,037 | 1.745 | 1.745 | 1.745 | 0.000 | 0: 1.745 | 0: 1.745 |
| remove | random | A | scaleDown | 25,000 | 585,936 | 1.707 | 1.707 | 1.707 | 0.000 | 0: 1.707 | 0: 1.707 |
| remove | random | A | fullLifecycle | 50,000 | 579,415 | 1.726 | 1.726 | 1.726 | 0.000 | 0: 1.726 | 0: 1.726 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 862,432 | 1.160 | 1.160 | 1.160 | 0.000 | 0: 1.160 | 0: 1.160 |
| remove | tail | A | fullLifecycle | 12,500 | 862,432 | 1.160 | 1.160 | 1.160 | 0.000 | 0: 1.160 | 0: 1.160 |
| replace | head | A | scaleUp | 25,000 | 535,417 | 1.868 | 1.868 | 1.868 | 0.000 | 0: 1.868 | 0: 1.868 |
| replace | head | A | scaleDown | 25,000 | 551,031 | 1.815 | 1.815 | 1.815 | 0.000 | 0: 1.815 | 0: 1.815 |
| replace | head | A | fullLifecycle | 50,000 | 543,112 | 1.841 | 1.841 | 1.841 | 0.000 | 0: 1.841 | 0: 1.841 |
| replace | random | A | scaleUp | 25,000 | 377,770 | 2.647 | 2.647 | 2.647 | 0.000 | 0: 2.647 | 0: 2.647 |
| replace | random | A | scaleDown | 25,000 | 417,000 | 2.398 | 2.398 | 2.398 | 0.000 | 0: 2.398 | 0: 2.398 |
| replace | random | A | fullLifecycle | 50,000 | 396,417 | 2.523 | 2.523 | 2.523 | 0.000 | 0: 2.523 | 0: 2.523 |
| replace | tail | A | scaleUp | 25,000 | 570,759 | 1.752 | 1.752 | 1.752 | 0.000 | 0: 1.752 | 0: 1.752 |
| replace | tail | A | scaleDown | 25,000 | 209,347 | 4.777 | 4.777 | 4.777 | 0.000 | 0: 4.777 | 0: 4.777 |
| replace | tail | A | fullLifecycle | 50,000 | 306,334 | 3.264 | 3.264 | 3.264 | 0.000 | 0: 3.264 | 0: 3.264 |
| sequence | — | A | scaleUp | 6 | 82 | 12269.917 | 12269.917 | 12269.917 | 0.000 | 0: 12269.917 | 0: 12269.917 |
| sequence | — | A | scaleDown | 6 | 106 | 9402.050 | 9402.050 | 9402.050 | 0.000 | 0: 9402.050 | 0: 9402.050 |
| sequence | — | A | fullLifecycle | 12 | 92 | 10835.983 | 10835.983 | 10835.983 | 0.000 | 0: 10835.983 | 0: 10835.983 |
| value | head | A | scaleUp | 25,000 | 3,395,816 | 0.294 | 0.294 | 0.294 | 0.000 | 0: 0.294 | 0: 0.294 |
| value | head | A | scaleDown | 25,000 | 2,710,585 | 0.369 | 0.369 | 0.369 | 0.000 | 0: 0.369 | 0: 0.369 |
| value | head | A | fullLifecycle | 50,000 | 3,014,754 | 0.332 | 0.332 | 0.332 | 0.000 | 0: 0.332 | 0: 0.332 |
| value | random | A | scaleUp | 25,000 | 1,116,231 | 0.896 | 0.896 | 0.896 | 0.000 | 0: 0.896 | 0: 0.896 |
| value | random | A | scaleDown | 25,000 | 1,136,338 | 0.880 | 0.880 | 0.880 | 0.000 | 0: 0.880 | 0: 0.880 |
| value | random | A | fullLifecycle | 50,000 | 1,126,195 | 0.888 | 0.888 | 0.888 | 0.000 | 0: 0.888 | 0: 0.888 |
| value | tail | A | scaleUp | 25,000 | 6,888,950 | 0.145 | 0.145 | 0.145 | 0.000 | 0: 0.145 | 0: 0.145 |
| value | tail | A | scaleDown | 25,000 | 4,688,057 | 0.213 | 0.213 | 0.213 | 0.000 | 0: 0.213 | 0: 0.213 |
| value | tail | A | fullLifecycle | 50,000 | 5,579,299 | 0.179 | 0.179 | 0.179 | 0.000 | 0: 0.179 | 0: 0.179 |
| values | — | A | scaleUp | 6 | 118 | 8468.633 | 8468.633 | 8468.633 | 0.000 | 0: 8468.633 | 0: 8468.633 |
| values | — | A | scaleDown | 6 | 282 | 3540.517 | 3540.517 | 3540.517 | 0.000 | 0: 3540.517 | 0: 3540.517 |
| values | — | A | fullLifecycle | 12 | 167 | 6004.575 | 6004.575 | 6004.575 | 0.000 | 0: 6004.575 | 0: 6004.575 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5410752.667 | 427.165 | 8.478 |
| A | scaleDown | 5 | 4407357.600 | 432.094 | 8.548 |
| A | fullLifecycle | 11 | 4954664.000 | 429.144 | 8.506 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3116296.167 | 246.023 | 4.883 |
| A | scaleDown | 5 | 2595337.600 | 254.445 | 5.034 |
| A | fullLifecycle | 11 | 2879496.818 | 249.405 | 4.944 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 255,598 | 3.912 | 2.000 | 50.300 |
| apply | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 308,140 | 3.245 | 1.700 | 79.200 |
| apply | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 334,633 | 2.988 | 1.500 | 639.600 |
| apply | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 347,299 | 2.879 | 1.500 | 639.600 |
| apply | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 356,337 | 2.806 | 1.500 | 639.600 |
| apply | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 361,186 | 2.769 | 1.500 | 639.600 |
| apply | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 360,501 | 2.774 | 1.500 | 639.600 |
| apply | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 362,098 | 2.762 | 1.500 | 639.600 |
| apply | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 364,483 | 2.744 | 1.500 | 639.600 |
| apply | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 364,944 | 2.740 | 1.400 | 639.600 |
| apply | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 369,584 | 2.706 | 1.300 | 639.600 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 370,942 | 2.696 | 1.200 | 639.600 |
| insert | head | 0 | up | 1,000 | 50,007 | A | 500 | 947,867 | 1.055 | 0.400 | 40.200 |
| insert | head | 0 | up | 5,000 | 256,206 | A | 2,500 | 1,043,406 | 0.958 | 0.400 | 40.200 |
| insert | head | 0 | up | 10,000 | 508,328 | A | 5,000 | 1,177,856 | 0.849 | 0.300 | 162.500 |
| insert | head | 0 | up | 15,000 | 756,035 | A | 7,500 | 1,198,485 | 0.834 | 0.300 | 399.800 |
| insert | head | 0 | up | 20,000 | 1,005,850 | A | 10,000 | 1,269,116 | 0.788 | 0.300 | 399.800 |
| insert | head | 0 | up | 25,000 | 1,252,902 | A | 12,500 | 1,320,906 | 0.757 | 0.300 | 399.800 |
| insert | head | 0 | down | 20,000 | 1,007,225 | A | 12,500 | 1,320,906 | 0.757 | 0.300 | 399.800 |
| insert | head | 0 | down | 15,000 | 759,799 | A | 12,500 | 1,320,906 | 0.757 | 0.300 | 399.800 |
| insert | head | 0 | down | 10,000 | 506,363 | A | 12,500 | 1,320,906 | 0.757 | 0.300 | 399.800 |
| insert | head | 0 | down | 5,000 | 254,264 | A | 12,500 | 1,320,906 | 0.757 | 0.300 | 399.800 |
| insert | head | 0 | down | 1,000 | 50,210 | A | 12,500 | 1,320,906 | 0.757 | 0.300 | 399.800 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,320,906 | 0.757 | 0.300 | 399.800 |
| insert | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 564,239 | 1.772 | 0.500 | 324.600 |
| insert | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 536,579 | 1.864 | 0.500 | 587.600 |
| insert | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 572,987 | 1.745 | 0.500 | 1145.600 |
| insert | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 614,605 | 1.627 | 0.500 | 1145.600 |
| insert | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 633,607 | 1.578 | 0.500 | 1145.600 |
| insert | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 652,151 | 1.533 | 0.500 | 1145.600 |
| insert | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 633,188 | 1.579 | 0.500 | 1145.600 |
| insert | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 632,283 | 1.582 | 0.500 | 1145.600 |
| insert | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 631,362 | 1.584 | 0.500 | 1145.600 |
| insert | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 638,840 | 1.565 | 0.500 | 1145.600 |
| insert | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 654,464 | 1.528 | 0.300 | 1145.600 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 658,885 | 1.518 | 0.300 | 1145.600 |
| insert | tail | 0 | up | 1,000 | 50,007 | A | 500 | 1,211,827 | 0.825 | 0.300 | 16.800 |
| insert | tail | 0 | up | 5,000 | 256,206 | A | 2,500 | 1,214,949 | 0.823 | 0.300 | 54.400 |
| insert | tail | 0 | up | 10,000 | 508,328 | A | 5,000 | 1,395,751 | 0.716 | 0.300 | 74.500 |
| insert | tail | 0 | up | 15,000 | 756,035 | A | 7,500 | 1,469,234 | 0.681 | 0.300 | 160.400 |
| insert | tail | 0 | up | 20,000 | 1,005,850 | A | 10,000 | 1,544,330 | 0.648 | 0.300 | 160.400 |
| insert | tail | 0 | up | 25,000 | 1,252,902 | A | 12,500 | 1,525,879 | 0.655 | 0.300 | 309.300 |
| insert | tail | 0 | down | 20,000 | 1,007,225 | A | 12,500 | 1,525,879 | 0.655 | 0.300 | 309.300 |
| insert | tail | 0 | down | 15,000 | 759,799 | A | 12,500 | 1,525,879 | 0.655 | 0.300 | 309.300 |
| insert | tail | 0 | down | 10,000 | 506,363 | A | 12,500 | 1,525,879 | 0.655 | 0.300 | 309.300 |
| insert | tail | 0 | down | 5,000 | 254,264 | A | 12,500 | 1,525,879 | 0.655 | 0.300 | 309.300 |
| insert | tail | 0 | down | 1,000 | 50,210 | A | 12,500 | 1,525,879 | 0.655 | 0.300 | 309.300 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,525,879 | 0.655 | 0.300 | 309.300 |
| remove | head | 0 | up | 1,000 | 50,007 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 256,206 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 508,328 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 756,035 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,005,850 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,252,902 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,007,225 | A | 2,500 | 789,715 | 1.266 | 0.800 | 7.800 |
| remove | head | 0 | down | 15,000 | 759,799 | A | 5,000 | 786,275 | 1.272 | 0.800 | 48.000 |
| remove | head | 0 | down | 10,000 | 506,363 | A | 7,500 | 752,513 | 1.329 | 0.700 | 606.800 |
| remove | head | 0 | down | 5,000 | 254,264 | A | 10,000 | 770,992 | 1.297 | 0.700 | 606.800 |
| remove | head | 0 | down | 1,000 | 50,210 | A | 12,000 | 793,913 | 1.260 | 0.700 | 606.800 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 798,258 | 1.253 | 0.700 | 606.800 |
| remove | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 515,650 | 1.939 | 0.900 | 28.800 |
| remove | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 533,658 | 1.874 | 0.900 | 109.200 |
| remove | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 547,507 | 1.826 | 0.900 | 326.800 |
| remove | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 563,097 | 1.776 | 0.900 | 326.800 |
| remove | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 566,909 | 1.764 | 0.900 | 326.800 |
| remove | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 573,037 | 1.745 | 0.900 | 326.800 |
| remove | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 564,795 | 1.771 | 0.900 | 326.800 |
| remove | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 560,843 | 1.783 | 0.900 | 326.800 |
| remove | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 562,506 | 1.778 | 0.900 | 326.800 |
| remove | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 567,113 | 1.763 | 0.900 | 326.800 |
| remove | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 576,205 | 1.735 | 0.800 | 326.800 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 579,415 | 1.726 | 0.800 | 326.800 |
| remove | tail | 0 | up | 1,000 | 50,007 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 256,206 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 508,328 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 756,035 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,005,850 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,252,902 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,007,225 | A | 2,500 | 876,947 | 1.140 | 0.800 | 44.200 |
| remove | tail | 0 | down | 15,000 | 759,799 | A | 5,000 | 852,006 | 1.174 | 0.700 | 54.700 |
| remove | tail | 0 | down | 10,000 | 506,363 | A | 7,500 | 815,235 | 1.227 | 0.700 | 490.200 |
| remove | tail | 0 | down | 5,000 | 254,264 | A | 10,000 | 834,516 | 1.198 | 0.700 | 490.200 |
| remove | tail | 0 | down | 1,000 | 50,210 | A | 12,000 | 857,461 | 1.166 | 0.600 | 490.200 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 862,432 | 1.160 | 0.600 | 490.200 |
| replace | head | 0 | up | 1,000 | 50,007 | A | 1,000 | 356,532 | 2.805 | 1.300 | 565.400 |
| replace | head | 0 | up | 5,000 | 256,206 | A | 5,000 | 411,784 | 2.428 | 1.300 | 918.900 |
| replace | head | 0 | up | 10,000 | 508,328 | A | 10,000 | 482,404 | 2.073 | 1.100 | 918.900 |
| replace | head | 0 | up | 15,000 | 756,035 | A | 15,000 | 514,612 | 1.943 | 1.100 | 918.900 |
| replace | head | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 538,209 | 1.858 | 1.000 | 918.900 |
| replace | head | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 535,417 | 1.868 | 1.000 | 1015.100 |
| replace | head | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 533,122 | 1.876 | 1.000 | 1015.100 |
| replace | head | 0 | down | 15,000 | 759,799 | A | 35,000 | 531,743 | 1.881 | 1.000 | 1015.100 |
| replace | head | 0 | down | 10,000 | 506,363 | A | 40,000 | 533,514 | 1.874 | 1.000 | 1015.100 |
| replace | head | 0 | down | 5,000 | 254,264 | A | 45,000 | 534,080 | 1.872 | 1.000 | 1015.100 |
| replace | head | 0 | down | 1,000 | 50,210 | A | 49,000 | 541,417 | 1.847 | 1.000 | 1015.100 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 543,112 | 1.841 | 0.900 | 1015.100 |
| replace | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 342,372 | 2.921 | 1.300 | 298.200 |
| replace | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 361,327 | 2.768 | 1.300 | 409.200 |
| replace | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 392,368 | 2.549 | 1.200 | 409.200 |
| replace | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 381,979 | 2.618 | 1.200 | 756.200 |
| replace | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 380,626 | 2.627 | 1.100 | 1462.600 |
| replace | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 377,770 | 2.647 | 1.100 | 1916.600 |
| replace | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 379,729 | 2.633 | 1.100 | 1916.600 |
| replace | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 373,120 | 2.680 | 1.100 | 1916.600 |
| replace | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 380,112 | 2.631 | 1.100 | 1916.600 |
| replace | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 384,469 | 2.601 | 1.100 | 1916.600 |
| replace | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 393,546 | 2.541 | 1.100 | 1916.600 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 396,417 | 2.523 | 0.900 | 1916.600 |
| replace | tail | 0 | up | 1,000 | 50,007 | A | 1,000 | 439,116 | 2.277 | 1.100 | 98.700 |
| replace | tail | 0 | up | 5,000 | 256,206 | A | 5,000 | 477,186 | 2.096 | 1.100 | 250.200 |
| replace | tail | 0 | up | 10,000 | 508,328 | A | 10,000 | 530,611 | 1.885 | 1.000 | 250.200 |
| replace | tail | 0 | up | 15,000 | 756,035 | A | 15,000 | 551,315 | 1.814 | 1.000 | 250.200 |
| replace | tail | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 561,166 | 1.782 | 1.000 | 305.400 |
| replace | tail | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 570,759 | 1.752 | 1.000 | 305.400 |
| replace | tail | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 478,095 | 2.092 | 1.000 | 2341.800 |
| replace | tail | 0 | down | 15,000 | 759,799 | A | 35,000 | 320,921 | 3.116 | 1.000 | 2341.800 |
| replace | tail | 0 | down | 10,000 | 506,363 | A | 40,000 | 330,032 | 3.030 | 1.000 | 2341.800 |
| replace | tail | 0 | down | 5,000 | 254,264 | A | 45,000 | 299,494 | 3.339 | 1.000 | 2341.800 |
| replace | tail | 0 | down | 1,000 | 50,210 | A | 49,000 | 303,586 | 3.294 | 1.000 | 2341.800 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 306,334 | 3.264 | 0.900 | 2341.800 |
| value | head | 0 | up | 1,000 | 50,007 | A | 1,000 | 1,389,082 | 0.720 | 0.100 | 340.900 |
| value | head | 0 | up | 5,000 | 256,206 | A | 5,000 | 2,425,183 | 0.412 | 0.100 | 340.900 |
| value | head | 0 | up | 10,000 | 508,328 | A | 10,000 | 2,871,583 | 0.348 | 0.100 | 340.900 |
| value | head | 0 | up | 15,000 | 756,035 | A | 15,000 | 3,102,058 | 0.322 | 0.100 | 340.900 |
| value | head | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 3,276,808 | 0.305 | 0.100 | 340.900 |
| value | head | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 3,395,816 | 0.294 | 0.100 | 340.900 |
| value | head | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 3,280,087 | 0.305 | 0.100 | 340.900 |
| value | head | 0 | down | 15,000 | 759,799 | A | 35,000 | 3,150,570 | 0.317 | 0.100 | 340.900 |
| value | head | 0 | down | 10,000 | 506,363 | A | 40,000 | 3,079,126 | 0.325 | 0.100 | 340.900 |
| value | head | 0 | down | 5,000 | 254,264 | A | 45,000 | 3,048,512 | 0.328 | 0.100 | 340.900 |
| value | head | 0 | down | 1,000 | 50,210 | A | 49,000 | 3,019,901 | 0.331 | 0.100 | 340.900 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 3,014,754 | 0.332 | 0.100 | 340.900 |
| value | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 1,306,677 | 0.765 | 0.100 | 34.300 |
| value | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 1,127,930 | 0.887 | 0.100 | 34.600 |
| value | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 1,130,199 | 0.885 | 0.100 | 34.600 |
| value | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 1,095,570 | 0.913 | 0.100 | 52.600 |
| value | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 1,113,307 | 0.898 | 0.100 | 52.600 |
| value | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 1,116,231 | 0.896 | 0.100 | 68.400 |
| value | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 1,101,597 | 0.908 | 0.100 | 68.400 |
| value | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 1,087,930 | 0.919 | 0.100 | 68.400 |
| value | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 1,092,120 | 0.916 | 0.100 | 68.400 |
| value | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 1,094,230 | 0.914 | 0.100 | 68.400 |
| value | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 1,117,420 | 0.895 | 0.100 | 68.400 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 1,126,195 | 0.888 | 0.100 | 68.400 |
| value | tail | 0 | up | 1,000 | 50,007 | A | 1,000 | 5,910,165 | 0.169 | 0.100 | 1.900 |
| value | tail | 0 | up | 5,000 | 256,206 | A | 5,000 | 5,517,546 | 0.181 | 0.100 | 1.900 |
| value | tail | 0 | up | 10,000 | 508,328 | A | 10,000 | 5,987,665 | 0.167 | 0.100 | 6.700 |
| value | tail | 0 | up | 15,000 | 756,035 | A | 15,000 | 6,322,978 | 0.158 | 0.000 | 13.200 |
| value | tail | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 6,663,779 | 0.150 | 0.000 | 13.200 |
| value | tail | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 6,888,950 | 0.145 | 0.000 | 13.200 |
| value | tail | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 6,348,400 | 0.158 | 0.000 | 13.400 |
| value | tail | 0 | down | 15,000 | 759,799 | A | 35,000 | 6,017,778 | 0.166 | 0.000 | 13.400 |
| value | tail | 0 | down | 10,000 | 506,363 | A | 40,000 | 5,792,736 | 0.173 | 0.000 | 14.600 |
| value | tail | 0 | down | 5,000 | 254,264 | A | 45,000 | 5,660,947 | 0.177 | 0.000 | 14.600 |
| value | tail | 0 | down | 1,000 | 50,210 | A | 49,000 | 5,587,165 | 0.179 | 0.000 | 17.300 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,579,299 | 0.179 | 0.000 | 17.300 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,727 | 366.700 |
| create | — | 0 | up | 5,000 | A | 1 | 1,084 | 922.800 |
| create | — | 0 | up | 10,000 | A | 1 | 641 | 1559.200 |
| create | — | 0 | up | 15,000 | A | 1 | 479 | 2086.100 |
| create | — | 0 | up | 20,000 | A | 1 | 287 | 3483.700 |
| create | — | 0 | up | 25,000 | A | 1 | 250 | 3992.100 |
| create | — | 0 | down | 20,000 | A | 1 | 290 | 3449.000 |
| create | — | 0 | down | 15,000 | A | 1 | 388 | 2579.000 |
| create | — | 0 | down | 10,000 | A | 1 | 568 | 1761.800 |
| create | — | 0 | down | 5,000 | A | 1 | 1,242 | 805.400 |
| create | — | 0 | down | 1,000 | A | 1 | 7,278 | 137.400 |
| create | — | 0 | down | 0 | A | 1 | 66,667 | 15.000 |
| sequence | — | 0 | up | 1,000 | A | 1 | 449 | 2227.100 |
| sequence | — | 0 | up | 5,000 | A | 1 | 134 | 7446.600 |
| sequence | — | 0 | up | 10,000 | A | 1 | 88 | 11307.800 |
| sequence | — | 0 | up | 15,000 | A | 1 | 74 | 13605.400 |
| sequence | — | 0 | up | 20,000 | A | 1 | 53 | 18783.500 |
| sequence | — | 0 | up | 25,000 | A | 1 | 49 | 20249.100 |
| sequence | — | 0 | down | 20,000 | A | 1 | 61 | 16480.800 |
| sequence | — | 0 | down | 15,000 | A | 1 | 73 | 13670.400 |
| sequence | — | 0 | down | 10,000 | A | 1 | 91 | 11043.300 |
| sequence | — | 0 | down | 5,000 | A | 1 | 113 | 8886.700 |
| sequence | — | 0 | down | 1,000 | A | 1 | 196 | 5102.600 |
| sequence | — | 0 | down | 0 | A | 1 | 814 | 1228.500 |
| values | — | 0 | up | 1,000 | A | 1 | 608 | 1644.000 |
| values | — | 0 | up | 5,000 | A | 1 | 219 | 4569.500 |
| values | — | 0 | up | 10,000 | A | 1 | 52 | 19415.100 |
| values | — | 0 | up | 15,000 | A | 1 | 136 | 7369.200 |
| values | — | 0 | up | 20,000 | A | 1 | 122 | 8194.000 |
| values | — | 0 | up | 25,000 | A | 1 | 104 | 9620.000 |
| values | — | 0 | down | 20,000 | A | 1 | 133 | 7540.700 |
| values | — | 0 | down | 15,000 | A | 1 | 158 | 6347.900 |
| values | — | 0 | down | 10,000 | A | 1 | 219 | 4570.500 |
| values | — | 0 | down | 5,000 | A | 1 | 420 | 2379.100 |
| values | — | 0 | down | 1,000 | A | 1 | 2,535 | 394.400 |
| values | — | 0 | down | 0 | A | 1 | 95,238 | 10.500 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.613 | 0.232 | 0.382 |
| 0 | up | 5000 | 3.122 | 1.167 | 1.955 |
| 0 | up | 10000 | 6.220 | 2.342 | 3.878 |
| 0 | up | 15000 | 9.408 | 3.640 | 5.768 |
| 0 | up | 20000 | 12.780 | 5.106 | 7.674 |
| 0 | up | 25000 | 16.189 | 6.630 | 9.559 |
| 0 | down | 20000 | 13.291 | 5.606 | 7.685 |
| 0 | down | 15000 | 9.922 | 4.125 | 5.797 |
| 0 | down | 10000 | 7.152 | 3.289 | 3.863 |
| 0 | down | 5000 | 4.095 | 2.155 | 1.940 |
| 0 | down | 1000 | 1.797 | 1.414 | 0.383 |
| 0 | down | 0 | 1.224 | 1.224 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 50,007 | 0.402 | 421.580 | 8.430 | 121.371 | 15.527 |
| 0 | up | A | 5,000 | 5,000 | 256,206 | 2.057 | 431.302 | 8.417 | 154.688 | 19.655 |
| 0 | up | A | 10,000 | 10,000 | 508,328 | 4.090 | 428.881 | 8.437 | 196.004 | 24.526 |
| 0 | up | A | 15,000 | 15,000 | 756,035 | 6.108 | 426.991 | 8.472 | 209.992 | 29.295 |
| 0 | up | A | 20,000 | 20,000 | 1,005,850 | 8.143 | 426.916 | 8.489 | 281.375 | 34.105 |
| 0 | up | A | 25,000 | 25,000 | 1,252,902 | 10.161 | 426.177 | 8.504 | 295.535 | 38.840 |
| 0 | down | A | 20,000 | 20,000 | 1,007,225 | 8.223 | 431.124 | 8.561 | 296.980 | 34.153 |
| 0 | down | A | 15,000 | 15,000 | 759,799 | 6.203 | 433.606 | 8.560 | 302.672 | 29.427 |
| 0 | down | A | 10,000 | 10,000 | 506,363 | 4.124 | 432.479 | 8.541 | 299.547 | 24.629 |
| 0 | down | A | 5,000 | 5,000 | 254,264 | 2.060 | 431.993 | 8.495 | 298.051 | 19.850 |
| 0 | down | A | 1,000 | 1,000 | 50,210 | 0.406 | 425.476 | 8.474 | 296.633 | 15.980 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 297.684 | 14.908 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 50007 | 184507 | 184.507 | 3.690 | 272.03 | 14.52 | 162.13 | 12.30 |
| 0 | up | A | 5000 | 256206 | 1218174 | 243.635 | 4.755 | 1644.25 | 73.50 | 830.68 | 61.66 |
| 0 | up | A | 10000 | 508328 | 2441689 | 244.169 | 4.803 | 3276.35 | 148.92 | 1655.21 | 124.79 |
| 0 | up | A | 15000 | 756035 | 3694120 | 246.275 | 4.886 | 4916.66 | 225.99 | 3545.68 | 200.14 |
| 0 | up | A | 20000 | 1005850 | 4950983 | 247.549 | 4.922 | 7073.44 | 311.23 | 5103.00 | 263.55 |
| 0 | up | A | 25000 | 1252902 | 6208304 | 248.332 | 4.955 | 9192.05 | 392.29 | 6496.81 | 335.16 |
| 0 | down | A | 20000 | 1007225 | 5103545 | 255.177 | 5.067 | 7538.07 | 326.43 | 5289.65 | 278.22 |
| 0 | down | A | 15000 | 759799 | 3844421 | 256.295 | 5.060 | 5730.74 | 247.34 | 4004.94 | 209.82 |
| 0 | down | A | 10000 | 506363 | 2541344 | 254.134 | 5.019 | 3828.12 | 165.02 | 2670.80 | 139.89 |
| 0 | down | A | 5000 | 254264 | 1247949 | 249.590 | 4.908 | 1909.46 | 79.58 | 1334.90 | 67.69 |
| 0 | down | A | 1000 | 50210 | 239429 | 239.429 | 4.769 | 375.26 | 16.04 | 262.97 | 13.69 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 427.165 | 8.478 | 246.023 | 4.883 |
| 0 | A | scaleDown | 432.094 | 8.548 | 254.445 | 5.034 |
| 0 | A | fullLifecycle | 429.144 | 8.506 | 249.405 | 4.944 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
