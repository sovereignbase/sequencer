# Large string benchmarks

2026-11-27T17:29:12.273Z · local run

1 runs; times are median ns/call. IQR is Q3 minus Q1.

| UTF-16 code units | Operation | Representation | Median ns | IQR ns |
| ---: | --- | --- | ---: | ---: |
| 1024 | insert | array | 2055.62 | 0.00 |
| 1024 | insert.append | array | 11903.24 | 0.00 |
| 1024 | replace | array | 2723.67 | 0.00 |
| 1024 | remove | array | 1111.67 | 0.00 |
| 1024 | remove.middle | array | 1840.61 | 0.00 |
| 1024 | replace.middle | array | 2092.02 | 0.00 |
| 1024 | apply | array | 683.42 | 0.00 |
| 1024 | apply.array | array | 615.44 | 0.00 |
| 1024 | concurrent.apply | array | 64727.39 | 0.00 |
| 1024 | merge | array | 2746.75 | 0.00 |
| 1024 | create | array | 2653.19 | 0.00 |
| 1024 | value.random | array | 42.39 | 0.00 |
| 1024 | values.range | array | 99.08 | 0.00 |
| 1024 | values.array | array | 1123.63 | 0.00 |
| 1024 | values.text | array | 12731.21 | 0.00 |
| 1024 | sequence.array | array | 1441.12 | 0.00 |
| 1024 | sequence.text | array | 9399.36 | 0.00 |
| 1024 | sequence.edited.text | array | 14311.28 | 0.00 |
| 1024 | sequence.masked.text | array | 11062.56 | 0.00 |
| 1024 | insert | string | 527.51 | 0.00 |
| 1024 | insert.append | string | 4317.29 | 0.00 |
| 1024 | replace | string | 1254.72 | 0.00 |
| 1024 | remove | string | 1040.27 | 0.00 |
| 1024 | remove.middle | string | 1017.60 | 0.00 |
| 1024 | replace.middle | string | 1417.04 | 0.00 |
| 1024 | apply | string | 791.08 | 0.00 |
| 1024 | apply.array | string | 2175.17 | 0.00 |
| 1024 | concurrent.apply | string | 3548.74 | 0.00 |
| 1024 | merge | string | 1297.58 | 0.00 |
| 1024 | create | string | 1023.45 | 0.00 |
| 1024 | value.random | string | 52.45 | 0.00 |
| 1024 | values.range | string | 142.37 | 0.00 |
| 1024 | values.array | string | 1619.69 | 0.00 |
| 1024 | values.text | string | 67.84 | 0.00 |
| 1024 | sequence.array | string | 1878.80 | 0.00 |
| 1024 | sequence.text | string | 191.69 | 0.00 |
| 1024 | sequence.edited.text | string | 2096.13 | 0.00 |
| 1024 | sequence.masked.text | string | 3298.62 | 0.00 |
| 65536 | insert | array | 223975.00 | 0.00 |
| 65536 | insert.append | array | 987007.69 | 0.00 |
| 65536 | replace | array | 235896.23 | 0.00 |
| 65536 | remove | array | 2523.63 | 0.00 |
| 65536 | remove.middle | array | 197448.03 | 0.00 |
| 65536 | replace.middle | array | 208740.00 | 0.00 |
| 65536 | apply | array | 899.38 | 0.00 |
| 65536 | apply.array | array | 536.44 | 0.00 |
| 65536 | concurrent.apply | array | 3850285.71 | 0.00 |
| 65536 | merge | array | 223537.01 | 0.00 |
| 65536 | create | array | 214914.96 | 0.00 |
| 65536 | value.random | array | 48.70 | 0.00 |
| 65536 | values.range | array | 125.04 | 0.00 |
| 65536 | values.array | array | 189761.36 | 0.00 |
| 65536 | values.text | array | 784459.37 | 0.00 |
| 65536 | sequence.array | array | 191735.88 | 0.00 |
| 65536 | sequence.text | array | 668750.00 | 0.00 |
| 65536 | sequence.edited.text | array | 882062.07 | 0.00 |
| 65536 | sequence.masked.text | array | 665110.53 | 0.00 |
| 65536 | insert | string | 522.05 | 0.00 |
| 65536 | insert.append | string | 20009.92 | 0.00 |
| 65536 | replace | string | 1284.58 | 0.00 |
| 65536 | remove | string | 873.10 | 0.00 |
| 65536 | remove.middle | string | 913.76 | 0.00 |
| 65536 | replace.middle | string | 1241.03 | 0.00 |
| 65536 | apply | string | 717.32 | 0.00 |
| 65536 | apply.array | string | 234417.19 | 0.00 |
| 65536 | concurrent.apply | string | 132155.79 | 0.00 |
| 65536 | merge | string | 1007.76 | 0.00 |
| 65536 | create | string | 932.90 | 0.00 |
| 65536 | value.random | string | 45.60 | 0.00 |
| 65536 | values.range | string | 134.44 | 0.00 |
| 65536 | values.array | string | 213363.28 | 0.00 |
| 65536 | values.text | string | 62.36 | 0.00 |
| 65536 | sequence.array | string | 223464.84 | 0.00 |
| 65536 | sequence.text | string | 189.20 | 0.00 |
| 65536 | sequence.edited.text | string | 83571.00 | 0.00 |
| 65536 | sequence.masked.text | string | 2933.09 | 0.00 |
| 1048576 | insert | array | 3166700.00 | 0.00 |
| 1048576 | insert.append | array | 22988100.00 | 0.00 |
| 1048576 | replace | array | 2838133.33 | 0.00 |
| 1048576 | remove | array | 17212.52 | 0.00 |
| 1048576 | remove.middle | array | 4368200.00 | 0.00 |
| 1048576 | replace.middle | array | 3355811.11 | 0.00 |
| 1048576 | apply | array | 1483.06 | 0.00 |
| 1048576 | apply.array | array | 712.40 | 0.00 |
| 1048576 | concurrent.apply | array | 81207900.00 | 0.00 |
| 1048576 | merge | array | 3684900.00 | 0.00 |
| 1048576 | create | array | 3983800.00 | 0.00 |
| 1048576 | value.random | array | 51.22 | 0.00 |
| 1048576 | values.range | array | 114.66 | 0.00 |
| 1048576 | values.array | array | 2591720.00 | 0.00 |
| 1048576 | values.text | array | 14581950.00 | 0.00 |
| 1048576 | sequence.array | array | 3247875.00 | 0.00 |
| 1048576 | sequence.text | array | 85281450.00 | 0.00 |
| 1048576 | sequence.edited.text | array | 76623300.00 | 0.00 |
| 1048576 | sequence.masked.text | array | 81108800.00 | 0.00 |
| 1048576 | insert | string | 521.68 | 0.00 |
| 1048576 | insert.append | string | 597211.90 | 0.00 |
| 1048576 | replace | string | 1726.27 | 0.00 |
| 1048576 | remove | string | 1186.38 | 0.00 |
| 1048576 | remove.middle | string | 1148.96 | 0.00 |
| 1048576 | replace.middle | string | 1405.26 | 0.00 |
| 1048576 | apply | string | 1377.43 | 0.00 |
| 1048576 | apply.array | string | 3787757.14 | 0.00 |
| 1048576 | concurrent.apply | string | 1400322.22 | 0.00 |
| 1048576 | merge | string | 1320.80 | 0.00 |
| 1048576 | create | string | 1038.65 | 0.00 |
| 1048576 | value.random | string | 50.29 | 0.00 |
| 1048576 | values.range | string | 139.81 | 0.00 |
| 1048576 | values.array | string | 3279112.50 | 0.00 |
| 1048576 | values.text | string | 82.86 | 0.00 |
| 1048576 | sequence.array | string | 3392912.50 | 0.00 |
| 1048576 | sequence.text | string | 203.09 | 0.00 |
| 1048576 | sequence.edited.text | string | 1604212.50 | 0.00 |
| 1048576 | sequence.masked.text | string | 3379.45 | 0.00 |

Encoded snapshots use string Footage in both representations.

## Estimated retained memory and snapshot size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
| 1024 | array | 0.0082 | 1.02 | 0.04 | 2.02 | 0.05 |
| 1024 | string | 0.0023 | 1.02 | 0.04 | 1.02 | 0.05 |
| 65536 | array | 0.5004 | 64.02 | 0.12 | 128.02 | 0.18 |
| 65536 | string | 0.1254 | 64.02 | 0.12 | 64.02 | 0.12 |
| 1048576 | array | 8.0004 | 1024.02 | 1.05 | 2048.02 | 2.05 |
| 1048576 | string | 2.0004 | 1024.02 | 1.05 | 1024.02 | 1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.
