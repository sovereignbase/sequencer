# Tuple benchmarks

2026-11-27T17:28:57.899Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

## Throughput (ops/s)

| Indices | Method / case | Projection | Static tuple | Tuple / Projection |
| ---: | --- | ---: | ---: | ---: |
| 2 | create.empty | 2,945,610 | 2,363,851 | 0.80× |
| 2 | create.sequence | 984,651 | 842,366 | 0.86× |
| 2 | replace.random | 1,136,510 | 1,697,445 | 1.49× |
| 2 | apply.replace | 762,674 | 933,943 | 1.22× |
| 2 | apply.duplicate | 1,791,968 | 1,788,121 | 1.00× |
| 2 | merge.duplicate | 1,623,995 | 1,595,929 | 0.98× |
| 2 | length | 132,984,632 | 140,186,456 | 1.05× |
| 2 | value.random | 32,475,533 | 54,567,968 | 1.68× |
| 2 | values | 12,645,626 | 13,408,626 | 1.06× |
| 2 | sequence | 3,484,778 | 3,071,507 | 0.88× |
| 4 | create.empty | 2,265,889 | 2,407,712 | 1.06× |
| 4 | create.sequence | 735,458 | 722,157 | 0.98× |
| 4 | replace.random | 1,111,120 | 1,445,661 | 1.30× |
| 4 | apply.replace | 687,072 | 963,043 | 1.40× |
| 4 | apply.duplicate | 1,702,033 | 1,717,348 | 1.01× |
| 4 | merge.duplicate | 1,264,246 | 1,266,660 | 1.00× |
| 4 | length | 36,248,718 | 40,389,809 | 1.11× |
| 4 | value.random | 24,479,170 | 56,321,100 | 2.30× |
| 4 | values | 6,986,240 | 7,449,342 | 1.07× |
| 4 | sequence | 2,817,339 | 2,784,695 | 0.99× |
| 8 | create.empty | 2,648,785 | 2,267,398 | 0.86× |
| 8 | create.sequence | 469,258 | 221,498 | 0.47× |
| 8 | replace.random | 948,498 | 1,576,628 | 1.66× |
| 8 | apply.replace | 657,918 | 1,048,912 | 1.59× |
| 8 | apply.duplicate | 1,817,368 | 1,798,564 | 0.99× |
| 8 | merge.duplicate | 969,953 | 875,374 | 0.90× |
| 8 | length | 35,765,186 | 39,309,571 | 1.10× |
| 8 | value.random | 19,507,846 | 56,875,873 | 2.92× |
| 8 | values | 4,700,687 | 4,807,435 | 1.02× |
| 8 | sequence | 1,713,125 | 1,897,098 | 1.11× |
| 100 | create.empty | 2,489,717 | 2,228,500 | 0.90× |
| 100 | create.sequence | 68,399 | 88,376 | 1.29× |
| 100 | replace.random | 979,840 | 1,621,819 | 1.66× |
| 100 | apply.replace | 662,813 | 1,061,830 | 1.60× |
| 100 | apply.duplicate | 1,588,625 | 1,659,301 | 1.04× |
| 100 | merge.duplicate | 96,785 | 69,956 | 0.72× |
| 100 | length | 37,149,962 | 39,725,710 | 1.07× |
| 100 | value.random | 13,576,682 | 50,351,885 | 3.71× |
| 100 | values | 531,415 | 685,483 | 1.29× |
| 100 | sequence | 187,787 | 200,314 | 1.07× |

## Memory and encoded size

| Indices | Mode | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ---: | --- | ---: | ---: | ---: |
| 2 | Projection | 0.0006 | 0.03 | 0.04 |
| 2 | Static tuple | 0.0007 | 0.04 | 0.05 |
| 4 | Projection | 0.0013 | 0.06 | 0.05 |
| 4 | Static tuple | 0.0009 | 0.06 | 0.07 |
| 8 | Projection | 0.0022 | 0.12 | 0.08 |
| 8 | Static tuple | 0.0013 | 0.10 | 0.09 |
| 100 | Projection | 0.0196 | 0.67 | 0.57 |
| 100 | Static tuple | 0.0110 | 0.51 | 0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.
