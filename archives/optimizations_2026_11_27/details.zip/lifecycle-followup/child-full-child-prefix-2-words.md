# Words benchmarks

2026-11-27T17:29:33.630Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload | Words | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| append | unpacked | 5.90 | 3.61 | 22.88 | 28,475 | 190,551 | 130 |
| append | packed | 5.90 | 3.61 | 13.98 | 23,067 | 163,495 | 319 |
| prepend | unpacked | 40.07 | 18.06 | 22.94 | 1,710 | 678 | 206 |
| prepend | packed | 5.90 | 3.62 | 13.99 | 27,911 | 1,448 | 229 |
| random | unpacked | 138.05 | 57.31 | 39.88 | 469 | 192 | 88 |
| random | packed | 49.58 | 35.38 | 23.45 | 14,696 | 521 | 117 |
| concurrent | unpacked | 92.24 | 42.76 | 32.34 | 611 | 214 | 109 |
| concurrent | packed | 38.94 | 28.15 | 20.71 | 16,197 | 413 | 147 |

## API and transport latency

| Workload | Words | Operation | Median ns | IQR ns |
| --- | --- | --- | ---: | ---: |
| append | numeric | sequence | 603.05 | 0.00 |
| append | numeric | encode | 35119.10 | 0.00 |
| append | numeric | decode | 3143.21 | 0.00 |
| append | numeric | create | 2152.33 | 0.00 |
| append | numeric | load | 5247.94 | 0.00 |
| append | numeric | apply | 3984146.15 | 0.00 |
| append | numeric | receive | 7677071.43 | 0.00 |
| append | binary | sequence | 663.42 | 0.00 |
| append | binary | encode | 43352.08 | 0.00 |
| append | binary | decode | 1971.55 | 0.00 |
| append | binary | create | 2361.96 | 0.00 |
| append | binary | load | 6116.39 | 0.00 |
| append | binary | apply | 1988400.00 | 0.00 |
| append | binary | receive | 3131431.25 | 0.00 |
| prepend | numeric | sequence | 538323.66 | 0.00 |
| prepend | numeric | encode | 584644.19 | 0.00 |
| prepend | numeric | decode | 311298.76 | 0.00 |
| prepend | numeric | create | 719967.14 | 0.00 |
| prepend | numeric | load | 1474350.00 | 0.00 |
| prepend | numeric | apply | 2632610.53 | 0.00 |
| prepend | numeric | receive | 4864763.64 | 0.00 |
| prepend | binary | sequence | 406624.19 | 0.00 |
| prepend | binary | encode | 35827.79 | 0.00 |
| prepend | binary | decode | 2464.72 | 0.00 |
| prepend | binary | create | 677801.35 | 0.00 |
| prepend | binary | load | 690779.45 | 0.00 |
| prepend | binary | apply | 3066252.94 | 0.00 |
| prepend | binary | receive | 4357391.67 | 0.00 |
| random | numeric | sequence | 1046972.92 | 0.00 |
| random | numeric | encode | 2133300.00 | 0.00 |
| random | numeric | decode | 1125853.33 | 0.00 |
| random | numeric | create | 1899900.00 | 0.00 |
| random | numeric | load | 5211130.00 | 0.00 |
| random | numeric | apply | 9226316.67 | 0.00 |
| random | numeric | receive | 11350100.00 | 0.00 |
| random | binary | sequence | 882573.68 | 0.00 |
| random | binary | encode | 68046.47 | 0.00 |
| random | binary | decode | 2165.74 | 0.00 |
| random | binary | create | 1832453.57 | 0.00 |
| random | binary | load | 1918655.56 | 0.00 |
| random | binary | apply | 6266512.50 | 0.00 |
| random | binary | receive | 8516266.67 | 0.00 |
| concurrent | numeric | sequence | 821354.10 | 0.00 |
| concurrent | numeric | encode | 1636625.81 | 0.00 |
| concurrent | numeric | decode | 811783.87 | 0.00 |
| concurrent | numeric | create | 2252291.30 | 0.00 |
| concurrent | numeric | load | 4681772.73 | 0.00 |
| concurrent | numeric | apply | 5690300.00 | 0.00 |
| concurrent | numeric | receive | 9172916.67 | 0.00 |
| concurrent | binary | sequence | 700662.50 | 0.00 |
| concurrent | binary | encode | 61739.14 | 0.00 |
| concurrent | binary | decode | 2181.69 | 0.00 |
| concurrent | binary | create | 2256560.87 | 0.00 |
| concurrent | binary | load | 2421580.95 | 0.00 |
| concurrent | binary | apply | 5158310.00 | 0.00 |
| concurrent | binary | receive | 6822062.50 | 0.00 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.
