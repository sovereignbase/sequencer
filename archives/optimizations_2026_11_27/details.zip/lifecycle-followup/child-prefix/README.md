[![npm version](https://img.shields.io/npm/v/@sovereignbase/sequencer)](https://www.npmjs.com/package/@sovereignbase/sequencer)
[![JSR](https://jsr.io/badges/@sovereignbase/sequencer)](https://jsr.io/@sovereignbase/sequencer)
[![CI](https://github.com/sovereignbase/sequencer/actions/workflows/ci.yaml/badge.svg?branch=master)](https://github.com/sovereignbase/sequencer/actions/workflows/ci.yaml)
[![codecov](https://codecov.io/gh/sovereignbase/sequencer/branch/master/graph/badge.svg)](https://codecov.io/gh/sovereignbase/sequencer)
[![license](https://img.shields.io/npm/l/@sovereignbase/sequencer)](https://github.com/sovereignbase/sequencer/blob/master/LICENSE)

# Sequencer

Sequencer provides a total order guarantee for distributed editing. It allows independently operating actors to make concurrent edits and eventually converge on the same state without relying on network arrival order or perfectly synchronized clocks.

## Contents

- [Projection](#projection) · [Usage](#projection-usage) · [Benchmarks](#projection-benchmarks)
- [Tuple mode](#tuple-mode) · [Usage](#tuple-usage) · [Benchmarks](#tuple-benchmarks)
- [Text mode](#text-mode) · [Usage](#text-usage) · [Benchmarks](#text-benchmarks)
- [Packed words](#packed-words) · [Usage](#packed-words-usage) · [Benchmarks](#packed-words-benchmarks)
- [Batch](#batch) · [Usage](#batch-usage) · [Benchmarks](#batch-benchmarks)
- [Errors](#errors) · [Tests](#tests)
- [Credits](#credits) · [License](#license)

## Projection

<a id="projection-usage"></a>

### Usage

```ts
import { Projection } from '@sovereignbase/sequencer'

const projectionA = new Projection<string>(1)

const projectionB = new Projection<string>(2)

const insertDelta = projectionA.insert(['Hello World'], 0)
console.log(projectionA.value(0)) // "Hello World"

projectionB.apply(insertDelta)
console.log(projectionB.value(0)) // "Hello World"

const replaceDelta = projectionA.replace(['Hello Dude'], 0, 0)
console.log(projectionA.value(0)) // "Hello Dude"

const replaceAcknowledgement = projectionB.apply(replaceDelta)
console.log(projectionB.value(0)) // "Hello Dude"

projectionA.apply(replaceAcknowledgement?.[1])

const removeDelta = projectionA.remove(0, 0)
console.log(projectionA.value(0)) // undefined

const removeAcknowledgement = projectionB.apply(removeDelta)
console.log(projectionB.value(0)) // undefined

projectionA.apply(removeAcknowledgement?.[1])

const serializable = projectionA.sequence()

const acknowledgements = projectionB.merge(serializable)
projectionA.apply(acknowledgements?.[1])

projectionA.destroy()
projectionB.destroy()
```

<a id="projection-benchmarks"></a>

### Benchmarks

<!-- BEGIN GENERATED:projection:benchmarks -->

2026-11-27T17:28:13.184Z · local run

#### Moderate bundle size

| Format   | Raw (KiB) | Minified (KiB) | Minified + gzip (KiB) |
| -------- | --------: | -------------: | --------------------: |
| ESM      |    199.44 |         163.09 |                 56.54 |
| CommonJS |    199.62 |         164.71 |                 56.75 |

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

#### Average throughput during editing to checkpoint

Arithmetic means of 1 runs, in ops/s, from each phase's start to checkpoint.
Strips contain 1–100 Frames (visible entries). Headers show Strip counts and mean Frame counts.

**↑ Scale up (0 → 25,000 Strips)**

| Method / case  | 1,000 Strips<br>50,007 Frames | 5,000 Strips<br>256,206 Frames | 10,000 Strips<br>508,328 Frames | 15,000 Strips<br>756,035 Frames | 20,000 Strips<br>1,005,850 Frames | 25,000 Strips<br>1,252,902 Frames |
| -------------- | ----------------------------: | -----------------------------: | ------------------------------: | ------------------------------: | --------------------------------: | --------------------------------: |
| apply.random   |                       255,598 |                        308,140 |                         334,633 |                         347,299 |                           356,337 |                           361,186 |
| insert.head    |                       947,867 |                      1,043,406 |                       1,177,856 |                       1,198,485 |                         1,269,116 |                         1,320,906 |
| insert.random  |                       564,239 |                        536,579 |                         572,987 |                         614,605 |                           633,607 |                           652,151 |
| insert.tail    |                     1,211,827 |                      1,214,949 |                       1,395,751 |                       1,469,234 |                         1,544,330 |                         1,525,879 |
| remove.head    |                             — |                              — |                               — |                               — |                                 — |                                 — |
| remove.random  |                       515,650 |                        533,658 |                         547,507 |                         563,097 |                           566,909 |                           573,037 |
| remove.tail    |                             — |                              — |                               — |                               — |                                 — |                                 — |
| replace.head   |                       356,532 |                        411,784 |                         482,404 |                         514,612 |                           538,209 |                           535,417 |
| replace.random |                       342,372 |                        361,327 |                         392,368 |                         381,979 |                           380,626 |                           377,770 |
| replace.tail   |                       439,116 |                        477,186 |                         530,611 |                         551,315 |                           561,166 |                           570,759 |
| value.head     |                     1,389,082 |                      2,425,183 |                       2,871,583 |                       3,102,058 |                         3,276,808 |                         3,395,816 |
| value.random   |                     1,306,677 |                      1,127,930 |                       1,130,199 |                       1,095,570 |                         1,113,307 |                         1,116,231 |
| value.tail     |                     5,910,165 |                      5,517,546 |                       5,987,665 |                       6,322,978 |                         6,663,779 |                         6,888,950 |

**↓ Scale down (25,000 → 0 Strips)**

| Method / case  | 20,000 Strips<br>1,007,225 Frames | 15,000 Strips<br>759,799 Frames | 10,000 Strips<br>506,363 Frames | 5,000 Strips<br>254,264 Frames | 1,000 Strips<br>50,210 Frames | 0 Strips<br>0 Frames |
| -------------- | --------------------------------: | ------------------------------: | ------------------------------: | -----------------------------: | ----------------------------: | -------------------: |
| apply.random   |                           357,117 |                         364,401 |                         370,114 |                        369,753 |                       378,758 |              381,241 |
| insert.head    |                                 — |                               — |                               — |                              — |                             — |                    — |
| insert.random  |                           552,816 |                         587,534 |                         599,511 |                        622,946 |                       656,892 |              665,759 |
| insert.tail    |                                 — |                               — |                               — |                              — |                             — |                    — |
| remove.head    |                           789,715 |                         786,275 |                         752,513 |                        770,992 |                       793,913 |              798,258 |
| remove.random  |                           526,904 |                         532,513 |                         545,788 |                        559,879 |                       579,542 |              585,936 |
| remove.tail    |                           876,947 |                         852,006 |                         815,235 |                        834,516 |                       857,461 |              862,432 |
| replace.head   |                           521,937 |                         522,775 |                         530,373 |                        532,418 |                       547,813 |              551,031 |
| replace.random |                           389,833 |                         361,980 |                         384,081 |                        393,185 |                       411,443 |              417,000 |
| replace.tail   |                           263,884 |                         153,233 |                         193,801 |                        187,878 |                       204,077 |              209,347 |
| value.head     |                         2,802,533 |                       2,668,730 |                       2,664,914 |                      2,702,958 |                     2,707,673 |            2,710,585 |
| value.random   |                         1,033,827 |                       1,023,081 |                       1,054,170 |                      1,067,920 |                     1,118,662 |            1,136,338 |
| value.tail     |                         4,559,548 |                       4,572,265 |                       4,578,475 |                      4,629,415 |                     4,668,262 |            4,688,057 |

#### API throughput at checkpoint

Checkpoint calls, in ops/s, averaged across runs.

**↑ Scale up (0 → 25,000 Strips)**

| Method                            | 1,000 Strips<br>50,007 Frames | 5,000 Strips<br>256,206 Frames | 10,000 Strips<br>508,328 Frames | 15,000 Strips<br>756,035 Frames | 20,000 Strips<br>1,005,850 Frames | 25,000 Strips<br>1,252,902 Frames |
| --------------------------------- | ----------------------------: | -----------------------------: | ------------------------------: | ------------------------------: | --------------------------------: | --------------------------------: |
| new Projection(actorID, sequence) |                         2,727 |                          1,084 |                             641 |                             479 |                               287 |                               250 |
| sequence()                        |                           449 |                            134 |                              88 |                              74 |                                53 |                                49 |
| values()                          |                           608 |                            219 |                              52 |                             136 |                               122 |                               104 |

**↓ Scale down (25,000 → 0 Strips)**

| Method                            | 20,000 Strips<br>1,007,225 Frames | 15,000 Strips<br>759,799 Frames | 10,000 Strips<br>506,363 Frames | 5,000 Strips<br>254,264 Frames | 1,000 Strips<br>50,210 Frames | 0 Strips<br>0 Frames |
| --------------------------------- | --------------------------------: | ------------------------------: | ------------------------------: | -----------------------------: | ----------------------------: | -------------------: |
| new Projection(actorID, sequence) |                               290 |                             388 |                             568 |                          1,242 |                         7,278 |               66,667 |
| sequence()                        |                                61 |                              73 |                              91 |                            113 |                           196 |                  814 |
| values()                          |                               133 |                             158 |                             219 |                            420 |                         2,535 |               95,238 |

#### Sequence disk size at checkpoint

Complete exported Sequences, including Footage and acknowledgements. Sizes are in KiB.

**↑ Scale up (0 → 25,000 Strips)**

| Encoding           | 1,000 Strips<br>50,007 Frames | 5,000 Strips<br>256,206 Frames | 10,000 Strips<br>508,328 Frames | 15,000 Strips<br>756,035 Frames | 20,000 Strips<br>1,005,850 Frames | 25,000 Strips<br>1,252,902 Frames |
| ------------------ | ----------------------------: | -----------------------------: | ------------------------------: | ------------------------------: | --------------------------------: | --------------------------------: |
| JSON               |                        272.03 |                       1,644.25 |                        3,276.35 |                        4,916.66 |                          7,073.44 |                          9,192.05 |
| JSON + gzip        |                         14.52 |                          73.50 |                          148.92 |                          225.99 |                            311.23 |                            392.29 |
| MessagePack        |                        162.13 |                         830.68 |                        1,655.21 |                        3,545.68 |                          5,103.00 |                          6,496.81 |
| MessagePack + gzip |                         12.30 |                          61.66 |                          124.79 |                          200.14 |                            263.55 |                            335.16 |

**↓ Scale down (25,000 → 0 Strips)**

| Encoding           | 20,000 Strips<br>1,007,225 Frames | 15,000 Strips<br>759,799 Frames | 10,000 Strips<br>506,363 Frames | 5,000 Strips<br>254,264 Frames | 1,000 Strips<br>50,210 Frames | 0 Strips<br>0 Frames |
| ------------------ | --------------------------------: | ------------------------------: | ------------------------------: | -----------------------------: | ----------------------------: | -------------------: |
| JSON               |                          7,538.07 |                        5,730.74 |                        3,828.12 |                       1,909.46 |                        375.26 |                 0.02 |
| JSON + gzip        |                            326.43 |                          247.34 |                          165.02 |                          79.58 |                         16.04 |                 0.03 |
| MessagePack        |                          5,289.65 |                        4,004.94 |                        2,670.80 |                       1,334.90 |                        262.97 |                 0.01 |
| MessagePack + gzip |                            278.22 |                          209.82 |                          139.89 |                          67.69 |                         13.69 |                 0.03 |

#### Memory usage at checkpoint

One instance after checkpoint compaction and recreation: live native allocation plus retained JS array slots and string code units, in MiB (1,048,576 bytes). Unused WASM capacity is excluded.

**↑ Scale up (0 → 25,000 Strips)**

| Measurement            | 1,000 Strips<br>50,007 Frames | 5,000 Strips<br>256,206 Frames | 10,000 Strips<br>508,328 Frames | 15,000 Strips<br>756,035 Frames | 20,000 Strips<br>1,005,850 Frames | 25,000 Strips<br>1,252,902 Frames |
| ---------------------- | ----------------------------: | -----------------------------: | ------------------------------: | ------------------------------: | --------------------------------: | --------------------------------: |
| Estimated memory (MiB) |                          0.61 |                           3.12 |                            6.22 |                            9.41 |                             12.78 |                             16.19 |

**↓ Scale down (25,000 → 0 Strips)**

| Measurement            | 20,000 Strips<br>1,007,225 Frames | 15,000 Strips<br>759,799 Frames | 10,000 Strips<br>506,363 Frames | 5,000 Strips<br>254,264 Frames | 1,000 Strips<br>50,210 Frames | 0 Strips<br>0 Frames |
| ---------------------- | --------------------------------: | ------------------------------: | ------------------------------: | -----------------------------: | ----------------------------: | -------------------: |
| Estimated memory (MiB) |                             13.29 |                            9.92 |                            7.15 |                           4.09 |                          1.80 |                 1.22 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49,
win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.
Peer synchronization, encoding and explicit JS process garbage collection are outside API timings.
[Full lifecycle results](../child-full-child-prefix-2-lifecycle.md) · [Throughput results](benchmark/.results/throughput.md).

<!-- END GENERATED:projection:benchmarks -->

## Tuple mode

<a id="tuple-usage"></a>

### Usage

Each index represents an independent slot. Adding or removing values
never shifts other values. Empty slots return `undefined`.

Omit `maxLength` to allow dynamic growth.

```ts
const tuple = new Projection<string>(1, undefined, { enabled: 1, maxLength: 4 })
tuple.insert(['hello'], 2)
tuple.replace(['world'], 2, 2)
tuple.remove(2, 2)
```

<a id="tuple-benchmarks"></a>

### Benchmarks

<!-- BEGIN GENERATED:tuple:benchmarks -->

2026-11-27T17:28:57.899Z · local run

Arithmetic means of 1 runs. Ordinary Projection versus a static tuple with maxLength. Both contain the same values; replacements preserve the field count.

#### Throughput (ops/s)

| Indices | Method / case   | Projection | Static tuple | Tuple / Projection |
| ------: | --------------- | ---------: | -----------: | -----------------: |
|       2 | create.sequence |    984,651 |      842,366 |              0.86× |
|       2 | replace.random  |  1,136,510 |    1,697,445 |              1.49× |
|       2 | apply.replace   |    762,674 |      933,943 |              1.22× |
|       2 | value.random    | 32,475,533 |   54,567,968 |              1.68× |
|       4 | create.sequence |    735,458 |      722,157 |              0.98× |
|       4 | replace.random  |  1,111,120 |    1,445,661 |              1.30× |
|       4 | apply.replace   |    687,072 |      963,043 |              1.40× |
|       4 | value.random    | 24,479,170 |   56,321,100 |              2.30× |
|       8 | create.sequence |    469,258 |      221,498 |              0.47× |
|       8 | replace.random  |    948,498 |    1,576,628 |              1.66× |
|       8 | apply.replace   |    657,918 |    1,048,912 |              1.59× |
|       8 | value.random    | 19,507,846 |   56,875,873 |              2.92× |
|     100 | create.sequence |     68,399 |       88,376 |              1.29× |
|     100 | replace.random  |    979,840 |    1,621,819 |              1.66× |
|     100 | apply.replace   |    662,813 |    1,061,830 |              1.60× |
|     100 | value.random    | 13,576,682 |   50,351,885 |              3.71× |

#### Memory and encoded size

| Indices | Mode         | Estimated allocated memory (MiB) | MessagePack (KiB) | MessagePack + gzip (KiB) |
| ------: | ------------ | -------------------------------: | ----------------: | -----------------------: |
|       2 | Projection   |                           0.0006 |              0.03 |                     0.04 |
|       2 | Static tuple |                           0.0007 |              0.04 |                     0.05 |
|       4 | Projection   |                           0.0013 |              0.06 |                     0.05 |
|       4 | Static tuple |                           0.0009 |              0.06 |                     0.07 |
|       8 | Projection   |                           0.0022 |              0.12 |                     0.08 |
|       8 | Static tuple |                           0.0013 |              0.10 |                     0.09 |
|     100 | Projection   |                           0.0196 |              0.67 |                     0.57 |
|     100 | Static tuple |                           0.0110 |              0.51 |                     0.35 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Fixtures are hydrated compacted snapshots after one replacement per field. Each case warms up for ≥25 ms and measures ≥50 ms of API time; mutation bursts restart after 4,096 replacements. Peer authoring, encoding, result checks, destruction and explicit JS process garbage collection are outside API timings. Memory estimates are the increase in live native allocator bytes plus retained JS array slots for one instance, including exercised runtime buffers. Unused WASM capacity, JS object headers and referenced payload objects are excluded.

[Full tuple results](../child-full-child-prefix-2-tuple.md).

<!-- END GENERATED:tuple:benchmarks -->

## Text mode

<a id="text-usage"></a>

### Usage

String inputs retain UTF-16 code units without creating character arrays.
Array results remain the default; `true` requests string Footage.

```ts
const text = new Projection<string>(1)
const gossip = text.insert('Hello', 0)
const replica = new Projection<string>(2)
replica.apply(gossip, true)
const visibleText = replica.values(undefined, undefined, true)
const snapshot = replica.sequence(true)
const restored = new Projection<string>(3, snapshot, undefined, true)
text.destroy()
replica.destroy()
restored.destroy()
```

<a id="text-benchmarks"></a>

### Benchmarks

<!-- BEGIN GENERATED:text:benchmarks -->

2026-11-27T17:29:12.273Z · local run

1 runs; median throughput in ops/s. Sizes are UTF-16 code units.

| Operation            | 1,024 array | 1,024 string | 65,536 array | 65,536 string | 1,048,576 array | 1,048,576 string |
| -------------------- | ----------: | -----------: | -----------: | ------------: | --------------: | ---------------: |
| insert               |     486,472 |    1,895,682 |        4,465 |     1,915,540 |             316 |        1,916,885 |
| insert.append        |      84,011 |      231,627 |        1,013 |        49,975 |              44 |            1,674 |
| replace              |     367,152 |      796,988 |        4,239 |       778,463 |             352 |          579,284 |
| remove               |     899,548 |      961,288 |      396,254 |     1,145,350 |          58,097 |          842,902 |
| remove.middle        |     543,297 |      982,702 |        5,065 |     1,094,382 |             229 |          870,350 |
| replace.middle       |     478,008 |      705,696 |        4,791 |       805,784 |             298 |          711,611 |
| apply                |   1,463,223 |    1,264,100 |    1,111,880 |     1,394,075 |         674,283 |          725,990 |
| apply.array          |   1,624,849 |      459,734 |    1,864,148 |         4,266 |       1,403,701 |              264 |
| concurrent.apply     |      15,449 |      281,790 |          260 |         7,567 |              12 |              714 |
| merge                |     364,066 |      770,664 |        4,474 |       992,296 |             271 |          757,116 |
| create               |     376,905 |      977,088 |        4,653 |     1,071,929 |             251 |          962,791 |
| value.random         |  23,593,196 |   19,066,960 |   20,532,936 |    21,927,562 |      19,522,483 |       19,883,797 |
| values.range         |  10,092,710 |    7,023,959 |    7,997,462 |     7,438,102 |       8,721,736 |        7,152,399 |
| values.array         |     889,972 |      617,400 |        5,270 |         4,687 |             386 |              305 |
| values.text          |      78,547 |   14,741,104 |        1,275 |    16,035,037 |              69 |       12,068,912 |
| sequence.array       |     693,903 |      532,254 |        5,216 |         4,475 |             308 |              295 |
| sequence.text        |     106,390 |    5,216,884 |        1,495 |     5,285,332 |              12 |        4,923,960 |
| sequence.edited.text |      69,875 |      477,069 |        1,134 |        11,966 |              13 |              623 |
| sequence.masked.text |      90,395 |      303,157 |        1,504 |       340,937 |              12 |          295,907 |

Encoded snapshots use string Footage in both representations.

#### Memory and encoded size

| UTF-16 code units | Representation | Estimated MiB | Snapshot MessagePack KiB | Snapshot gzip KiB | Gossip MessagePack KiB | Gossip gzip KiB |
| ----------------: | -------------- | ------------: | -----------------------: | ----------------: | ---------------------: | --------------: |
|              1024 | array          |        0.0082 |                     1.02 |              0.04 |                   2.02 |            0.05 |
|              1024 | string         |        0.0023 |                     1.02 |              0.04 |                   1.02 |            0.05 |
|             65536 | array          |        0.5004 |                    64.02 |              0.12 |                 128.02 |            0.18 |
|             65536 | string         |        0.1254 |                    64.02 |              0.12 |                  64.02 |            0.12 |
|           1048576 | array          |        8.0004 |                  1024.02 |              1.05 |                2048.02 |            2.05 |
|           1048576 | string         |        2.0004 |                  1024.02 |              1.05 |                1024.02 |            1.05 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Splitting and text assembly are included where required; peer preparation, encoding and explicit JS process garbage collection are outside API timings.

[Full text results](../child-full-child-prefix-2-text.md).

<!-- END GENERATED:text:benchmarks -->

## Packed words

<a id="packed-words-usage"></a>

### Usage

Unpacked words remain the default. The optional final `binaryEncode` argument
returns `Uint8Array` metadata for binary serializers such as MessagePack.
Footage keeps its existing array or string representation.

```ts
const projection = new Projection<string>(1)
const gossip = projection.insert('Hello', 0, true)
const snapshot = projection.sequence(true, true)
const replica = new Projection<string>(2, snapshot, undefined, true)
replica.apply(projection.remove(0, 0, true), true, true)
projection.destroy()
replica.destroy()
```

<a id="packed-words-benchmarks"></a>

### Benchmarks

<!-- BEGIN GENERATED:words:benchmarks -->

2026-11-27T17:29:33.630Z · local run

1 runs, 6,000 edits. Median results; string Footage in both modes.

| Workload   | Words    | Snapshot KiB | Snapshot gzip KiB | Mean update B | Encode ops/s | Load ops/s | Receive batches/s |
| ---------- | -------- | -----------: | ----------------: | ------------: | -----------: | ---------: | ----------------: |
| append     | unpacked |         5.90 |              3.61 |         22.88 |       28,475 |    190,551 |               130 |
| append     | packed   |         5.90 |              3.61 |         13.98 |       23,067 |    163,495 |               319 |
| prepend    | unpacked |        40.07 |             18.06 |         22.94 |        1,710 |        678 |               206 |
| prepend    | packed   |         5.90 |              3.62 |         13.99 |       27,911 |      1,448 |               229 |
| random     | unpacked |       138.05 |             57.31 |         39.88 |          469 |        192 |                88 |
| random     | packed   |        49.58 |             35.38 |         23.45 |       14,696 |        521 |               117 |
| concurrent | unpacked |        92.24 |             42.76 |         32.34 |          611 |        214 |               109 |
| concurrent | packed   |        38.94 |             28.15 |         20.71 |       16,197 |        413 |               147 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Random and concurrent workloads mix insertion, removal and replacement. Concurrent authors edit independent views. Sizes use MessagePack; updates are encoded individually. Load includes decoding and construction. Receive includes decoding and applying one complete edit batch. Preparation, checks, destruction and explicit JS process garbage collection are outside timings.

[Full words results](../child-full-child-prefix-2-words.md).

<!-- END GENERATED:words:benchmarks -->

## Batch

Collect local edits into one packed Gossip. Edits are immediately visible;
Footage stays in JavaScript.

<a id="batch-usage"></a>

### Usage

```ts
const projection = new Projection<string>(1)
const peer = new Projection<string>(2)
projection.apply([[1], [2]])
peer.apply([[1], [2]])
const gossip = projection.batch((edit) => {
  edit.insert('hello', 0)
  edit.replace('H', 0, 0)
})
const result = peer.apply(gossip, true, true)
projection.apply(result?.[1] ?? [])
projection.destroy()
peer.destroy()
```

<a id="batch-benchmarks"></a>

### Benchmarks

<!-- BEGIN GENERATED:batch:benchmarks -->

2026-11-27T17:29:40.763Z · local run

1 runs, 6,000 edits per author. Concurrent authors edit independent views; causal authors exchange history before the second author edits. Median results.

| Workload              | Mode       | Author edits/s | Apply edits/s | Receive edits/s | Update/author KiB | Document KiB | Memory MiB |
| --------------------- | ---------- | -------------: | ------------: | --------------: | ----------------: | -----------: | ---------: |
| append                | individual |      2,452,283 |     1,092,578 |         556,426 |             76.05 |         5.99 |      0.012 |
| append                | batch      |      2,632,503 |   246,913,580 |     213,523,132 |              5.88 |         5.99 |      0.012 |
| prepend               | individual |      1,696,977 |     1,584,200 |         844,535 |             76.11 |         5.99 |      0.896 |
| prepend               | batch      |      1,492,277 |     2,404,713 |       2,234,387 |              5.89 |         5.99 |      0.896 |
| random.characters     | individual |      1,121,202 |     1,133,508 |         838,328 |             82.09 |        28.31 |      0.917 |
| random.characters     | batch      |      1,314,694 |     1,630,612 |       1,542,218 |             22.95 |        28.31 |      0.917 |
| random.words          | individual |      1,143,140 |     1,216,644 |         825,105 |            125.68 |        73.88 |      0.991 |
| random.words          | batch      |      1,099,787 |     1,849,169 |       1,738,979 |             59.71 |        73.88 |      0.991 |
| concurrent.characters | individual |      1,260,570 |       991,531 |         783,162 |             82.04 |        56.41 |      1.834 |
| concurrent.characters | batch      |      1,360,729 |     1,608,967 |       1,684,092 |             22.92 |        56.41 |      1.834 |
| concurrent.words      | individual |      1,296,821 |     1,414,477 |         953,349 |            125.74 |       147.81 |      1.981 |
| concurrent.words      | batch      |      1,340,602 |     1,780,970 |       1,512,306 |             59.79 |       147.81 |      1.981 |
| concurrent.mixed      | individual |        728,116 |       957,717 |         701,189 |            154.61 |        97.82 |      1.505 |
| concurrent.mixed      | batch      |      1,005,598 |     1,171,463 |       1,161,755 |             56.88 |        97.82 |      1.505 |
| causal.characters     | individual |      1,238,173 |     1,424,620 |       1,049,860 |             88.96 |        63.81 |      1.842 |
| causal.characters     | batch      |      1,278,622 |     1,886,437 |       1,760,848 |             23.18 |        63.81 |      1.842 |
| causal.words          | individual |      1,278,568 |     1,413,677 |         978,194 |            135.13 |       156.41 |      1.989 |
| causal.words          | batch      |      1,083,903 |     1,606,619 |       1,466,455 |             60.68 |       156.41 |      1.989 |
| causal.mixed          | individual |        757,017 |       998,668 |         726,727 |            161.05 |       103.75 |      1.509 |
| causal.mixed          | batch      |        909,863 |     1,328,448 |       1,204,759 |             57.34 |       103.75 |      1.509 |

Measured on Node 24.16.0, V8 13.6.233.17-node.49, win32 x64, Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz. Both modes group each author's binary Gossip into one MessagePack message. Batch Footage is uncompressed. Receive includes MessagePack decoding; apply excludes it. Document size follows complete acknowledgement exchange. Memory estimates use one receiver recreated from that compact checkpoint in a fresh runtime, excluding the author runtime. Preparation, verification, destruction and explicit JS process garbage collection are outside timings.

[Full batch results](../child-full-child-prefix-2-batch.md).

<!-- END GENERATED:batch:benchmarks -->

## Errors

| Code                      | Meaning                                                             |
| ------------------------- | ------------------------------------------------------------------- |
| `PROJECTION_DESTROYED`    | An operation was called after the Projection was destroyed.         |
| `BATCH_CLOSED`            | An editor was used after its batch callback finished.               |
| `NATIVE_OPERATION_FAILED` | The native runtime reported an initialization or operation failure. |
| `STRING_ENCODING_FAILED`  | Footage concatenation as text failed.                               |
| `UNKNOWN_ERROR`           | All other errors.                                                   |

Invalid input to `apply()` or `merge()` returns `undefined` instead of throwing.

## Tests

### Behaviour guaranteed by excessive tests

2026-11-27T16:45:59.798Z · [CI run](https://github.com/sovereignbase/sequencer/actions/runs/46035866481)

The latest verification passed 403 Vitest tests and 153 compatibility checks.
The configured 100% coverage threshold is met (100% statements, 100% branches, 100% functions, 100% lines).
See the [test suites](test/README.md) and
[automated test report](https://sovereignbase.dev/sequencer/tests/).

### Works everywhere where JavaScript and Wasm works

2026-11-27T16:45:59.804Z · [CI run](https://github.com/sovereignbase/sequencer/actions/runs/46035866481)

Runtimes covered by the latest compatibility verification:

- Node.js, ESM: passed
- Node.js, CommonJS: passed
- Deno: passed
- Bun: passed
- Edge Runtime: passed
- Cloudflare Workers through workerd: passed
- Chromium browser windows: passed
- Firefox browser windows: passed
- WebKit browser windows: passed

### Tested realtime and offline text editing behaviour examples

- [Online and offline editors](test/convergence/delivery/offline_realtime_editing/README.md): six editors converge through delayed, reversed and shuffled delivery, including offline changes arriving during online editing.
- [Concurrent replacements](test/convergence/delivery/concurrent_replacement_delivery/README.md): independent replacement histories retain the same surviving content across delivery orders.
- [Restart and redelivery](test/convergence/persistence/restart_redelivery/README.md): stored Sequences preserve visible content through hydration, duplicate delivery and further edits.
- [Peer-to-peer fanout](test/integration/fanout_peer_to_peer/README.md): independently editing browser peers synchronize through BroadcastChannel.
- [WebSocket fanout](test/integration/fanout_websocket/README.md): three browser peers converge through a stateless JSON Gossip relay.

## Credits

This could not have been made without years of work from many great engineers of many great projects, to mention a few:

- [AUTOMERGE](https://github.com/automerge)

- [YJS](https://github.com/yjs)

- [DIAMOND TYPES](https://github.com/josephg/diamond-types)

## License

Licensed under the Apache License, Version 2.0.

Copyright © 2026 Sovereignbase.
