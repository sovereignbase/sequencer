# Sequencer dynamic lifecycle benchmark

2026-11-27T17:13:45.353Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.23 | 162.89 | 56.49 |
| CommonJS | 199.41 | 164.51 | 56.69 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 294,309 | 3.398 | 3.398 | 3.398 | 0.000 | 0: 3.398 | 0: 3.398 |
| apply | random | A | scaleDown | 24,999 | 354,180 | 2.823 | 2.823 | 2.823 | 0.000 | 0: 2.823 | 0: 2.823 |
| apply | random | A | fullLifecycle | 49,999 | 321,480 | 3.111 | 3.111 | 3.111 | 0.000 | 0: 3.111 | 0: 3.111 |
| create | — | A | scaleUp | 7 | 546 | 1832.143 | 1832.143 | 1832.143 | 0.000 | 0: 1832.143 | 0: 1832.143 |
| create | — | A | scaleDown | 6 | 663 | 1508.200 | 1508.200 | 1508.200 | 0.000 | 0: 1508.200 | 0: 1508.200 |
| create | — | A | fullLifecycle | 13 | 594 | 1682.631 | 1682.631 | 1682.631 | 0.000 | 0: 1682.631 | 0: 1682.631 |
| insert | head | A | scaleUp | 12,500 | 1,230,581 | 0.813 | 0.813 | 0.813 | 0.000 | 0: 0.813 | 0: 0.813 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,230,581 | 0.813 | 0.813 | 0.813 | 0.000 | 0: 0.813 | 0: 0.813 |
| insert | random | A | scaleUp | 25,000 | 534,748 | 1.870 | 1.870 | 1.870 | 0.000 | 0: 1.870 | 0: 1.870 |
| insert | random | A | scaleDown | 25,000 | 642,543 | 1.556 | 1.556 | 1.556 | 0.000 | 0: 1.556 | 0: 1.556 |
| insert | random | A | fullLifecycle | 50,000 | 583,711 | 1.713 | 1.713 | 1.713 | 0.000 | 0: 1.713 | 0: 1.713 |
| insert | tail | A | scaleUp | 12,500 | 1,322,024 | 0.756 | 0.756 | 0.756 | 0.000 | 0: 0.756 | 0: 0.756 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,322,024 | 0.756 | 0.756 | 0.756 | 0.000 | 0: 0.756 | 0: 0.756 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 721,172 | 1.387 | 1.387 | 1.387 | 0.000 | 0: 1.387 | 0: 1.387 |
| remove | head | A | fullLifecycle | 12,500 | 721,172 | 1.387 | 1.387 | 1.387 | 0.000 | 0: 1.387 | 0: 1.387 |
| remove | random | A | scaleUp | 25,000 | 455,778 | 2.194 | 2.194 | 2.194 | 0.000 | 0: 2.194 | 0: 2.194 |
| remove | random | A | scaleDown | 25,000 | 529,106 | 1.890 | 1.890 | 1.890 | 0.000 | 0: 1.890 | 0: 1.890 |
| remove | random | A | fullLifecycle | 50,000 | 489,712 | 2.042 | 2.042 | 2.042 | 0.000 | 0: 2.042 | 0: 2.042 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 830,957 | 1.203 | 1.203 | 1.203 | 0.000 | 0: 1.203 | 0: 1.203 |
| remove | tail | A | fullLifecycle | 12,500 | 830,957 | 1.203 | 1.203 | 1.203 | 0.000 | 0: 1.203 | 0: 1.203 |
| replace | head | A | scaleUp | 25,000 | 444,498 | 2.250 | 2.250 | 2.250 | 0.000 | 0: 2.250 | 0: 2.250 |
| replace | head | A | scaleDown | 25,000 | 503,311 | 1.987 | 1.987 | 1.987 | 0.000 | 0: 1.987 | 0: 1.987 |
| replace | head | A | fullLifecycle | 50,000 | 472,080 | 2.118 | 2.118 | 2.118 | 0.000 | 0: 2.118 | 0: 2.118 |
| replace | random | A | scaleUp | 25,000 | 328,952 | 3.040 | 3.040 | 3.040 | 0.000 | 0: 3.040 | 0: 3.040 |
| replace | random | A | scaleDown | 25,000 | 408,339 | 2.449 | 2.449 | 2.449 | 0.000 | 0: 2.449 | 0: 2.449 |
| replace | random | A | fullLifecycle | 50,000 | 364,372 | 2.744 | 2.744 | 2.744 | 0.000 | 0: 2.744 | 0: 2.744 |
| replace | tail | A | scaleUp | 25,000 | 454,931 | 2.198 | 2.198 | 2.198 | 0.000 | 0: 2.198 | 0: 2.198 |
| replace | tail | A | scaleDown | 25,000 | 58,594 | 17.067 | 17.067 | 17.067 | 0.000 | 0: 17.067 | 0: 17.067 |
| replace | tail | A | fullLifecycle | 50,000 | 103,816 | 9.632 | 9.632 | 9.632 | 0.000 | 0: 9.632 | 0: 9.632 |
| sequence | — | A | scaleUp | 6 | 77 | 12982.567 | 12982.567 | 12982.567 | 0.000 | 0: 12982.567 | 0: 12982.567 |
| sequence | — | A | scaleDown | 6 | 94 | 10605.217 | 10605.217 | 10605.217 | 0.000 | 0: 10605.217 | 0: 10605.217 |
| sequence | — | A | fullLifecycle | 12 | 85 | 11793.892 | 11793.892 | 11793.892 | 0.000 | 0: 11793.892 | 0: 11793.892 |
| value | head | A | scaleUp | 25,000 | 3,001,417 | 0.333 | 0.333 | 0.333 | 0.000 | 0: 0.333 | 0: 0.333 |
| value | head | A | scaleDown | 25,000 | 2,430,677 | 0.411 | 0.411 | 0.411 | 0.000 | 0: 0.411 | 0: 0.411 |
| value | head | A | fullLifecycle | 50,000 | 2,686,064 | 0.372 | 0.372 | 0.372 | 0.000 | 0: 0.372 | 0: 0.372 |
| value | random | A | scaleUp | 25,000 | 816,657 | 1.225 | 1.225 | 1.225 | 0.000 | 0: 1.225 | 0: 1.225 |
| value | random | A | scaleDown | 25,000 | 1,012,991 | 0.987 | 0.987 | 0.987 | 0.000 | 0: 0.987 | 0: 0.987 |
| value | random | A | fullLifecycle | 50,000 | 904,290 | 1.106 | 1.106 | 1.106 | 0.000 | 0: 1.106 | 0: 1.106 |
| value | tail | A | scaleUp | 25,000 | 6,248,906 | 0.160 | 0.160 | 0.160 | 0.000 | 0: 0.160 | 0: 0.160 |
| value | tail | A | scaleDown | 25,000 | 4,281,775 | 0.234 | 0.234 | 0.234 | 0.000 | 0: 0.234 | 0: 0.234 |
| value | tail | A | fullLifecycle | 50,000 | 5,081,611 | 0.197 | 0.197 | 0.197 | 0.000 | 0: 0.197 | 0: 0.197 |
| values | — | A | scaleUp | 6 | 108 | 9268.833 | 9268.833 | 9268.833 | 0.000 | 0: 9268.833 | 0: 9268.833 |
| values | — | A | scaleDown | 6 | 267 | 3740.033 | 3740.033 | 3740.033 | 0.000 | 0: 3740.033 | 0: 3740.033 |
| values | — | A | fullLifecycle | 12 | 154 | 6504.433 | 6504.433 | 6504.433 | 0.000 | 0: 6504.433 | 0: 6504.433 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5448434.000 | 430.140 | 8.475 |
| A | scaleDown | 5 | 4404655.200 | 431.829 | 8.549 |
| A | fullLifecycle | 11 | 4973989.091 | 430.818 | 8.505 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3135629.000 | 247.550 | 4.877 |
| A | scaleDown | 5 | 2594145.800 | 254.328 | 5.035 |
| A | fullLifecycle | 11 | 2889500.273 | 250.272 | 4.940 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 254,848 | 3.924 | 1.800 | 243.000 |
| apply | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 282,102 | 3.545 | 1.600 | 243.000 |
| apply | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 297,004 | 3.367 | 1.500 | 1003.200 |
| apply | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 310,082 | 3.225 | 1.500 | 1003.200 |
| apply | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 315,466 | 3.170 | 1.500 | 1003.200 |
| apply | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 294,309 | 3.398 | 1.500 | 1003.200 |
| apply | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 300,514 | 3.328 | 1.500 | 1003.200 |
| apply | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 306,292 | 3.265 | 1.500 | 1003.200 |
| apply | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 310,624 | 3.219 | 1.500 | 1003.200 |
| apply | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 313,239 | 3.192 | 1.500 | 1003.200 |
| apply | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 319,577 | 3.129 | 1.400 | 1003.200 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 321,480 | 3.111 | 1.300 | 1003.200 |
| insert | head | 0 | up | 1,000 | 49,966 | A | 500 | 1,054,630 | 0.948 | 0.300 | 18.800 |
| insert | head | 0 | up | 5,000 | 254,523 | A | 2,500 | 1,099,143 | 0.910 | 0.300 | 18.800 |
| insert | head | 0 | up | 10,000 | 509,098 | A | 5,000 | 1,224,530 | 0.817 | 0.300 | 58.700 |
| insert | head | 0 | up | 15,000 | 765,837 | A | 7,500 | 1,299,917 | 0.769 | 0.300 | 58.700 |
| insert | head | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 1,315,028 | 0.760 | 0.300 | 58.700 |
| insert | head | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 1,230,581 | 0.813 | 0.300 | 58.700 |
| insert | head | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 1,230,581 | 0.813 | 0.300 | 58.700 |
| insert | head | 0 | down | 15,000 | 757,461 | A | 12,500 | 1,230,581 | 0.813 | 0.300 | 58.700 |
| insert | head | 0 | down | 10,000 | 505,565 | A | 12,500 | 1,230,581 | 0.813 | 0.300 | 58.700 |
| insert | head | 0 | down | 5,000 | 249,719 | A | 12,500 | 1,230,581 | 0.813 | 0.300 | 58.700 |
| insert | head | 0 | down | 1,000 | 50,567 | A | 12,500 | 1,230,581 | 0.813 | 0.300 | 58.700 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,230,581 | 0.813 | 0.300 | 58.700 |
| insert | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 536,797 | 1.863 | 0.500 | 494.100 |
| insert | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 502,301 | 1.991 | 0.500 | 494.100 |
| insert | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 575,632 | 1.737 | 0.500 | 494.100 |
| insert | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 593,472 | 1.685 | 0.500 | 494.100 |
| insert | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 582,596 | 1.716 | 0.500 | 700.100 |
| insert | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 534,748 | 1.870 | 0.500 | 700.100 |
| insert | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 540,066 | 1.852 | 0.500 | 700.100 |
| insert | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 547,811 | 1.825 | 0.500 | 700.100 |
| insert | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 559,747 | 1.787 | 0.500 | 700.100 |
| insert | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 565,225 | 1.769 | 0.500 | 700.100 |
| insert | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 578,693 | 1.728 | 0.500 | 700.100 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 583,711 | 1.713 | 0.400 | 700.100 |
| insert | tail | 0 | up | 1,000 | 49,966 | A | 500 | 1,223,391 | 0.817 | 0.300 | 7.700 |
| insert | tail | 0 | up | 5,000 | 254,523 | A | 2,500 | 1,170,522 | 0.854 | 0.300 | 68.400 |
| insert | tail | 0 | up | 10,000 | 509,098 | A | 5,000 | 1,342,967 | 0.745 | 0.300 | 72.100 |
| insert | tail | 0 | up | 15,000 | 765,837 | A | 7,500 | 1,397,976 | 0.715 | 0.300 | 154.000 |
| insert | tail | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 1,451,863 | 0.689 | 0.300 | 154.000 |
| insert | tail | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 1,322,024 | 0.756 | 0.300 | 328.600 |
| insert | tail | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 1,322,024 | 0.756 | 0.300 | 328.600 |
| insert | tail | 0 | down | 15,000 | 757,461 | A | 12,500 | 1,322,024 | 0.756 | 0.300 | 328.600 |
| insert | tail | 0 | down | 10,000 | 505,565 | A | 12,500 | 1,322,024 | 0.756 | 0.300 | 328.600 |
| insert | tail | 0 | down | 5,000 | 249,719 | A | 12,500 | 1,322,024 | 0.756 | 0.300 | 328.600 |
| insert | tail | 0 | down | 1,000 | 50,567 | A | 12,500 | 1,322,024 | 0.756 | 0.300 | 328.600 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,322,024 | 0.756 | 0.300 | 328.600 |
| remove | head | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 684,182 | 1.462 | 0.900 | 16.200 |
| remove | head | 0 | down | 15,000 | 757,461 | A | 5,000 | 705,916 | 1.417 | 0.900 | 17.500 |
| remove | head | 0 | down | 10,000 | 505,565 | A | 7,500 | 681,354 | 1.468 | 0.800 | 586.600 |
| remove | head | 0 | down | 5,000 | 249,719 | A | 10,000 | 702,301 | 1.424 | 0.800 | 586.600 |
| remove | head | 0 | down | 1,000 | 50,567 | A | 12,000 | 717,107 | 1.394 | 0.800 | 586.600 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 721,172 | 1.387 | 0.600 | 586.600 |
| remove | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 466,657 | 2.143 | 0.900 | 326.400 |
| remove | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 446,010 | 2.242 | 0.900 | 326.400 |
| remove | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 477,024 | 2.096 | 0.800 | 332.000 |
| remove | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 497,833 | 2.009 | 0.800 | 332.000 |
| remove | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 494,286 | 2.023 | 0.800 | 332.000 |
| remove | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 455,778 | 2.194 | 0.800 | 332.000 |
| remove | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 459,669 | 2.175 | 0.800 | 332.000 |
| remove | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 466,767 | 2.142 | 0.800 | 332.000 |
| remove | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 471,285 | 2.122 | 0.800 | 332.000 |
| remove | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 476,457 | 2.099 | 0.800 | 332.000 |
| remove | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 485,706 | 2.059 | 0.800 | 332.000 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 489,712 | 2.042 | 0.700 | 332.000 |
| remove | tail | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 768,144 | 1.302 | 0.800 | 59.200 |
| remove | tail | 0 | down | 15,000 | 757,461 | A | 5,000 | 799,578 | 1.251 | 0.800 | 59.200 |
| remove | tail | 0 | down | 10,000 | 505,565 | A | 7,500 | 804,635 | 1.243 | 0.800 | 59.200 |
| remove | tail | 0 | down | 5,000 | 249,719 | A | 10,000 | 811,701 | 1.232 | 0.700 | 59.200 |
| remove | tail | 0 | down | 1,000 | 50,567 | A | 12,000 | 825,378 | 1.212 | 0.700 | 59.200 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 830,957 | 1.203 | 0.600 | 59.200 |
| replace | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 452,468 | 2.210 | 1.200 | 33.200 |
| replace | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 456,175 | 2.192 | 1.100 | 223.700 |
| replace | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 506,732 | 1.973 | 1.100 | 223.700 |
| replace | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 526,275 | 1.900 | 1.000 | 343.600 |
| replace | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 518,445 | 1.929 | 1.000 | 1189.000 |
| replace | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 444,498 | 2.250 | 1.000 | 4439.400 |
| replace | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 454,678 | 2.199 | 1.000 | 4439.400 |
| replace | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 450,647 | 2.219 | 1.000 | 4439.400 |
| replace | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 455,920 | 2.193 | 1.000 | 4439.400 |
| replace | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 460,993 | 2.169 | 1.000 | 4439.400 |
| replace | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 469,131 | 2.132 | 1.000 | 4439.400 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 472,080 | 2.118 | 0.900 | 4439.400 |
| replace | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 370,137 | 2.702 | 1.100 | 160.100 |
| replace | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 306,658 | 3.261 | 1.100 | 890.600 |
| replace | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 345,962 | 2.890 | 1.100 | 890.600 |
| replace | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 350,952 | 2.849 | 1.100 | 890.600 |
| replace | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 354,603 | 2.820 | 1.100 | 890.600 |
| replace | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 328,952 | 3.040 | 1.100 | 890.600 |
| replace | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 337,037 | 2.967 | 1.100 | 890.600 |
| replace | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 342,118 | 2.923 | 1.100 | 890.600 |
| replace | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 349,374 | 2.862 | 1.100 | 890.600 |
| replace | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 352,808 | 2.834 | 1.100 | 890.600 |
| replace | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 361,574 | 2.766 | 1.000 | 890.600 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 364,372 | 2.744 | 1.000 | 890.600 |
| replace | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 469,021 | 2.132 | 1.100 | 124.300 |
| replace | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 496,860 | 2.013 | 1.100 | 124.300 |
| replace | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 528,131 | 1.893 | 1.100 | 197.200 |
| replace | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 524,898 | 1.905 | 1.000 | 997.900 |
| replace | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 524,879 | 1.905 | 1.000 | 997.900 |
| replace | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 454,931 | 2.198 | 1.000 | 3787.300 |
| replace | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 135,687 | 7.370 | 1.000 | 3787.300 |
| replace | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 102,269 | 9.778 | 1.000 | 3787.300 |
| replace | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 103,154 | 9.694 | 1.000 | 3787.300 |
| replace | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 99,074 | 10.094 | 0.900 | 3787.300 |
| replace | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 102,227 | 9.782 | 0.900 | 3787.300 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 103,816 | 9.632 | 0.800 | 3787.300 |
| value | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 1,577,287 | 0.634 | 0.100 | 208.900 |
| value | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 2,465,726 | 0.406 | 0.100 | 208.900 |
| value | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 2,836,155 | 0.353 | 0.100 | 208.900 |
| value | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 2,997,482 | 0.334 | 0.100 | 208.900 |
| value | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 3,118,325 | 0.321 | 0.100 | 208.900 |
| value | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 3,001,417 | 0.333 | 0.100 | 208.900 |
| value | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 2,892,486 | 0.346 | 0.100 | 208.900 |
| value | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 2,812,826 | 0.356 | 0.100 | 208.900 |
| value | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 2,754,157 | 0.363 | 0.100 | 208.900 |
| value | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 2,702,930 | 0.370 | 0.100 | 208.900 |
| value | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 2,686,477 | 0.372 | 0.100 | 208.900 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,686,064 | 0.372 | 0.100 | 208.900 |
| value | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 1,309,415 | 0.764 | 0.100 | 33.000 |
| value | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 863,409 | 1.158 | 0.100 | 33.000 |
| value | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 915,642 | 1.092 | 0.100 | 33.000 |
| value | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 913,387 | 1.095 | 0.100 | 62.100 |
| value | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 911,050 | 1.098 | 0.100 | 62.100 |
| value | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 816,657 | 1.225 | 0.100 | 62.100 |
| value | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 837,418 | 1.194 | 0.100 | 86.500 |
| value | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 849,758 | 1.177 | 0.100 | 86.500 |
| value | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 866,823 | 1.154 | 0.100 | 86.500 |
| value | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 873,705 | 1.145 | 0.100 | 86.500 |
| value | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 895,605 | 1.117 | 0.100 | 86.500 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 904,290 | 1.106 | 0.100 | 86.500 |
| value | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 5,747,126 | 0.174 | 0.100 | 4.700 |
| value | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 5,443,658 | 0.184 | 0.100 | 13.600 |
| value | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 5,832,604 | 0.171 | 0.100 | 13.800 |
| value | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 6,175,127 | 0.162 | 0.000 | 13.800 |
| value | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 6,395,089 | 0.156 | 0.000 | 14.400 |
| value | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 6,248,906 | 0.160 | 0.000 | 14.400 |
| value | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 5,818,690 | 0.172 | 0.000 | 27.500 |
| value | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 5,563,061 | 0.180 | 0.000 | 27.500 |
| value | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 5,313,426 | 0.188 | 0.000 | 59.600 |
| value | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 5,157,889 | 0.194 | 0.000 | 59.600 |
| value | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 5,074,618 | 0.197 | 0.000 | 77.700 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,081,611 | 0.197 | 0.000 | 77.700 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,803 | 356.800 |
| create | — | 0 | up | 5,000 | A | 1 | 801 | 1248.400 |
| create | — | 0 | up | 10,000 | A | 1 | 644 | 1553.600 |
| create | — | 0 | up | 15,000 | A | 1 | 416 | 2404.300 |
| create | — | 0 | up | 20,000 | A | 1 | 309 | 3239.400 |
| create | — | 0 | up | 25,000 | A | 1 | 259 | 3854.000 |
| create | — | 0 | down | 20,000 | A | 1 | 278 | 3596.900 |
| create | — | 0 | down | 15,000 | A | 1 | 386 | 2590.000 |
| create | — | 0 | down | 10,000 | A | 1 | 538 | 1860.400 |
| create | — | 0 | down | 5,000 | A | 1 | 1,195 | 836.700 |
| create | — | 0 | down | 1,000 | A | 1 | 6,631 | 150.800 |
| create | — | 0 | down | 0 | A | 1 | 69,444 | 14.400 |
| sequence | — | 0 | up | 1,000 | A | 1 | 440 | 2270.300 |
| sequence | — | 0 | up | 5,000 | A | 1 | 132 | 7603.700 |
| sequence | — | 0 | up | 10,000 | A | 1 | 91 | 10956.800 |
| sequence | — | 0 | up | 15,000 | A | 1 | 67 | 14834.500 |
| sequence | — | 0 | up | 20,000 | A | 1 | 51 | 19572.300 |
| sequence | — | 0 | up | 25,000 | A | 1 | 44 | 22657.800 |
| sequence | — | 0 | down | 20,000 | A | 1 | 56 | 17824.400 |
| sequence | — | 0 | down | 15,000 | A | 1 | 61 | 16374.700 |
| sequence | — | 0 | down | 10,000 | A | 1 | 79 | 12690.600 |
| sequence | — | 0 | down | 5,000 | A | 1 | 109 | 9207.400 |
| sequence | — | 0 | down | 1,000 | A | 1 | 161 | 6196.400 |
| sequence | — | 0 | down | 0 | A | 1 | 747 | 1337.800 |
| values | — | 0 | up | 1,000 | A | 1 | 585 | 1709.500 |
| values | — | 0 | up | 5,000 | A | 1 | 198 | 5047.400 |
| values | — | 0 | up | 10,000 | A | 1 | 50 | 20082.700 |
| values | — | 0 | up | 15,000 | A | 1 | 119 | 8401.900 |
| values | — | 0 | up | 20,000 | A | 1 | 101 | 9862.500 |
| values | — | 0 | up | 25,000 | A | 1 | 95 | 10509.000 |
| values | — | 0 | down | 20,000 | A | 1 | 116 | 8620.700 |
| values | — | 0 | down | 15,000 | A | 1 | 161 | 6196.300 |
| values | — | 0 | down | 10,000 | A | 1 | 222 | 4501.700 |
| values | — | 0 | down | 5,000 | A | 1 | 378 | 2644.600 |
| values | — | 0 | down | 1,000 | A | 1 | 2,138 | 467.800 |
| values | — | 0 | down | 0 | A | 1 | 109,890 | 9.100 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.613 | 0.232 | 0.381 |
| 0 | up | 5000 | 3.108 | 1.167 | 1.942 |
| 0 | up | 10000 | 6.228 | 2.343 | 3.884 |
| 0 | up | 15000 | 9.486 | 3.643 | 5.843 |
| 0 | up | 20000 | 12.852 | 5.113 | 7.739 |
| 0 | up | 25000 | 16.278 | 6.637 | 9.641 |
| 0 | down | 20000 | 13.340 | 5.613 | 7.727 |
| 0 | down | 15000 | 9.910 | 4.131 | 5.779 |
| 0 | down | 10000 | 7.153 | 3.295 | 3.857 |
| 0 | down | 5000 | 4.067 | 2.161 | 1.905 |
| 0 | down | 1000 | 1.807 | 1.421 | 0.386 |
| 0 | down | 0 | 1.231 | 1.231 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 49,966 | 0.402 | 421.140 | 8.429 | 120.418 | 15.525 |
| 0 | up | A | 5,000 | 5,000 | 254,523 | 2.043 | 428.454 | 8.417 | 150.813 | 19.625 |
| 0 | up | A | 10,000 | 10,000 | 509,098 | 4.098 | 429.682 | 8.440 | 194.734 | 24.536 |
| 0 | up | A | 15,000 | 15,000 | 765,837 | 6.183 | 432.249 | 8.466 | 208.438 | 29.444 |
| 0 | up | A | 20,000 | 20,000 | 1,014,350 | 8.209 | 430.368 | 8.486 | 279.426 | 34.234 |
| 0 | up | A | 25,000 | 25,000 | 1,263,607 | 10.242 | 429.572 | 8.499 | 293.344 | 39.002 |
| 0 | down | A | 20,000 | 20,000 | 1,012,792 | 8.267 | 433.443 | 8.559 | 295.301 | 34.236 |
| 0 | down | A | 15,000 | 15,000 | 757,461 | 6.185 | 432.337 | 8.562 | 298.023 | 29.390 |
| 0 | down | A | 10,000 | 10,000 | 505,565 | 4.118 | 431.804 | 8.541 | 297.375 | 24.615 |
| 0 | down | A | 5,000 | 5,000 | 249,719 | 2.025 | 424.661 | 8.503 | 295.121 | 19.779 |
| 0 | down | A | 1,000 | 1,000 | 50,567 | 0.408 | 428.020 | 8.464 | 293.523 | 15.984 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 294.605 | 14.906 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 49966 | 184228 | 184.228 | 3.687 | 271.76 | 14.53 | 161.92 | 12.35 |
| 0 | up | A | 5000 | 254523 | 1210131 | 242.026 | 4.755 | 1634.13 | 73.21 | 825.25 | 61.48 |
| 0 | up | A | 10000 | 509098 | 2448079 | 244.808 | 4.809 | 3283.48 | 149.01 | 1658.86 | 124.83 |
| 0 | up | A | 15000 | 765837 | 3734371 | 248.958 | 4.876 | 4974.88 | 226.26 | 3590.17 | 200.09 |
| 0 | up | A | 20000 | 1014350 | 4987172 | 249.359 | 4.917 | 7129.39 | 311.11 | 5143.68 | 263.60 |
| 0 | up | A | 25000 | 1263607 | 6249793 | 249.992 | 4.946 | 9254.82 | 392.21 | 6545.54 | 334.80 |
| 0 | down | A | 20000 | 1012792 | 5129580 | 256.479 | 5.065 | 7576.63 | 326.54 | 5319.60 | 278.20 |
| 0 | down | A | 15000 | 757461 | 3834350 | 255.623 | 5.062 | 5712.74 | 247.20 | 3993.54 | 209.87 |
| 0 | down | A | 10000 | 505565 | 2537356 | 253.736 | 5.019 | 3822.17 | 165.03 | 2665.76 | 139.77 |
| 0 | down | A | 5000 | 249719 | 1229097 | 245.819 | 4.922 | 1877.54 | 79.58 | 1312.05 | 67.88 |
| 0 | down | A | 1000 | 50567 | 240346 | 240.346 | 4.753 | 377.29 | 15.97 | 264.47 | 13.64 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 430.140 | 8.475 | 247.550 | 4.877 |
| 0 | A | scaleDown | 431.829 | 8.549 | 254.328 | 5.035 |
| 0 | A | fullLifecycle | 430.818 | 8.505 | 250.272 | 4.940 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
