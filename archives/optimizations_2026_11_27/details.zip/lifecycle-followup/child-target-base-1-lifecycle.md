# Sequencer dynamic lifecycle benchmark

2026-11-27T17:14:12.810Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.23 | 162.89 | 56.49 |
| CommonJS | 199.41 | 164.51 | 56.69 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 303,786 | 3.292 | 3.292 | 3.292 | 0.000 | 0: 3.292 | 0: 3.292 |
| apply | random | A | scaleDown | 24,999 | 329,813 | 3.032 | 3.032 | 3.032 | 0.000 | 0: 3.032 | 0: 3.032 |
| apply | random | A | fullLifecycle | 49,999 | 316,265 | 3.162 | 3.162 | 3.162 | 0.000 | 0: 3.162 | 0: 3.162 |
| create | — | A | scaleUp | 7 | 519 | 1927.743 | 1927.743 | 1927.743 | 0.000 | 0: 1927.743 | 0: 1927.743 |
| create | — | A | scaleDown | 6 | 664 | 1505.450 | 1505.450 | 1505.450 | 0.000 | 0: 1505.450 | 0: 1505.450 |
| create | — | A | fullLifecycle | 13 | 577 | 1732.838 | 1732.838 | 1732.838 | 0.000 | 0: 1732.838 | 0: 1732.838 |
| insert | head | A | scaleUp | 12,500 | 1,341,878 | 0.745 | 0.745 | 0.745 | 0.000 | 0: 0.745 | 0: 0.745 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,341,878 | 0.745 | 0.745 | 0.745 | 0.000 | 0: 0.745 | 0: 0.745 |
| insert | random | A | scaleUp | 25,000 | 603,997 | 1.656 | 1.656 | 1.656 | 0.000 | 0: 1.656 | 0: 1.656 |
| insert | random | A | scaleDown | 25,000 | 587,544 | 1.702 | 1.702 | 1.702 | 0.000 | 0: 1.702 | 0: 1.702 |
| insert | random | A | fullLifecycle | 50,000 | 595,657 | 1.679 | 1.679 | 1.679 | 0.000 | 0: 1.679 | 0: 1.679 |
| insert | tail | A | scaleUp | 12,500 | 1,201,946 | 0.832 | 0.832 | 0.832 | 0.000 | 0: 0.832 | 0: 0.832 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,201,946 | 0.832 | 0.832 | 0.832 | 0.000 | 0: 0.832 | 0: 0.832 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 634,083 | 1.577 | 1.577 | 1.577 | 0.000 | 0: 1.577 | 0: 1.577 |
| remove | head | A | fullLifecycle | 12,500 | 634,083 | 1.577 | 1.577 | 1.577 | 0.000 | 0: 1.577 | 0: 1.577 |
| remove | random | A | scaleUp | 25,000 | 462,819 | 2.161 | 2.161 | 2.161 | 0.000 | 0: 2.161 | 0: 2.161 |
| remove | random | A | scaleDown | 25,000 | 490,242 | 2.040 | 2.040 | 2.040 | 0.000 | 0: 2.040 | 0: 2.040 |
| remove | random | A | fullLifecycle | 50,000 | 476,136 | 2.100 | 2.100 | 2.100 | 0.000 | 0: 2.100 | 0: 2.100 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 736,494 | 1.358 | 1.358 | 1.358 | 0.000 | 0: 1.358 | 0: 1.358 |
| remove | tail | A | fullLifecycle | 12,500 | 736,494 | 1.358 | 1.358 | 1.358 | 0.000 | 0: 1.358 | 0: 1.358 |
| replace | head | A | scaleUp | 25,000 | 500,286 | 1.999 | 1.999 | 1.999 | 0.000 | 0: 1.999 | 0: 1.999 |
| replace | head | A | scaleDown | 25,000 | 461,936 | 2.165 | 2.165 | 2.165 | 0.000 | 0: 2.165 | 0: 2.165 |
| replace | head | A | fullLifecycle | 50,000 | 480,347 | 2.082 | 2.082 | 2.082 | 0.000 | 0: 2.082 | 0: 2.082 |
| replace | random | A | scaleUp | 25,000 | 357,013 | 2.801 | 2.801 | 2.801 | 0.000 | 0: 2.801 | 0: 2.801 |
| replace | random | A | scaleDown | 25,000 | 367,661 | 2.720 | 2.720 | 2.720 | 0.000 | 0: 2.720 | 0: 2.720 |
| replace | random | A | fullLifecycle | 50,000 | 362,258 | 2.760 | 2.760 | 2.760 | 0.000 | 0: 2.760 | 0: 2.760 |
| replace | tail | A | scaleUp | 25,000 | 507,737 | 1.970 | 1.970 | 1.970 | 0.000 | 0: 1.970 | 0: 1.970 |
| replace | tail | A | scaleDown | 25,000 | 55,317 | 18.078 | 18.078 | 18.078 | 0.000 | 0: 18.078 | 0: 18.078 |
| replace | tail | A | fullLifecycle | 50,000 | 99,764 | 10.024 | 10.024 | 10.024 | 0.000 | 0: 10.024 | 0: 10.024 |
| sequence | — | A | scaleUp | 6 | 72 | 13875.133 | 13875.133 | 13875.133 | 0.000 | 0: 13875.133 | 0: 13875.133 |
| sequence | — | A | scaleDown | 6 | 97 | 10344.717 | 10344.717 | 10344.717 | 0.000 | 0: 10344.717 | 0: 10344.717 |
| sequence | — | A | fullLifecycle | 12 | 83 | 12109.925 | 12109.925 | 12109.925 | 0.000 | 0: 12109.925 | 0: 12109.925 |
| value | head | A | scaleUp | 25,000 | 3,170,135 | 0.315 | 0.315 | 0.315 | 0.000 | 0: 0.315 | 0: 0.315 |
| value | head | A | scaleDown | 25,000 | 2,399,969 | 0.417 | 0.417 | 0.417 | 0.000 | 0: 0.417 | 0: 0.417 |
| value | head | A | fullLifecycle | 50,000 | 2,731,808 | 0.366 | 0.366 | 0.366 | 0.000 | 0: 0.366 | 0: 0.366 |
| value | random | A | scaleUp | 25,000 | 931,907 | 1.073 | 1.073 | 1.073 | 0.000 | 0: 1.073 | 0: 1.073 |
| value | random | A | scaleDown | 25,000 | 985,793 | 1.014 | 1.014 | 1.014 | 0.000 | 0: 1.014 | 0: 1.014 |
| value | random | A | fullLifecycle | 50,000 | 958,093 | 1.044 | 1.044 | 1.044 | 0.000 | 0: 1.044 | 0: 1.044 |
| value | tail | A | scaleUp | 25,000 | 6,319,994 | 0.158 | 0.158 | 0.158 | 0.000 | 0: 0.158 | 0: 0.158 |
| value | tail | A | scaleDown | 25,000 | 4,063,059 | 0.246 | 0.246 | 0.246 | 0.000 | 0: 0.246 | 0: 0.246 |
| value | tail | A | fullLifecycle | 50,000 | 4,946,234 | 0.202 | 0.202 | 0.202 | 0.000 | 0: 0.202 | 0: 0.202 |
| values | — | A | scaleUp | 6 | 146 | 6853.467 | 6853.467 | 6853.467 | 0.000 | 0: 6853.467 | 0: 6853.467 |
| values | — | A | scaleDown | 6 | 243 | 4114.083 | 4114.083 | 4114.083 | 0.000 | 0: 4114.083 | 0: 4114.083 |
| values | — | A | fullLifecycle | 12 | 182 | 5483.775 | 5483.775 | 5483.775 | 0.000 | 0: 5483.775 | 0: 5483.775 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5428540.000 | 428.569 | 8.477 |
| A | scaleDown | 5 | 4409840.000 | 432.337 | 8.548 |
| A | fullLifecycle | 11 | 4965494.545 | 430.082 | 8.506 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3126055.667 | 246.794 | 4.882 |
| A | scaleDown | 5 | 2596615.600 | 254.570 | 5.033 |
| A | fullLifecycle | 11 | 2885401.091 | 249.917 | 4.943 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 254,434 | 3.930 | 1.700 | 211.400 |
| apply | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 299,891 | 3.335 | 1.500 | 462.500 |
| apply | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 307,189 | 3.255 | 1.500 | 669.800 |
| apply | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 309,985 | 3.226 | 1.500 | 669.800 |
| apply | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 306,591 | 3.262 | 1.500 | 1280.300 |
| apply | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 303,786 | 3.292 | 1.500 | 1629.900 |
| apply | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 304,589 | 3.283 | 1.500 | 1629.900 |
| apply | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 307,756 | 3.249 | 1.500 | 1629.900 |
| apply | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 308,171 | 3.245 | 1.500 | 1629.900 |
| apply | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 311,195 | 3.213 | 1.500 | 1629.900 |
| apply | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 314,564 | 3.179 | 1.500 | 1629.900 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 316,265 | 3.162 | 1.400 | 1629.900 |
| insert | head | 0 | up | 1,000 | 51,204 | A | 500 | 922,679 | 1.084 | 0.300 | 55.100 |
| insert | head | 0 | up | 5,000 | 250,037 | A | 2,500 | 1,108,303 | 0.902 | 0.300 | 55.100 |
| insert | head | 0 | up | 10,000 | 506,154 | A | 5,000 | 1,237,011 | 0.808 | 0.300 | 55.100 |
| insert | head | 0 | up | 15,000 | 762,134 | A | 7,500 | 1,296,075 | 0.772 | 0.300 | 55.100 |
| insert | head | 0 | up | 20,000 | 1,012,964 | A | 10,000 | 1,321,772 | 0.757 | 0.300 | 55.100 |
| insert | head | 0 | up | 25,000 | 1,259,727 | A | 12,500 | 1,341,878 | 0.745 | 0.300 | 55.100 |
| insert | head | 0 | down | 20,000 | 1,009,630 | A | 12,500 | 1,341,878 | 0.745 | 0.300 | 55.100 |
| insert | head | 0 | down | 15,000 | 759,633 | A | 12,500 | 1,341,878 | 0.745 | 0.300 | 55.100 |
| insert | head | 0 | down | 10,000 | 507,941 | A | 12,500 | 1,341,878 | 0.745 | 0.300 | 55.100 |
| insert | head | 0 | down | 5,000 | 250,794 | A | 12,500 | 1,341,878 | 0.745 | 0.300 | 55.100 |
| insert | head | 0 | down | 1,000 | 51,447 | A | 12,500 | 1,341,878 | 0.745 | 0.300 | 55.100 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,341,878 | 0.745 | 0.300 | 55.100 |
| insert | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 528,039 | 1.894 | 0.500 | 327.200 |
| insert | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 535,745 | 1.867 | 0.500 | 876.800 |
| insert | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 604,617 | 1.654 | 0.500 | 876.800 |
| insert | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 613,086 | 1.631 | 0.500 | 876.800 |
| insert | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 601,507 | 1.662 | 0.500 | 876.800 |
| insert | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 603,997 | 1.656 | 0.500 | 876.800 |
| insert | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 589,747 | 1.696 | 0.500 | 876.800 |
| insert | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 572,211 | 1.748 | 0.500 | 1651.500 |
| insert | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 580,656 | 1.722 | 0.500 | 1651.500 |
| insert | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 584,580 | 1.711 | 0.500 | 1651.500 |
| insert | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 590,643 | 1.693 | 0.500 | 1651.500 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 595,657 | 1.679 | 0.400 | 1651.500 |
| insert | tail | 0 | up | 1,000 | 51,204 | A | 500 | 1,072,961 | 0.932 | 0.300 | 25.400 |
| insert | tail | 0 | up | 5,000 | 250,037 | A | 2,500 | 726,871 | 1.376 | 0.300 | 1490.500 |
| insert | tail | 0 | up | 10,000 | 506,154 | A | 5,000 | 1,000,380 | 1.000 | 0.300 | 1490.500 |
| insert | tail | 0 | up | 15,000 | 762,134 | A | 7,500 | 1,124,522 | 0.889 | 0.300 | 1490.500 |
| insert | tail | 0 | up | 20,000 | 1,012,964 | A | 10,000 | 1,176,222 | 0.850 | 0.300 | 1490.500 |
| insert | tail | 0 | up | 25,000 | 1,259,727 | A | 12,500 | 1,201,946 | 0.832 | 0.300 | 1490.500 |
| insert | tail | 0 | down | 20,000 | 1,009,630 | A | 12,500 | 1,201,946 | 0.832 | 0.300 | 1490.500 |
| insert | tail | 0 | down | 15,000 | 759,633 | A | 12,500 | 1,201,946 | 0.832 | 0.300 | 1490.500 |
| insert | tail | 0 | down | 10,000 | 507,941 | A | 12,500 | 1,201,946 | 0.832 | 0.300 | 1490.500 |
| insert | tail | 0 | down | 5,000 | 250,794 | A | 12,500 | 1,201,946 | 0.832 | 0.300 | 1490.500 |
| insert | tail | 0 | down | 1,000 | 51,447 | A | 12,500 | 1,201,946 | 0.832 | 0.300 | 1490.500 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,201,946 | 0.832 | 0.300 | 1490.500 |
| remove | head | 0 | up | 1,000 | 51,204 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 250,037 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 506,154 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 762,134 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,012,964 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,259,727 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,009,630 | A | 2,500 | 616,052 | 1.623 | 0.900 | 37.900 |
| remove | head | 0 | down | 15,000 | 759,633 | A | 5,000 | 587,876 | 1.701 | 0.900 | 462.000 |
| remove | head | 0 | down | 10,000 | 507,941 | A | 7,500 | 587,986 | 1.701 | 0.900 | 670.900 |
| remove | head | 0 | down | 5,000 | 250,794 | A | 10,000 | 612,014 | 1.634 | 0.900 | 670.900 |
| remove | head | 0 | down | 1,000 | 51,447 | A | 12,000 | 628,187 | 1.592 | 0.900 | 670.900 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 634,083 | 1.577 | 0.800 | 670.900 |
| remove | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 392,943 | 2.545 | 0.900 | 465.800 |
| remove | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 473,037 | 2.114 | 0.800 | 465.800 |
| remove | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 481,269 | 2.078 | 0.800 | 465.800 |
| remove | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 482,473 | 2.073 | 0.800 | 654.400 |
| remove | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 475,491 | 2.103 | 0.800 | 654.400 |
| remove | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 462,819 | 2.161 | 0.800 | 1929.200 |
| remove | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 457,971 | 2.184 | 0.800 | 1929.200 |
| remove | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 459,937 | 2.174 | 0.800 | 1929.200 |
| remove | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 462,696 | 2.161 | 0.800 | 1929.200 |
| remove | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 467,788 | 2.138 | 0.800 | 1929.200 |
| remove | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 472,438 | 2.117 | 0.800 | 1929.200 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 476,136 | 2.100 | 0.800 | 1929.200 |
| remove | tail | 0 | up | 1,000 | 51,204 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 250,037 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 506,154 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 762,134 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,012,964 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,259,727 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,009,630 | A | 2,500 | 693,731 | 1.441 | 0.900 | 53.700 |
| remove | tail | 0 | down | 15,000 | 759,633 | A | 5,000 | 693,770 | 1.441 | 0.900 | 53.700 |
| remove | tail | 0 | down | 10,000 | 507,941 | A | 7,500 | 713,830 | 1.401 | 0.900 | 53.700 |
| remove | tail | 0 | down | 5,000 | 250,794 | A | 10,000 | 722,616 | 1.384 | 0.900 | 53.700 |
| remove | tail | 0 | down | 1,000 | 51,447 | A | 12,000 | 731,529 | 1.367 | 0.800 | 53.700 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 736,494 | 1.358 | 0.800 | 53.700 |
| replace | head | 0 | up | 1,000 | 51,204 | A | 1,000 | 313,568 | 3.189 | 1.200 | 854.500 |
| replace | head | 0 | up | 5,000 | 250,037 | A | 5,000 | 444,101 | 2.252 | 1.200 | 854.500 |
| replace | head | 0 | up | 10,000 | 506,154 | A | 10,000 | 476,515 | 2.099 | 1.200 | 854.500 |
| replace | head | 0 | up | 15,000 | 762,134 | A | 15,000 | 490,201 | 2.040 | 1.200 | 854.500 |
| replace | head | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 499,958 | 2.000 | 1.100 | 854.500 |
| replace | head | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 500,286 | 1.999 | 1.100 | 854.500 |
| replace | head | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 491,873 | 2.033 | 1.100 | 854.500 |
| replace | head | 0 | down | 15,000 | 759,633 | A | 35,000 | 487,880 | 2.050 | 1.100 | 854.500 |
| replace | head | 0 | down | 10,000 | 507,941 | A | 40,000 | 484,863 | 2.062 | 1.100 | 854.500 |
| replace | head | 0 | down | 5,000 | 250,794 | A | 45,000 | 477,295 | 2.095 | 1.100 | 1544.000 |
| replace | head | 0 | down | 1,000 | 51,447 | A | 49,000 | 478,384 | 2.090 | 1.100 | 1544.000 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 480,347 | 2.082 | 1.000 | 1544.000 |
| replace | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 375,601 | 2.662 | 1.300 | 91.800 |
| replace | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 364,458 | 2.744 | 1.300 | 393.700 |
| replace | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 372,945 | 2.681 | 1.200 | 393.700 |
| replace | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 361,692 | 2.765 | 1.200 | 779.200 |
| replace | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 358,916 | 2.786 | 1.200 | 779.200 |
| replace | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 357,013 | 2.801 | 1.200 | 779.200 |
| replace | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 356,258 | 2.807 | 1.200 | 779.200 |
| replace | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 353,952 | 2.825 | 1.200 | 779.200 |
| replace | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 354,884 | 2.818 | 1.200 | 779.200 |
| replace | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 354,774 | 2.819 | 1.200 | 779.200 |
| replace | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 359,340 | 2.783 | 1.100 | 779.200 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 362,258 | 2.760 | 1.100 | 779.200 |
| replace | tail | 0 | up | 1,000 | 51,204 | A | 1,000 | 433,877 | 2.305 | 1.100 | 98.600 |
| replace | tail | 0 | up | 5,000 | 250,037 | A | 5,000 | 496,875 | 2.013 | 1.100 | 169.800 |
| replace | tail | 0 | up | 10,000 | 506,154 | A | 10,000 | 485,079 | 2.062 | 1.100 | 1157.800 |
| replace | tail | 0 | up | 15,000 | 762,134 | A | 15,000 | 507,667 | 1.970 | 1.100 | 1157.800 |
| replace | tail | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 503,465 | 1.986 | 1.100 | 1157.800 |
| replace | tail | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 507,737 | 1.970 | 1.100 | 1157.800 |
| replace | tail | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 130,725 | 7.650 | 1.100 | 1157.800 |
| replace | tail | 0 | down | 15,000 | 759,633 | A | 35,000 | 97,412 | 10.266 | 1.100 | 1157.800 |
| replace | tail | 0 | down | 10,000 | 507,941 | A | 40,000 | 98,233 | 10.180 | 1.100 | 1157.800 |
| replace | tail | 0 | down | 5,000 | 250,794 | A | 45,000 | 95,322 | 10.491 | 1.100 | 1157.800 |
| replace | tail | 0 | down | 1,000 | 51,447 | A | 49,000 | 98,247 | 10.178 | 1.100 | 1157.800 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 99,764 | 10.024 | 0.900 | 1157.800 |
| value | head | 0 | up | 1,000 | 51,204 | A | 1,000 | 1,062,699 | 0.941 | 0.100 | 334.000 |
| value | head | 0 | up | 5,000 | 250,037 | A | 5,000 | 2,245,980 | 0.445 | 0.100 | 334.000 |
| value | head | 0 | up | 10,000 | 506,154 | A | 10,000 | 2,740,702 | 0.365 | 0.100 | 334.000 |
| value | head | 0 | up | 15,000 | 762,134 | A | 15,000 | 2,943,312 | 0.340 | 0.100 | 334.000 |
| value | head | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 3,073,944 | 0.325 | 0.100 | 334.000 |
| value | head | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 3,170,135 | 0.315 | 0.100 | 334.000 |
| value | head | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 2,998,711 | 0.333 | 0.100 | 334.000 |
| value | head | 0 | down | 15,000 | 759,633 | A | 35,000 | 2,901,458 | 0.345 | 0.100 | 334.000 |
| value | head | 0 | down | 10,000 | 507,941 | A | 40,000 | 2,825,318 | 0.354 | 0.100 | 334.000 |
| value | head | 0 | down | 5,000 | 250,794 | A | 45,000 | 2,784,447 | 0.359 | 0.100 | 334.000 |
| value | head | 0 | down | 1,000 | 51,447 | A | 49,000 | 2,740,201 | 0.365 | 0.100 | 334.000 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,731,808 | 0.366 | 0.100 | 334.000 |
| value | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 1,311,303 | 0.763 | 0.100 | 38.900 |
| value | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 1,015,146 | 0.985 | 0.100 | 38.900 |
| value | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 987,810 | 1.012 | 0.100 | 38.900 |
| value | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 951,505 | 1.051 | 0.100 | 54.600 |
| value | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 938,813 | 1.065 | 0.100 | 54.600 |
| value | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 931,907 | 1.073 | 0.100 | 54.600 |
| value | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 930,922 | 1.074 | 0.100 | 54.600 |
| value | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 930,898 | 1.074 | 0.100 | 54.600 |
| value | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 933,585 | 1.071 | 0.100 | 106.000 |
| value | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 938,004 | 1.066 | 0.100 | 106.000 |
| value | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 948,768 | 1.054 | 0.100 | 106.000 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 958,093 | 1.044 | 0.100 | 106.000 |
| value | tail | 0 | up | 1,000 | 51,204 | A | 1,000 | 5,720,824 | 0.175 | 0.100 | 5.300 |
| value | tail | 0 | up | 5,000 | 250,037 | A | 5,000 | 5,543,237 | 0.180 | 0.100 | 13.900 |
| value | tail | 0 | up | 10,000 | 506,154 | A | 10,000 | 5,673,115 | 0.176 | 0.100 | 41.100 |
| value | tail | 0 | up | 15,000 | 762,134 | A | 15,000 | 5,961,844 | 0.168 | 0.000 | 41.100 |
| value | tail | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 6,203,474 | 0.161 | 0.000 | 41.100 |
| value | tail | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 6,319,994 | 0.158 | 0.000 | 41.100 |
| value | tail | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 5,798,334 | 0.172 | 0.000 | 41.100 |
| value | tail | 0 | down | 15,000 | 759,633 | A | 35,000 | 5,426,104 | 0.184 | 0.000 | 63.200 |
| value | tail | 0 | down | 10,000 | 507,941 | A | 40,000 | 5,227,938 | 0.191 | 0.000 | 63.200 |
| value | tail | 0 | down | 5,000 | 250,794 | A | 45,000 | 5,026,697 | 0.199 | 0.000 | 63.200 |
| value | tail | 0 | down | 1,000 | 51,447 | A | 49,000 | 4,941,808 | 0.202 | 0.000 | 63.200 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 4,946,234 | 0.202 | 0.000 | 63.200 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,796 | 357.600 |
| create | — | 0 | up | 5,000 | A | 1 | 1,183 | 845.100 |
| create | — | 0 | up | 10,000 | A | 1 | 569 | 1756.900 |
| create | — | 0 | up | 15,000 | A | 1 | 401 | 2494.000 |
| create | — | 0 | up | 20,000 | A | 1 | 301 | 3317.900 |
| create | — | 0 | up | 25,000 | A | 1 | 220 | 4542.000 |
| create | — | 0 | down | 20,000 | A | 1 | 278 | 3596.000 |
| create | — | 0 | down | 15,000 | A | 1 | 381 | 2621.500 |
| create | — | 0 | down | 10,000 | A | 1 | 552 | 1810.900 |
| create | — | 0 | down | 5,000 | A | 1 | 1,177 | 849.400 |
| create | — | 0 | down | 1,000 | A | 1 | 7,057 | 141.700 |
| create | — | 0 | down | 0 | A | 1 | 75,758 | 13.200 |
| sequence | — | 0 | up | 1,000 | A | 1 | 441 | 2266.700 |
| sequence | — | 0 | up | 5,000 | A | 1 | 130 | 7714.900 |
| sequence | — | 0 | up | 10,000 | A | 1 | 82 | 12262.700 |
| sequence | — | 0 | up | 15,000 | A | 1 | 71 | 14119.800 |
| sequence | — | 0 | up | 20,000 | A | 1 | 50 | 19924.200 |
| sequence | — | 0 | up | 25,000 | A | 1 | 37 | 26962.500 |
| sequence | — | 0 | down | 20,000 | A | 1 | 56 | 17904.100 |
| sequence | — | 0 | down | 15,000 | A | 1 | 67 | 14882.300 |
| sequence | — | 0 | down | 10,000 | A | 1 | 79 | 12736.200 |
| sequence | — | 0 | down | 5,000 | A | 1 | 114 | 8778.900 |
| sequence | — | 0 | down | 1,000 | A | 1 | 154 | 6477.600 |
| sequence | — | 0 | down | 0 | A | 1 | 776 | 1289.200 |
| values | — | 0 | up | 1,000 | A | 1 | 596 | 1677.800 |
| values | — | 0 | up | 5,000 | A | 1 | 256 | 3908.400 |
| values | — | 0 | up | 10,000 | A | 1 | 177 | 5665.100 |
| values | — | 0 | up | 15,000 | A | 1 | 118 | 8453.200 |
| values | — | 0 | up | 20,000 | A | 1 | 104 | 9640.400 |
| values | — | 0 | up | 25,000 | A | 1 | 85 | 11775.900 |
| values | — | 0 | down | 20,000 | A | 1 | 113 | 8834.100 |
| values | — | 0 | down | 15,000 | A | 1 | 130 | 7714.200 |
| values | — | 0 | down | 10,000 | A | 1 | 190 | 5250.700 |
| values | — | 0 | down | 5,000 | A | 1 | 431 | 2319.600 |
| values | — | 0 | down | 1,000 | A | 1 | 1,796 | 556.800 |
| values | — | 0 | down | 0 | A | 1 | 109,890 | 9.100 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.622 | 0.232 | 0.391 |
| 0 | up | 5000 | 3.076 | 1.168 | 1.908 |
| 0 | up | 10000 | 6.205 | 2.343 | 3.862 |
| 0 | up | 15000 | 9.457 | 3.643 | 5.815 |
| 0 | up | 20000 | 12.841 | 5.112 | 7.728 |
| 0 | up | 25000 | 16.247 | 6.636 | 9.611 |
| 0 | down | 20000 | 13.315 | 5.612 | 7.703 |
| 0 | down | 15000 | 9.926 | 4.131 | 5.796 |
| 0 | down | 10000 | 7.170 | 3.295 | 3.875 |
| 0 | down | 5000 | 4.075 | 2.161 | 1.913 |
| 0 | down | 1000 | 1.812 | 1.420 | 0.393 |
| 0 | down | 0 | 1.230 | 1.230 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 51,204 | 0.411 | 430.756 | 8.413 | 121.820 | 15.543 |
| 0 | up | A | 5,000 | 5,000 | 250,037 | 2.010 | 421.606 | 8.431 | 154.102 | 19.574 |
| 0 | up | A | 10,000 | 10,000 | 506,154 | 4.075 | 427.300 | 8.442 | 196.004 | 24.488 |
| 0 | up | A | 15,000 | 15,000 | 762,134 | 6.154 | 430.176 | 8.467 | 208.957 | 29.386 |
| 0 | up | A | 20,000 | 20,000 | 1,012,964 | 8.198 | 429.835 | 8.487 | 279.250 | 34.212 |
| 0 | up | A | 25,000 | 25,000 | 1,259,727 | 10.214 | 428.405 | 8.502 | 293.594 | 38.942 |
| 0 | down | A | 20,000 | 20,000 | 1,009,630 | 8.241 | 432.089 | 8.559 | 296.375 | 34.188 |
| 0 | down | A | 15,000 | 15,000 | 759,633 | 6.201 | 433.508 | 8.560 | 301.141 | 29.423 |
| 0 | down | A | 10,000 | 10,000 | 507,941 | 4.136 | 433.718 | 8.539 | 299.816 | 24.652 |
| 0 | down | A | 5,000 | 5,000 | 250,794 | 2.034 | 426.570 | 8.504 | 297.625 | 19.795 |
| 0 | down | A | 1,000 | 1,000 | 51,447 | 0.415 | 434.772 | 8.451 | 295.934 | 15.997 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 297.051 | 14.906 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 51204 | 187497 | 187.497 | 3.662 | 277.53 | 14.54 | 165.41 | 12.36 |
| 0 | up | A | 5000 | 250037 | 1195941 | 239.188 | 4.783 | 1610.38 | 73.38 | 813.25 | 61.61 |
| 0 | up | A | 10000 | 506154 | 2435808 | 243.581 | 4.812 | 3265.74 | 148.71 | 1649.99 | 124.72 |
| 0 | up | A | 15000 | 762134 | 3716482 | 247.765 | 4.876 | 4950.79 | 226.25 | 3565.22 | 200.28 |
| 0 | up | A | 20000 | 1012964 | 4982573 | 249.129 | 4.919 | 7121.78 | 311.32 | 5144.59 | 263.55 |
| 0 | up | A | 25000 | 1259727 | 6238033 | 249.521 | 4.952 | 9237.87 | 392.58 | 6535.88 | 334.89 |
| 0 | down | A | 20000 | 1009630 | 5113545 | 255.677 | 5.065 | 7558.03 | 326.74 | 5304.48 | 278.22 |
| 0 | down | A | 15000 | 759633 | 3843527 | 256.235 | 5.060 | 5727.79 | 247.31 | 4004.31 | 209.86 |
| 0 | down | A | 10000 | 507941 | 2547329 | 254.733 | 5.015 | 3837.94 | 164.83 | 2677.99 | 139.88 |
| 0 | down | A | 5000 | 250794 | 1235293 | 247.059 | 4.926 | 1887.01 | 79.61 | 1318.78 | 67.84 |
| 0 | down | A | 1000 | 51447 | 243384 | 243.384 | 4.731 | 382.91 | 15.90 | 268.58 | 13.64 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 428.569 | 8.477 | 246.794 | 4.882 |
| 0 | A | scaleDown | 432.337 | 8.548 | 254.570 | 5.033 |
| 0 | A | fullLifecycle | 430.082 | 8.506 | 249.917 | 4.943 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
