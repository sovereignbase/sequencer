# Sequencer dynamic lifecycle benchmark

2026-11-27T17:14:22.020Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.23 | 162.89 | 56.49 |
| CommonJS | 199.41 | 164.51 | 56.69 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 314,937 | 3.175 | 3.175 | 3.175 | 0.000 | 0: 3.175 | 0: 3.175 |
| apply | random | A | scaleDown | 24,999 | 321,987 | 3.106 | 3.106 | 3.106 | 0.000 | 0: 3.106 | 0: 3.106 |
| apply | random | A | fullLifecycle | 49,999 | 318,423 | 3.140 | 3.140 | 3.140 | 0.000 | 0: 3.140 | 0: 3.140 |
| create | — | A | scaleUp | 7 | 506 | 1974.500 | 1974.500 | 1974.500 | 0.000 | 0: 1974.500 | 0: 1974.500 |
| create | — | A | scaleDown | 6 | 660 | 1514.050 | 1514.050 | 1514.050 | 0.000 | 0: 1514.050 | 0: 1514.050 |
| create | — | A | fullLifecycle | 13 | 568 | 1761.985 | 1761.985 | 1761.985 | 0.000 | 0: 1761.985 | 0: 1761.985 |
| insert | head | A | scaleUp | 12,500 | 1,291,856 | 0.774 | 0.774 | 0.774 | 0.000 | 0: 0.774 | 0: 0.774 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,291,856 | 0.774 | 0.774 | 0.774 | 0.000 | 0: 0.774 | 0: 0.774 |
| insert | random | A | scaleUp | 25,000 | 549,214 | 1.821 | 1.821 | 1.821 | 0.000 | 0: 1.821 | 0: 1.821 |
| insert | random | A | scaleDown | 25,000 | 578,531 | 1.729 | 1.729 | 1.729 | 0.000 | 0: 1.729 | 0: 1.729 |
| insert | random | A | fullLifecycle | 50,000 | 563,491 | 1.775 | 1.775 | 1.775 | 0.000 | 0: 1.775 | 0: 1.775 |
| insert | tail | A | scaleUp | 12,500 | 1,450,251 | 0.690 | 0.690 | 0.690 | 0.000 | 0: 0.690 | 0: 0.690 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,450,251 | 0.690 | 0.690 | 0.690 | 0.000 | 0: 0.690 | 0: 0.690 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 685,732 | 1.458 | 1.458 | 1.458 | 0.000 | 0: 1.458 | 0: 1.458 |
| remove | head | A | fullLifecycle | 12,500 | 685,732 | 1.458 | 1.458 | 1.458 | 0.000 | 0: 1.458 | 0: 1.458 |
| remove | random | A | scaleUp | 25,000 | 474,741 | 2.106 | 2.106 | 2.106 | 0.000 | 0: 2.106 | 0: 2.106 |
| remove | random | A | scaleDown | 25,000 | 484,785 | 2.063 | 2.063 | 2.063 | 0.000 | 0: 2.063 | 0: 2.063 |
| remove | random | A | fullLifecycle | 50,000 | 479,711 | 2.085 | 2.085 | 2.085 | 0.000 | 0: 2.085 | 0: 2.085 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 744,101 | 1.344 | 1.344 | 1.344 | 0.000 | 0: 1.344 | 0: 1.344 |
| remove | tail | A | fullLifecycle | 12,500 | 744,101 | 1.344 | 1.344 | 1.344 | 0.000 | 0: 1.344 | 0: 1.344 |
| replace | head | A | scaleUp | 25,000 | 481,927 | 2.075 | 2.075 | 2.075 | 0.000 | 0: 2.075 | 0: 2.075 |
| replace | head | A | scaleDown | 25,000 | 456,360 | 2.191 | 2.191 | 2.191 | 0.000 | 0: 2.191 | 0: 2.191 |
| replace | head | A | fullLifecycle | 50,000 | 468,795 | 2.133 | 2.133 | 2.133 | 0.000 | 0: 2.133 | 0: 2.133 |
| replace | random | A | scaleUp | 25,000 | 334,096 | 2.993 | 2.993 | 2.993 | 0.000 | 0: 2.993 | 0: 2.993 |
| replace | random | A | scaleDown | 25,000 | 366,060 | 2.732 | 2.732 | 2.732 | 0.000 | 0: 2.732 | 0: 2.732 |
| replace | random | A | fullLifecycle | 50,000 | 349,348 | 2.862 | 2.862 | 2.862 | 0.000 | 0: 2.862 | 0: 2.862 |
| replace | tail | A | scaleUp | 25,000 | 538,898 | 1.856 | 1.856 | 1.856 | 0.000 | 0: 1.856 | 0: 1.856 |
| replace | tail | A | scaleDown | 25,000 | 48,479 | 20.627 | 20.627 | 20.627 | 0.000 | 0: 20.627 | 0: 20.627 |
| replace | tail | A | fullLifecycle | 50,000 | 88,956 | 11.242 | 11.242 | 11.242 | 0.000 | 0: 11.242 | 0: 11.242 |
| sequence | — | A | scaleUp | 6 | 62 | 16168.700 | 16168.700 | 16168.700 | 0.000 | 0: 16168.700 | 0: 16168.700 |
| sequence | — | A | scaleDown | 6 | 92 | 10870.850 | 10870.850 | 10870.850 | 0.000 | 0: 10870.850 | 0: 10870.850 |
| sequence | — | A | fullLifecycle | 12 | 74 | 13519.775 | 13519.775 | 13519.775 | 0.000 | 0: 13519.775 | 0: 13519.775 |
| value | head | A | scaleUp | 25,000 | 3,327,964 | 0.300 | 0.300 | 0.300 | 0.000 | 0: 0.300 | 0: 0.300 |
| value | head | A | scaleDown | 25,000 | 2,414,036 | 0.414 | 0.414 | 0.414 | 0.000 | 0: 0.414 | 0: 0.414 |
| value | head | A | fullLifecycle | 50,000 | 2,798,267 | 0.357 | 0.357 | 0.357 | 0.000 | 0: 0.357 | 0: 0.357 |
| value | random | A | scaleUp | 25,000 | 899,575 | 1.112 | 1.112 | 1.112 | 0.000 | 0: 1.112 | 0: 1.112 |
| value | random | A | scaleDown | 25,000 | 939,758 | 1.064 | 1.064 | 1.064 | 0.000 | 0: 1.064 | 0: 1.064 |
| value | random | A | fullLifecycle | 50,000 | 919,227 | 1.088 | 1.088 | 1.088 | 0.000 | 0: 1.088 | 0: 1.088 |
| value | tail | A | scaleUp | 25,000 | 6,309,626 | 0.158 | 0.158 | 0.158 | 0.000 | 0: 0.158 | 0: 0.158 |
| value | tail | A | scaleDown | 25,000 | 4,176,342 | 0.239 | 0.239 | 0.239 | 0.000 | 0: 0.239 | 0: 0.239 |
| value | tail | A | fullLifecycle | 50,000 | 5,025,984 | 0.199 | 0.199 | 0.199 | 0.000 | 0: 0.199 | 0: 0.199 |
| values | — | A | scaleUp | 6 | 107 | 9355.067 | 9355.067 | 9355.067 | 0.000 | 0: 9355.067 | 0: 9355.067 |
| values | — | A | scaleDown | 6 | 247 | 4050.367 | 4050.367 | 4050.367 | 0.000 | 0: 4050.367 | 0: 4050.367 |
| values | — | A | fullLifecycle | 12 | 149 | 6702.717 | 6702.717 | 6702.717 | 0.000 | 0: 6702.717 | 0: 6702.717 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5410752.667 | 427.165 | 8.478 |
| A | scaleDown | 5 | 4407357.600 | 432.094 | 8.548 |
| A | fullLifecycle | 11 | 4954664.000 | 429.144 | 8.506 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3116296.167 | 246.023 | 4.883 |
| A | scaleDown | 5 | 2595337.600 | 254.445 | 5.034 |
| A | fullLifecycle | 11 | 2879496.818 | 249.405 | 4.944 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 279,540 | 3.577 | 1.800 | 61.700 |
| apply | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 288,539 | 3.466 | 1.600 | 1522.200 |
| apply | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 309,620 | 3.230 | 1.500 | 1522.200 |
| apply | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 318,415 | 3.141 | 1.500 | 1522.200 |
| apply | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 321,860 | 3.107 | 1.500 | 1522.200 |
| apply | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 314,937 | 3.175 | 1.500 | 1522.200 |
| apply | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 315,536 | 3.169 | 1.500 | 1522.200 |
| apply | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 310,137 | 3.224 | 1.500 | 1522.200 |
| apply | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 311,159 | 3.214 | 1.500 | 1522.200 |
| apply | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 313,791 | 3.187 | 1.500 | 1522.200 |
| apply | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 316,763 | 3.157 | 1.400 | 1522.200 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 318,423 | 3.140 | 1.200 | 1522.200 |
| insert | head | 0 | up | 1,000 | 50,007 | A | 500 | 1,075,963 | 0.929 | 0.300 | 19.000 |
| insert | head | 0 | up | 5,000 | 256,206 | A | 2,500 | 1,160,362 | 0.862 | 0.300 | 22.000 |
| insert | head | 0 | up | 10,000 | 508,328 | A | 5,000 | 1,254,894 | 0.797 | 0.300 | 85.000 |
| insert | head | 0 | up | 15,000 | 756,035 | A | 7,500 | 1,273,193 | 0.785 | 0.300 | 237.400 |
| insert | head | 0 | up | 20,000 | 1,005,850 | A | 10,000 | 1,302,677 | 0.768 | 0.300 | 237.400 |
| insert | head | 0 | up | 25,000 | 1,252,902 | A | 12,500 | 1,291,856 | 0.774 | 0.300 | 237.400 |
| insert | head | 0 | down | 20,000 | 1,007,225 | A | 12,500 | 1,291,856 | 0.774 | 0.300 | 237.400 |
| insert | head | 0 | down | 15,000 | 759,799 | A | 12,500 | 1,291,856 | 0.774 | 0.300 | 237.400 |
| insert | head | 0 | down | 10,000 | 506,363 | A | 12,500 | 1,291,856 | 0.774 | 0.300 | 237.400 |
| insert | head | 0 | down | 5,000 | 254,264 | A | 12,500 | 1,291,856 | 0.774 | 0.300 | 237.400 |
| insert | head | 0 | down | 1,000 | 50,210 | A | 12,500 | 1,291,856 | 0.774 | 0.300 | 237.400 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,291,856 | 0.774 | 0.300 | 237.400 |
| insert | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 345,805 | 2.892 | 0.300 | 1026.200 |
| insert | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 492,645 | 2.030 | 0.300 | 1026.200 |
| insert | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 518,834 | 1.927 | 0.300 | 1363.100 |
| insert | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 552,614 | 1.810 | 0.300 | 1363.100 |
| insert | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 558,047 | 1.792 | 0.300 | 1363.100 |
| insert | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 549,214 | 1.821 | 0.300 | 1363.100 |
| insert | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 541,730 | 1.846 | 0.300 | 1363.100 |
| insert | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 527,770 | 1.895 | 0.300 | 1363.100 |
| insert | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 533,944 | 1.873 | 0.300 | 1363.100 |
| insert | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 547,094 | 1.828 | 0.300 | 1363.100 |
| insert | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 558,638 | 1.790 | 0.300 | 1363.100 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 563,491 | 1.775 | 0.300 | 1363.100 |
| insert | tail | 0 | up | 1,000 | 50,007 | A | 500 | 1,112,347 | 0.899 | 0.300 | 28.600 |
| insert | tail | 0 | up | 5,000 | 256,206 | A | 2,500 | 1,308,558 | 0.764 | 0.300 | 48.700 |
| insert | tail | 0 | up | 10,000 | 508,328 | A | 5,000 | 1,446,676 | 0.691 | 0.300 | 80.200 |
| insert | tail | 0 | up | 15,000 | 756,035 | A | 7,500 | 1,483,034 | 0.674 | 0.300 | 155.900 |
| insert | tail | 0 | up | 20,000 | 1,005,850 | A | 10,000 | 1,509,913 | 0.662 | 0.300 | 155.900 |
| insert | tail | 0 | up | 25,000 | 1,252,902 | A | 12,500 | 1,450,251 | 0.690 | 0.300 | 304.100 |
| insert | tail | 0 | down | 20,000 | 1,007,225 | A | 12,500 | 1,450,251 | 0.690 | 0.300 | 304.100 |
| insert | tail | 0 | down | 15,000 | 759,799 | A | 12,500 | 1,450,251 | 0.690 | 0.300 | 304.100 |
| insert | tail | 0 | down | 10,000 | 506,363 | A | 12,500 | 1,450,251 | 0.690 | 0.300 | 304.100 |
| insert | tail | 0 | down | 5,000 | 254,264 | A | 12,500 | 1,450,251 | 0.690 | 0.300 | 304.100 |
| insert | tail | 0 | down | 1,000 | 50,210 | A | 12,500 | 1,450,251 | 0.690 | 0.300 | 304.100 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,450,251 | 0.690 | 0.300 | 304.100 |
| remove | head | 0 | up | 1,000 | 50,007 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 256,206 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 508,328 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 756,035 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,005,850 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,252,902 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,007,225 | A | 2,500 | 678,389 | 1.474 | 0.800 | 52.300 |
| remove | head | 0 | down | 15,000 | 759,799 | A | 5,000 | 631,784 | 1.583 | 0.800 | 52.300 |
| remove | head | 0 | down | 10,000 | 506,363 | A | 7,500 | 620,548 | 1.611 | 0.800 | 657.300 |
| remove | head | 0 | down | 5,000 | 254,264 | A | 10,000 | 657,804 | 1.520 | 0.800 | 657.300 |
| remove | head | 0 | down | 1,000 | 50,210 | A | 12,000 | 679,079 | 1.473 | 0.700 | 657.300 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 685,732 | 1.458 | 0.700 | 657.300 |
| remove | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 528,569 | 1.892 | 0.800 | 29.400 |
| remove | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 423,266 | 2.363 | 0.800 | 2358.100 |
| remove | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 462,037 | 2.164 | 0.800 | 2358.100 |
| remove | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 482,543 | 2.072 | 0.800 | 2358.100 |
| remove | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 488,047 | 2.049 | 0.800 | 2358.100 |
| remove | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 474,741 | 2.106 | 0.800 | 2358.100 |
| remove | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 469,589 | 2.130 | 0.800 | 2358.100 |
| remove | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 456,049 | 2.193 | 0.800 | 2358.100 |
| remove | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 458,522 | 2.181 | 0.800 | 2358.100 |
| remove | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 468,571 | 2.134 | 0.800 | 2358.100 |
| remove | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 475,892 | 2.101 | 0.800 | 2358.100 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 479,711 | 2.085 | 0.700 | 2358.100 |
| remove | tail | 0 | up | 1,000 | 50,007 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 256,206 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 508,328 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 756,035 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,005,850 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,252,902 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,007,225 | A | 2,500 | 796,432 | 1.256 | 0.700 | 76.900 |
| remove | tail | 0 | down | 15,000 | 759,799 | A | 5,000 | 700,192 | 1.428 | 0.700 | 113.000 |
| remove | tail | 0 | down | 10,000 | 506,363 | A | 7,500 | 689,319 | 1.451 | 0.700 | 501.600 |
| remove | tail | 0 | down | 5,000 | 254,264 | A | 10,000 | 723,296 | 1.383 | 0.700 | 501.600 |
| remove | tail | 0 | down | 1,000 | 50,210 | A | 12,000 | 738,398 | 1.354 | 0.700 | 501.600 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 744,101 | 1.344 | 0.700 | 501.600 |
| replace | head | 0 | up | 1,000 | 50,007 | A | 1,000 | 367,255 | 2.723 | 1.000 | 498.800 |
| replace | head | 0 | up | 5,000 | 256,206 | A | 5,000 | 406,428 | 2.460 | 1.000 | 892.500 |
| replace | head | 0 | up | 10,000 | 508,328 | A | 10,000 | 477,710 | 2.093 | 1.000 | 892.500 |
| replace | head | 0 | up | 15,000 | 756,035 | A | 15,000 | 460,534 | 2.171 | 1.000 | 2993.400 |
| replace | head | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 488,116 | 2.049 | 1.000 | 2993.400 |
| replace | head | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 481,927 | 2.075 | 1.000 | 2993.400 |
| replace | head | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 482,601 | 2.072 | 1.000 | 2993.400 |
| replace | head | 0 | down | 15,000 | 759,799 | A | 35,000 | 471,442 | 2.121 | 1.000 | 2993.400 |
| replace | head | 0 | down | 10,000 | 506,363 | A | 40,000 | 453,377 | 2.206 | 1.000 | 3550.700 |
| replace | head | 0 | down | 5,000 | 254,264 | A | 45,000 | 460,266 | 2.173 | 1.000 | 3550.700 |
| replace | head | 0 | down | 1,000 | 50,210 | A | 49,000 | 466,340 | 2.144 | 1.000 | 3550.700 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 468,795 | 2.133 | 0.900 | 3550.700 |
| replace | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 342,313 | 2.921 | 1.200 | 267.600 |
| replace | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 365,182 | 2.738 | 1.200 | 386.900 |
| replace | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 368,176 | 2.716 | 1.200 | 665.000 |
| replace | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 354,909 | 2.818 | 1.200 | 897.600 |
| replace | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 348,483 | 2.870 | 1.200 | 1186.700 |
| replace | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 334,096 | 2.993 | 1.200 | 1879.400 |
| replace | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 337,930 | 2.959 | 1.200 | 1879.400 |
| replace | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 327,913 | 3.050 | 1.200 | 1879.400 |
| replace | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 332,897 | 3.004 | 1.200 | 1879.400 |
| replace | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 339,805 | 2.943 | 1.100 | 1879.400 |
| replace | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 346,432 | 2.887 | 1.000 | 1879.400 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 349,348 | 2.862 | 0.900 | 1879.400 |
| replace | tail | 0 | up | 1,000 | 50,007 | A | 1,000 | 428,522 | 2.334 | 1.000 | 113.700 |
| replace | tail | 0 | up | 5,000 | 256,206 | A | 5,000 | 517,004 | 1.934 | 1.000 | 132.500 |
| replace | tail | 0 | up | 10,000 | 508,328 | A | 10,000 | 539,826 | 1.852 | 1.000 | 168.600 |
| replace | tail | 0 | up | 15,000 | 756,035 | A | 15,000 | 549,203 | 1.821 | 1.000 | 168.600 |
| replace | tail | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 548,434 | 1.823 | 1.000 | 322.800 |
| replace | tail | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 538,898 | 1.856 | 1.000 | 322.800 |
| replace | tail | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 120,624 | 8.290 | 1.000 | 3645.200 |
| replace | tail | 0 | down | 15,000 | 759,799 | A | 35,000 | 84,189 | 11.878 | 1.000 | 3645.200 |
| replace | tail | 0 | down | 10,000 | 506,363 | A | 40,000 | 85,134 | 11.746 | 1.000 | 3645.200 |
| replace | tail | 0 | down | 5,000 | 254,264 | A | 45,000 | 84,652 | 11.813 | 1.000 | 3645.200 |
| replace | tail | 0 | down | 1,000 | 50,210 | A | 49,000 | 87,564 | 11.420 | 1.000 | 3645.200 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 88,956 | 11.242 | 0.900 | 3645.200 |
| value | head | 0 | up | 1,000 | 50,007 | A | 1,000 | 1,220,107 | 0.820 | 0.100 | 391.300 |
| value | head | 0 | up | 5,000 | 256,206 | A | 5,000 | 2,467,065 | 0.405 | 0.100 | 391.300 |
| value | head | 0 | up | 10,000 | 508,328 | A | 10,000 | 2,955,345 | 0.338 | 0.100 | 391.300 |
| value | head | 0 | up | 15,000 | 756,035 | A | 15,000 | 3,175,679 | 0.315 | 0.100 | 391.300 |
| value | head | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 3,303,546 | 0.303 | 0.100 | 391.300 |
| value | head | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 3,327,964 | 0.300 | 0.100 | 391.300 |
| value | head | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 3,140,967 | 0.318 | 0.100 | 391.300 |
| value | head | 0 | down | 15,000 | 759,799 | A | 35,000 | 2,930,808 | 0.341 | 0.100 | 391.300 |
| value | head | 0 | down | 10,000 | 506,363 | A | 40,000 | 2,862,049 | 0.349 | 0.100 | 391.300 |
| value | head | 0 | down | 5,000 | 254,264 | A | 45,000 | 2,827,219 | 0.354 | 0.100 | 391.300 |
| value | head | 0 | down | 1,000 | 50,210 | A | 49,000 | 2,796,788 | 0.358 | 0.100 | 391.300 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,798,267 | 0.357 | 0.100 | 391.300 |
| value | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 1,430,206 | 0.699 | 0.200 | 31.500 |
| value | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 1,068,102 | 0.936 | 0.100 | 47.000 |
| value | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 1,011,521 | 0.989 | 0.100 | 47.000 |
| value | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 967,031 | 1.034 | 0.100 | 47.000 |
| value | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 954,946 | 1.047 | 0.100 | 53.500 |
| value | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 899,575 | 1.112 | 0.100 | 53.500 |
| value | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 900,163 | 1.111 | 0.100 | 53.500 |
| value | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 879,653 | 1.137 | 0.100 | 59.600 |
| value | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 882,833 | 1.133 | 0.100 | 87.000 |
| value | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 895,542 | 1.117 | 0.100 | 87.000 |
| value | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 910,942 | 1.098 | 0.100 | 87.000 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 919,227 | 1.088 | 0.100 | 87.000 |
| value | tail | 0 | up | 1,000 | 50,007 | A | 1,000 | 5,485,464 | 0.182 | 0.100 | 4.900 |
| value | tail | 0 | up | 5,000 | 256,206 | A | 5,000 | 5,054,590 | 0.198 | 0.000 | 59.900 |
| value | tail | 0 | up | 10,000 | 508,328 | A | 10,000 | 5,558,335 | 0.180 | 0.000 | 59.900 |
| value | tail | 0 | up | 15,000 | 756,035 | A | 15,000 | 5,893,910 | 0.170 | 0.000 | 59.900 |
| value | tail | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 6,222,969 | 0.161 | 0.000 | 59.900 |
| value | tail | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 6,309,626 | 0.158 | 0.000 | 59.900 |
| value | tail | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 5,893,794 | 0.170 | 0.000 | 59.900 |
| value | tail | 0 | down | 15,000 | 759,799 | A | 35,000 | 5,527,043 | 0.181 | 0.000 | 59.900 |
| value | tail | 0 | down | 10,000 | 506,363 | A | 40,000 | 5,257,624 | 0.190 | 0.000 | 59.900 |
| value | tail | 0 | down | 5,000 | 254,264 | A | 45,000 | 5,114,392 | 0.196 | 0.000 | 59.900 |
| value | tail | 0 | down | 1,000 | 50,210 | A | 49,000 | 5,023,735 | 0.199 | 0.000 | 59.900 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,025,984 | 0.199 | 0.000 | 59.900 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,223 | 449.900 |
| create | — | 0 | up | 5,000 | A | 1 | 858 | 1166.100 |
| create | — | 0 | up | 10,000 | A | 1 | 639 | 1565.700 |
| create | — | 0 | up | 15,000 | A | 1 | 425 | 2352.100 |
| create | — | 0 | up | 20,000 | A | 1 | 275 | 3631.700 |
| create | — | 0 | up | 25,000 | A | 1 | 239 | 4191.000 |
| create | — | 0 | down | 20,000 | A | 1 | 286 | 3500.500 |
| create | — | 0 | down | 15,000 | A | 1 | 388 | 2580.200 |
| create | — | 0 | down | 10,000 | A | 1 | 497 | 2012.700 |
| create | — | 0 | down | 5,000 | A | 1 | 1,218 | 821.000 |
| create | — | 0 | down | 1,000 | A | 1 | 6,398 | 156.300 |
| create | — | 0 | down | 0 | A | 1 | 73,529 | 13.600 |
| sequence | — | 0 | up | 1,000 | A | 1 | 441 | 2266.500 |
| sequence | — | 0 | up | 5,000 | A | 1 | 91 | 10994.200 |
| sequence | — | 0 | up | 10,000 | A | 1 | 87 | 11444.300 |
| sequence | — | 0 | up | 15,000 | A | 1 | 67 | 14901.900 |
| sequence | — | 0 | up | 20,000 | A | 1 | 38 | 26132.000 |
| sequence | — | 0 | up | 25,000 | A | 1 | 32 | 31273.300 |
| sequence | — | 0 | down | 20,000 | A | 1 | 47 | 21211.800 |
| sequence | — | 0 | down | 15,000 | A | 1 | 65 | 15389.000 |
| sequence | — | 0 | down | 10,000 | A | 1 | 86 | 11575.500 |
| sequence | — | 0 | down | 5,000 | A | 1 | 101 | 9885.300 |
| sequence | — | 0 | down | 1,000 | A | 1 | 171 | 5850.200 |
| sequence | — | 0 | down | 0 | A | 1 | 761 | 1313.300 |
| values | — | 0 | up | 1,000 | A | 1 | 570 | 1753.800 |
| values | — | 0 | up | 5,000 | A | 1 | 206 | 4861.500 |
| values | — | 0 | up | 10,000 | A | 1 | 49 | 20307.300 |
| values | — | 0 | up | 15,000 | A | 1 | 118 | 8483.900 |
| values | — | 0 | up | 20,000 | A | 1 | 122 | 8224.700 |
| values | — | 0 | up | 25,000 | A | 1 | 80 | 12499.200 |
| values | — | 0 | down | 20,000 | A | 1 | 109 | 9136.800 |
| values | — | 0 | down | 15,000 | A | 1 | 146 | 6841.800 |
| values | — | 0 | down | 10,000 | A | 1 | 176 | 5674.100 |
| values | — | 0 | down | 5,000 | A | 1 | 472 | 2118.200 |
| values | — | 0 | down | 1,000 | A | 1 | 1,920 | 520.700 |
| values | — | 0 | down | 0 | A | 1 | 94,340 | 10.600 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.613 | 0.232 | 0.382 |
| 0 | up | 5000 | 3.122 | 1.167 | 1.955 |
| 0 | up | 10000 | 6.220 | 2.342 | 3.878 |
| 0 | up | 15000 | 9.408 | 3.640 | 5.768 |
| 0 | up | 20000 | 12.780 | 5.106 | 7.674 |
| 0 | up | 25000 | 16.189 | 6.630 | 9.559 |
| 0 | down | 20000 | 13.291 | 5.606 | 7.685 |
| 0 | down | 15000 | 9.922 | 4.125 | 5.797 |
| 0 | down | 10000 | 7.152 | 3.289 | 3.863 |
| 0 | down | 5000 | 4.095 | 2.155 | 1.940 |
| 0 | down | 1000 | 1.797 | 1.414 | 0.383 |
| 0 | down | 0 | 1.224 | 1.224 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 50,007 | 0.402 | 421.580 | 8.430 | 121.270 | 15.526 |
| 0 | up | A | 5,000 | 5,000 | 256,206 | 2.057 | 431.302 | 8.417 | 154.477 | 19.653 |
| 0 | up | A | 10,000 | 10,000 | 508,328 | 4.090 | 428.881 | 8.437 | 195.477 | 24.525 |
| 0 | up | A | 15,000 | 15,000 | 756,035 | 6.108 | 426.991 | 8.472 | 209.211 | 29.294 |
| 0 | up | A | 20,000 | 20,000 | 1,005,850 | 8.143 | 426.916 | 8.489 | 279.715 | 34.104 |
| 0 | up | A | 25,000 | 25,000 | 1,252,902 | 10.161 | 426.177 | 8.504 | 294.074 | 38.838 |
| 0 | down | A | 20,000 | 20,000 | 1,007,225 | 8.223 | 431.124 | 8.561 | 296.563 | 34.151 |
| 0 | down | A | 15,000 | 15,000 | 759,799 | 6.203 | 433.606 | 8.560 | 301.332 | 29.426 |
| 0 | down | A | 10,000 | 10,000 | 506,363 | 4.124 | 432.479 | 8.541 | 300.273 | 24.628 |
| 0 | down | A | 5,000 | 5,000 | 254,264 | 2.060 | 431.993 | 8.495 | 298.137 | 19.848 |
| 0 | down | A | 1,000 | 1,000 | 50,210 | 0.406 | 425.476 | 8.474 | 295.805 | 15.978 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 297.070 | 14.906 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 50007 | 184507 | 184.507 | 3.690 | 272.03 | 14.52 | 162.13 | 12.30 |
| 0 | up | A | 5000 | 256206 | 1218174 | 243.635 | 4.755 | 1644.25 | 73.50 | 830.68 | 61.66 |
| 0 | up | A | 10000 | 508328 | 2441689 | 244.169 | 4.803 | 3276.35 | 148.92 | 1655.21 | 124.79 |
| 0 | up | A | 15000 | 756035 | 3694120 | 246.275 | 4.886 | 4916.66 | 225.99 | 3545.68 | 200.14 |
| 0 | up | A | 20000 | 1005850 | 4950983 | 247.549 | 4.922 | 7073.44 | 311.23 | 5103.00 | 263.55 |
| 0 | up | A | 25000 | 1252902 | 6208304 | 248.332 | 4.955 | 9192.05 | 392.29 | 6496.81 | 335.16 |
| 0 | down | A | 20000 | 1007225 | 5103545 | 255.177 | 5.067 | 7538.07 | 326.43 | 5289.65 | 278.22 |
| 0 | down | A | 15000 | 759799 | 3844421 | 256.295 | 5.060 | 5730.74 | 247.34 | 4004.94 | 209.82 |
| 0 | down | A | 10000 | 506363 | 2541344 | 254.134 | 5.019 | 3828.12 | 165.02 | 2670.80 | 139.89 |
| 0 | down | A | 5000 | 254264 | 1247949 | 249.590 | 4.908 | 1909.46 | 79.58 | 1334.90 | 67.69 |
| 0 | down | A | 1000 | 50210 | 239429 | 239.429 | 4.769 | 375.26 | 16.04 | 262.97 | 13.69 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 427.165 | 8.478 | 246.023 | 4.883 |
| 0 | A | scaleDown | 432.094 | 8.548 | 254.445 | 5.034 |
| 0 | A | fullLifecycle | 429.144 | 8.506 | 249.405 | 4.944 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
