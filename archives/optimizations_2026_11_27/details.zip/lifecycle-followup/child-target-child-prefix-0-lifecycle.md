# Sequencer dynamic lifecycle benchmark

2026-11-27T17:13:55.665Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.44 | 163.09 | 56.54 |
| CommonJS | 199.62 | 164.71 | 56.75 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 305,323 | 3.275 | 3.275 | 3.275 | 0.000 | 0: 3.275 | 0: 3.275 |
| apply | random | A | scaleDown | 24,999 | 349,234 | 2.863 | 2.863 | 2.863 | 0.000 | 0: 2.863 | 0: 2.863 |
| apply | random | A | fullLifecycle | 49,999 | 325,805 | 3.069 | 3.069 | 3.069 | 0.000 | 0: 3.069 | 0: 3.069 |
| create | — | A | scaleUp | 7 | 551 | 1814.814 | 1814.814 | 1814.814 | 0.000 | 0: 1814.814 | 0: 1814.814 |
| create | — | A | scaleDown | 6 | 679 | 1471.833 | 1471.833 | 1471.833 | 0.000 | 0: 1471.833 | 0: 1471.833 |
| create | — | A | fullLifecycle | 13 | 604 | 1656.515 | 1656.515 | 1656.515 | 0.000 | 0: 1656.515 | 0: 1656.515 |
| insert | head | A | scaleUp | 12,500 | 1,315,803 | 0.760 | 0.760 | 0.760 | 0.000 | 0: 0.760 | 0: 0.760 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,315,803 | 0.760 | 0.760 | 0.760 | 0.000 | 0: 0.760 | 0: 0.760 |
| insert | random | A | scaleUp | 25,000 | 520,105 | 1.923 | 1.923 | 1.923 | 0.000 | 0: 1.923 | 0: 1.923 |
| insert | random | A | scaleDown | 25,000 | 643,390 | 1.554 | 1.554 | 1.554 | 0.000 | 0: 1.554 | 0: 1.554 |
| insert | random | A | fullLifecycle | 50,000 | 575,216 | 1.738 | 1.738 | 1.738 | 0.000 | 0: 1.738 | 0: 1.738 |
| insert | tail | A | scaleUp | 12,500 | 1,397,226 | 0.716 | 0.716 | 0.716 | 0.000 | 0: 0.716 | 0: 0.716 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,397,226 | 0.716 | 0.716 | 0.716 | 0.000 | 0: 0.716 | 0: 0.716 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 741,118 | 1.349 | 1.349 | 1.349 | 0.000 | 0: 1.349 | 0: 1.349 |
| remove | head | A | fullLifecycle | 12,500 | 741,118 | 1.349 | 1.349 | 1.349 | 0.000 | 0: 1.349 | 0: 1.349 |
| remove | random | A | scaleUp | 25,000 | 487,005 | 2.053 | 2.053 | 2.053 | 0.000 | 0: 2.053 | 0: 2.053 |
| remove | random | A | scaleDown | 25,000 | 542,261 | 1.844 | 1.844 | 1.844 | 0.000 | 0: 1.844 | 0: 1.844 |
| remove | random | A | fullLifecycle | 50,000 | 513,149 | 1.949 | 1.949 | 1.949 | 0.000 | 0: 1.949 | 0: 1.949 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 830,112 | 1.205 | 1.205 | 1.205 | 0.000 | 0: 1.205 | 0: 1.205 |
| remove | tail | A | fullLifecycle | 12,500 | 830,112 | 1.205 | 1.205 | 1.205 | 0.000 | 0: 1.205 | 0: 1.205 |
| replace | head | A | scaleUp | 25,000 | 473,007 | 2.114 | 2.114 | 2.114 | 0.000 | 0: 2.114 | 0: 2.114 |
| replace | head | A | scaleDown | 25,000 | 506,506 | 1.974 | 1.974 | 1.974 | 0.000 | 0: 1.974 | 0: 1.974 |
| replace | head | A | fullLifecycle | 50,000 | 489,184 | 2.044 | 2.044 | 2.044 | 0.000 | 0: 2.044 | 0: 2.044 |
| replace | random | A | scaleUp | 25,000 | 338,534 | 2.954 | 2.954 | 2.954 | 0.000 | 0: 2.954 | 0: 2.954 |
| replace | random | A | scaleDown | 25,000 | 408,603 | 2.447 | 2.447 | 2.447 | 0.000 | 0: 2.447 | 0: 2.447 |
| replace | random | A | fullLifecycle | 50,000 | 370,283 | 2.701 | 2.701 | 2.701 | 0.000 | 0: 2.701 | 0: 2.701 |
| replace | tail | A | scaleUp | 25,000 | 493,660 | 2.026 | 2.026 | 2.026 | 0.000 | 0: 2.026 | 0: 2.026 |
| replace | tail | A | scaleDown | 25,000 | 202,782 | 4.931 | 4.931 | 4.931 | 0.000 | 0: 4.931 | 0: 4.931 |
| replace | tail | A | fullLifecycle | 50,000 | 287,476 | 3.479 | 3.479 | 3.479 | 0.000 | 0: 3.479 | 0: 3.479 |
| sequence | — | A | scaleUp | 6 | 76 | 13152.833 | 13152.833 | 13152.833 | 0.000 | 0: 13152.833 | 0: 13152.833 |
| sequence | — | A | scaleDown | 6 | 96 | 10442.967 | 10442.967 | 10442.967 | 0.000 | 0: 10442.967 | 0: 10442.967 |
| sequence | — | A | fullLifecycle | 12 | 85 | 11797.900 | 11797.900 | 11797.900 | 0.000 | 0: 11797.900 | 0: 11797.900 |
| value | head | A | scaleUp | 25,000 | 3,184,632 | 0.314 | 0.314 | 0.314 | 0.000 | 0: 0.314 | 0: 0.314 |
| value | head | A | scaleDown | 25,000 | 2,384,336 | 0.419 | 0.419 | 0.419 | 0.000 | 0: 0.419 | 0: 0.419 |
| value | head | A | fullLifecycle | 50,000 | 2,726,980 | 0.367 | 0.367 | 0.367 | 0.000 | 0: 0.367 | 0: 0.367 |
| value | random | A | scaleUp | 25,000 | 902,071 | 1.109 | 1.109 | 1.109 | 0.000 | 0: 1.109 | 0: 1.109 |
| value | random | A | scaleDown | 25,000 | 1,000,124 | 1.000 | 1.000 | 1.000 | 0.000 | 0: 1.000 | 0: 1.000 |
| value | random | A | fullLifecycle | 50,000 | 948,570 | 1.054 | 1.054 | 1.054 | 0.000 | 0: 1.054 | 0: 1.054 |
| value | tail | A | scaleUp | 25,000 | 6,258,136 | 0.160 | 0.160 | 0.160 | 0.000 | 0: 0.160 | 0: 0.160 |
| value | tail | A | scaleDown | 25,000 | 4,359,426 | 0.229 | 0.229 | 0.229 | 0.000 | 0: 0.229 | 0: 0.229 |
| value | tail | A | fullLifecycle | 50,000 | 5,139,010 | 0.195 | 0.195 | 0.195 | 0.000 | 0: 0.195 | 0: 0.195 |
| values | — | A | scaleUp | 6 | 159 | 6280.733 | 6280.733 | 6280.733 | 0.000 | 0: 6280.733 | 0: 6280.733 |
| values | — | A | scaleDown | 6 | 233 | 4283.217 | 4283.217 | 4283.217 | 0.000 | 0: 4283.217 | 0: 4283.217 |
| values | — | A | fullLifecycle | 12 | 189 | 5281.975 | 5281.975 | 5281.975 | 0.000 | 0: 5281.975 | 0: 5281.975 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5448434.000 | 430.140 | 8.475 |
| A | scaleDown | 5 | 4404655.200 | 431.829 | 8.549 |
| A | fullLifecycle | 11 | 4973989.091 | 430.818 | 8.505 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3135629.000 | 247.550 | 4.877 |
| A | scaleDown | 5 | 2594145.800 | 254.328 | 5.035 |
| A | fullLifecycle | 11 | 2889500.273 | 250.272 | 4.940 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 244,278 | 4.094 | 1.900 | 234.100 |
| apply | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 269,460 | 3.711 | 1.600 | 1522.800 |
| apply | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 269,029 | 3.717 | 1.500 | 1522.800 |
| apply | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 288,555 | 3.466 | 1.500 | 1522.800 |
| apply | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 298,135 | 3.354 | 1.500 | 1522.800 |
| apply | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 305,323 | 3.275 | 1.500 | 1522.800 |
| apply | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 308,068 | 3.246 | 1.500 | 1522.800 |
| apply | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 311,966 | 3.205 | 1.500 | 1522.800 |
| apply | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 315,498 | 3.170 | 1.500 | 1522.800 |
| apply | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 317,901 | 3.146 | 1.400 | 1522.800 |
| apply | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 323,710 | 3.089 | 1.400 | 1522.800 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 325,805 | 3.069 | 1.200 | 1522.800 |
| insert | head | 0 | up | 1,000 | 49,966 | A | 500 | 765,228 | 1.307 | 0.300 | 140.500 |
| insert | head | 0 | up | 5,000 | 254,523 | A | 2,500 | 983,826 | 1.016 | 0.300 | 186.200 |
| insert | head | 0 | up | 10,000 | 509,098 | A | 5,000 | 1,153,323 | 0.867 | 0.300 | 186.200 |
| insert | head | 0 | up | 15,000 | 765,837 | A | 7,500 | 1,247,069 | 0.802 | 0.300 | 186.200 |
| insert | head | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 1,280,459 | 0.781 | 0.300 | 186.200 |
| insert | head | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 1,315,803 | 0.760 | 0.300 | 186.200 |
| insert | head | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 1,315,803 | 0.760 | 0.300 | 186.200 |
| insert | head | 0 | down | 15,000 | 757,461 | A | 12,500 | 1,315,803 | 0.760 | 0.300 | 186.200 |
| insert | head | 0 | down | 10,000 | 505,565 | A | 12,500 | 1,315,803 | 0.760 | 0.300 | 186.200 |
| insert | head | 0 | down | 5,000 | 249,719 | A | 12,500 | 1,315,803 | 0.760 | 0.300 | 186.200 |
| insert | head | 0 | down | 1,000 | 50,567 | A | 12,500 | 1,315,803 | 0.760 | 0.300 | 186.200 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,315,803 | 0.760 | 0.300 | 186.200 |
| insert | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 538,938 | 1.855 | 0.400 | 311.400 |
| insert | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 557,787 | 1.793 | 0.400 | 475.900 |
| insert | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 567,205 | 1.763 | 0.400 | 475.900 |
| insert | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 585,855 | 1.707 | 0.400 | 475.900 |
| insert | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 499,681 | 2.001 | 0.400 | 5800.900 |
| insert | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 520,105 | 1.923 | 0.400 | 5800.900 |
| insert | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 523,864 | 1.909 | 0.400 | 5800.900 |
| insert | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 532,217 | 1.879 | 0.400 | 5800.900 |
| insert | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 546,695 | 1.829 | 0.400 | 5800.900 |
| insert | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 557,087 | 1.795 | 0.400 | 5800.900 |
| insert | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 570,218 | 1.754 | 0.400 | 5800.900 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 575,216 | 1.738 | 0.400 | 5800.900 |
| insert | tail | 0 | up | 1,000 | 49,966 | A | 500 | 1,075,963 | 0.929 | 0.300 | 24.200 |
| insert | tail | 0 | up | 5,000 | 254,523 | A | 2,500 | 1,129,995 | 0.885 | 0.300 | 210.200 |
| insert | tail | 0 | up | 10,000 | 509,098 | A | 5,000 | 1,276,878 | 0.783 | 0.300 | 210.200 |
| insert | tail | 0 | up | 15,000 | 765,837 | A | 7,500 | 1,351,303 | 0.740 | 0.300 | 210.200 |
| insert | tail | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 1,409,026 | 0.710 | 0.300 | 210.200 |
| insert | tail | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 1,397,226 | 0.716 | 0.300 | 305.100 |
| insert | tail | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 1,397,226 | 0.716 | 0.300 | 305.100 |
| insert | tail | 0 | down | 15,000 | 757,461 | A | 12,500 | 1,397,226 | 0.716 | 0.300 | 305.100 |
| insert | tail | 0 | down | 10,000 | 505,565 | A | 12,500 | 1,397,226 | 0.716 | 0.300 | 305.100 |
| insert | tail | 0 | down | 5,000 | 249,719 | A | 12,500 | 1,397,226 | 0.716 | 0.300 | 305.100 |
| insert | tail | 0 | down | 1,000 | 50,567 | A | 12,500 | 1,397,226 | 0.716 | 0.300 | 305.100 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,397,226 | 0.716 | 0.300 | 305.100 |
| remove | head | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 707,014 | 1.414 | 0.900 | 15.300 |
| remove | head | 0 | down | 15,000 | 757,461 | A | 5,000 | 720,835 | 1.387 | 0.800 | 84.400 |
| remove | head | 0 | down | 10,000 | 505,565 | A | 7,500 | 693,808 | 1.441 | 0.800 | 668.700 |
| remove | head | 0 | down | 5,000 | 249,719 | A | 10,000 | 721,490 | 1.386 | 0.800 | 668.700 |
| remove | head | 0 | down | 1,000 | 50,567 | A | 12,000 | 735,308 | 1.360 | 0.700 | 668.700 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 741,118 | 1.349 | 0.700 | 668.700 |
| remove | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 447,067 | 2.237 | 0.800 | 262.400 |
| remove | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 485,909 | 2.058 | 0.800 | 262.400 |
| remove | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 462,109 | 2.164 | 0.800 | 390.400 |
| remove | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 481,359 | 2.077 | 0.800 | 390.400 |
| remove | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 481,422 | 2.077 | 0.800 | 390.400 |
| remove | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 487,005 | 2.053 | 0.800 | 390.400 |
| remove | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 486,501 | 2.055 | 0.800 | 390.400 |
| remove | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 488,547 | 2.047 | 0.800 | 390.400 |
| remove | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 494,025 | 2.024 | 0.800 | 390.400 |
| remove | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 501,304 | 1.995 | 0.800 | 390.400 |
| remove | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 508,985 | 1.965 | 0.800 | 390.400 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 513,149 | 1.949 | 0.700 | 390.400 |
| remove | tail | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 741,444 | 1.349 | 0.800 | 57.900 |
| remove | tail | 0 | down | 15,000 | 757,461 | A | 5,000 | 784,757 | 1.274 | 0.800 | 57.900 |
| remove | tail | 0 | down | 10,000 | 505,565 | A | 7,500 | 794,837 | 1.258 | 0.700 | 76.200 |
| remove | tail | 0 | down | 5,000 | 249,719 | A | 10,000 | 811,135 | 1.233 | 0.700 | 76.200 |
| remove | tail | 0 | down | 1,000 | 50,567 | A | 12,000 | 823,763 | 1.214 | 0.700 | 76.200 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 830,112 | 1.205 | 0.700 | 76.200 |
| replace | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 419,410 | 2.384 | 1.100 | 44.300 |
| replace | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 465,823 | 2.147 | 1.100 | 171.100 |
| replace | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 492,283 | 2.031 | 1.100 | 171.100 |
| replace | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 516,136 | 1.937 | 1.000 | 370.000 |
| replace | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 507,707 | 1.970 | 1.000 | 1659.700 |
| replace | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 473,007 | 2.114 | 1.000 | 4245.900 |
| replace | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 478,070 | 2.092 | 1.000 | 4245.900 |
| replace | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 471,330 | 2.122 | 1.000 | 4245.900 |
| replace | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 475,222 | 2.104 | 1.000 | 4245.900 |
| replace | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 480,576 | 2.081 | 1.000 | 4245.900 |
| replace | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 486,718 | 2.055 | 1.000 | 4245.900 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 489,184 | 2.044 | 0.900 | 4245.900 |
| replace | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 368,487 | 2.714 | 1.100 | 88.000 |
| replace | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 318,236 | 3.142 | 1.100 | 1194.500 |
| replace | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 335,325 | 2.982 | 1.100 | 1194.500 |
| replace | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 340,586 | 2.936 | 1.100 | 1194.500 |
| replace | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 330,686 | 3.024 | 1.100 | 3061.900 |
| replace | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 338,534 | 2.954 | 1.100 | 3061.900 |
| replace | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 343,392 | 2.912 | 1.100 | 3061.900 |
| replace | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 346,556 | 2.886 | 1.100 | 3061.900 |
| replace | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 354,285 | 2.823 | 1.100 | 3061.900 |
| replace | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 359,358 | 2.783 | 1.000 | 3061.900 |
| replace | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 367,359 | 2.722 | 1.000 | 3061.900 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 370,283 | 2.701 | 0.900 | 3061.900 |
| replace | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 344,329 | 2.904 | 1.000 | 612.600 |
| replace | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 452,579 | 2.210 | 1.000 | 612.600 |
| replace | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 476,181 | 2.100 | 1.000 | 612.600 |
| replace | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 492,735 | 2.029 | 1.000 | 775.000 |
| replace | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 499,763 | 2.001 | 1.000 | 775.000 |
| replace | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 493,660 | 2.026 | 1.000 | 1641.700 |
| replace | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 433,768 | 2.305 | 1.000 | 1641.700 |
| replace | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 294,959 | 3.390 | 1.000 | 1641.700 |
| replace | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 304,192 | 3.287 | 1.000 | 1641.700 |
| replace | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 281,703 | 3.550 | 0.900 | 1641.700 |
| replace | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 284,335 | 3.517 | 0.900 | 1641.700 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 287,476 | 3.479 | 0.900 | 1641.700 |
| value | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 1,457,089 | 0.686 | 0.100 | 245.800 |
| value | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 2,419,433 | 0.413 | 0.100 | 245.800 |
| value | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 2,709,954 | 0.369 | 0.100 | 245.800 |
| value | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 2,974,774 | 0.336 | 0.100 | 245.800 |
| value | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 3,112,550 | 0.321 | 0.100 | 245.800 |
| value | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 3,184,632 | 0.314 | 0.100 | 245.800 |
| value | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 3,000,540 | 0.333 | 0.100 | 245.800 |
| value | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 2,880,990 | 0.347 | 0.100 | 245.800 |
| value | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 2,810,094 | 0.356 | 0.100 | 245.800 |
| value | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 2,756,897 | 0.363 | 0.100 | 245.800 |
| value | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 2,723,766 | 0.367 | 0.100 | 245.800 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,726,980 | 0.367 | 0.100 | 245.800 |
| value | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 1,296,008 | 0.772 | 0.100 | 16.500 |
| value | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 984,155 | 1.016 | 0.100 | 17.200 |
| value | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 891,957 | 1.121 | 0.100 | 18.700 |
| value | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 892,400 | 1.121 | 0.100 | 41.900 |
| value | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 899,556 | 1.112 | 0.100 | 55.100 |
| value | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 902,071 | 1.109 | 0.100 | 59.400 |
| value | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 898,941 | 1.112 | 0.100 | 77.200 |
| value | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 900,915 | 1.110 | 0.100 | 77.200 |
| value | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 913,876 | 1.094 | 0.100 | 77.200 |
| value | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 923,556 | 1.083 | 0.100 | 77.200 |
| value | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 939,979 | 1.064 | 0.100 | 81.700 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 948,570 | 1.054 | 0.100 | 81.700 |
| value | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 5,227,392 | 0.191 | 0.100 | 5.200 |
| value | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 5,237,247 | 0.191 | 0.100 | 18.400 |
| value | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 5,439,809 | 0.184 | 0.100 | 52.000 |
| value | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 5,844,991 | 0.171 | 0.000 | 52.000 |
| value | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 6,097,003 | 0.164 | 0.000 | 52.000 |
| value | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 6,258,136 | 0.160 | 0.000 | 52.000 |
| value | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 5,822,868 | 0.172 | 0.000 | 52.000 |
| value | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 5,565,538 | 0.180 | 0.000 | 52.000 |
| value | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 5,372,806 | 0.186 | 0.000 | 52.000 |
| value | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 5,236,577 | 0.191 | 0.000 | 52.000 |
| value | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 5,137,238 | 0.195 | 0.000 | 52.000 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,139,010 | 0.195 | 0.000 | 52.000 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,684 | 372.600 |
| create | — | 0 | up | 5,000 | A | 1 | 1,059 | 944.400 |
| create | — | 0 | up | 10,000 | A | 1 | 592 | 1690.400 |
| create | — | 0 | up | 15,000 | A | 1 | 418 | 2393.000 |
| create | — | 0 | up | 20,000 | A | 1 | 313 | 3196.400 |
| create | — | 0 | up | 25,000 | A | 1 | 261 | 3828.800 |
| create | — | 0 | down | 20,000 | A | 1 | 280 | 3567.600 |
| create | — | 0 | down | 15,000 | A | 1 | 397 | 2516.300 |
| create | — | 0 | down | 10,000 | A | 1 | 570 | 1753.400 |
| create | — | 0 | down | 5,000 | A | 1 | 1,210 | 826.500 |
| create | — | 0 | down | 1,000 | A | 1 | 6,515 | 153.500 |
| create | — | 0 | down | 0 | A | 1 | 72,993 | 13.700 |
| sequence | — | 0 | up | 1,000 | A | 1 | 432 | 2315.300 |
| sequence | — | 0 | up | 5,000 | A | 1 | 125 | 7984.100 |
| sequence | — | 0 | up | 10,000 | A | 1 | 88 | 11375.900 |
| sequence | — | 0 | up | 15,000 | A | 1 | 67 | 14852.000 |
| sequence | — | 0 | up | 20,000 | A | 1 | 52 | 19104.600 |
| sequence | — | 0 | up | 25,000 | A | 1 | 43 | 23285.100 |
| sequence | — | 0 | down | 20,000 | A | 1 | 54 | 18357.100 |
| sequence | — | 0 | down | 15,000 | A | 1 | 64 | 15569.100 |
| sequence | — | 0 | down | 10,000 | A | 1 | 85 | 11789.800 |
| sequence | — | 0 | down | 5,000 | A | 1 | 117 | 8543.700 |
| sequence | — | 0 | down | 1,000 | A | 1 | 143 | 6973.900 |
| sequence | — | 0 | down | 0 | A | 1 | 702 | 1424.200 |
| values | — | 0 | up | 1,000 | A | 1 | 547 | 1829.600 |
| values | — | 0 | up | 5,000 | A | 1 | 221 | 4529.600 |
| values | — | 0 | up | 10,000 | A | 1 | 207 | 4829.800 |
| values | — | 0 | up | 15,000 | A | 1 | 137 | 7296.100 |
| values | — | 0 | up | 20,000 | A | 1 | 108 | 9259.200 |
| values | — | 0 | up | 25,000 | A | 1 | 101 | 9940.100 |
| values | — | 0 | down | 20,000 | A | 1 | 109 | 9194.600 |
| values | — | 0 | down | 15,000 | A | 1 | 142 | 7056.600 |
| values | — | 0 | down | 10,000 | A | 1 | 177 | 5634.300 |
| values | — | 0 | down | 5,000 | A | 1 | 304 | 3292.800 |
| values | — | 0 | down | 1,000 | A | 1 | 1,981 | 504.700 |
| values | — | 0 | down | 0 | A | 1 | 61,350 | 16.300 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.613 | 0.232 | 0.381 |
| 0 | up | 5000 | 3.108 | 1.167 | 1.942 |
| 0 | up | 10000 | 6.228 | 2.343 | 3.884 |
| 0 | up | 15000 | 9.486 | 3.643 | 5.843 |
| 0 | up | 20000 | 12.852 | 5.113 | 7.739 |
| 0 | up | 25000 | 16.278 | 6.637 | 9.641 |
| 0 | down | 20000 | 13.340 | 5.613 | 7.727 |
| 0 | down | 15000 | 9.910 | 4.131 | 5.779 |
| 0 | down | 10000 | 7.153 | 3.295 | 3.857 |
| 0 | down | 5000 | 4.067 | 2.161 | 1.905 |
| 0 | down | 1000 | 1.807 | 1.421 | 0.386 |
| 0 | down | 0 | 1.231 | 1.231 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 49,966 | 0.402 | 421.140 | 8.429 | 120.930 | 15.526 |
| 0 | up | A | 5,000 | 5,000 | 254,523 | 2.043 | 428.454 | 8.417 | 152.496 | 19.642 |
| 0 | up | A | 10,000 | 10,000 | 509,098 | 4.098 | 429.682 | 8.440 | 194.898 | 24.534 |
| 0 | up | A | 15,000 | 15,000 | 765,837 | 6.183 | 432.249 | 8.466 | 209.020 | 29.445 |
| 0 | up | A | 20,000 | 20,000 | 1,014,350 | 8.209 | 430.368 | 8.486 | 281.539 | 34.235 |
| 0 | up | A | 25,000 | 25,000 | 1,263,607 | 10.242 | 429.572 | 8.499 | 296.246 | 39.003 |
| 0 | down | A | 20,000 | 20,000 | 1,012,792 | 8.267 | 433.443 | 8.559 | 295.930 | 34.237 |
| 0 | down | A | 15,000 | 15,000 | 757,461 | 6.185 | 432.337 | 8.562 | 301.574 | 29.391 |
| 0 | down | A | 10,000 | 10,000 | 505,565 | 4.118 | 431.804 | 8.541 | 298.707 | 24.617 |
| 0 | down | A | 5,000 | 5,000 | 249,719 | 2.025 | 424.661 | 8.503 | 296.410 | 19.781 |
| 0 | down | A | 1,000 | 1,000 | 50,567 | 0.408 | 428.020 | 8.464 | 295.262 | 15.985 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 295.691 | 14.908 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 49966 | 184228 | 184.228 | 3.687 | 271.76 | 14.53 | 161.92 | 12.35 |
| 0 | up | A | 5000 | 254523 | 1210131 | 242.026 | 4.755 | 1634.13 | 73.21 | 825.25 | 61.48 |
| 0 | up | A | 10000 | 509098 | 2448079 | 244.808 | 4.809 | 3283.48 | 149.01 | 1658.86 | 124.83 |
| 0 | up | A | 15000 | 765837 | 3734371 | 248.958 | 4.876 | 4974.88 | 226.26 | 3590.17 | 200.09 |
| 0 | up | A | 20000 | 1014350 | 4987172 | 249.359 | 4.917 | 7129.39 | 311.11 | 5143.68 | 263.60 |
| 0 | up | A | 25000 | 1263607 | 6249793 | 249.992 | 4.946 | 9254.82 | 392.21 | 6545.54 | 334.80 |
| 0 | down | A | 20000 | 1012792 | 5129580 | 256.479 | 5.065 | 7576.63 | 326.54 | 5319.60 | 278.20 |
| 0 | down | A | 15000 | 757461 | 3834350 | 255.623 | 5.062 | 5712.74 | 247.20 | 3993.54 | 209.87 |
| 0 | down | A | 10000 | 505565 | 2537356 | 253.736 | 5.019 | 3822.17 | 165.03 | 2665.76 | 139.77 |
| 0 | down | A | 5000 | 249719 | 1229097 | 245.819 | 4.922 | 1877.54 | 79.58 | 1312.05 | 67.88 |
| 0 | down | A | 1000 | 50567 | 240346 | 240.346 | 4.753 | 377.29 | 15.97 | 264.47 | 13.64 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 430.140 | 8.475 | 247.550 | 4.877 |
| 0 | A | scaleDown | 431.829 | 8.549 | 254.328 | 5.035 |
| 0 | A | fullLifecycle | 430.818 | 8.505 | 250.272 | 4.940 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
