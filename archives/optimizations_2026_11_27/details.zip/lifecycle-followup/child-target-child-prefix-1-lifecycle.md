# Sequencer dynamic lifecycle benchmark

2026-11-27T17:14:03.930Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.44 | 163.09 | 56.54 |
| CommonJS | 199.62 | 164.71 | 56.75 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 311,119 | 3.214 | 3.214 | 3.214 | 0.000 | 0: 3.214 | 0: 3.214 |
| apply | random | A | scaleDown | 24,999 | 349,308 | 2.863 | 2.863 | 2.863 | 0.000 | 0: 2.863 | 0: 2.863 |
| apply | random | A | fullLifecycle | 49,999 | 329,109 | 3.039 | 3.039 | 3.039 | 0.000 | 0: 3.039 | 0: 3.039 |
| create | — | A | scaleUp | 7 | 523 | 1911.129 | 1911.129 | 1911.129 | 0.000 | 0: 1911.129 | 0: 1911.129 |
| create | — | A | scaleDown | 6 | 578 | 1730.717 | 1730.717 | 1730.717 | 0.000 | 0: 1730.717 | 0: 1730.717 |
| create | — | A | fullLifecycle | 13 | 547 | 1827.862 | 1827.862 | 1827.862 | 0.000 | 0: 1827.862 | 0: 1827.862 |
| insert | head | A | scaleUp | 12,500 | 1,348,116 | 0.742 | 0.742 | 0.742 | 0.000 | 0: 0.742 | 0: 0.742 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,348,116 | 0.742 | 0.742 | 0.742 | 0.000 | 0: 0.742 | 0: 0.742 |
| insert | random | A | scaleUp | 25,000 | 595,045 | 1.681 | 1.681 | 1.681 | 0.000 | 0: 1.681 | 0: 1.681 |
| insert | random | A | scaleDown | 25,000 | 591,949 | 1.689 | 1.689 | 1.689 | 0.000 | 0: 1.689 | 0: 1.689 |
| insert | random | A | fullLifecycle | 50,000 | 593,493 | 1.685 | 1.685 | 1.685 | 0.000 | 0: 1.685 | 0: 1.685 |
| insert | tail | A | scaleUp | 12,500 | 1,351,220 | 0.740 | 0.740 | 0.740 | 0.000 | 0: 0.740 | 0: 0.740 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,351,220 | 0.740 | 0.740 | 0.740 | 0.000 | 0: 0.740 | 0: 0.740 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 725,289 | 1.379 | 1.379 | 1.379 | 0.000 | 0: 1.379 | 0: 1.379 |
| remove | head | A | fullLifecycle | 12,500 | 725,289 | 1.379 | 1.379 | 1.379 | 0.000 | 0: 1.379 | 0: 1.379 |
| remove | random | A | scaleUp | 25,000 | 433,766 | 2.305 | 2.305 | 2.305 | 0.000 | 0: 2.305 | 0: 2.305 |
| remove | random | A | scaleDown | 25,000 | 526,875 | 1.898 | 1.898 | 1.898 | 0.000 | 0: 1.898 | 0: 1.898 |
| remove | random | A | fullLifecycle | 50,000 | 475,808 | 2.102 | 2.102 | 2.102 | 0.000 | 0: 2.102 | 0: 2.102 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 844,623 | 1.184 | 1.184 | 1.184 | 0.000 | 0: 1.184 | 0: 1.184 |
| remove | tail | A | fullLifecycle | 12,500 | 844,623 | 1.184 | 1.184 | 1.184 | 0.000 | 0: 1.184 | 0: 1.184 |
| replace | head | A | scaleUp | 25,000 | 542,900 | 1.842 | 1.842 | 1.842 | 0.000 | 0: 1.842 | 0: 1.842 |
| replace | head | A | scaleDown | 25,000 | 525,003 | 1.905 | 1.905 | 1.905 | 0.000 | 0: 1.905 | 0: 1.905 |
| replace | head | A | fullLifecycle | 50,000 | 533,801 | 1.873 | 1.873 | 1.873 | 0.000 | 0: 1.873 | 0: 1.873 |
| replace | random | A | scaleUp | 25,000 | 356,373 | 2.806 | 2.806 | 2.806 | 0.000 | 0: 2.806 | 0: 2.806 |
| replace | random | A | scaleDown | 25,000 | 390,698 | 2.560 | 2.560 | 2.560 | 0.000 | 0: 2.560 | 0: 2.560 |
| replace | random | A | fullLifecycle | 50,000 | 372,747 | 2.683 | 2.683 | 2.683 | 0.000 | 0: 2.683 | 0: 2.683 |
| replace | tail | A | scaleUp | 25,000 | 543,459 | 1.840 | 1.840 | 1.840 | 0.000 | 0: 1.840 | 0: 1.840 |
| replace | tail | A | scaleDown | 25,000 | 192,118 | 5.205 | 5.205 | 5.205 | 0.000 | 0: 5.205 | 0: 5.205 |
| replace | tail | A | fullLifecycle | 50,000 | 283,881 | 3.523 | 3.523 | 3.523 | 0.000 | 0: 3.523 | 0: 3.523 |
| sequence | — | A | scaleUp | 6 | 77 | 13044.550 | 13044.550 | 13044.550 | 0.000 | 0: 13044.550 | 0: 13044.550 |
| sequence | — | A | scaleDown | 6 | 85 | 11756.917 | 11756.917 | 11756.917 | 0.000 | 0: 11756.917 | 0: 11756.917 |
| sequence | — | A | fullLifecycle | 12 | 81 | 12400.733 | 12400.733 | 12400.733 | 0.000 | 0: 12400.733 | 0: 12400.733 |
| value | head | A | scaleUp | 25,000 | 3,240,693 | 0.309 | 0.309 | 0.309 | 0.000 | 0: 0.309 | 0: 0.309 |
| value | head | A | scaleDown | 25,000 | 2,329,091 | 0.429 | 0.429 | 0.429 | 0.000 | 0: 0.429 | 0: 0.429 |
| value | head | A | fullLifecycle | 50,000 | 2,710,292 | 0.369 | 0.369 | 0.369 | 0.000 | 0: 0.369 | 0: 0.369 |
| value | random | A | scaleUp | 25,000 | 915,181 | 1.093 | 1.093 | 1.093 | 0.000 | 0: 1.093 | 0: 1.093 |
| value | random | A | scaleDown | 25,000 | 992,197 | 1.008 | 1.008 | 1.008 | 0.000 | 0: 1.008 | 0: 1.008 |
| value | random | A | fullLifecycle | 50,000 | 952,134 | 1.050 | 1.050 | 1.050 | 0.000 | 0: 1.050 | 0: 1.050 |
| value | tail | A | scaleUp | 25,000 | 6,407,792 | 0.156 | 0.156 | 0.156 | 0.000 | 0: 0.156 | 0: 0.156 |
| value | tail | A | scaleDown | 25,000 | 4,359,046 | 0.229 | 0.229 | 0.229 | 0.000 | 0: 0.229 | 0: 0.229 |
| value | tail | A | fullLifecycle | 50,000 | 5,188,498 | 0.193 | 0.193 | 0.193 | 0.000 | 0: 0.193 | 0: 0.193 |
| values | — | A | scaleUp | 6 | 78 | 12853.767 | 12853.767 | 12853.767 | 0.000 | 0: 12853.767 | 0: 12853.767 |
| values | — | A | scaleDown | 6 | 254 | 3931.417 | 3931.417 | 3931.417 | 0.000 | 0: 3931.417 | 0: 3931.417 |
| values | — | A | fullLifecycle | 12 | 119 | 8392.592 | 8392.592 | 8392.592 | 0.000 | 0: 8392.592 | 0: 8392.592 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5428540.000 | 428.569 | 8.477 |
| A | scaleDown | 5 | 4409840.000 | 432.337 | 8.548 |
| A | fullLifecycle | 11 | 4965494.545 | 430.082 | 8.506 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3126055.667 | 246.794 | 4.882 |
| A | scaleDown | 5 | 2596615.600 | 254.570 | 5.033 |
| A | fullLifecycle | 11 | 2885401.091 | 249.917 | 4.943 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 278,862 | 3.586 | 1.600 | 243.000 |
| apply | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 310,594 | 3.220 | 1.600 | 490.200 |
| apply | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 314,370 | 3.181 | 1.400 | 655.200 |
| apply | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 323,549 | 3.091 | 1.400 | 655.200 |
| apply | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 316,890 | 3.156 | 1.400 | 1238.300 |
| apply | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 311,119 | 3.214 | 1.400 | 1617.100 |
| apply | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 312,821 | 3.197 | 1.400 | 1617.100 |
| apply | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 314,304 | 3.182 | 1.400 | 1617.100 |
| apply | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 317,262 | 3.152 | 1.400 | 1617.100 |
| apply | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 321,488 | 3.111 | 1.400 | 1617.100 |
| apply | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 327,528 | 3.053 | 1.400 | 1617.100 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 329,109 | 3.039 | 1.200 | 1617.100 |
| insert | head | 0 | up | 1,000 | 51,204 | A | 500 | 1,140,251 | 0.877 | 0.300 | 17.700 |
| insert | head | 0 | up | 5,000 | 250,037 | A | 2,500 | 1,180,582 | 0.847 | 0.300 | 17.700 |
| insert | head | 0 | up | 10,000 | 506,154 | A | 5,000 | 1,281,493 | 0.780 | 0.300 | 22.600 |
| insert | head | 0 | up | 15,000 | 762,134 | A | 7,500 | 1,341,874 | 0.745 | 0.300 | 22.600 |
| insert | head | 0 | up | 20,000 | 1,012,964 | A | 10,000 | 1,347,854 | 0.742 | 0.300 | 22.600 |
| insert | head | 0 | up | 25,000 | 1,259,727 | A | 12,500 | 1,348,116 | 0.742 | 0.300 | 22.600 |
| insert | head | 0 | down | 20,000 | 1,009,630 | A | 12,500 | 1,348,116 | 0.742 | 0.300 | 22.600 |
| insert | head | 0 | down | 15,000 | 759,633 | A | 12,500 | 1,348,116 | 0.742 | 0.300 | 22.600 |
| insert | head | 0 | down | 10,000 | 507,941 | A | 12,500 | 1,348,116 | 0.742 | 0.300 | 22.600 |
| insert | head | 0 | down | 5,000 | 250,794 | A | 12,500 | 1,348,116 | 0.742 | 0.300 | 22.600 |
| insert | head | 0 | down | 1,000 | 51,447 | A | 12,500 | 1,348,116 | 0.742 | 0.300 | 22.600 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,348,116 | 0.742 | 0.300 | 22.600 |
| insert | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 517,866 | 1.931 | 0.500 | 331.200 |
| insert | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 549,469 | 1.820 | 0.500 | 876.600 |
| insert | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 592,817 | 1.687 | 0.500 | 876.600 |
| insert | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 614,994 | 1.626 | 0.500 | 876.600 |
| insert | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 597,004 | 1.675 | 0.500 | 876.600 |
| insert | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 595,045 | 1.681 | 0.400 | 876.600 |
| insert | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 586,740 | 1.704 | 0.400 | 876.600 |
| insert | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 563,774 | 1.774 | 0.400 | 2108.700 |
| insert | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 576,400 | 1.735 | 0.400 | 2108.700 |
| insert | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 580,114 | 1.724 | 0.400 | 2108.700 |
| insert | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 588,543 | 1.699 | 0.400 | 2108.700 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 593,493 | 1.685 | 0.400 | 2108.700 |
| insert | tail | 0 | up | 1,000 | 51,204 | A | 500 | 1,042,535 | 0.959 | 0.300 | 39.500 |
| insert | tail | 0 | up | 5,000 | 250,037 | A | 2,500 | 1,210,947 | 0.826 | 0.300 | 82.100 |
| insert | tail | 0 | up | 10,000 | 506,154 | A | 5,000 | 1,340,914 | 0.746 | 0.300 | 82.100 |
| insert | tail | 0 | up | 15,000 | 762,134 | A | 7,500 | 1,385,553 | 0.722 | 0.300 | 171.500 |
| insert | tail | 0 | up | 20,000 | 1,012,964 | A | 10,000 | 1,356,907 | 0.737 | 0.300 | 291.700 |
| insert | tail | 0 | up | 25,000 | 1,259,727 | A | 12,500 | 1,351,220 | 0.740 | 0.300 | 312.800 |
| insert | tail | 0 | down | 20,000 | 1,009,630 | A | 12,500 | 1,351,220 | 0.740 | 0.300 | 312.800 |
| insert | tail | 0 | down | 15,000 | 759,633 | A | 12,500 | 1,351,220 | 0.740 | 0.300 | 312.800 |
| insert | tail | 0 | down | 10,000 | 507,941 | A | 12,500 | 1,351,220 | 0.740 | 0.300 | 312.800 |
| insert | tail | 0 | down | 5,000 | 250,794 | A | 12,500 | 1,351,220 | 0.740 | 0.300 | 312.800 |
| insert | tail | 0 | down | 1,000 | 51,447 | A | 12,500 | 1,351,220 | 0.740 | 0.300 | 312.800 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,351,220 | 0.740 | 0.300 | 312.800 |
| remove | head | 0 | up | 1,000 | 51,204 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 250,037 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 506,154 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 762,134 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,012,964 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,259,727 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,009,630 | A | 2,500 | 735,922 | 1.359 | 0.800 | 61.300 |
| remove | head | 0 | down | 15,000 | 759,633 | A | 5,000 | 684,866 | 1.460 | 0.800 | 332.100 |
| remove | head | 0 | down | 10,000 | 507,941 | A | 7,500 | 676,309 | 1.479 | 0.800 | 611.600 |
| remove | head | 0 | down | 5,000 | 250,794 | A | 10,000 | 701,233 | 1.426 | 0.800 | 611.600 |
| remove | head | 0 | down | 1,000 | 51,447 | A | 12,000 | 720,059 | 1.389 | 0.800 | 611.600 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 725,289 | 1.379 | 0.800 | 611.600 |
| remove | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 408,263 | 2.449 | 0.700 | 437.500 |
| remove | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 494,760 | 2.021 | 0.700 | 437.500 |
| remove | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 492,308 | 2.031 | 0.700 | 437.500 |
| remove | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 422,566 | 2.366 | 0.700 | 2905.100 |
| remove | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 428,411 | 2.334 | 0.700 | 2905.100 |
| remove | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 433,766 | 2.305 | 0.700 | 2905.100 |
| remove | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 441,103 | 2.267 | 0.700 | 2905.100 |
| remove | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 445,143 | 2.246 | 0.700 | 2905.100 |
| remove | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 454,437 | 2.201 | 0.700 | 2905.100 |
| remove | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 462,878 | 2.160 | 0.700 | 2905.100 |
| remove | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 472,031 | 2.119 | 0.700 | 2905.100 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 475,808 | 2.102 | 0.700 | 2905.100 |
| remove | tail | 0 | up | 1,000 | 51,204 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 250,037 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 506,154 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 762,134 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,012,964 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,259,727 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,009,630 | A | 2,500 | 823,452 | 1.214 | 0.800 | 14.500 |
| remove | tail | 0 | down | 15,000 | 759,633 | A | 5,000 | 805,633 | 1.241 | 0.800 | 15.500 |
| remove | tail | 0 | down | 10,000 | 507,941 | A | 7,500 | 828,400 | 1.207 | 0.700 | 15.500 |
| remove | tail | 0 | down | 5,000 | 250,794 | A | 10,000 | 833,458 | 1.200 | 0.700 | 44.000 |
| remove | tail | 0 | down | 1,000 | 51,447 | A | 12,000 | 841,503 | 1.188 | 0.700 | 44.000 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 844,623 | 1.184 | 0.600 | 44.000 |
| replace | head | 0 | up | 1,000 | 51,204 | A | 1,000 | 472,634 | 2.116 | 1.000 | 46.600 |
| replace | head | 0 | up | 5,000 | 250,037 | A | 5,000 | 514,202 | 1.945 | 0.900 | 235.700 |
| replace | head | 0 | up | 10,000 | 506,154 | A | 10,000 | 528,824 | 1.891 | 0.900 | 418.800 |
| replace | head | 0 | up | 15,000 | 762,134 | A | 15,000 | 543,876 | 1.839 | 0.900 | 418.800 |
| replace | head | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 546,217 | 1.831 | 0.900 | 418.800 |
| replace | head | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 542,900 | 1.842 | 0.900 | 667.500 |
| replace | head | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 537,906 | 1.859 | 0.900 | 667.500 |
| replace | head | 0 | down | 15,000 | 759,633 | A | 35,000 | 527,116 | 1.897 | 0.900 | 667.500 |
| replace | head | 0 | down | 10,000 | 507,941 | A | 40,000 | 528,198 | 1.893 | 0.900 | 667.500 |
| replace | head | 0 | down | 5,000 | 250,794 | A | 45,000 | 528,569 | 1.892 | 0.900 | 667.500 |
| replace | head | 0 | down | 1,000 | 51,447 | A | 49,000 | 532,180 | 1.879 | 0.900 | 667.500 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 533,801 | 1.873 | 0.900 | 667.500 |
| replace | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 423,747 | 2.360 | 1.100 | 85.000 |
| replace | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 399,074 | 2.506 | 1.100 | 371.900 |
| replace | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 387,060 | 2.584 | 1.100 | 371.900 |
| replace | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 361,546 | 2.766 | 1.100 | 2047.400 |
| replace | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 358,646 | 2.788 | 1.100 | 2047.400 |
| replace | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 356,373 | 2.806 | 1.100 | 2047.400 |
| replace | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 358,994 | 2.786 | 1.100 | 2047.400 |
| replace | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 358,798 | 2.787 | 1.100 | 2047.400 |
| replace | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 362,372 | 2.760 | 1.100 | 2047.400 |
| replace | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 362,702 | 2.757 | 1.100 | 2047.400 |
| replace | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 369,886 | 2.704 | 1.100 | 2047.400 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 372,747 | 2.683 | 1.000 | 2047.400 |
| replace | tail | 0 | up | 1,000 | 51,204 | A | 1,000 | 494,682 | 2.022 | 1.000 | 93.100 |
| replace | tail | 0 | up | 5,000 | 250,037 | A | 5,000 | 525,381 | 1.903 | 1.000 | 226.700 |
| replace | tail | 0 | up | 10,000 | 506,154 | A | 10,000 | 518,374 | 1.929 | 1.000 | 996.900 |
| replace | tail | 0 | up | 15,000 | 762,134 | A | 15,000 | 549,296 | 1.821 | 1.000 | 996.900 |
| replace | tail | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 541,894 | 1.845 | 1.000 | 996.900 |
| replace | tail | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 543,459 | 1.840 | 1.000 | 996.900 |
| replace | tail | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 469,218 | 2.131 | 1.000 | 996.900 |
| replace | tail | 0 | down | 15,000 | 759,633 | A | 35,000 | 281,266 | 3.555 | 1.000 | 5184.900 |
| replace | tail | 0 | down | 10,000 | 507,941 | A | 40,000 | 291,443 | 3.431 | 1.000 | 5184.900 |
| replace | tail | 0 | down | 5,000 | 250,794 | A | 45,000 | 275,259 | 3.633 | 1.000 | 5184.900 |
| replace | tail | 0 | down | 1,000 | 51,447 | A | 49,000 | 280,829 | 3.561 | 1.000 | 5184.900 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 283,881 | 3.523 | 0.900 | 5184.900 |
| value | head | 0 | up | 1,000 | 51,204 | A | 1,000 | 1,406,668 | 0.711 | 0.100 | 292.900 |
| value | head | 0 | up | 5,000 | 250,037 | A | 5,000 | 2,590,405 | 0.386 | 0.100 | 292.900 |
| value | head | 0 | up | 10,000 | 506,154 | A | 10,000 | 2,961,910 | 0.338 | 0.100 | 292.900 |
| value | head | 0 | up | 15,000 | 762,134 | A | 15,000 | 3,157,363 | 0.317 | 0.100 | 292.900 |
| value | head | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 3,216,882 | 0.311 | 0.100 | 292.900 |
| value | head | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 3,240,693 | 0.309 | 0.100 | 292.900 |
| value | head | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 3,033,122 | 0.330 | 0.100 | 292.900 |
| value | head | 0 | down | 15,000 | 759,633 | A | 35,000 | 2,878,692 | 0.347 | 0.100 | 292.900 |
| value | head | 0 | down | 10,000 | 507,941 | A | 40,000 | 2,815,137 | 0.355 | 0.100 | 292.900 |
| value | head | 0 | down | 5,000 | 250,794 | A | 45,000 | 2,753,809 | 0.363 | 0.100 | 292.900 |
| value | head | 0 | down | 1,000 | 51,447 | A | 49,000 | 2,710,972 | 0.369 | 0.100 | 292.900 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,710,292 | 0.369 | 0.100 | 292.900 |
| value | random | 0 | up | 1,000 | 51,204 | A | 1,000 | 1,435,956 | 0.696 | 0.100 | 32.700 |
| value | random | 0 | up | 5,000 | 250,037 | A | 5,000 | 1,052,454 | 0.950 | 0.100 | 187.600 |
| value | random | 0 | up | 10,000 | 506,154 | A | 10,000 | 987,723 | 1.012 | 0.100 | 187.600 |
| value | random | 0 | up | 15,000 | 762,134 | A | 15,000 | 959,239 | 1.042 | 0.100 | 187.600 |
| value | random | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 935,436 | 1.069 | 0.100 | 187.600 |
| value | random | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 915,181 | 1.093 | 0.100 | 187.600 |
| value | random | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 912,151 | 1.096 | 0.100 | 187.600 |
| value | random | 0 | down | 15,000 | 759,633 | A | 35,000 | 909,263 | 1.100 | 0.100 | 187.600 |
| value | random | 0 | down | 10,000 | 507,941 | A | 40,000 | 919,781 | 1.087 | 0.100 | 187.600 |
| value | random | 0 | down | 5,000 | 250,794 | A | 45,000 | 925,922 | 1.080 | 0.100 | 187.600 |
| value | random | 0 | down | 1,000 | 51,447 | A | 49,000 | 944,609 | 1.059 | 0.100 | 187.600 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 952,134 | 1.050 | 0.100 | 187.600 |
| value | tail | 0 | up | 1,000 | 51,204 | A | 1,000 | 6,169,031 | 0.162 | 0.100 | 2.100 |
| value | tail | 0 | up | 5,000 | 250,037 | A | 5,000 | 5,818,013 | 0.172 | 0.100 | 5.000 |
| value | tail | 0 | up | 10,000 | 506,154 | A | 10,000 | 5,946,364 | 0.168 | 0.100 | 24.800 |
| value | tail | 0 | up | 15,000 | 762,134 | A | 15,000 | 6,169,031 | 0.162 | 0.000 | 36.100 |
| value | tail | 0 | up | 20,000 | 1,012,964 | A | 20,000 | 6,329,915 | 0.158 | 0.000 | 36.100 |
| value | tail | 0 | up | 25,000 | 1,259,727 | A | 25,000 | 6,407,792 | 0.156 | 0.000 | 36.100 |
| value | tail | 0 | down | 20,000 | 1,009,630 | A | 30,000 | 5,929,322 | 0.169 | 0.000 | 45.700 |
| value | tail | 0 | down | 15,000 | 759,633 | A | 35,000 | 5,573,692 | 0.179 | 0.000 | 45.700 |
| value | tail | 0 | down | 10,000 | 507,941 | A | 40,000 | 5,393,961 | 0.185 | 0.000 | 45.700 |
| value | tail | 0 | down | 5,000 | 250,794 | A | 45,000 | 5,247,018 | 0.191 | 0.000 | 45.700 |
| value | tail | 0 | down | 1,000 | 51,447 | A | 49,000 | 5,187,655 | 0.193 | 0.000 | 45.700 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,188,498 | 0.193 | 0.000 | 45.700 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,103 | 475.600 |
| create | — | 0 | up | 5,000 | A | 1 | 1,070 | 934.200 |
| create | — | 0 | up | 10,000 | A | 1 | 623 | 1605.600 |
| create | — | 0 | up | 15,000 | A | 1 | 340 | 2937.500 |
| create | — | 0 | up | 20,000 | A | 1 | 308 | 3241.600 |
| create | — | 0 | up | 25,000 | A | 1 | 259 | 3857.800 |
| create | — | 0 | down | 20,000 | A | 1 | 201 | 4975.100 |
| create | — | 0 | down | 15,000 | A | 1 | 384 | 2607.400 |
| create | — | 0 | down | 10,000 | A | 1 | 563 | 1777.000 |
| create | — | 0 | down | 5,000 | A | 1 | 1,165 | 858.700 |
| create | — | 0 | down | 1,000 | A | 1 | 6,592 | 151.700 |
| create | — | 0 | down | 0 | A | 1 | 69,444 | 14.400 |
| sequence | — | 0 | up | 1,000 | A | 1 | 416 | 2404.600 |
| sequence | — | 0 | up | 5,000 | A | 1 | 134 | 7482.500 |
| sequence | — | 0 | up | 10,000 | A | 1 | 79 | 12685.200 |
| sequence | — | 0 | up | 15,000 | A | 1 | 74 | 13513.400 |
| sequence | — | 0 | up | 20,000 | A | 1 | 50 | 20066.300 |
| sequence | — | 0 | up | 25,000 | A | 1 | 45 | 22115.300 |
| sequence | — | 0 | down | 20,000 | A | 1 | 39 | 25774.100 |
| sequence | — | 0 | down | 15,000 | A | 1 | 66 | 15180.000 |
| sequence | — | 0 | down | 10,000 | A | 1 | 82 | 12145.900 |
| sequence | — | 0 | down | 5,000 | A | 1 | 107 | 9332.400 |
| sequence | — | 0 | down | 1,000 | A | 1 | 147 | 6788.100 |
| sequence | — | 0 | down | 0 | A | 1 | 757 | 1321.000 |
| values | — | 0 | up | 1,000 | A | 1 | 602 | 1660.400 |
| values | — | 0 | up | 5,000 | A | 1 | 166 | 6023.700 |
| values | — | 0 | up | 10,000 | A | 1 | 48 | 20804.500 |
| values | — | 0 | up | 15,000 | A | 1 | 34 | 29041.800 |
| values | — | 0 | up | 20,000 | A | 1 | 113 | 8837.500 |
| values | — | 0 | up | 25,000 | A | 1 | 93 | 10754.700 |
| values | — | 0 | down | 20,000 | A | 1 | 117 | 8567.600 |
| values | — | 0 | down | 15,000 | A | 1 | 140 | 7129.100 |
| values | — | 0 | down | 10,000 | A | 1 | 193 | 5185.100 |
| values | — | 0 | down | 5,000 | A | 1 | 448 | 2230.700 |
| values | — | 0 | down | 1,000 | A | 1 | 2,150 | 465.200 |
| values | — | 0 | down | 0 | A | 1 | 92,593 | 10.800 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.622 | 0.232 | 0.391 |
| 0 | up | 5000 | 3.076 | 1.168 | 1.908 |
| 0 | up | 10000 | 6.205 | 2.343 | 3.862 |
| 0 | up | 15000 | 9.457 | 3.643 | 5.815 |
| 0 | up | 20000 | 12.841 | 5.112 | 7.728 |
| 0 | up | 25000 | 16.247 | 6.636 | 9.611 |
| 0 | down | 20000 | 13.315 | 5.612 | 7.703 |
| 0 | down | 15000 | 9.926 | 4.131 | 5.796 |
| 0 | down | 10000 | 7.170 | 3.295 | 3.875 |
| 0 | down | 5000 | 4.075 | 2.161 | 1.913 |
| 0 | down | 1000 | 1.812 | 1.420 | 0.393 |
| 0 | down | 0 | 1.230 | 1.230 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 51,204 | 0.411 | 430.756 | 8.413 | 121.996 | 15.545 |
| 0 | up | A | 5,000 | 5,000 | 250,037 | 2.010 | 421.606 | 8.431 | 154.809 | 19.561 |
| 0 | up | A | 10,000 | 10,000 | 506,154 | 4.075 | 427.300 | 8.442 | 196.875 | 24.477 |
| 0 | up | A | 15,000 | 15,000 | 762,134 | 6.154 | 430.176 | 8.467 | 209.496 | 29.391 |
| 0 | up | A | 20,000 | 20,000 | 1,012,964 | 8.198 | 429.835 | 8.487 | 279.582 | 34.214 |
| 0 | up | A | 25,000 | 25,000 | 1,259,727 | 10.214 | 428.405 | 8.502 | 294.887 | 38.944 |
| 0 | down | A | 20,000 | 20,000 | 1,009,630 | 8.241 | 432.089 | 8.559 | 298.188 | 34.190 |
| 0 | down | A | 15,000 | 15,000 | 759,633 | 6.201 | 433.508 | 8.560 | 303.137 | 29.425 |
| 0 | down | A | 10,000 | 10,000 | 507,941 | 4.136 | 433.718 | 8.539 | 302.141 | 24.654 |
| 0 | down | A | 5,000 | 5,000 | 250,794 | 2.034 | 426.570 | 8.504 | 300.105 | 19.798 |
| 0 | down | A | 1,000 | 1,000 | 51,447 | 0.415 | 434.772 | 8.451 | 299.055 | 15.999 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 300.109 | 14.908 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 51204 | 187497 | 187.497 | 3.662 | 277.53 | 14.54 | 165.41 | 12.36 |
| 0 | up | A | 5000 | 250037 | 1195941 | 239.188 | 4.783 | 1610.38 | 73.38 | 813.25 | 61.61 |
| 0 | up | A | 10000 | 506154 | 2435808 | 243.581 | 4.812 | 3265.74 | 148.71 | 1649.99 | 124.72 |
| 0 | up | A | 15000 | 762134 | 3716482 | 247.765 | 4.876 | 4950.79 | 226.25 | 3565.22 | 200.28 |
| 0 | up | A | 20000 | 1012964 | 4982573 | 249.129 | 4.919 | 7121.78 | 311.32 | 5144.59 | 263.55 |
| 0 | up | A | 25000 | 1259727 | 6238033 | 249.521 | 4.952 | 9237.87 | 392.58 | 6535.88 | 334.89 |
| 0 | down | A | 20000 | 1009630 | 5113545 | 255.677 | 5.065 | 7558.03 | 326.74 | 5304.48 | 278.22 |
| 0 | down | A | 15000 | 759633 | 3843527 | 256.235 | 5.060 | 5727.79 | 247.31 | 4004.31 | 209.86 |
| 0 | down | A | 10000 | 507941 | 2547329 | 254.733 | 5.015 | 3837.94 | 164.83 | 2677.99 | 139.88 |
| 0 | down | A | 5000 | 250794 | 1235293 | 247.059 | 4.926 | 1887.01 | 79.61 | 1318.78 | 67.84 |
| 0 | down | A | 1000 | 51447 | 243384 | 243.384 | 4.731 | 382.91 | 15.90 | 268.58 | 13.64 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 428.569 | 8.477 | 246.794 | 4.882 |
| 0 | A | scaleDown | 432.337 | 8.548 | 254.570 | 5.033 |
| 0 | A | fullLifecycle | 430.082 | 8.506 | 249.917 | 4.943 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
