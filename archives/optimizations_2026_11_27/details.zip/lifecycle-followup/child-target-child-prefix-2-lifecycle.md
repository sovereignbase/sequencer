# Sequencer dynamic lifecycle benchmark

2026-11-27T17:14:30.120Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.44 | 163.09 | 56.54 |
| CommonJS | 199.62 | 164.71 | 56.75 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 310,243 | 3.223 | 3.223 | 3.223 | 0.000 | 0: 3.223 | 0: 3.223 |
| apply | random | A | scaleDown | 24,999 | 345,037 | 2.898 | 2.898 | 2.898 | 0.000 | 0: 2.898 | 0: 2.898 |
| apply | random | A | fullLifecycle | 49,999 | 326,716 | 3.061 | 3.061 | 3.061 | 0.000 | 0: 3.061 | 0: 3.061 |
| create | — | A | scaleUp | 7 | 528 | 1895.657 | 1895.657 | 1895.657 | 0.000 | 0: 1895.657 | 0: 1895.657 |
| create | — | A | scaleDown | 6 | 662 | 1510.517 | 1510.517 | 1510.517 | 0.000 | 0: 1510.517 | 0: 1510.517 |
| create | — | A | fullLifecycle | 13 | 582 | 1717.900 | 1717.900 | 1717.900 | 0.000 | 0: 1717.900 | 0: 1717.900 |
| insert | head | A | scaleUp | 12,500 | 1,336,455 | 0.748 | 0.748 | 0.748 | 0.000 | 0: 0.748 | 0: 0.748 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,336,455 | 0.748 | 0.748 | 0.748 | 0.000 | 0: 0.748 | 0: 0.748 |
| insert | random | A | scaleUp | 25,000 | 576,024 | 1.736 | 1.736 | 1.736 | 0.000 | 0: 1.736 | 0: 1.736 |
| insert | random | A | scaleDown | 25,000 | 595,952 | 1.678 | 1.678 | 1.678 | 0.000 | 0: 1.678 | 0: 1.678 |
| insert | random | A | fullLifecycle | 50,000 | 585,818 | 1.707 | 1.707 | 1.707 | 0.000 | 0: 1.707 | 0: 1.707 |
| insert | tail | A | scaleUp | 12,500 | 1,463,666 | 0.683 | 0.683 | 0.683 | 0.000 | 0: 0.683 | 0: 0.683 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,463,666 | 0.683 | 0.683 | 0.683 | 0.000 | 0: 0.683 | 0: 0.683 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 753,275 | 1.328 | 1.328 | 1.328 | 0.000 | 0: 1.328 | 0: 1.328 |
| remove | head | A | fullLifecycle | 12,500 | 753,275 | 1.328 | 1.328 | 1.328 | 0.000 | 0: 1.328 | 0: 1.328 |
| remove | random | A | scaleUp | 25,000 | 484,960 | 2.062 | 2.062 | 2.062 | 0.000 | 0: 2.062 | 0: 2.062 |
| remove | random | A | scaleDown | 25,000 | 492,904 | 2.029 | 2.029 | 2.029 | 0.000 | 0: 2.029 | 0: 2.029 |
| remove | random | A | fullLifecycle | 50,000 | 488,900 | 2.045 | 2.045 | 2.045 | 0.000 | 0: 2.045 | 0: 2.045 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 800,323 | 1.249 | 1.249 | 1.249 | 0.000 | 0: 1.249 | 0: 1.249 |
| remove | tail | A | fullLifecycle | 12,500 | 800,323 | 1.249 | 1.249 | 1.249 | 0.000 | 0: 1.249 | 0: 1.249 |
| replace | head | A | scaleUp | 25,000 | 527,028 | 1.897 | 1.897 | 1.897 | 0.000 | 0: 1.897 | 0: 1.897 |
| replace | head | A | scaleDown | 25,000 | 519,946 | 1.923 | 1.923 | 1.923 | 0.000 | 0: 1.923 | 0: 1.923 |
| replace | head | A | fullLifecycle | 50,000 | 523,463 | 1.910 | 1.910 | 1.910 | 0.000 | 0: 1.910 | 0: 1.910 |
| replace | random | A | scaleUp | 25,000 | 348,770 | 2.867 | 2.867 | 2.867 | 0.000 | 0: 2.867 | 0: 2.867 |
| replace | random | A | scaleDown | 25,000 | 363,196 | 2.753 | 2.753 | 2.753 | 0.000 | 0: 2.753 | 0: 2.753 |
| replace | random | A | fullLifecycle | 50,000 | 355,837 | 2.810 | 2.810 | 2.810 | 0.000 | 0: 2.810 | 0: 2.810 |
| replace | tail | A | scaleUp | 25,000 | 561,554 | 1.781 | 1.781 | 1.781 | 0.000 | 0: 1.781 | 0: 1.781 |
| replace | tail | A | scaleDown | 25,000 | 192,408 | 5.197 | 5.197 | 5.197 | 0.000 | 0: 5.197 | 0: 5.197 |
| replace | tail | A | fullLifecycle | 50,000 | 286,612 | 3.489 | 3.489 | 3.489 | 0.000 | 0: 3.489 | 0: 3.489 |
| sequence | — | A | scaleUp | 6 | 76 | 13146.833 | 13146.833 | 13146.833 | 0.000 | 0: 13146.833 | 0: 13146.833 |
| sequence | — | A | scaleDown | 6 | 96 | 10376.250 | 10376.250 | 10376.250 | 0.000 | 0: 10376.250 | 0: 10376.250 |
| sequence | — | A | fullLifecycle | 12 | 85 | 11761.542 | 11761.542 | 11761.542 | 0.000 | 0: 11761.542 | 0: 11761.542 |
| value | head | A | scaleUp | 25,000 | 3,063,237 | 0.326 | 0.326 | 0.326 | 0.000 | 0: 0.326 | 0: 0.326 |
| value | head | A | scaleDown | 25,000 | 2,354,936 | 0.425 | 0.425 | 0.425 | 0.000 | 0: 0.425 | 0: 0.425 |
| value | head | A | fullLifecycle | 50,000 | 2,662,790 | 0.376 | 0.376 | 0.376 | 0.000 | 0: 0.376 | 0: 0.376 |
| value | random | A | scaleUp | 25,000 | 891,736 | 1.121 | 1.121 | 1.121 | 0.000 | 0: 1.121 | 0: 1.121 |
| value | random | A | scaleDown | 25,000 | 929,641 | 1.076 | 1.076 | 1.076 | 0.000 | 0: 1.076 | 0: 1.076 |
| value | random | A | fullLifecycle | 50,000 | 910,294 | 1.099 | 1.099 | 1.099 | 0.000 | 0: 1.099 | 0: 1.099 |
| value | tail | A | scaleUp | 25,000 | 6,606,067 | 0.151 | 0.151 | 0.151 | 0.000 | 0: 0.151 | 0: 0.151 |
| value | tail | A | scaleDown | 25,000 | 4,254,088 | 0.235 | 0.235 | 0.235 | 0.000 | 0: 0.235 | 0: 0.235 |
| value | tail | A | fullLifecycle | 50,000 | 5,175,394 | 0.193 | 0.193 | 0.193 | 0.000 | 0: 0.193 | 0: 0.193 |
| values | — | A | scaleUp | 6 | 143 | 6992.933 | 6992.933 | 6992.933 | 0.000 | 0: 6992.933 | 0: 6992.933 |
| values | — | A | scaleDown | 6 | 244 | 4098.167 | 4098.167 | 4098.167 | 0.000 | 0: 4098.167 | 0: 4098.167 |
| values | — | A | fullLifecycle | 12 | 180 | 5545.550 | 5545.550 | 5545.550 | 0.000 | 0: 5545.550 | 0: 5545.550 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5410752.667 | 427.165 | 8.478 |
| A | scaleDown | 5 | 4407357.600 | 432.094 | 8.548 |
| A | fullLifecycle | 11 | 4954664.000 | 429.144 | 8.506 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3116296.167 | 246.023 | 4.883 |
| A | scaleDown | 5 | 2595337.600 | 254.445 | 5.034 |
| A | fullLifecycle | 11 | 2879496.818 | 249.405 | 4.944 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 284,244 | 3.518 | 1.600 | 42.800 |
| apply | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 328,306 | 3.046 | 1.400 | 348.000 |
| apply | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 302,344 | 3.307 | 1.400 | 2295.800 |
| apply | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 298,481 | 3.350 | 1.400 | 3205.500 |
| apply | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 303,352 | 3.297 | 1.400 | 3205.500 |
| apply | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 310,243 | 3.223 | 1.400 | 3205.500 |
| apply | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 314,801 | 3.177 | 1.400 | 3205.500 |
| apply | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 319,451 | 3.130 | 1.400 | 3205.500 |
| apply | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 319,879 | 3.126 | 1.400 | 3205.500 |
| apply | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 320,120 | 3.124 | 1.400 | 3205.500 |
| apply | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 324,585 | 3.081 | 1.400 | 3205.500 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 326,716 | 3.061 | 1.200 | 3205.500 |
| insert | head | 0 | up | 1,000 | 50,007 | A | 500 | 971,440 | 1.029 | 0.300 | 41.400 |
| insert | head | 0 | up | 5,000 | 256,206 | A | 2,500 | 1,179,023 | 0.848 | 0.300 | 49.200 |
| insert | head | 0 | up | 10,000 | 508,328 | A | 5,000 | 1,277,074 | 0.783 | 0.300 | 86.000 |
| insert | head | 0 | up | 15,000 | 756,035 | A | 7,500 | 1,293,862 | 0.773 | 0.300 | 231.600 |
| insert | head | 0 | up | 20,000 | 1,005,850 | A | 10,000 | 1,306,711 | 0.765 | 0.300 | 231.600 |
| insert | head | 0 | up | 25,000 | 1,252,902 | A | 12,500 | 1,336,455 | 0.748 | 0.300 | 231.600 |
| insert | head | 0 | down | 20,000 | 1,007,225 | A | 12,500 | 1,336,455 | 0.748 | 0.300 | 231.600 |
| insert | head | 0 | down | 15,000 | 759,799 | A | 12,500 | 1,336,455 | 0.748 | 0.300 | 231.600 |
| insert | head | 0 | down | 10,000 | 506,363 | A | 12,500 | 1,336,455 | 0.748 | 0.300 | 231.600 |
| insert | head | 0 | down | 5,000 | 254,264 | A | 12,500 | 1,336,455 | 0.748 | 0.300 | 231.600 |
| insert | head | 0 | down | 1,000 | 50,210 | A | 12,500 | 1,336,455 | 0.748 | 0.300 | 231.600 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,336,455 | 0.748 | 0.300 | 231.600 |
| insert | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 540,482 | 1.850 | 0.400 | 309.200 |
| insert | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 581,220 | 1.721 | 0.400 | 473.600 |
| insert | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 540,614 | 1.850 | 0.400 | 1176.000 |
| insert | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 576,327 | 1.735 | 0.400 | 1176.000 |
| insert | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 568,510 | 1.759 | 0.400 | 1176.000 |
| insert | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 576,024 | 1.736 | 0.400 | 1176.000 |
| insert | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 564,614 | 1.771 | 0.400 | 1176.000 |
| insert | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 566,882 | 1.764 | 0.400 | 1176.000 |
| insert | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 565,313 | 1.769 | 0.400 | 1176.000 |
| insert | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 568,695 | 1.758 | 0.400 | 1176.000 |
| insert | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 580,605 | 1.722 | 0.400 | 1176.000 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 585,818 | 1.707 | 0.400 | 1176.000 |
| insert | tail | 0 | up | 1,000 | 50,007 | A | 500 | 1,097,454 | 0.911 | 0.300 | 23.600 |
| insert | tail | 0 | up | 5,000 | 256,206 | A | 2,500 | 1,314,060 | 0.761 | 0.300 | 63.500 |
| insert | tail | 0 | up | 10,000 | 508,328 | A | 5,000 | 1,430,943 | 0.699 | 0.300 | 70.500 |
| insert | tail | 0 | up | 15,000 | 756,035 | A | 7,500 | 1,486,326 | 0.673 | 0.300 | 155.000 |
| insert | tail | 0 | up | 20,000 | 1,005,850 | A | 10,000 | 1,493,830 | 0.669 | 0.300 | 155.000 |
| insert | tail | 0 | up | 25,000 | 1,252,902 | A | 12,500 | 1,463,666 | 0.683 | 0.300 | 328.100 |
| insert | tail | 0 | down | 20,000 | 1,007,225 | A | 12,500 | 1,463,666 | 0.683 | 0.300 | 328.100 |
| insert | tail | 0 | down | 15,000 | 759,799 | A | 12,500 | 1,463,666 | 0.683 | 0.300 | 328.100 |
| insert | tail | 0 | down | 10,000 | 506,363 | A | 12,500 | 1,463,666 | 0.683 | 0.300 | 328.100 |
| insert | tail | 0 | down | 5,000 | 254,264 | A | 12,500 | 1,463,666 | 0.683 | 0.300 | 328.100 |
| insert | tail | 0 | down | 1,000 | 50,210 | A | 12,500 | 1,463,666 | 0.683 | 0.300 | 328.100 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,463,666 | 0.683 | 0.300 | 328.100 |
| remove | head | 0 | up | 1,000 | 50,007 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 256,206 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 508,328 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 756,035 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,005,850 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,252,902 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,007,225 | A | 2,500 | 778,210 | 1.285 | 0.800 | 7.600 |
| remove | head | 0 | down | 15,000 | 759,799 | A | 5,000 | 776,060 | 1.289 | 0.800 | 9.500 |
| remove | head | 0 | down | 10,000 | 506,363 | A | 7,500 | 717,786 | 1.393 | 0.800 | 620.600 |
| remove | head | 0 | down | 5,000 | 254,264 | A | 10,000 | 728,109 | 1.373 | 0.800 | 620.600 |
| remove | head | 0 | down | 1,000 | 50,210 | A | 12,000 | 746,733 | 1.339 | 0.700 | 620.600 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 753,275 | 1.328 | 0.700 | 620.600 |
| remove | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 501,002 | 1.996 | 0.800 | 61.500 |
| remove | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 479,230 | 2.087 | 0.800 | 1270.500 |
| remove | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 460,217 | 2.173 | 0.800 | 1270.500 |
| remove | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 489,777 | 2.042 | 0.800 | 1270.500 |
| remove | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 483,771 | 2.067 | 0.800 | 1270.500 |
| remove | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 484,960 | 2.062 | 0.800 | 1270.500 |
| remove | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 485,011 | 2.062 | 0.800 | 1270.500 |
| remove | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 487,423 | 2.052 | 0.800 | 1270.500 |
| remove | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 484,111 | 2.066 | 0.800 | 1270.500 |
| remove | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 475,255 | 2.104 | 0.800 | 2254.700 |
| remove | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 484,745 | 2.063 | 0.800 | 2254.700 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 488,900 | 2.045 | 0.700 | 2254.700 |
| remove | tail | 0 | up | 1,000 | 50,007 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 256,206 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 508,328 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 756,035 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,005,850 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,252,902 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,007,225 | A | 2,500 | 831,532 | 1.203 | 0.700 | 47.000 |
| remove | tail | 0 | down | 15,000 | 759,799 | A | 5,000 | 825,859 | 1.211 | 0.700 | 68.700 |
| remove | tail | 0 | down | 10,000 | 506,363 | A | 7,500 | 761,932 | 1.312 | 0.700 | 546.500 |
| remove | tail | 0 | down | 5,000 | 254,264 | A | 10,000 | 773,635 | 1.293 | 0.700 | 546.500 |
| remove | tail | 0 | down | 1,000 | 50,210 | A | 12,000 | 794,813 | 1.258 | 0.700 | 546.500 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 800,323 | 1.249 | 0.600 | 546.500 |
| replace | head | 0 | up | 1,000 | 50,007 | A | 1,000 | 369,358 | 2.707 | 1.100 | 418.300 |
| replace | head | 0 | up | 5,000 | 256,206 | A | 5,000 | 450,446 | 2.220 | 1.100 | 836.300 |
| replace | head | 0 | up | 10,000 | 508,328 | A | 10,000 | 501,125 | 1.996 | 1.100 | 836.300 |
| replace | head | 0 | up | 15,000 | 756,035 | A | 15,000 | 525,216 | 1.904 | 1.000 | 836.300 |
| replace | head | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 534,596 | 1.871 | 1.000 | 836.300 |
| replace | head | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 527,028 | 1.897 | 1.000 | 836.300 |
| replace | head | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 523,994 | 1.908 | 1.000 | 836.300 |
| replace | head | 0 | down | 15,000 | 759,799 | A | 35,000 | 522,586 | 1.914 | 1.000 | 836.300 |
| replace | head | 0 | down | 10,000 | 506,363 | A | 40,000 | 518,103 | 1.930 | 1.000 | 836.300 |
| replace | head | 0 | down | 5,000 | 254,264 | A | 45,000 | 514,742 | 1.943 | 1.000 | 836.300 |
| replace | head | 0 | down | 1,000 | 50,210 | A | 49,000 | 520,769 | 1.920 | 1.000 | 836.300 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 523,463 | 1.910 | 0.900 | 836.300 |
| replace | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 331,049 | 3.021 | 1.200 | 270.600 |
| replace | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 380,938 | 2.625 | 1.200 | 354.600 |
| replace | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 374,907 | 2.667 | 1.200 | 354.600 |
| replace | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 368,303 | 2.715 | 1.200 | 690.800 |
| replace | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 352,893 | 2.834 | 1.200 | 1878.100 |
| replace | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 348,770 | 2.867 | 1.200 | 1878.100 |
| replace | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 352,642 | 2.836 | 1.200 | 1878.100 |
| replace | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 348,538 | 2.869 | 1.200 | 1878.100 |
| replace | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 340,843 | 2.934 | 1.200 | 2070.300 |
| replace | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 344,794 | 2.900 | 1.100 | 2070.300 |
| replace | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 352,539 | 2.837 | 1.100 | 2070.300 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 355,837 | 2.810 | 0.900 | 2070.300 |
| replace | tail | 0 | up | 1,000 | 50,007 | A | 1,000 | 423,012 | 2.364 | 1.000 | 116.800 |
| replace | tail | 0 | up | 5,000 | 256,206 | A | 5,000 | 538,010 | 1.859 | 1.000 | 164.500 |
| replace | tail | 0 | up | 10,000 | 508,328 | A | 10,000 | 552,483 | 1.810 | 1.000 | 169.500 |
| replace | tail | 0 | up | 15,000 | 756,035 | A | 15,000 | 566,138 | 1.766 | 1.000 | 169.500 |
| replace | tail | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 560,581 | 1.784 | 1.000 | 308.800 |
| replace | tail | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 561,554 | 1.781 | 1.000 | 308.800 |
| replace | tail | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 466,311 | 2.144 | 1.000 | 2877.000 |
| replace | tail | 0 | down | 15,000 | 759,799 | A | 35,000 | 310,321 | 3.222 | 1.000 | 2877.000 |
| replace | tail | 0 | down | 10,000 | 506,363 | A | 40,000 | 316,070 | 3.164 | 1.000 | 2877.000 |
| replace | tail | 0 | down | 5,000 | 254,264 | A | 45,000 | 281,354 | 3.554 | 0.900 | 2877.000 |
| replace | tail | 0 | down | 1,000 | 50,210 | A | 49,000 | 283,701 | 3.525 | 0.900 | 2877.000 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 286,612 | 3.489 | 0.800 | 2877.000 |
| value | head | 0 | up | 1,000 | 50,007 | A | 1,000 | 1,082,368 | 0.924 | 0.100 | 571.700 |
| value | head | 0 | up | 5,000 | 256,206 | A | 5,000 | 2,354,271 | 0.425 | 0.100 | 571.700 |
| value | head | 0 | up | 10,000 | 508,328 | A | 10,000 | 2,694,691 | 0.371 | 0.100 | 571.700 |
| value | head | 0 | up | 15,000 | 756,035 | A | 15,000 | 2,902,421 | 0.345 | 0.100 | 571.700 |
| value | head | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 3,008,152 | 0.332 | 0.100 | 571.700 |
| value | head | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 3,063,237 | 0.326 | 0.100 | 571.700 |
| value | head | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 2,922,951 | 0.342 | 0.100 | 571.700 |
| value | head | 0 | down | 15,000 | 759,799 | A | 35,000 | 2,831,120 | 0.353 | 0.100 | 571.700 |
| value | head | 0 | down | 10,000 | 506,363 | A | 40,000 | 2,745,537 | 0.364 | 0.100 | 571.700 |
| value | head | 0 | down | 5,000 | 254,264 | A | 45,000 | 2,685,397 | 0.372 | 0.100 | 571.700 |
| value | head | 0 | down | 1,000 | 50,210 | A | 49,000 | 2,663,376 | 0.375 | 0.100 | 571.700 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,662,790 | 0.376 | 0.100 | 571.700 |
| value | random | 0 | up | 1,000 | 50,007 | A | 1,000 | 1,219,959 | 0.820 | 0.100 | 59.800 |
| value | random | 0 | up | 5,000 | 256,206 | A | 5,000 | 1,052,831 | 0.950 | 0.100 | 59.800 |
| value | random | 0 | up | 10,000 | 508,328 | A | 10,000 | 927,429 | 1.078 | 0.100 | 60.800 |
| value | random | 0 | up | 15,000 | 756,035 | A | 15,000 | 930,429 | 1.075 | 0.100 | 63.300 |
| value | random | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 896,704 | 1.115 | 0.100 | 63.300 |
| value | random | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 891,736 | 1.121 | 0.100 | 63.300 |
| value | random | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 887,430 | 1.127 | 0.100 | 63.300 |
| value | random | 0 | down | 15,000 | 759,799 | A | 35,000 | 886,413 | 1.128 | 0.100 | 63.300 |
| value | random | 0 | down | 10,000 | 506,363 | A | 40,000 | 883,964 | 1.131 | 0.100 | 63.300 |
| value | random | 0 | down | 5,000 | 254,264 | A | 45,000 | 884,112 | 1.131 | 0.100 | 63.300 |
| value | random | 0 | down | 1,000 | 50,210 | A | 49,000 | 901,831 | 1.109 | 0.100 | 63.300 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 910,294 | 1.099 | 0.100 | 63.300 |
| value | tail | 0 | up | 1,000 | 50,007 | A | 1,000 | 5,743,825 | 0.174 | 0.100 | 3.800 |
| value | tail | 0 | up | 5,000 | 256,206 | A | 5,000 | 5,907,372 | 0.169 | 0.100 | 3.800 |
| value | tail | 0 | up | 10,000 | 508,328 | A | 10,000 | 6,061,708 | 0.165 | 0.100 | 15.700 |
| value | tail | 0 | up | 15,000 | 756,035 | A | 15,000 | 6,342,495 | 0.158 | 0.000 | 15.700 |
| value | tail | 0 | up | 20,000 | 1,005,850 | A | 20,000 | 6,501,528 | 0.154 | 0.000 | 15.700 |
| value | tail | 0 | up | 25,000 | 1,252,902 | A | 25,000 | 6,606,067 | 0.151 | 0.000 | 15.700 |
| value | tail | 0 | down | 20,000 | 1,007,225 | A | 30,000 | 6,067,593 | 0.165 | 0.000 | 15.700 |
| value | tail | 0 | down | 15,000 | 759,799 | A | 35,000 | 5,752,321 | 0.174 | 0.000 | 15.700 |
| value | tail | 0 | down | 10,000 | 506,363 | A | 40,000 | 5,464,630 | 0.183 | 0.000 | 15.700 |
| value | tail | 0 | down | 5,000 | 254,264 | A | 45,000 | 5,252,469 | 0.190 | 0.000 | 18.500 |
| value | tail | 0 | down | 1,000 | 50,210 | A | 49,000 | 5,178,336 | 0.193 | 0.000 | 18.500 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 5,175,394 | 0.193 | 0.000 | 18.500 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 2,380 | 420.100 |
| create | — | 0 | up | 5,000 | A | 1 | 910 | 1099.300 |
| create | — | 0 | up | 10,000 | A | 1 | 561 | 1782.400 |
| create | — | 0 | up | 15,000 | A | 1 | 415 | 2408.900 |
| create | — | 0 | up | 20,000 | A | 1 | 290 | 3443.400 |
| create | — | 0 | up | 25,000 | A | 1 | 249 | 4008.100 |
| create | — | 0 | down | 20,000 | A | 1 | 274 | 3649.800 |
| create | — | 0 | down | 15,000 | A | 1 | 383 | 2609.500 |
| create | — | 0 | down | 10,000 | A | 1 | 560 | 1785.700 |
| create | — | 0 | down | 5,000 | A | 1 | 1,152 | 868.200 |
| create | — | 0 | down | 1,000 | A | 1 | 7,396 | 135.200 |
| create | — | 0 | down | 0 | A | 1 | 68,027 | 14.700 |
| sequence | — | 0 | up | 1,000 | A | 1 | 371 | 2699.000 |
| sequence | — | 0 | up | 5,000 | A | 1 | 135 | 7400.000 |
| sequence | — | 0 | up | 10,000 | A | 1 | 87 | 11432.400 |
| sequence | — | 0 | up | 15,000 | A | 1 | 74 | 13556.500 |
| sequence | — | 0 | up | 20,000 | A | 1 | 50 | 20044.300 |
| sequence | — | 0 | up | 25,000 | A | 1 | 42 | 23748.800 |
| sequence | — | 0 | down | 20,000 | A | 1 | 56 | 17769.800 |
| sequence | — | 0 | down | 15,000 | A | 1 | 66 | 15260.800 |
| sequence | — | 0 | down | 10,000 | A | 1 | 83 | 12014.200 |
| sequence | — | 0 | down | 5,000 | A | 1 | 98 | 10164.800 |
| sequence | — | 0 | down | 1,000 | A | 1 | 174 | 5760.500 |
| sequence | — | 0 | down | 0 | A | 1 | 777 | 1287.400 |
| values | — | 0 | up | 1,000 | A | 1 | 536 | 1864.700 |
| values | — | 0 | up | 5,000 | A | 1 | 204 | 4899.400 |
| values | — | 0 | up | 10,000 | A | 1 | 188 | 5307.400 |
| values | — | 0 | up | 15,000 | A | 1 | 123 | 8127.300 |
| values | — | 0 | up | 20,000 | A | 1 | 96 | 10362.800 |
| values | — | 0 | up | 25,000 | A | 1 | 88 | 11396.000 |
| values | — | 0 | down | 20,000 | A | 1 | 113 | 8854.600 |
| values | — | 0 | down | 15,000 | A | 1 | 142 | 7036.300 |
| values | — | 0 | down | 10,000 | A | 1 | 218 | 4592.200 |
| values | — | 0 | down | 5,000 | A | 1 | 285 | 3505.800 |
| values | — | 0 | down | 1,000 | A | 1 | 1,693 | 590.700 |
| values | — | 0 | down | 0 | A | 1 | 106,383 | 9.400 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.613 | 0.232 | 0.382 |
| 0 | up | 5000 | 3.122 | 1.167 | 1.955 |
| 0 | up | 10000 | 6.220 | 2.342 | 3.878 |
| 0 | up | 15000 | 9.408 | 3.640 | 5.768 |
| 0 | up | 20000 | 12.780 | 5.106 | 7.674 |
| 0 | up | 25000 | 16.189 | 6.630 | 9.559 |
| 0 | down | 20000 | 13.291 | 5.606 | 7.685 |
| 0 | down | 15000 | 9.922 | 4.125 | 5.797 |
| 0 | down | 10000 | 7.152 | 3.289 | 3.863 |
| 0 | down | 5000 | 4.095 | 2.155 | 1.940 |
| 0 | down | 1000 | 1.797 | 1.414 | 0.383 |
| 0 | down | 0 | 1.224 | 1.224 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 50,007 | 0.402 | 421.580 | 8.430 | 120.793 | 15.527 |
| 0 | up | A | 5,000 | 5,000 | 256,206 | 2.057 | 431.302 | 8.417 | 153.801 | 19.671 |
| 0 | up | A | 10,000 | 10,000 | 508,328 | 4.090 | 428.881 | 8.437 | 195.258 | 24.522 |
| 0 | up | A | 15,000 | 15,000 | 756,035 | 6.108 | 426.991 | 8.472 | 208.730 | 29.295 |
| 0 | up | A | 20,000 | 20,000 | 1,005,850 | 8.143 | 426.916 | 8.489 | 279.945 | 34.106 |
| 0 | up | A | 25,000 | 25,000 | 1,252,902 | 10.161 | 426.177 | 8.504 | 294.086 | 38.840 |
| 0 | down | A | 20,000 | 20,000 | 1,007,225 | 8.223 | 431.124 | 8.561 | 297.219 | 34.153 |
| 0 | down | A | 15,000 | 15,000 | 759,799 | 6.203 | 433.606 | 8.560 | 302.199 | 29.428 |
| 0 | down | A | 10,000 | 10,000 | 506,363 | 4.124 | 432.479 | 8.541 | 300.734 | 24.629 |
| 0 | down | A | 5,000 | 5,000 | 254,264 | 2.060 | 431.993 | 8.495 | 298.652 | 19.850 |
| 0 | down | A | 1,000 | 1,000 | 50,210 | 0.406 | 425.476 | 8.474 | 297.035 | 15.980 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 298.215 | 14.908 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 50007 | 184507 | 184.507 | 3.690 | 272.03 | 14.52 | 162.13 | 12.30 |
| 0 | up | A | 5000 | 256206 | 1218174 | 243.635 | 4.755 | 1644.25 | 73.50 | 830.68 | 61.66 |
| 0 | up | A | 10000 | 508328 | 2441689 | 244.169 | 4.803 | 3276.35 | 148.92 | 1655.21 | 124.79 |
| 0 | up | A | 15000 | 756035 | 3694120 | 246.275 | 4.886 | 4916.66 | 225.99 | 3545.68 | 200.14 |
| 0 | up | A | 20000 | 1005850 | 4950983 | 247.549 | 4.922 | 7073.44 | 311.23 | 5103.00 | 263.55 |
| 0 | up | A | 25000 | 1252902 | 6208304 | 248.332 | 4.955 | 9192.05 | 392.29 | 6496.81 | 335.16 |
| 0 | down | A | 20000 | 1007225 | 5103545 | 255.177 | 5.067 | 7538.07 | 326.43 | 5289.65 | 278.22 |
| 0 | down | A | 15000 | 759799 | 3844421 | 256.295 | 5.060 | 5730.74 | 247.34 | 4004.94 | 209.82 |
| 0 | down | A | 10000 | 506363 | 2541344 | 254.134 | 5.019 | 3828.12 | 165.02 | 2670.80 | 139.89 |
| 0 | down | A | 5000 | 254264 | 1247949 | 249.590 | 4.908 | 1909.46 | 79.58 | 1334.90 | 67.69 |
| 0 | down | A | 1000 | 50210 | 239429 | 239.429 | 4.769 | 375.26 | 16.04 | 262.97 | 13.69 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 427.165 | 8.478 | 246.023 | 4.883 |
| 0 | A | scaleDown | 432.094 | 8.548 | 254.445 | 5.034 |
| 0 | A | fullLifecycle | 429.144 | 8.506 | 249.405 | 4.944 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
