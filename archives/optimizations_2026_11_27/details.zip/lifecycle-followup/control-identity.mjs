import fs from 'node:fs'
import crypto from 'node:crypto'
const root='temp/optimization_2026_11_27_lifecycle/'
const hash=b=>crypto.createHash('sha256').update(b).digest('hex')
const tree=(dir,relative='')=>fs.readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.isDirectory()?tree(dir+'/'+e.name,relative+e.name+'/'):[relative+e.name])
const rows=[]
for(const part of ['src','dist','benchmark','scripts'])for(const name of tree(root+'base/'+part)){
  const file=part+'/'+name,a=fs.readFileSync(root+'base/'+file),b=fs.readFileSync(root+'control/'+file)
  if(!a.equals(b))throw Error('Control differs: '+file)
  rows.push({file,sha256:hash(a)})
}
fs.writeFileSync(root+'control-identity.json',JSON.stringify({files:rows.length,rows},null,2))
console.log(rows.length+' identical control files verified')
