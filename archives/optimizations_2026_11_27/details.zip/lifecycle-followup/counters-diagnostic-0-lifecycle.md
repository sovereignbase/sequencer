# Sequencer dynamic lifecycle benchmark

2026-11-27T17:09:12.309Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.32 | 163.00 | 56.56 |
| CommonJS | 199.50 | 164.62 | 56.77 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 216,472 | 4.620 | 4.620 | 4.620 | 0.000 | 0: 4.620 | 0: 4.620 |
| apply | random | A | scaleDown | 24,999 | 245,764 | 4.069 | 4.069 | 4.069 | 0.000 | 0: 4.069 | 0: 4.069 |
| apply | random | A | fullLifecycle | 49,999 | 230,189 | 4.344 | 4.344 | 4.344 | 0.000 | 0: 4.344 | 0: 4.344 |
| create | — | A | scaleUp | 7 | 333 | 3005.529 | 3005.529 | 3005.529 | 0.000 | 0: 3005.529 | 0: 3005.529 |
| create | — | A | scaleDown | 6 | 504 | 1985.267 | 1985.267 | 1985.267 | 0.000 | 0: 1985.267 | 0: 1985.267 |
| create | — | A | fullLifecycle | 13 | 395 | 2534.638 | 2534.638 | 2534.638 | 0.000 | 0: 2534.638 | 0: 2534.638 |
| insert | head | A | scaleUp | 12,500 | 915,014 | 1.093 | 1.093 | 1.093 | 0.000 | 0: 1.093 | 0: 1.093 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 915,014 | 1.093 | 1.093 | 1.093 | 0.000 | 0: 1.093 | 0: 1.093 |
| insert | random | A | scaleUp | 25,000 | 398,257 | 2.511 | 2.511 | 2.511 | 0.000 | 0: 2.511 | 0: 2.511 |
| insert | random | A | scaleDown | 25,000 | 409,377 | 2.443 | 2.443 | 2.443 | 0.000 | 0: 2.443 | 0: 2.443 |
| insert | random | A | fullLifecycle | 50,000 | 403,741 | 2.477 | 2.477 | 2.477 | 0.000 | 0: 2.477 | 0: 2.477 |
| insert | tail | A | scaleUp | 12,500 | 981,216 | 1.019 | 1.019 | 1.019 | 0.000 | 0: 1.019 | 0: 1.019 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 981,216 | 1.019 | 1.019 | 1.019 | 0.000 | 0: 1.019 | 0: 1.019 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 496,566 | 2.014 | 2.014 | 2.014 | 0.000 | 0: 2.014 | 0: 2.014 |
| remove | head | A | fullLifecycle | 12,500 | 496,566 | 2.014 | 2.014 | 2.014 | 0.000 | 0: 2.014 | 0: 2.014 |
| remove | random | A | scaleUp | 25,000 | 314,311 | 3.182 | 3.182 | 3.182 | 0.000 | 0: 3.182 | 0: 3.182 |
| remove | random | A | scaleDown | 25,000 | 329,986 | 3.030 | 3.030 | 3.030 | 0.000 | 0: 3.030 | 0: 3.030 |
| remove | random | A | fullLifecycle | 50,000 | 321,958 | 3.106 | 3.106 | 3.106 | 0.000 | 0: 3.106 | 0: 3.106 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 593,334 | 1.685 | 1.685 | 1.685 | 0.000 | 0: 1.685 | 0: 1.685 |
| remove | tail | A | fullLifecycle | 12,500 | 593,334 | 1.685 | 1.685 | 1.685 | 0.000 | 0: 1.685 | 0: 1.685 |
| replace | head | A | scaleUp | 25,000 | 346,642 | 2.885 | 2.885 | 2.885 | 0.000 | 0: 2.885 | 0: 2.885 |
| replace | head | A | scaleDown | 25,000 | 325,837 | 3.069 | 3.069 | 3.069 | 0.000 | 0: 3.069 | 0: 3.069 |
| replace | head | A | fullLifecycle | 50,000 | 335,918 | 2.977 | 2.977 | 2.977 | 0.000 | 0: 2.977 | 0: 2.977 |
| replace | random | A | scaleUp | 25,000 | 236,720 | 4.224 | 4.224 | 4.224 | 0.000 | 0: 4.224 | 0: 4.224 |
| replace | random | A | scaleDown | 25,000 | 278,942 | 3.585 | 3.585 | 3.585 | 0.000 | 0: 3.585 | 0: 3.585 |
| replace | random | A | fullLifecycle | 50,000 | 256,103 | 3.905 | 3.905 | 3.905 | 0.000 | 0: 3.905 | 0: 3.905 |
| replace | tail | A | scaleUp | 25,000 | 126,379 | 7.913 | 7.913 | 7.913 | 0.000 | 0: 7.913 | 0: 7.913 |
| replace | tail | A | scaleDown | 25,000 | 28,502 | 35.085 | 35.085 | 35.085 | 0.000 | 0: 35.085 | 0: 35.085 |
| replace | tail | A | fullLifecycle | 50,000 | 46,514 | 21.499 | 21.499 | 21.499 | 0.000 | 0: 21.499 | 0: 21.499 |
| sequence | — | A | scaleUp | 6 | 44 | 22641.150 | 22641.150 | 22641.150 | 0.000 | 0: 22641.150 | 0: 22641.150 |
| sequence | — | A | scaleDown | 6 | 60 | 16578.367 | 16578.367 | 16578.367 | 0.000 | 0: 16578.367 | 0: 16578.367 |
| sequence | — | A | fullLifecycle | 12 | 51 | 19609.758 | 19609.758 | 19609.758 | 0.000 | 0: 19609.758 | 0: 19609.758 |
| value | head | A | scaleUp | 25,000 | 2,066,543 | 0.484 | 0.484 | 0.484 | 0.000 | 0: 0.484 | 0: 0.484 |
| value | head | A | scaleDown | 25,000 | 1,720,341 | 0.581 | 0.581 | 0.581 | 0.000 | 0: 0.581 | 0: 0.581 |
| value | head | A | fullLifecycle | 50,000 | 1,877,617 | 0.533 | 0.533 | 0.533 | 0.000 | 0: 0.533 | 0: 0.533 |
| value | random | A | scaleUp | 25,000 | 609,322 | 1.641 | 1.641 | 1.641 | 0.000 | 0: 1.641 | 0: 1.641 |
| value | random | A | scaleDown | 25,000 | 651,098 | 1.536 | 1.536 | 1.536 | 0.000 | 0: 1.536 | 0: 1.536 |
| value | random | A | fullLifecycle | 50,000 | 629,518 | 1.589 | 1.589 | 1.589 | 0.000 | 0: 1.589 | 0: 1.589 |
| value | tail | A | scaleUp | 25,000 | 4,778,287 | 0.209 | 0.209 | 0.209 | 0.000 | 0: 0.209 | 0: 0.209 |
| value | tail | A | scaleDown | 25,000 | 3,279,850 | 0.305 | 0.305 | 0.305 | 0.000 | 0: 0.305 | 0: 0.305 |
| value | tail | A | fullLifecycle | 50,000 | 3,889,749 | 0.257 | 0.257 | 0.257 | 0.000 | 0: 0.257 | 0: 0.257 |
| values | — | A | scaleUp | 6 | 76 | 13087.450 | 13087.450 | 13087.450 | 0.000 | 0: 13087.450 | 0: 13087.450 |
| values | — | A | scaleDown | 6 | 183 | 5449.933 | 5449.933 | 5449.933 | 0.000 | 0: 5449.933 | 0: 5449.933 |
| values | — | A | fullLifecycle | 12 | 108 | 9268.692 | 9268.692 | 9268.692 | 0.000 | 0: 9268.692 | 0: 9268.692 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5448434.000 | 430.140 | 8.475 |
| A | scaleDown | 5 | 4404655.200 | 431.829 | 8.549 |
| A | fullLifecycle | 11 | 4973989.091 | 430.818 | 8.505 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3135629.000 | 247.550 | 4.877 |
| A | scaleDown | 5 | 2594145.800 | 254.328 | 5.035 |
| A | fullLifecycle | 11 | 2889500.273 | 250.272 | 4.940 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 127,698 | 7.831 | 2.800 | 554.300 |
| apply | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 191,110 | 5.233 | 2.200 | 554.300 |
| apply | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 182,444 | 5.481 | 2.200 | 3431.600 |
| apply | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 199,548 | 5.011 | 2.100 | 3431.600 |
| apply | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 208,415 | 4.798 | 2.000 | 3431.600 |
| apply | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 216,472 | 4.620 | 2.000 | 3431.600 |
| apply | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 221,042 | 4.524 | 2.000 | 3431.600 |
| apply | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 224,536 | 4.454 | 2.000 | 3431.600 |
| apply | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 225,664 | 4.431 | 2.000 | 3431.600 |
| apply | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 226,763 | 4.410 | 2.000 | 3431.600 |
| apply | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 229,520 | 4.357 | 2.000 | 3431.600 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 230,189 | 4.344 | 1.900 | 3431.600 |
| insert | head | 0 | up | 1,000 | 49,966 | A | 500 | 518,457 | 1.929 | 0.600 | 58.200 |
| insert | head | 0 | up | 5,000 | 254,523 | A | 2,500 | 703,611 | 1.421 | 0.600 | 58.200 |
| insert | head | 0 | up | 10,000 | 509,098 | A | 5,000 | 804,285 | 1.243 | 0.400 | 58.200 |
| insert | head | 0 | up | 15,000 | 765,837 | A | 7,500 | 870,150 | 1.149 | 0.400 | 58.200 |
| insert | head | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 890,099 | 1.123 | 0.400 | 58.200 |
| insert | head | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 915,014 | 1.093 | 0.400 | 58.200 |
| insert | head | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 915,014 | 1.093 | 0.400 | 58.200 |
| insert | head | 0 | down | 15,000 | 757,461 | A | 12,500 | 915,014 | 1.093 | 0.400 | 58.200 |
| insert | head | 0 | down | 10,000 | 505,565 | A | 12,500 | 915,014 | 1.093 | 0.400 | 58.200 |
| insert | head | 0 | down | 5,000 | 249,719 | A | 12,500 | 915,014 | 1.093 | 0.400 | 58.200 |
| insert | head | 0 | down | 1,000 | 50,567 | A | 12,500 | 915,014 | 1.093 | 0.400 | 58.200 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 915,014 | 1.093 | 0.400 | 58.200 |
| insert | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 219,366 | 4.559 | 0.900 | 864.200 |
| insert | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 325,873 | 3.069 | 0.700 | 864.200 |
| insert | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 362,555 | 2.758 | 0.700 | 864.200 |
| insert | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 384,790 | 2.599 | 0.700 | 864.200 |
| insert | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 385,528 | 2.594 | 0.700 | 864.200 |
| insert | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 398,257 | 2.511 | 0.700 | 864.200 |
| insert | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 395,571 | 2.528 | 0.700 | 864.200 |
| insert | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 394,759 | 2.533 | 0.700 | 864.200 |
| insert | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 398,183 | 2.511 | 0.700 | 864.200 |
| insert | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 397,583 | 2.515 | 0.700 | 864.200 |
| insert | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 401,373 | 2.491 | 0.700 | 864.200 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 403,741 | 2.477 | 0.600 | 864.200 |
| insert | tail | 0 | up | 1,000 | 49,966 | A | 500 | 466,679 | 2.143 | 0.600 | 170.200 |
| insert | tail | 0 | up | 5,000 | 254,523 | A | 2,500 | 747,183 | 1.338 | 0.500 | 170.200 |
| insert | tail | 0 | up | 10,000 | 509,098 | A | 5,000 | 883,626 | 1.132 | 0.400 | 170.200 |
| insert | tail | 0 | up | 15,000 | 765,837 | A | 7,500 | 948,311 | 1.055 | 0.300 | 196.100 |
| insert | tail | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 994,728 | 1.005 | 0.300 | 196.100 |
| insert | tail | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 981,216 | 1.019 | 0.300 | 590.900 |
| insert | tail | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 981,216 | 1.019 | 0.300 | 590.900 |
| insert | tail | 0 | down | 15,000 | 757,461 | A | 12,500 | 981,216 | 1.019 | 0.300 | 590.900 |
| insert | tail | 0 | down | 10,000 | 505,565 | A | 12,500 | 981,216 | 1.019 | 0.300 | 590.900 |
| insert | tail | 0 | down | 5,000 | 249,719 | A | 12,500 | 981,216 | 1.019 | 0.300 | 590.900 |
| insert | tail | 0 | down | 1,000 | 50,567 | A | 12,500 | 981,216 | 1.019 | 0.300 | 590.900 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 981,216 | 1.019 | 0.300 | 590.900 |
| remove | head | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 460,566 | 2.171 | 1.000 | 62.400 |
| remove | head | 0 | down | 15,000 | 757,461 | A | 5,000 | 487,681 | 2.051 | 1.000 | 62.400 |
| remove | head | 0 | down | 10,000 | 505,565 | A | 7,500 | 468,727 | 2.133 | 1.000 | 925.400 |
| remove | head | 0 | down | 5,000 | 249,719 | A | 10,000 | 485,265 | 2.061 | 1.000 | 925.400 |
| remove | head | 0 | down | 1,000 | 50,567 | A | 12,000 | 493,226 | 2.027 | 1.000 | 925.400 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 496,566 | 2.014 | 1.000 | 925.400 |
| remove | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 207,987 | 4.808 | 1.500 | 529.600 |
| remove | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 289,712 | 3.452 | 1.300 | 529.600 |
| remove | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 298,399 | 3.351 | 1.300 | 529.600 |
| remove | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 296,199 | 3.376 | 1.200 | 3412.200 |
| remove | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 302,215 | 3.309 | 1.200 | 3412.200 |
| remove | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 314,311 | 3.182 | 1.200 | 3412.200 |
| remove | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 314,752 | 3.177 | 1.200 | 3412.200 |
| remove | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 317,092 | 3.154 | 1.200 | 3412.200 |
| remove | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 318,696 | 3.138 | 1.200 | 3412.200 |
| remove | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 321,235 | 3.113 | 1.200 | 3412.200 |
| remove | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 319,950 | 3.125 | 1.200 | 3412.200 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 321,958 | 3.106 | 1.100 | 3412.200 |
| remove | tail | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 595,848 | 1.678 | 1.000 | 22.800 |
| remove | tail | 0 | down | 15,000 | 757,461 | A | 5,000 | 604,346 | 1.655 | 0.900 | 28.100 |
| remove | tail | 0 | down | 10,000 | 505,565 | A | 7,500 | 591,735 | 1.690 | 0.900 | 28.100 |
| remove | tail | 0 | down | 5,000 | 249,719 | A | 10,000 | 592,782 | 1.687 | 0.900 | 34.800 |
| remove | tail | 0 | down | 1,000 | 50,567 | A | 12,000 | 591,538 | 1.691 | 0.900 | 69.300 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 593,334 | 1.685 | 0.900 | 69.300 |
| replace | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 220,819 | 4.529 | 1.700 | 75.200 |
| replace | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 303,901 | 3.291 | 1.500 | 251.100 |
| replace | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 294,879 | 3.391 | 1.400 | 4135.400 |
| replace | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 326,837 | 3.060 | 1.400 | 4135.400 |
| replace | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 335,082 | 2.984 | 1.400 | 4135.400 |
| replace | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 346,642 | 2.885 | 1.300 | 4135.400 |
| replace | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 348,737 | 2.867 | 1.300 | 4135.400 |
| replace | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 341,372 | 2.929 | 1.300 | 4135.400 |
| replace | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 329,660 | 3.033 | 1.300 | 4135.400 |
| replace | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 331,782 | 3.014 | 1.300 | 4135.400 |
| replace | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 334,856 | 2.986 | 1.300 | 4135.400 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 335,918 | 2.977 | 1.300 | 4135.400 |
| replace | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 184,560 | 5.418 | 1.600 | 190.300 |
| replace | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 211,795 | 4.722 | 1.600 | 1490.400 |
| replace | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 227,186 | 4.402 | 1.600 | 1490.400 |
| replace | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 218,277 | 4.581 | 1.500 | 5263.000 |
| replace | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 227,272 | 4.400 | 1.500 | 5263.000 |
| replace | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 236,720 | 4.224 | 1.500 | 5263.000 |
| replace | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 243,447 | 4.108 | 1.500 | 5263.000 |
| replace | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 246,643 | 4.054 | 1.500 | 5263.000 |
| replace | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 249,734 | 4.004 | 1.500 | 5263.000 |
| replace | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 251,943 | 3.969 | 1.500 | 5263.000 |
| replace | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 254,691 | 3.926 | 1.400 | 5263.000 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 256,103 | 3.905 | 1.400 | 5263.000 |
| replace | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 79,885 | 12.518 | 5.100 | 320.700 |
| replace | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 110,229 | 9.072 | 4.900 | 995.000 |
| replace | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 111,287 | 8.986 | 4.700 | 2735.100 |
| replace | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 121,073 | 8.259 | 4.500 | 2735.100 |
| replace | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 123,792 | 8.078 | 4.500 | 2735.100 |
| replace | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 126,379 | 7.913 | 4.200 | 2735.100 |
| replace | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 53,847 | 18.571 | 4.200 | 4950.000 |
| replace | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 44,509 | 22.467 | 4.200 | 4950.000 |
| replace | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 45,202 | 22.123 | 4.200 | 4950.000 |
| replace | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 44,720 | 22.361 | 4.200 | 4950.000 |
| replace | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 45,935 | 21.770 | 4.200 | 4950.000 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 46,514 | 21.499 | 4.200 | 4950.000 |
| value | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 529,521 | 1.889 | 0.200 | 724.400 |
| value | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 1,275,868 | 0.784 | 0.200 | 724.400 |
| value | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 1,622,034 | 0.617 | 0.200 | 724.400 |
| value | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 1,842,367 | 0.543 | 0.200 | 724.400 |
| value | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 1,962,477 | 0.510 | 0.200 | 724.400 |
| value | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 2,066,543 | 0.484 | 0.100 | 724.400 |
| value | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 1,977,666 | 0.506 | 0.100 | 724.400 |
| value | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 1,943,127 | 0.515 | 0.100 | 724.400 |
| value | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 1,915,085 | 0.522 | 0.100 | 724.400 |
| value | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 1,892,060 | 0.529 | 0.100 | 724.400 |
| value | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 1,882,769 | 0.531 | 0.100 | 724.400 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 1,877,617 | 0.533 | 0.100 | 724.400 |
| value | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 553,250 | 1.808 | 0.200 | 120.300 |
| value | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 601,793 | 1.662 | 0.200 | 120.300 |
| value | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 590,926 | 1.692 | 0.200 | 120.300 |
| value | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 588,847 | 1.698 | 0.200 | 120.300 |
| value | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 591,677 | 1.690 | 0.200 | 120.300 |
| value | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 609,322 | 1.641 | 0.200 | 120.300 |
| value | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 615,941 | 1.624 | 0.200 | 120.300 |
| value | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 620,735 | 1.611 | 0.200 | 120.300 |
| value | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 619,823 | 1.613 | 0.200 | 120.300 |
| value | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 619,398 | 1.614 | 0.200 | 120.300 |
| value | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 624,455 | 1.601 | 0.200 | 120.300 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 629,518 | 1.589 | 0.100 | 120.300 |
| value | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 2,931,692 | 0.341 | 0.100 | 18.500 |
| value | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 3,662,199 | 0.273 | 0.100 | 63.600 |
| value | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 4,000,480 | 0.250 | 0.100 | 63.600 |
| value | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 4,358,945 | 0.229 | 0.100 | 63.600 |
| value | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 4,589,682 | 0.218 | 0.100 | 63.600 |
| value | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 4,778,287 | 0.209 | 0.000 | 63.600 |
| value | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 4,445,564 | 0.225 | 0.000 | 63.600 |
| value | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 4,269,178 | 0.234 | 0.000 | 63.600 |
| value | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 4,104,458 | 0.244 | 0.000 | 63.600 |
| value | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 3,975,511 | 0.252 | 0.000 | 63.600 |
| value | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 3,901,585 | 0.256 | 0.000 | 63.600 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 3,889,749 | 0.257 | 0.000 | 63.600 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 1,192 | 838.600 |
| create | — | 0 | up | 5,000 | A | 1 | 719 | 1391.700 |
| create | — | 0 | up | 10,000 | A | 1 | 498 | 2009.500 |
| create | — | 0 | up | 15,000 | A | 1 | 273 | 3656.800 |
| create | — | 0 | up | 20,000 | A | 1 | 216 | 4635.200 |
| create | — | 0 | up | 25,000 | A | 1 | 120 | 8332.700 |
| create | — | 0 | down | 20,000 | A | 1 | 237 | 4214.300 |
| create | — | 0 | down | 15,000 | A | 1 | 246 | 4064.900 |
| create | — | 0 | down | 10,000 | A | 1 | 462 | 2165.400 |
| create | — | 0 | down | 5,000 | A | 1 | 955 | 1046.600 |
| create | — | 0 | down | 1,000 | A | 1 | 2,489 | 401.800 |
| create | — | 0 | down | 0 | A | 1 | 53,763 | 18.600 |
| sequence | — | 0 | up | 1,000 | A | 1 | 196 | 5103.100 |
| sequence | — | 0 | up | 5,000 | A | 1 | 78 | 12739.300 |
| sequence | — | 0 | up | 10,000 | A | 1 | 58 | 17106.900 |
| sequence | — | 0 | up | 15,000 | A | 1 | 36 | 28110.100 |
| sequence | — | 0 | up | 20,000 | A | 1 | 27 | 37432.800 |
| sequence | — | 0 | up | 25,000 | A | 1 | 28 | 35354.700 |
| sequence | — | 0 | down | 20,000 | A | 1 | 34 | 29379.300 |
| sequence | — | 0 | down | 15,000 | A | 1 | 41 | 24342.900 |
| sequence | — | 0 | down | 10,000 | A | 1 | 53 | 18740.000 |
| sequence | — | 0 | down | 5,000 | A | 1 | 64 | 15523.600 |
| sequence | — | 0 | down | 1,000 | A | 1 | 106 | 9428.300 |
| sequence | — | 0 | down | 0 | A | 1 | 486 | 2056.100 |
| values | — | 0 | up | 1,000 | A | 1 | 366 | 2730.800 |
| values | — | 0 | up | 5,000 | A | 1 | 177 | 5663.400 |
| values | — | 0 | up | 10,000 | A | 1 | 36 | 27922.100 |
| values | — | 0 | up | 15,000 | A | 1 | 85 | 11750.100 |
| values | — | 0 | up | 20,000 | A | 1 | 62 | 16087.700 |
| values | — | 0 | up | 25,000 | A | 1 | 70 | 14370.600 |
| values | — | 0 | down | 20,000 | A | 1 | 80 | 12562.800 |
| values | — | 0 | down | 15,000 | A | 1 | 102 | 9757.400 |
| values | — | 0 | down | 10,000 | A | 1 | 152 | 6568.200 |
| values | — | 0 | down | 5,000 | A | 1 | 320 | 3122.300 |
| values | — | 0 | down | 1,000 | A | 1 | 1,488 | 672.200 |
| values | — | 0 | down | 0 | A | 1 | 59,880 | 16.700 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.613 | 0.232 | 0.381 |
| 0 | up | 5000 | 3.108 | 1.167 | 1.942 |
| 0 | up | 10000 | 6.228 | 2.343 | 3.884 |
| 0 | up | 15000 | 9.486 | 3.643 | 5.843 |
| 0 | up | 20000 | 12.852 | 5.113 | 7.739 |
| 0 | up | 25000 | 16.278 | 6.637 | 9.641 |
| 0 | down | 20000 | 13.340 | 5.613 | 7.727 |
| 0 | down | 15000 | 9.910 | 4.131 | 5.779 |
| 0 | down | 10000 | 7.153 | 3.295 | 3.857 |
| 0 | down | 5000 | 4.067 | 2.161 | 1.905 |
| 0 | down | 1000 | 1.807 | 1.421 | 0.386 |
| 0 | down | 0 | 1.231 | 1.231 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 49,966 | 0.402 | 421.140 | 8.429 | 121.762 | 15.539 |
| 0 | up | A | 5,000 | 5,000 | 254,523 | 2.043 | 428.454 | 8.417 | 151.219 | 19.649 |
| 0 | up | A | 10,000 | 10,000 | 509,098 | 4.098 | 429.682 | 8.440 | 195.180 | 24.557 |
| 0 | up | A | 15,000 | 15,000 | 765,837 | 6.183 | 432.249 | 8.466 | 208.152 | 29.467 |
| 0 | up | A | 20,000 | 20,000 | 1,014,350 | 8.209 | 430.368 | 8.486 | 280.039 | 34.258 |
| 0 | up | A | 25,000 | 25,000 | 1,263,607 | 10.242 | 429.572 | 8.499 | 294.770 | 39.026 |
| 0 | down | A | 20,000 | 20,000 | 1,012,792 | 8.267 | 433.443 | 8.559 | 295.211 | 34.253 |
| 0 | down | A | 15,000 | 15,000 | 757,461 | 6.185 | 432.337 | 8.562 | 300.156 | 29.412 |
| 0 | down | A | 10,000 | 10,000 | 505,565 | 4.118 | 431.804 | 8.541 | 297.867 | 24.633 |
| 0 | down | A | 5,000 | 5,000 | 249,719 | 2.025 | 424.661 | 8.503 | 295.527 | 19.795 |
| 0 | down | A | 1,000 | 1,000 | 50,567 | 0.408 | 428.020 | 8.464 | 294.402 | 16.000 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 295.445 | 14.925 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 49966 | 184228 | 184.228 | 3.687 | 271.76 | 14.53 | 161.92 | 12.35 |
| 0 | up | A | 5000 | 254523 | 1210131 | 242.026 | 4.755 | 1634.13 | 73.21 | 825.25 | 61.48 |
| 0 | up | A | 10000 | 509098 | 2448079 | 244.808 | 4.809 | 3283.48 | 149.01 | 1658.86 | 124.83 |
| 0 | up | A | 15000 | 765837 | 3734371 | 248.958 | 4.876 | 4974.88 | 226.26 | 3590.17 | 200.09 |
| 0 | up | A | 20000 | 1014350 | 4987172 | 249.359 | 4.917 | 7129.39 | 311.11 | 5143.68 | 263.60 |
| 0 | up | A | 25000 | 1263607 | 6249793 | 249.992 | 4.946 | 9254.82 | 392.21 | 6545.54 | 334.80 |
| 0 | down | A | 20000 | 1012792 | 5129580 | 256.479 | 5.065 | 7576.63 | 326.54 | 5319.60 | 278.20 |
| 0 | down | A | 15000 | 757461 | 3834350 | 255.623 | 5.062 | 5712.74 | 247.20 | 3993.54 | 209.87 |
| 0 | down | A | 10000 | 505565 | 2537356 | 253.736 | 5.019 | 3822.17 | 165.03 | 2665.76 | 139.77 |
| 0 | down | A | 5000 | 249719 | 1229097 | 245.819 | 4.922 | 1877.54 | 79.58 | 1312.05 | 67.88 |
| 0 | down | A | 1000 | 50567 | 240346 | 240.346 | 4.753 | 377.29 | 15.97 | 264.47 | 13.64 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 430.140 | 8.475 | 247.550 | 4.877 |
| 0 | A | scaleDown | 431.829 | 8.549 | 254.328 | 5.035 |
| 0 | A | fullLifecycle | 430.818 | 8.505 | 250.272 | 4.940 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
