# Sequencer dynamic lifecycle benchmark

2026-11-27T17:10:41.307Z · local run

Node 24.16.0; V8 13.6.233.17-node.49; win32 x64; Intel(R) Core(TM) i5-10210U CPU @ 1.60GHz.

Runs: 1; lifecycle: 0 → 25,000 → 0 visible Strips; Strip length: 1…100 Frames.

Latencies use the authoritative sample-weighted arithmetic average. All latency columns are µs/op.

## Bundle size

Both bundles include WASM. Terser uses three compression passes; gzip uses level 9.

| Format | Raw KiB | Minified KiB | Minified + gzip KiB |
| --- | ---: | ---: | ---: |
| ESM | 199.32 | 163.00 | 56.56 |
| CommonJS | 199.50 | 164.62 | 56.77 |

## Aggregate operation latency

| Method | case | Replica | scope | calls | ops/sec | weighted avg | mean run avg | median run avg | std. dev. | minimum run | maximum run |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | --- | --- |
| apply | random | A | scaleUp | 25,000 | 256,122 | 3.904 | 3.904 | 3.904 | 0.000 | 0: 3.904 | 0: 3.904 |
| apply | random | A | scaleDown | 24,999 | 312,767 | 3.197 | 3.197 | 3.197 | 0.000 | 0: 3.197 | 0: 3.197 |
| apply | random | A | fullLifecycle | 49,999 | 281,624 | 3.551 | 3.551 | 3.551 | 0.000 | 0: 3.551 | 0: 3.551 |
| create | — | A | scaleUp | 7 | 476 | 2099.786 | 2099.786 | 2099.786 | 0.000 | 0: 2099.786 | 0: 2099.786 |
| create | — | A | scaleDown | 6 | 639 | 1564.567 | 1564.567 | 1564.567 | 0.000 | 0: 1564.567 | 0: 1564.567 |
| create | — | A | fullLifecycle | 13 | 540 | 1852.762 | 1852.762 | 1852.762 | 0.000 | 0: 1852.762 | 0: 1852.762 |
| insert | head | A | scaleUp | 12,500 | 1,177,568 | 0.849 | 0.849 | 0.849 | 0.000 | 0: 0.849 | 0: 0.849 |
| insert | head | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | head | A | fullLifecycle | 12,500 | 1,177,568 | 0.849 | 0.849 | 0.849 | 0.000 | 0: 0.849 | 0: 0.849 |
| insert | random | A | scaleUp | 25,000 | 499,228 | 2.003 | 2.003 | 2.003 | 0.000 | 0: 2.003 | 0: 2.003 |
| insert | random | A | scaleDown | 25,000 | 545,888 | 1.832 | 1.832 | 1.832 | 0.000 | 0: 1.832 | 0: 1.832 |
| insert | random | A | fullLifecycle | 50,000 | 521,517 | 1.917 | 1.917 | 1.917 | 0.000 | 0: 1.917 | 0: 1.917 |
| insert | tail | A | scaleUp | 12,500 | 1,271,708 | 0.786 | 0.786 | 0.786 | 0.000 | 0: 0.786 | 0: 0.786 |
| insert | tail | A | scaleDown | 0 | — | — | — | — | — | — | — |
| insert | tail | A | fullLifecycle | 12,500 | 1,271,708 | 0.786 | 0.786 | 0.786 | 0.000 | 0: 0.786 | 0: 0.786 |
| remove | head | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | head | A | scaleDown | 12,500 | 652,217 | 1.533 | 1.533 | 1.533 | 0.000 | 0: 1.533 | 0: 1.533 |
| remove | head | A | fullLifecycle | 12,500 | 652,217 | 1.533 | 1.533 | 1.533 | 0.000 | 0: 1.533 | 0: 1.533 |
| remove | random | A | scaleUp | 25,000 | 391,003 | 2.558 | 2.558 | 2.558 | 0.000 | 0: 2.558 | 0: 2.558 |
| remove | random | A | scaleDown | 25,000 | 429,106 | 2.330 | 2.330 | 2.330 | 0.000 | 0: 2.330 | 0: 2.330 |
| remove | random | A | fullLifecycle | 50,000 | 409,169 | 2.444 | 2.444 | 2.444 | 0.000 | 0: 2.444 | 0: 2.444 |
| remove | tail | A | scaleUp | 0 | — | — | — | — | — | — | — |
| remove | tail | A | scaleDown | 12,500 | 772,139 | 1.295 | 1.295 | 1.295 | 0.000 | 0: 1.295 | 0: 1.295 |
| remove | tail | A | fullLifecycle | 12,500 | 772,139 | 1.295 | 1.295 | 1.295 | 0.000 | 0: 1.295 | 0: 1.295 |
| replace | head | A | scaleUp | 25,000 | 445,745 | 2.243 | 2.243 | 2.243 | 0.000 | 0: 2.243 | 0: 2.243 |
| replace | head | A | scaleDown | 25,000 | 449,191 | 2.226 | 2.226 | 2.226 | 0.000 | 0: 2.226 | 0: 2.226 |
| replace | head | A | fullLifecycle | 50,000 | 447,461 | 2.235 | 2.235 | 2.235 | 0.000 | 0: 2.235 | 0: 2.235 |
| replace | random | A | scaleUp | 25,000 | 308,745 | 3.239 | 3.239 | 3.239 | 0.000 | 0: 3.239 | 0: 3.239 |
| replace | random | A | scaleDown | 25,000 | 360,160 | 2.777 | 2.777 | 2.777 | 0.000 | 0: 2.777 | 0: 2.777 |
| replace | random | A | fullLifecycle | 50,000 | 332,477 | 3.008 | 3.008 | 3.008 | 0.000 | 0: 3.008 | 0: 3.008 |
| replace | tail | A | scaleUp | 25,000 | 161,037 | 6.210 | 6.210 | 6.210 | 0.000 | 0: 6.210 | 0: 6.210 |
| replace | tail | A | scaleDown | 25,000 | 37,116 | 26.942 | 26.942 | 26.942 | 0.000 | 0: 26.942 | 0: 26.942 |
| replace | tail | A | fullLifecycle | 50,000 | 60,328 | 16.576 | 16.576 | 16.576 | 0.000 | 0: 16.576 | 0: 16.576 |
| sequence | — | A | scaleUp | 6 | 63 | 15904.183 | 15904.183 | 15904.183 | 0.000 | 0: 15904.183 | 0: 15904.183 |
| sequence | — | A | scaleDown | 6 | 80 | 12442.583 | 12442.583 | 12442.583 | 0.000 | 0: 12442.583 | 0: 12442.583 |
| sequence | — | A | fullLifecycle | 12 | 71 | 14173.383 | 14173.383 | 14173.383 | 0.000 | 0: 14173.383 | 0: 14173.383 |
| value | head | A | scaleUp | 25,000 | 2,761,150 | 0.362 | 0.362 | 0.362 | 0.000 | 0: 0.362 | 0: 0.362 |
| value | head | A | scaleDown | 25,000 | 2,244,508 | 0.446 | 0.446 | 0.446 | 0.000 | 0: 0.446 | 0: 0.446 |
| value | head | A | fullLifecycle | 50,000 | 2,476,167 | 0.404 | 0.404 | 0.404 | 0.000 | 0: 0.404 | 0: 0.404 |
| value | random | A | scaleUp | 25,000 | 760,998 | 1.314 | 1.314 | 1.314 | 0.000 | 0: 1.314 | 0: 1.314 |
| value | random | A | scaleDown | 25,000 | 875,047 | 1.143 | 1.143 | 1.143 | 0.000 | 0: 1.143 | 0: 1.143 |
| value | random | A | fullLifecycle | 50,000 | 814,047 | 1.228 | 1.228 | 1.228 | 0.000 | 0: 1.228 | 0: 1.228 |
| value | tail | A | scaleUp | 25,000 | 5,871,991 | 0.170 | 0.170 | 0.170 | 0.000 | 0: 0.170 | 0: 0.170 |
| value | tail | A | scaleDown | 25,000 | 4,045,504 | 0.247 | 0.247 | 0.247 | 0.000 | 0: 0.247 | 0: 0.247 |
| value | tail | A | fullLifecycle | 50,000 | 4,790,557 | 0.209 | 0.209 | 0.209 | 0.000 | 0: 0.209 | 0: 0.209 |
| values | — | A | scaleUp | 6 | 90 | 11112.183 | 11112.183 | 11112.183 | 0.000 | 0: 11112.183 | 0: 11112.183 |
| values | — | A | scaleDown | 6 | 238 | 4195.267 | 4195.267 | 4195.267 | 0.000 | 0: 4195.267 | 0: 4195.267 |
| values | — | A | fullLifecycle | 12 | 131 | 7653.725 | 7653.725 | 7653.725 | 0.000 | 0: 7653.725 | 0: 7653.725 |

## Aggregate exported Sequence estimate

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 5448434.000 | 430.140 | 8.475 |
| A | scaleDown | 5 | 4404655.200 | 431.829 | 8.549 |
| A | fullLifecycle | 11 | 4973989.091 | 430.818 | 8.505 |

## Aggregate disk usage

Nonempty checkpoint observations across all runs. Bytes per unit use total bytes divided by total units.

| Replica | scope | observations | avg bytes | B/Strip | B/Frame |
| --- | --- | ---: | ---: | ---: | ---: |
| A | scaleUp | 6 | 3135629.000 | 247.550 | 4.877 |
| A | scaleDown | 5 | 2594145.800 | 254.328 | 5.035 |
| A | fullLifecycle | 11 | 2889500.273 | 250.272 | 4.940 |

## Scaling performance

Checkpoint values are cumulative full-lifecycle averages at that point and are never reset.

| Method | case | Run | direction | Strips | Frames | Replica | calls | ops/sec | avg | min | max |
| --- | --- | ---: | --- | ---: | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| apply | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 187,066 | 5.346 | 2.300 | 264.300 |
| apply | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 242,896 | 4.117 | 1.900 | 264.300 |
| apply | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 243,885 | 4.100 | 1.800 | 1341.700 |
| apply | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 260,011 | 3.846 | 1.700 | 1341.700 |
| apply | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 244,893 | 4.083 | 1.700 | 7127.100 |
| apply | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 256,122 | 3.904 | 1.700 | 7127.100 |
| apply | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 263,266 | 3.798 | 1.700 | 7127.100 |
| apply | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 266,384 | 3.754 | 1.700 | 7127.100 |
| apply | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 270,753 | 3.693 | 1.700 | 7127.100 |
| apply | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 274,325 | 3.645 | 1.700 | 7127.100 |
| apply | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 279,902 | 3.573 | 1.700 | 7127.100 |
| apply | random | 0 | down | 0 | 0 | A | 49,999 | 281,624 | 3.551 | 1.400 | 7127.100 |
| insert | head | 0 | up | 1,000 | 49,966 | A | 500 | 733,353 | 1.364 | 0.500 | 48.500 |
| insert | head | 0 | up | 5,000 | 254,523 | A | 2,500 | 906,158 | 1.104 | 0.400 | 48.500 |
| insert | head | 0 | up | 10,000 | 509,098 | A | 5,000 | 1,024,884 | 0.976 | 0.400 | 48.500 |
| insert | head | 0 | up | 15,000 | 765,837 | A | 7,500 | 1,110,667 | 0.900 | 0.400 | 48.500 |
| insert | head | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 1,143,419 | 0.875 | 0.300 | 62.300 |
| insert | head | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 1,177,568 | 0.849 | 0.300 | 62.300 |
| insert | head | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 1,177,568 | 0.849 | 0.300 | 62.300 |
| insert | head | 0 | down | 15,000 | 757,461 | A | 12,500 | 1,177,568 | 0.849 | 0.300 | 62.300 |
| insert | head | 0 | down | 10,000 | 505,565 | A | 12,500 | 1,177,568 | 0.849 | 0.300 | 62.300 |
| insert | head | 0 | down | 5,000 | 249,719 | A | 12,500 | 1,177,568 | 0.849 | 0.300 | 62.300 |
| insert | head | 0 | down | 1,000 | 50,567 | A | 12,500 | 1,177,568 | 0.849 | 0.300 | 62.300 |
| insert | head | 0 | down | 0 | 0 | A | 12,500 | 1,177,568 | 0.849 | 0.300 | 62.300 |
| insert | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 394,524 | 2.535 | 0.600 | 379.800 |
| insert | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 434,375 | 2.302 | 0.600 | 543.000 |
| insert | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 462,725 | 2.161 | 0.600 | 543.000 |
| insert | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 489,555 | 2.043 | 0.600 | 543.000 |
| insert | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 489,591 | 2.043 | 0.600 | 738.000 |
| insert | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 499,228 | 2.003 | 0.600 | 738.000 |
| insert | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 498,662 | 2.005 | 0.600 | 738.000 |
| insert | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 493,402 | 2.027 | 0.500 | 738.000 |
| insert | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 502,157 | 1.991 | 0.500 | 738.000 |
| insert | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 507,237 | 1.971 | 0.500 | 738.000 |
| insert | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 517,447 | 1.933 | 0.500 | 738.000 |
| insert | random | 0 | down | 0 | 0 | A | 50,000 | 521,517 | 1.917 | 0.400 | 738.000 |
| insert | tail | 0 | up | 1,000 | 49,966 | A | 500 | 813,935 | 1.229 | 0.400 | 26.300 |
| insert | tail | 0 | up | 5,000 | 254,523 | A | 2,500 | 997,367 | 1.003 | 0.400 | 57.400 |
| insert | tail | 0 | up | 10,000 | 509,098 | A | 5,000 | 1,161,413 | 0.861 | 0.300 | 84.700 |
| insert | tail | 0 | up | 15,000 | 765,837 | A | 7,500 | 1,215,855 | 0.822 | 0.300 | 179.300 |
| insert | tail | 0 | up | 20,000 | 1,014,350 | A | 10,000 | 1,272,799 | 0.786 | 0.300 | 179.300 |
| insert | tail | 0 | up | 25,000 | 1,263,607 | A | 12,500 | 1,271,708 | 0.786 | 0.300 | 363.300 |
| insert | tail | 0 | down | 20,000 | 1,012,792 | A | 12,500 | 1,271,708 | 0.786 | 0.300 | 363.300 |
| insert | tail | 0 | down | 15,000 | 757,461 | A | 12,500 | 1,271,708 | 0.786 | 0.300 | 363.300 |
| insert | tail | 0 | down | 10,000 | 505,565 | A | 12,500 | 1,271,708 | 0.786 | 0.300 | 363.300 |
| insert | tail | 0 | down | 5,000 | 249,719 | A | 12,500 | 1,271,708 | 0.786 | 0.300 | 363.300 |
| insert | tail | 0 | down | 1,000 | 50,567 | A | 12,500 | 1,271,708 | 0.786 | 0.300 | 363.300 |
| insert | tail | 0 | down | 0 | 0 | A | 12,500 | 1,271,708 | 0.786 | 0.300 | 363.300 |
| remove | head | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | head | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | head | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 629,644 | 1.588 | 0.900 | 53.600 |
| remove | head | 0 | down | 15,000 | 757,461 | A | 5,000 | 618,276 | 1.617 | 0.900 | 53.600 |
| remove | head | 0 | down | 10,000 | 505,565 | A | 7,500 | 606,988 | 1.647 | 0.900 | 643.300 |
| remove | head | 0 | down | 5,000 | 249,719 | A | 10,000 | 633,312 | 1.579 | 0.800 | 643.300 |
| remove | head | 0 | down | 1,000 | 50,567 | A | 12,000 | 646,430 | 1.547 | 0.800 | 643.300 |
| remove | head | 0 | down | 0 | 0 | A | 12,500 | 652,217 | 1.533 | 0.800 | 643.300 |
| remove | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 321,688 | 3.109 | 1.100 | 315.200 |
| remove | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 335,920 | 2.977 | 1.100 | 1327.800 |
| remove | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 337,615 | 2.962 | 1.000 | 1502.800 |
| remove | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 370,424 | 2.700 | 1.000 | 1502.800 |
| remove | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 377,374 | 2.650 | 1.000 | 1502.800 |
| remove | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 391,003 | 2.558 | 1.000 | 1502.800 |
| remove | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 393,563 | 2.541 | 1.000 | 1502.800 |
| remove | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 387,507 | 2.581 | 1.000 | 1502.800 |
| remove | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 392,748 | 2.546 | 1.000 | 1502.800 |
| remove | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 398,827 | 2.507 | 1.000 | 1502.800 |
| remove | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 405,853 | 2.464 | 1.000 | 1502.800 |
| remove | random | 0 | down | 0 | 0 | A | 50,000 | 409,169 | 2.444 | 0.900 | 1502.800 |
| remove | tail | 0 | up | 1,000 | 49,966 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 5,000 | 254,523 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 10,000 | 509,098 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 15,000 | 765,837 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 20,000 | 1,014,350 | A | 0 | — | — | — | — |
| remove | tail | 0 | up | 25,000 | 1,263,607 | A | 0 | — | — | — | — |
| remove | tail | 0 | down | 20,000 | 1,012,792 | A | 2,500 | 769,325 | 1.300 | 0.900 | 18.400 |
| remove | tail | 0 | down | 15,000 | 757,461 | A | 5,000 | 746,469 | 1.340 | 0.800 | 34.100 |
| remove | tail | 0 | down | 10,000 | 505,565 | A | 7,500 | 750,811 | 1.332 | 0.800 | 34.100 |
| remove | tail | 0 | down | 5,000 | 249,719 | A | 10,000 | 761,232 | 1.314 | 0.800 | 59.600 |
| remove | tail | 0 | down | 1,000 | 50,567 | A | 12,000 | 767,607 | 1.303 | 0.800 | 59.600 |
| remove | tail | 0 | down | 0 | 0 | A | 12,500 | 772,139 | 1.295 | 0.700 | 59.600 |
| replace | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 332,546 | 3.007 | 1.500 | 44.200 |
| replace | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 330,391 | 3.027 | 1.200 | 1899.000 |
| replace | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 392,556 | 2.547 | 1.200 | 1899.000 |
| replace | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 423,795 | 2.360 | 1.200 | 1899.000 |
| replace | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 432,149 | 2.314 | 1.100 | 1899.000 |
| replace | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 445,745 | 2.243 | 1.100 | 1899.000 |
| replace | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 449,429 | 2.225 | 1.100 | 1899.000 |
| replace | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 434,870 | 2.300 | 1.100 | 1899.000 |
| replace | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 437,050 | 2.288 | 1.100 | 1899.000 |
| replace | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 440,725 | 2.269 | 1.000 | 1899.000 |
| replace | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 445,185 | 2.246 | 1.000 | 1899.000 |
| replace | head | 0 | down | 0 | 0 | A | 50,000 | 447,461 | 2.235 | 1.000 | 1899.000 |
| replace | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 295,037 | 3.389 | 1.500 | 115.400 |
| replace | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 267,745 | 3.735 | 1.500 | 1183.600 |
| replace | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 286,760 | 3.487 | 1.400 | 1183.600 |
| replace | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 295,077 | 3.389 | 1.400 | 1183.600 |
| replace | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 301,083 | 3.321 | 1.400 | 1183.600 |
| replace | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 308,745 | 3.239 | 1.400 | 1183.600 |
| replace | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 314,493 | 3.180 | 1.400 | 1183.600 |
| replace | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 313,903 | 3.186 | 1.300 | 1183.600 |
| replace | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 319,065 | 3.134 | 1.300 | 1183.600 |
| replace | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 323,414 | 3.092 | 1.100 | 1183.600 |
| replace | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 329,955 | 3.031 | 1.100 | 1183.600 |
| replace | random | 0 | down | 0 | 0 | A | 50,000 | 332,477 | 3.008 | 1.100 | 1183.600 |
| replace | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 102,222 | 9.783 | 4.600 | 885.700 |
| replace | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 127,591 | 7.838 | 4.600 | 2121.100 |
| replace | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 143,606 | 6.963 | 4.300 | 2121.100 |
| replace | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 152,943 | 6.538 | 4.100 | 2121.100 |
| replace | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 157,154 | 6.363 | 4.000 | 2121.100 |
| replace | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 161,037 | 6.210 | 3.900 | 2121.100 |
| replace | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 75,832 | 13.187 | 3.900 | 2121.100 |
| replace | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 58,759 | 17.019 | 3.900 | 2121.100 |
| replace | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 59,272 | 16.871 | 3.900 | 2121.100 |
| replace | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 58,229 | 17.174 | 3.900 | 2121.100 |
| replace | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 59,590 | 16.781 | 3.900 | 2215.100 |
| replace | tail | 0 | down | 0 | 0 | A | 50,000 | 60,328 | 16.576 | 3.900 | 2215.100 |
| value | head | 0 | up | 1,000 | 49,966 | A | 1,000 | 871,612 | 1.147 | 0.200 | 525.800 |
| value | head | 0 | up | 5,000 | 254,523 | A | 5,000 | 1,832,912 | 0.546 | 0.100 | 525.800 |
| value | head | 0 | up | 10,000 | 509,098 | A | 10,000 | 2,298,428 | 0.435 | 0.100 | 525.800 |
| value | head | 0 | up | 15,000 | 765,837 | A | 15,000 | 2,491,198 | 0.401 | 0.100 | 525.800 |
| value | head | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 2,626,982 | 0.381 | 0.100 | 525.800 |
| value | head | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 2,761,150 | 0.362 | 0.100 | 525.800 |
| value | head | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 2,656,419 | 0.376 | 0.100 | 525.800 |
| value | head | 0 | down | 15,000 | 757,461 | A | 35,000 | 2,556,685 | 0.391 | 0.100 | 525.800 |
| value | head | 0 | down | 10,000 | 505,565 | A | 40,000 | 2,519,653 | 0.397 | 0.100 | 525.800 |
| value | head | 0 | down | 5,000 | 249,719 | A | 45,000 | 2,493,586 | 0.401 | 0.100 | 525.800 |
| value | head | 0 | down | 1,000 | 50,567 | A | 49,000 | 2,479,531 | 0.403 | 0.100 | 525.800 |
| value | head | 0 | down | 0 | 0 | A | 50,000 | 2,476,167 | 0.404 | 0.100 | 525.800 |
| value | random | 0 | up | 1,000 | 49,966 | A | 1,000 | 1,065,871 | 0.938 | 0.200 | 22.300 |
| value | random | 0 | up | 5,000 | 254,523 | A | 5,000 | 813,233 | 1.230 | 0.200 | 22.300 |
| value | random | 0 | up | 10,000 | 509,098 | A | 10,000 | 740,061 | 1.351 | 0.200 | 42.200 |
| value | random | 0 | up | 15,000 | 765,837 | A | 15,000 | 750,957 | 1.332 | 0.200 | 122.600 |
| value | random | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 748,187 | 1.337 | 0.200 | 122.600 |
| value | random | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 760,998 | 1.314 | 0.200 | 122.600 |
| value | random | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 773,070 | 1.294 | 0.200 | 122.600 |
| value | random | 0 | down | 15,000 | 757,461 | A | 35,000 | 769,087 | 1.300 | 0.200 | 122.600 |
| value | random | 0 | down | 10,000 | 505,565 | A | 40,000 | 780,232 | 1.282 | 0.200 | 122.600 |
| value | random | 0 | down | 5,000 | 249,719 | A | 45,000 | 788,999 | 1.267 | 0.200 | 122.600 |
| value | random | 0 | down | 1,000 | 50,567 | A | 49,000 | 805,921 | 1.241 | 0.100 | 122.600 |
| value | random | 0 | down | 0 | 0 | A | 50,000 | 814,047 | 1.228 | 0.100 | 122.600 |
| value | tail | 0 | up | 1,000 | 49,966 | A | 1,000 | 4,050,223 | 0.247 | 0.100 | 7.100 |
| value | tail | 0 | up | 5,000 | 254,523 | A | 5,000 | 4,547,935 | 0.220 | 0.100 | 22.900 |
| value | tail | 0 | up | 10,000 | 509,098 | A | 10,000 | 5,045,409 | 0.198 | 0.100 | 34.300 |
| value | tail | 0 | up | 15,000 | 765,837 | A | 15,000 | 5,246,223 | 0.191 | 0.000 | 93.300 |
| value | tail | 0 | up | 20,000 | 1,014,350 | A | 20,000 | 5,563,592 | 0.180 | 0.000 | 93.300 |
| value | tail | 0 | up | 25,000 | 1,263,607 | A | 25,000 | 5,871,991 | 0.170 | 0.000 | 93.300 |
| value | tail | 0 | down | 20,000 | 1,012,792 | A | 30,000 | 5,482,757 | 0.182 | 0.000 | 93.300 |
| value | tail | 0 | down | 15,000 | 757,461 | A | 35,000 | 5,178,281 | 0.193 | 0.000 | 93.300 |
| value | tail | 0 | down | 10,000 | 505,565 | A | 40,000 | 5,022,223 | 0.199 | 0.000 | 93.300 |
| value | tail | 0 | down | 5,000 | 249,719 | A | 45,000 | 4,873,981 | 0.205 | 0.000 | 93.300 |
| value | tail | 0 | down | 1,000 | 50,567 | A | 49,000 | 4,789,319 | 0.209 | 0.000 | 93.300 |
| value | tail | 0 | down | 0 | 0 | A | 50,000 | 4,790,557 | 0.209 | 0.000 | 93.300 |

## Management performance

| Method | case | Run | direction | Strips | Replica | calls | ops/sec | avg |
| --- | --- | ---: | --- | ---: | --- | ---: | ---: | ---: |
| create | — | 0 | up | 1,000 | A | 1 | 1,951 | 512.600 |
| create | — | 0 | up | 5,000 | A | 1 | 762 | 1311.700 |
| create | — | 0 | up | 10,000 | A | 1 | 413 | 2420.100 |
| create | — | 0 | up | 15,000 | A | 1 | 392 | 2551.900 |
| create | — | 0 | up | 20,000 | A | 1 | 287 | 3482.800 |
| create | — | 0 | up | 25,000 | A | 1 | 234 | 4266.100 |
| create | — | 0 | down | 20,000 | A | 1 | 280 | 3570.400 |
| create | — | 0 | down | 15,000 | A | 1 | 357 | 2798.800 |
| create | — | 0 | down | 10,000 | A | 1 | 545 | 1835.900 |
| create | — | 0 | down | 5,000 | A | 1 | 1,094 | 913.800 |
| create | — | 0 | down | 1,000 | A | 1 | 3,939 | 253.900 |
| create | — | 0 | down | 0 | A | 1 | 68,493 | 14.600 |
| sequence | — | 0 | up | 1,000 | A | 1 | 344 | 2904.300 |
| sequence | — | 0 | up | 5,000 | A | 1 | 109 | 9149.500 |
| sequence | — | 0 | up | 10,000 | A | 1 | 63 | 15927.000 |
| sequence | — | 0 | up | 15,000 | A | 1 | 58 | 17195.700 |
| sequence | — | 0 | up | 20,000 | A | 1 | 42 | 24042.700 |
| sequence | — | 0 | up | 25,000 | A | 1 | 38 | 26205.900 |
| sequence | — | 0 | down | 20,000 | A | 1 | 47 | 21123.800 |
| sequence | — | 0 | down | 15,000 | A | 1 | 56 | 17940.000 |
| sequence | — | 0 | down | 10,000 | A | 1 | 69 | 14394.000 |
| sequence | — | 0 | down | 5,000 | A | 1 | 91 | 10987.600 |
| sequence | — | 0 | down | 1,000 | A | 1 | 116 | 8625.100 |
| sequence | — | 0 | down | 0 | A | 1 | 631 | 1585.000 |
| values | — | 0 | up | 1,000 | A | 1 | 448 | 2232.100 |
| values | — | 0 | up | 5,000 | A | 1 | 190 | 5265.400 |
| values | — | 0 | up | 10,000 | A | 1 | 40 | 24917.500 |
| values | — | 0 | up | 15,000 | A | 1 | 102 | 9851.800 |
| values | — | 0 | up | 20,000 | A | 1 | 95 | 10524.000 |
| values | — | 0 | up | 25,000 | A | 1 | 72 | 13882.300 |
| values | — | 0 | down | 20,000 | A | 1 | 108 | 9275.100 |
| values | — | 0 | down | 15,000 | A | 1 | 143 | 6973.400 |
| values | — | 0 | down | 10,000 | A | 1 | 188 | 5305.300 |
| values | — | 0 | down | 5,000 | A | 1 | 349 | 2868.600 |
| values | — | 0 | down | 1,000 | A | 1 | 1,358 | 736.400 |
| values | — | 0 | down | 0 | A | 1 | 78,125 | 12.800 |

## Memory usage

One instance after both peers restart from the same compacted checkpoint. Its peer is excluded. WASM bytes are live native allocations, excluding unused WASM capacity; JavaScript uses eight bytes per retained array slot, counting each Footage array once.

| Run | direction | visible Strips | estimated MiB | WASM MiB | JS MiB |
| ---: | --- | ---: | ---: | ---: | ---: |
| 0 | up | 1000 | 0.613 | 0.232 | 0.381 |
| 0 | up | 5000 | 3.108 | 1.167 | 1.942 |
| 0 | up | 10000 | 6.228 | 2.343 | 3.884 |
| 0 | up | 15000 | 9.486 | 3.643 | 5.843 |
| 0 | up | 20000 | 12.852 | 5.113 | 7.739 |
| 0 | up | 25000 | 16.278 | 6.637 | 9.641 |
| 0 | down | 20000 | 13.340 | 5.613 | 7.727 |
| 0 | down | 15000 | 9.910 | 4.131 | 5.779 |
| 0 | down | 10000 | 7.153 | 3.295 | 3.857 |
| 0 | down | 5000 | 4.067 | 2.161 | 1.905 |
| 0 | down | 1000 | 1.807 | 1.421 | 0.386 |
| 0 | down | 0 | 1.231 | 1.231 | 0.000 |

## Exported Sequence representation

The representation estimate describes exported metadata and Footage slots, independently of the live runtime.

| Run | direction | Replica | visible Strips | retained insertions | Frames | estimated memory MiB | memory B/Strip | memory B/Frame | process RSS MiB | process heap used MiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1,000 | 1,000 | 49,966 | 0.402 | 421.140 | 8.429 | 121.297 | 15.542 |
| 0 | up | A | 5,000 | 5,000 | 254,523 | 2.043 | 428.454 | 8.417 | 150.746 | 19.651 |
| 0 | up | A | 10,000 | 10,000 | 509,098 | 4.098 | 429.682 | 8.440 | 195.168 | 24.559 |
| 0 | up | A | 15,000 | 15,000 | 765,837 | 6.183 | 432.249 | 8.466 | 208.719 | 29.470 |
| 0 | up | A | 20,000 | 20,000 | 1,014,350 | 8.209 | 430.368 | 8.486 | 279.477 | 34.260 |
| 0 | up | A | 25,000 | 25,000 | 1,263,607 | 10.242 | 429.572 | 8.499 | 292.980 | 39.028 |
| 0 | down | A | 20,000 | 20,000 | 1,012,792 | 8.267 | 433.443 | 8.559 | 297.695 | 34.255 |
| 0 | down | A | 15,000 | 15,000 | 757,461 | 6.185 | 432.337 | 8.562 | 298.586 | 29.414 |
| 0 | down | A | 10,000 | 10,000 | 505,565 | 4.118 | 431.804 | 8.541 | 297.555 | 24.635 |
| 0 | down | A | 5,000 | 5,000 | 249,719 | 2.025 | 424.661 | 8.503 | 295.355 | 19.798 |
| 0 | down | A | 1,000 | 1,000 | 50,567 | 0.408 | 428.020 | 8.464 | 294.477 | 16.003 |
| 0 | down | A | 0 | 0 | 0 | 0.000 | — | — | 295.555 | 14.927 |

## Disk usage

Sequence sizes exclude filesystem metadata. JSON and MessagePack use numeric arrays; gzip uses level 9. Encoding and disk I/O are outside API timings.

| Run | direction | Replica | visible Strips | Frames | V8 bytes | disk B/Strip | disk B/Frame | JSON KiB | JSON + gzip KiB | MessagePack KiB | MessagePack + gzip KiB |
| ---: | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | up | A | 1000 | 49966 | 184228 | 184.228 | 3.687 | 271.76 | 14.53 | 161.92 | 12.35 |
| 0 | up | A | 5000 | 254523 | 1210131 | 242.026 | 4.755 | 1634.13 | 73.21 | 825.25 | 61.48 |
| 0 | up | A | 10000 | 509098 | 2448079 | 244.808 | 4.809 | 3283.48 | 149.01 | 1658.86 | 124.83 |
| 0 | up | A | 15000 | 765837 | 3734371 | 248.958 | 4.876 | 4974.88 | 226.26 | 3590.17 | 200.09 |
| 0 | up | A | 20000 | 1014350 | 4987172 | 249.359 | 4.917 | 7129.39 | 311.11 | 5143.68 | 263.60 |
| 0 | up | A | 25000 | 1263607 | 6249793 | 249.992 | 4.946 | 9254.82 | 392.21 | 6545.54 | 334.80 |
| 0 | down | A | 20000 | 1012792 | 5129580 | 256.479 | 5.065 | 7576.63 | 326.54 | 5319.60 | 278.20 |
| 0 | down | A | 15000 | 757461 | 3834350 | 255.623 | 5.062 | 5712.74 | 247.20 | 3993.54 | 209.87 |
| 0 | down | A | 10000 | 505565 | 2537356 | 253.736 | 5.019 | 3822.17 | 165.03 | 2665.76 | 139.77 |
| 0 | down | A | 5000 | 249719 | 1229097 | 245.819 | 4.922 | 1877.54 | 79.58 | 1312.05 | 67.88 |
| 0 | down | A | 1000 | 50567 | 240346 | 240.346 | 4.753 | 377.29 | 15.97 | 264.47 | 13.64 |
| 0 | down | A | 0 | 0 | 37 | — | — | 0.02 | 0.03 | 0.01 | 0.03 |

## Lifecycle space averages

| Run | Replica | scope | memory B/Strip | memory B/Frame | storage B/Strip | storage B/Frame |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 0 | A | scaleUp | 430.140 | 8.475 | 247.550 | 4.877 |
| 0 | A | scaleDown | 431.829 | 8.549 | 254.328 | 5.035 |
| 0 | A | fullLifecycle | 430.818 | 8.505 | 250.272 | 4.940 |

## Measurement notes

- Scale is the number of visible logical Strips maintained by the benchmark model. Every mutation targets a complete Strip boundary.
- The workload has two peers editing the same document. Every local Gossip is applied by the receiver and every acknowledgement returned by apply is gossiped back to the sender. apply.random times only the measured peer applying the remote replacement Gossip.
- At each checkpoint the measured Projection exports one compacted Sequence, both peers are destroyed, and both resume from that same Sequence. Memory is sampled after hydration in the measured peer's isolated runtime, excluding its peer. Each run starts fresh and warms independently. Memory includes live native allocator bytes and eight bytes per retained JavaScript array slot, counting each Footage array once. Unused WASM capacity, JS array headers, hidden backing capacity, application value objects, compiled code and JS engine bookkeeping are excluded. Observation occurs outside API timings after optional JS process garbage collection. Exported Sequence estimates and process observations remain separate.
- Sequence sizes include V8 serialization, JSON, MessagePack, and level-nine gzip of each transport encoding. Numeric metadata is represented as arrays; encoding is outside API timings.
- Every checkpoint destroys both old peers and replaces them from the same compacted Sequence. Memory is sampled after recreation; subsequent editing uses the new peers.
