# Archived Rust Experiment Workspace

This directory is an archived copy of the experimental Rust/WASM workspace.

The original top-level `rust/target/` directory was intentionally omitted. It is Cargo build cache and can be regenerated from the archived `Cargo.toml` and `Cargo.lock`.
