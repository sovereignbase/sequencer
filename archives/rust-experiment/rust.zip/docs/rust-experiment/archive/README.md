# CRList Rust/WASM Experiment

Experimental copy-write implementation of the CRList core.

This directory is intentionally separate from the TypeScript `src/` core. The
goal is to measure whether Rust and WASM can materially improve the hot paths
without changing the production implementation.

## Dependency Notes

- `wasm-bindgen 0.2.117`: MIT OR Apache-2.0, current as of 2026-04-08, not yanked.
- `serde 1.0.228`: MIT OR Apache-2.0, current as of 2026-04-08, not yanked.
- `serde_json 1.0.x`: serde ecosystem JSON value representation for native tests.
- `serde-wasm-bindgen 0.6.5`: MIT, not yanked, used only at the JS/WASM boundary.

## Commands

```powershell
cd rust
C:\Users\jorts\.cargo\bin\cargo.exe test
C:\Users\jorts\.cargo\bin\cargo.exe run --release --example bench
C:\Users\jorts\.cargo\bin\cargo.exe build --release --target wasm32-unknown-unknown
C:\Users\jorts\.cargo\bin\wasm-bindgen.exe --target nodejs --out-dir pkg-node target\wasm32-unknown-unknown\release\crlist_wasm_experiment.wasm
node bench/node-wasm.mjs
```

## Current Scope

Implemented:

- create
- read
- snapshot
- acknowledge
- garbage collect
- merge
- experimental insert/delete helpers with caller-provided UUIDv7

The local update API is deliberately not a one-for-one TypeScript clone yet,
because UUID generation should be decided at the JS boundary or added with a
separate dependency decision.
