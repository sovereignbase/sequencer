import { createRequire } from 'node:module'
import { performance } from 'node:perf_hooks'

const require = createRequire(import.meta.url)
const { WasmCrList } = require('../pkg-node/crlist_wasm_experiment.js')
const encoder = new TextEncoder()

const N = 5_000
const OPS = 1_000
const CREATE_OPS = 100
const REVERSED_OPS = 250
const ROOT = String.fromCharCode(0)

const snapshot = seedSnapshot(N)
const snapshotBytes = encoder.encode(JSON.stringify(snapshot))

bench('wasm object create hydrate snapshot', CREATE_OPS, () => {
  for (let index = 0; index < CREATE_OPS; index++) new WasmCrList(snapshot)
})

bench('wasm bytes create hydrate snapshot', CREATE_OPS, () => {
  for (let index = 0; index < CREATE_OPS; index++)
    WasmCrList.from_snapshot_json_bytes(snapshotBytes)
})

const readReplica = new WasmCrList(snapshot)
bench('wasm object read random indexed reads', OPS, () => {
  for (let index = 0; index < OPS; index++) {
    readReplica.read((index * 37) % N)
  }
})

const mergeTarget = new WasmCrList(seedSnapshot(N))
const orderedDeltas = appendDeltas(N, OPS)
bench('wasm object merge ordered deltas', orderedDeltas.length, () => {
  for (const delta of orderedDeltas) mergeTarget.merge(delta)
})

const bytesMergeTarget = WasmCrList.from_snapshot_json_bytes(
  encoder.encode(JSON.stringify(seedSnapshot(N)))
)
const orderedDeltaBytes = orderedDeltas.map((delta) =>
  encoder.encode(JSON.stringify(delta))
)
bench('wasm bytes merge ordered deltas', orderedDeltaBytes.length, () => {
  for (const delta of orderedDeltaBytes)
    bytesMergeTarget.merge_json_bytes(delta)
})

const shuffledTarget = WasmCrList.from_snapshot_json_bytes(
  encoder.encode(JSON.stringify(seedSnapshot(N)))
)
const reversedDeltas = appendDeltas(N, REVERSED_OPS).reverse()
bench('wasm object merge reversed gossip', reversedDeltas.length, () => {
  for (const delta of reversedDeltas) shuffledTarget.merge(delta)
})

const bytesShuffledTarget = WasmCrList.from_snapshot_json_bytes(
  encoder.encode(JSON.stringify(seedSnapshot(N)))
)
const reversedDeltaBytes = reversedDeltas.map((delta) =>
  encoder.encode(JSON.stringify(delta))
)
bench('wasm bytes merge reversed gossip', reversedDeltaBytes.length, () => {
  for (const delta of reversedDeltaBytes)
    bytesShuffledTarget.merge_json_bytes(delta)
})

function bench(label, ops, run) {
  console.log(`running ${label} ops=${ops}`)
  const start = performance.now()
  run()
  const ms = performance.now() - start
  console.log(
    `${label.padEnd(32)} ops=${String(ops).padStart(5)} ms=${ms
      .toFixed(2)
      .padStart(10)} ms/op=${(ms / ops).toFixed(4).padStart(8)} ops/sec=${(
      ops /
      (ms / 1000)
    )
      .toFixed(2)
      .padStart(10)}`
  )
}

function seedSnapshot(n) {
  let predecessor = ROOT
  const values = []
  for (let index = 0; index < n; index++) {
    const uuidv7 = uuid(index)
    values.push({
      uuidv7,
      predecessor,
      value: value(index),
    })
    predecessor = uuidv7
  }
  return { values, tombstones: [] }
}

function appendDeltas(offset, n) {
  let predecessor = uuid(offset - 1)
  const deltas = []
  for (let index = 0; index < n; index++) {
    const uuidv7 = uuid(offset + index)
    deltas.push({
      values: [
        {
          uuidv7,
          predecessor,
          value: value(offset + index),
        },
      ],
    })
    predecessor = uuidv7
  }
  return deltas
}

function uuid(index) {
  return `018f2fcb-60f7-7b28-9f6f-${index.toString(16).padStart(12, '0')}`
}

function value(index) {
  return { index, text: `value-${index}` }
}
