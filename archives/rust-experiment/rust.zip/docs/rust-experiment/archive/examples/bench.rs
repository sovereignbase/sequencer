use crlist_wasm_experiment::{Delta, Replica, Snapshot, SnapshotValue};
use serde_json::{json, Value};
use std::time::Instant;

const N: usize = 5_000;
const OPS: usize = 1_000;
const ROOT: &str = "\0";

fn main() {
    let snapshot = seed_snapshot(N);
    bench("create hydrate snapshot", OPS, || {
        let _ = Replica::create(Some(snapshot.clone()));
    });

    let mut read_replica = Replica::create(Some(snapshot.clone()));
    bench("read random indexed reads", OPS, || {
        for index in [37, 401, 1024, 4095, 7] {
            let _ = read_replica.read(index);
        }
    });

    let mut merge_target = Replica::create(Some(seed_snapshot(N)));
    let ordered_deltas = append_deltas(N, OPS);
    bench("merge ordered deltas", ordered_deltas.len(), || {
        for delta in &ordered_deltas {
            let _ = merge_target.merge(delta.clone());
        }
    });

    let mut shuffled_target = Replica::create(Some(seed_snapshot(N)));
    let mut shuffled = append_deltas(N, OPS);
    shuffled.reverse();
    bench("merge reversed gossip", shuffled.len(), || {
        for delta in &shuffled {
            let _ = shuffled_target.merge(delta.clone());
        }
    });
}

fn bench(label: &str, ops: usize, mut run: impl FnMut()) {
    let start = Instant::now();
    run();
    let ms = start.elapsed().as_secs_f64() * 1_000.0;
    println!(
        "{label:28} ops={ops:5} ms={ms:10.2} ms/op={:8.4} ops/sec={:10.2}",
        ms / ops as f64,
        ops as f64 / (ms / 1_000.0)
    );
}

fn seed_snapshot(n: usize) -> Snapshot {
    let mut predecessor = ROOT.to_string();
    let values = (0..n)
        .map(|index| {
            let uuidv7 = uuid(index);
            let entry = SnapshotValue {
                uuidv7: uuidv7.clone(),
                predecessor: predecessor.clone(),
                value: value(index),
            };
            predecessor = uuidv7;
            entry
        })
        .collect();
    Snapshot {
        values,
        tombstones: vec![],
    }
}

fn append_deltas(offset: usize, n: usize) -> Vec<Delta> {
    let mut predecessor = uuid(offset - 1);
    (0..n)
        .map(|index| {
            let uuidv7 = uuid(offset + index);
            let delta = Delta {
                values: Some(vec![SnapshotValue {
                    uuidv7: uuidv7.clone(),
                    predecessor: predecessor.clone(),
                    value: value(offset + index),
                }]),
                tombstones: None,
            };
            predecessor = uuidv7;
            delta
        })
        .collect()
}

fn uuid(index: usize) -> String {
    format!("018f2fcb-60f7-7b28-9f6f-{:012x}", index)
}

fn value(index: usize) -> Value {
    json!({ "index": index, "text": format!("value-{index}") })
}
