/* tslint:disable */
/* eslint-disable */

export class WasmCrList {
  free(): void
  [Symbol.dispose](): void
  acknowledge(): any
  static from_snapshot_json_bytes(snapshot: Uint8Array): WasmCrList
  garbage_collect(frontiers: any): void
  merge(delta: any): any
  merge_json_bytes(delta: Uint8Array): any
  constructor(snapshot: any)
  read(index: number): any
  snapshot(): any
  readonly size: number
}
