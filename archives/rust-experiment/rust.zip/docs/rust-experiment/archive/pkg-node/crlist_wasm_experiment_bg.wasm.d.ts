/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory
export const __wbg_wasmcrlist_free: (a: number, b: number) => void
export const wasmcrlist_acknowledge: (a: number) => any
export const wasmcrlist_from_snapshot_json_bytes: (
  a: number,
  b: number
) => [number, number, number]
export const wasmcrlist_garbage_collect: (a: number, b: any) => [number, number]
export const wasmcrlist_merge: (a: number, b: any) => [number, number, number]
export const wasmcrlist_merge_json_bytes: (
  a: number,
  b: number,
  c: number
) => [number, number, number]
export const wasmcrlist_new: (a: any) => [number, number, number]
export const wasmcrlist_read: (a: number, b: number) => any
export const wasmcrlist_size: (a: number) => number
export const wasmcrlist_snapshot: (a: number) => [number, number, number]
export const __wbindgen_malloc: (a: number, b: number) => number
export const __wbindgen_realloc: (
  a: number,
  b: number,
  c: number,
  d: number
) => number
export const __wbindgen_exn_store: (a: number) => void
export const __externref_table_alloc: () => number
export const __wbindgen_externrefs: WebAssembly.Table
export const __externref_table_dealloc: (a: number) => void
export const __wbindgen_start: () => void
