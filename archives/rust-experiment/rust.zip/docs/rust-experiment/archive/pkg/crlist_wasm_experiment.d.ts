/* tslint:disable */
/* eslint-disable */

export class WasmCrList {
  free(): void
  [Symbol.dispose](): void
  acknowledge(): any
  garbage_collect(frontiers: any): void
  merge(delta: any): any
  constructor(snapshot: any)
  read(index: number): any
  snapshot(): any
  readonly size: number
}

export type InitInput =
  | RequestInfo
  | URL
  | Response
  | BufferSource
  | WebAssembly.Module

export interface InitOutput {
  readonly memory: WebAssembly.Memory
  readonly __wbg_wasmcrlist_free: (a: number, b: number) => void
  readonly wasmcrlist_acknowledge: (a: number) => any
  readonly wasmcrlist_garbage_collect: (a: number, b: any) => [number, number]
  readonly wasmcrlist_merge: (a: number, b: any) => [number, number, number]
  readonly wasmcrlist_new: (a: any) => [number, number, number]
  readonly wasmcrlist_read: (a: number, b: number) => any
  readonly wasmcrlist_size: (a: number) => number
  readonly wasmcrlist_snapshot: (a: number) => [number, number, number]
  readonly __wbindgen_malloc: (a: number, b: number) => number
  readonly __wbindgen_realloc: (
    a: number,
    b: number,
    c: number,
    d: number
  ) => number
  readonly __wbindgen_exn_store: (a: number) => void
  readonly __externref_table_alloc: () => number
  readonly __wbindgen_externrefs: WebAssembly.Table
  readonly __externref_table_dealloc: (a: number) => void
  readonly __wbindgen_start: () => void
}

export type SyncInitInput = BufferSource | WebAssembly.Module

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(
  module: { module: SyncInitInput } | SyncInitInput
): InitOutput

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init(
  module_or_path?:
    | { module_or_path: InitInput | Promise<InitInput> }
    | InitInput
    | Promise<InitInput>
): Promise<InitOutput>
