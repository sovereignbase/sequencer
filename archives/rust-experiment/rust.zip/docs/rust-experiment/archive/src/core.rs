use crate::types::{Change, Delta, Entry, Snapshot, SnapshotValue, ROOT};
use serde_json::Value;
use std::collections::{BTreeSet, HashMap, HashSet};

#[derive(Default)]
pub struct Replica {
    pub size: usize,
    pub cursor: Option<String>,
    pub tombstones: BTreeSet<String>,
    parent: HashMap<String, Entry>,
    children: HashMap<String, Vec<String>>,
}

impl Replica {
    pub fn create(snapshot: Option<Snapshot>) -> Self {
        let mut replica = Self::default();
        let Some(snapshot) = snapshot else {
            return replica;
        };
        for tombstone in snapshot.tombstones {
            if is_uuid_v7(&tombstone) {
                replica.tombstones.insert(tombstone);
            }
        }
        for value in snapshot.values {
            if let Some(entry) = replica.snapshot_value_to_entry(value) {
                replica.update_entry_to_maps(entry);
            }
        }
        replica.flatten_and_link();
        replica.assert_indices();
        replica
    }

    pub fn read(&mut self, index: usize) -> Option<Value> {
        self.walk_to_index(index)
            .and_then(|id| self.parent.get(&id).map(|entry| entry.value.clone()))
    }

    pub fn snapshot(&self) -> Snapshot {
        let mut values: Vec<_> = self.parent.values().map(SnapshotValue::from).collect();
        values.sort_by(|a, b| a.uuidv7.cmp(&b.uuidv7));
        Snapshot {
            values,
            tombstones: self.tombstones.iter().cloned().collect(),
        }
    }

    pub fn acknowledge(&self) -> Option<String> {
        self.tombstones.iter().next_back().cloned()
    }

    pub fn garbage_collect(&mut self, frontiers: Vec<String>) {
        let Some(frontier) = frontiers.into_iter().min() else {
            return;
        };
        self.tombstones.retain(|tombstone| tombstone > &frontier);
    }

    pub fn merge(&mut self, delta: Delta) -> Option<Change> {
        let mut change = Change::new();
        let mut new_values = Vec::new();
        let mut needs_relink = false;
        if let Some(tombstones) = delta.tombstones {
            for tombstone in tombstones {
                if !is_uuid_v7(&tombstone) || !self.tombstones.insert(tombstone.clone()) {
                    continue;
                }
                if let Some(index) = self.delete_linked_entry(&tombstone, false) {
                    change.insert(index, None);
                    needs_relink = true;
                }
            }
        }
        let Some(values) = delta.values else {
            if needs_relink {
                self.assert_indices();
            }
            return (!change.is_empty()).then_some(change);
        };
        for value in values {
            if let Some(existing) = self.parent.get(&value.uuidv7) {
                if self.tombstones.contains(&value.uuidv7) || !is_predecessor(&value.predecessor) {
                    continue;
                }
                if existing.predecessor >= value.predecessor {
                    continue;
                }
                let id = existing.uuidv7.clone();
                self.move_entry_to_predecessor(&id, value.predecessor);
                new_values.push(id);
                needs_relink = true;
                continue;
            }
            let Some(entry) = self.snapshot_value_to_entry(value) else {
                continue;
            };
            let id = entry.uuidv7.clone();
            let predecessor_id = entry.predecessor.clone();
            let predecessor = (predecessor_id != ROOT)
                .then(|| self.parent.get(&predecessor_id).map(|p| p.uuidv7.clone()))
                .flatten();
            let root_successor = (!needs_relink
                && (predecessor_id == ROOT || predecessor.is_none()))
            .then(|| self.root_successor(&id))
            .flatten();
            let root_tail = (!needs_relink && predecessor_id == ROOT && self.size > 0)
                .then(|| self.tail())
                .flatten();
            self.update_entry_to_maps(entry);
            new_values.push(id.clone());
            if !needs_relink && predecessor_id == ROOT {
                if self.size == 0 {
                    self.cursor = Some(id);
                    self.size = self.parent.len();
                } else if let Some(successor) = root_successor {
                    let prev = self.parent[&successor].prev.clone();
                    let index = self.parent[&successor].index;
                    self.link_between(prev, &id, Some(successor), index);
                    self.shift_after(&id, 1);
                    self.cursor = Some(id);
                    self.size = self.parent.len();
                } else if let Some(tail) = root_tail {
                    let index = self.parent[&tail].index + 1;
                    self.link_between(Some(tail), &id, None, index);
                    self.cursor = Some(id);
                    self.size = self.parent.len();
                } else {
                    needs_relink = true;
                }
            } else if let Some(predecessor) = predecessor {
                if !needs_relink
                    && self
                        .parent
                        .get(&predecessor)
                        .and_then(|p| p.next.clone())
                        .is_none()
                {
                    let index = self.parent[&predecessor].index + 1;
                    self.link_after(&predecessor, &id, index);
                } else {
                    needs_relink = true;
                }
            } else {
                if let Some(successor) = root_successor {
                    let prev = self.parent[&successor].prev.clone();
                    let index = self.parent[&successor].index;
                    self.link_between(prev, &id, Some(successor), index);
                    self.shift_after(&id, 1);
                    self.cursor = Some(id);
                    self.size = self.parent.len();
                } else if let Some(tail) = self.tail() {
                    let index = self.parent[&tail].index + 1;
                    self.link_between(Some(tail), &id, None, index);
                    self.cursor = Some(id);
                    self.size = self.parent.len();
                } else {
                    needs_relink = true;
                }
            }
        }
        if needs_relink {
            self.flatten_and_link();
            self.assert_indices();
        }
        for id in new_values {
            if let Some(entry) = self.parent.get(&id) {
                change.insert(entry.index, Some(entry.value.clone()));
            }
        }
        (!change.is_empty()).then_some(change)
    }

    pub fn insert_after_with_uuid(
        &mut self,
        index: usize,
        uuidv7: String,
        value: Value,
    ) -> Option<Change> {
        if !is_uuid_v7(&uuidv7)
            || self.tombstones.contains(&uuidv7)
            || self.parent.contains_key(&uuidv7)
        {
            return None;
        }
        let predecessor = if self.size == 0 {
            ROOT.to_string()
        } else {
            self.walk_to_index(index)?;
            self.cursor.clone()?
        };
        let entry = Entry {
            uuidv7: uuidv7.clone(),
            value,
            predecessor: predecessor.clone(),
            index: 0,
            prev: None,
            next: None,
        };
        let next = (predecessor != ROOT)
            .then(|| {
                self.parent
                    .get(&predecessor)
                    .and_then(|entry| entry.next.clone())
            })
            .flatten();
        self.update_entry_to_maps(entry);
        if predecessor == ROOT && self.size == 0 {
            self.cursor = Some(uuidv7.clone());
            self.size = self.parent.len();
        } else if predecessor != ROOT {
            let index = self.parent[&predecessor].index + 1;
            self.link_between(Some(predecessor), &uuidv7, next, index);
            self.shift_after(&uuidv7, 1);
            self.size = self.parent.len();
        } else {
            self.flatten_and_link();
            self.assert_indices();
        }
        let entry = self.parent.get(&uuidv7)?;
        let mut change = Change::new();
        change.insert(entry.index, Some(entry.value.clone()));
        Some(change)
    }

    pub fn delete_range(&mut self, start: usize, end: Option<usize>) -> Option<Change> {
        if start > self.size {
            return None;
        }
        let end = end.unwrap_or(self.size).min(self.size);
        if end <= start {
            return None;
        }
        self.walk_to_index(start)?;
        let mut current = self.cursor.clone();
        let mut change = Change::new();
        let mut deleted = 0usize;
        while deleted < end - start {
            let Some(id) = current.clone() else {
                break;
            };
            current = self.parent.get(&id).and_then(|entry| entry.next.clone());
            if let Some(index) = self.delete_linked_entry(&id, true) {
                change.insert(index, None);
            }
            deleted += 1;
        }
        let mut rest = current;
        while let Some(id) = rest.clone() {
            if let Some(entry) = self.parent.get_mut(&id) {
                entry.index -= deleted;
                rest = entry.next.clone();
            } else {
                break;
            }
        }
        self.size = self.parent.len();
        (!change.is_empty()).then_some(change)
    }

    fn snapshot_value_to_entry(&self, value: SnapshotValue) -> Option<Entry> {
        if !is_uuid_v7(&value.uuidv7)
            || self.tombstones.contains(&value.uuidv7)
            || self.parent.contains_key(&value.uuidv7)
            || !is_predecessor(&value.predecessor)
        {
            return None;
        }
        Some(Entry {
            uuidv7: value.uuidv7,
            value: value.value,
            predecessor: value.predecessor,
            index: 0,
            prev: None,
            next: None,
        })
    }

    fn update_entry_to_maps(&mut self, entry: Entry) {
        self.children
            .entry(entry.predecessor.clone())
            .or_default()
            .push(entry.uuidv7.clone());
        self.parent.insert(entry.uuidv7.clone(), entry);
    }

    fn delete_entry_from_maps(&mut self, id: &str) -> Option<Entry> {
        let entry = self.parent.remove(id)?;
        if let Some(siblings) = self.children.get_mut(&entry.predecessor) {
            siblings.retain(|sibling| sibling != id);
        }
        Some(entry)
    }

    fn delete_linked_entry(&mut self, id: &str, add_tombstone: bool) -> Option<usize> {
        if add_tombstone {
            self.tombstones.insert(id.to_string());
        }
        let entry = self.delete_entry_from_maps(id)?;
        if let Some(prev) = entry.prev.clone() {
            if let Some(prev_entry) = self.parent.get_mut(&prev) {
                prev_entry.next = entry.next.clone();
            }
        }
        if let Some(next) = entry.next.clone() {
            if let Some(next_entry) = self.parent.get_mut(&next) {
                next_entry.prev = entry.prev.clone();
            }
        }
        if self.cursor.as_deref() == Some(id) {
            self.cursor = entry.next.clone().or(entry.prev.clone());
        }
        self.size = self.parent.len();
        Some(entry.index)
    }

    fn move_entry_to_predecessor(&mut self, id: &str, predecessor: String) {
        let Some(mut entry) = self.delete_entry_from_maps(id) else {
            return;
        };
        entry.predecessor = predecessor;
        self.update_entry_to_maps(entry);
    }

    fn flatten_and_link(&mut self) {
        self.size = 0;
        for entry in self.parent.values_mut() {
            entry.prev = None;
            entry.next = None;
        }
        let mut orphan_root_siblings = Vec::new();
        for (predecessor, siblings) in &self.children {
            if predecessor != ROOT && !self.parent.contains_key(predecessor) {
                orphan_root_siblings.extend(siblings.iter().cloned());
            }
        }
        let mut resolved = HashSet::new();
        let mut ids: Vec<_> = self.parent.keys().cloned().collect();
        ids.sort();
        for id in ids {
            let Some(entry) = self.parent.get(&id) else {
                continue;
            };
            let predecessor_id =
                if entry.predecessor == ROOT || self.parent.contains_key(&entry.predecessor) {
                    entry.predecessor.clone()
                } else {
                    ROOT.to_string()
                };
            if !resolved.insert(predecessor_id.clone()) {
                continue;
            }
            let predecessor = (predecessor_id != ROOT).then_some(predecessor_id.clone());
            if predecessor
                .as_ref()
                .is_some_and(|p| !self.parent.contains_key(p))
            {
                continue;
            }
            let mut siblings = if predecessor_id == ROOT {
                let mut values = self.children.get(ROOT).cloned().unwrap_or_default();
                values.extend(orphan_root_siblings.iter().cloned());
                values
            } else {
                self.children
                    .get(&predecessor_id)
                    .cloned()
                    .unwrap_or_default()
            };
            siblings.retain(|sibling| self.parent.contains_key(sibling));
            if siblings.is_empty() {
                continue;
            }
            siblings.sort();
            let mut prev = predecessor;
            for sibling in siblings {
                self.insert_after_prev(prev.clone(), sibling.clone());
                prev = Some(sibling);
            }
            self.cursor = Some(id);
        }
        self.size = self.parent.len();
    }

    fn insert_after_prev(&mut self, prev: Option<String>, id: String) {
        let next = prev
            .as_ref()
            .and_then(|prev| self.parent.get(prev))
            .and_then(|entry| entry.next.clone());
        self.link_between(prev, &id, next, 0);
    }

    fn link_after(&mut self, predecessor: &str, id: &str, index: usize) {
        self.link_between(Some(predecessor.to_string()), id, None, index);
        self.cursor = Some(id.to_string());
        self.size = self.parent.len();
    }

    fn link_between(&mut self, prev: Option<String>, id: &str, next: Option<String>, index: usize) {
        if let Some(entry) = self.parent.get_mut(id) {
            entry.prev = prev.clone();
            entry.next = next.clone();
            entry.index = index;
        }
        if let Some(prev) = prev {
            if let Some(prev_entry) = self.parent.get_mut(&prev) {
                prev_entry.next = Some(id.to_string());
            }
        }
        if let Some(next) = next {
            if let Some(next_entry) = self.parent.get_mut(&next) {
                next_entry.prev = Some(id.to_string());
            }
        }
    }

    fn shift_after(&mut self, id: &str, amount: usize) {
        let mut current = self.parent.get(id).and_then(|entry| entry.next.clone());
        while let Some(current_id) = current {
            if let Some(entry) = self.parent.get_mut(&current_id) {
                entry.index += amount;
                current = entry.next.clone();
            } else {
                break;
            }
        }
    }

    fn root_successor(&self, id: &str) -> Option<String> {
        self.parent
            .values()
            .filter(|entry| {
                (entry.predecessor == ROOT || !self.parent.contains_key(&entry.predecessor))
                    && entry.uuidv7.as_str() > id
            })
            .min_by(|a, b| a.uuidv7.cmp(&b.uuidv7))
            .map(|entry| entry.uuidv7.clone())
    }

    fn tail(&self) -> Option<String> {
        self.parent
            .values()
            .max_by_key(|entry| entry.index)
            .map(|entry| entry.uuidv7.clone())
    }

    fn assert_indices(&mut self) {
        let Some(mut current) = self.cursor.clone() else {
            return;
        };
        while let Some(prev) = self
            .parent
            .get(&current)
            .and_then(|entry| entry.prev.clone())
        {
            current = prev;
        }
        let mut index = 0usize;
        loop {
            let next = if let Some(entry) = self.parent.get_mut(&current) {
                entry.index = index;
                entry.next.clone()
            } else {
                None
            };
            let Some(next) = next else {
                break;
            };
            current = next;
            index += 1;
        }
    }

    fn walk_to_index(&mut self, target: usize) -> Option<String> {
        if target >= self.size {
            return None;
        }
        if self.cursor.is_none() {
            self.cursor = self
                .parent
                .values()
                .next()
                .map(|entry| entry.uuidv7.clone());
        }
        loop {
            let current = self.cursor.clone()?;
            let entry = self.parent.get(&current)?;
            match entry.index.cmp(&target) {
                std::cmp::Ordering::Equal => return Some(current),
                std::cmp::Ordering::Less => self.cursor = entry.next.clone(),
                std::cmp::Ordering::Greater => self.cursor = entry.prev.clone(),
            }
        }
    }
}

fn is_predecessor(value: &str) -> bool {
    value == ROOT || is_uuid_v7(value)
}

pub fn is_uuid_v7(value: &str) -> bool {
    let bytes = value.as_bytes();
    bytes.len() == 36
        && bytes[8] == b'-'
        && bytes[13] == b'-'
        && bytes[18] == b'-'
        && bytes[23] == b'-'
        && bytes[14] == b'7'
        && matches!(bytes[19], b'8' | b'9' | b'a' | b'b' | b'A' | b'B')
        && bytes
            .iter()
            .enumerate()
            .all(|(index, byte)| matches!(index, 8 | 13 | 18 | 23) || byte.is_ascii_hexdigit())
}

#[cfg(test)]
mod tests {
    use super::*;
    use serde_json::json;

    fn value(uuidv7: &str, predecessor: &str, value: &str) -> SnapshotValue {
        SnapshotValue {
            uuidv7: uuidv7.to_string(),
            predecessor: predecessor.to_string(),
            value: json!(value),
        }
    }

    const A: &str = "018f2fcb-60f7-7b28-9f6f-b1fbd832c001";
    const B: &str = "018f2fcb-60f7-7b28-9f6f-b1fbd832c002";
    const C: &str = "018f2fcb-60f7-7b28-9f6f-b1fbd832c003";

    #[test]
    fn create_orders_children() {
        let mut replica = Replica::create(Some(Snapshot {
            values: vec![value(C, B, "c"), value(A, ROOT, "a"), value(B, A, "b")],
            tombstones: vec![],
        }));
        assert_eq!(replica.size, 3);
        assert_eq!(replica.read(0), Some(json!("a")));
        assert_eq!(replica.read(1), Some(json!("b")));
        assert_eq!(replica.read(2), Some(json!("c")));
    }

    #[test]
    fn merge_is_idempotent() {
        let mut replica = Replica::default();
        let delta = Delta {
            values: Some(vec![value(A, ROOT, "a"), value(B, A, "b")]),
            tombstones: None,
        };
        assert!(replica.merge(delta.clone()).is_some());
        assert!(replica.merge(delta).is_none());
        assert_eq!(replica.size, 2);
    }

    #[test]
    fn tombstone_removes_live_entry() {
        let mut replica = Replica::create(Some(Snapshot {
            values: vec![value(A, ROOT, "a"), value(B, A, "b")],
            tombstones: vec![],
        }));
        let change = replica
            .merge(Delta {
                values: None,
                tombstones: Some(vec![A.to_string()]),
            })
            .unwrap();
        assert_eq!(change.get(&0), Some(&None));
        assert_eq!(replica.size, 1);
    }
}
