mod core;
mod types;

pub use core::{is_uuid_v7, Replica};
pub use types::{Change, Delta, Snapshot, SnapshotValue};

use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub struct WasmCrList {
    inner: Replica,
}

#[wasm_bindgen]
impl WasmCrList {
    #[wasm_bindgen(constructor)]
    pub fn new(snapshot: JsValue) -> Result<WasmCrList, JsValue> {
        let snapshot = if snapshot.is_null() || snapshot.is_undefined() {
            None
        } else {
            Some(from_js(snapshot)?)
        };
        Ok(Self {
            inner: Replica::create(snapshot),
        })
    }

    pub fn from_snapshot_json_bytes(snapshot: &[u8]) -> Result<WasmCrList, JsValue> {
        let snapshot = serde_json::from_slice(snapshot)
            .map_err(|error| JsValue::from_str(&error.to_string()))?;
        Ok(Self {
            inner: Replica::create(Some(snapshot)),
        })
    }

    #[wasm_bindgen(getter)]
    pub fn size(&self) -> usize {
        self.inner.size
    }

    pub fn read(&mut self, index: usize) -> JsValue {
        match self.inner.read(index) {
            Some(value) => to_js(value).unwrap_or(JsValue::UNDEFINED),
            None => JsValue::UNDEFINED,
        }
    }

    pub fn snapshot(&self) -> Result<JsValue, JsValue> {
        to_js(self.inner.snapshot())
    }

    pub fn merge(&mut self, delta: JsValue) -> Result<JsValue, JsValue> {
        let delta: Delta = from_js(delta)?;
        Ok(match self.inner.merge(delta) {
            Some(change) => to_js(change)?,
            None => JsValue::FALSE,
        })
    }

    pub fn merge_json_bytes(&mut self, delta: &[u8]) -> Result<JsValue, JsValue> {
        let delta: Delta =
            serde_json::from_slice(delta).map_err(|error| JsValue::from_str(&error.to_string()))?;
        Ok(match self.inner.merge(delta) {
            Some(change) => to_js(change)?,
            None => JsValue::FALSE,
        })
    }

    pub fn acknowledge(&self) -> JsValue {
        match self.inner.acknowledge() {
            Some(frontier) => to_js(frontier).unwrap_or(JsValue::FALSE),
            None => JsValue::FALSE,
        }
    }

    pub fn garbage_collect(&mut self, frontiers: JsValue) -> Result<(), JsValue> {
        let frontiers: Vec<String> = from_js(frontiers)?;
        self.inner.garbage_collect(frontiers);
        Ok(())
    }
}

fn from_js<T>(value: JsValue) -> Result<T, JsValue>
where
    T: serde::de::DeserializeOwned,
{
    serde_wasm_bindgen::from_value(value).map_err(|error| JsValue::from_str(&error.to_string()))
}

fn to_js<T>(value: T) -> Result<JsValue, JsValue>
where
    T: serde::Serialize,
{
    serde_wasm_bindgen::to_value(&value).map_err(|error| JsValue::from_str(&error.to_string()))
}
