use serde::{Deserialize, Serialize};
use serde_json::Value;
use std::collections::BTreeMap;

pub const ROOT: &str = "\0";

#[derive(Clone, Debug)]
pub struct Entry {
    pub uuidv7: String,
    pub value: Value,
    pub predecessor: String,
    pub index: usize,
    pub prev: Option<String>,
    pub next: Option<String>,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
pub struct SnapshotValue {
    pub uuidv7: String,
    pub value: Value,
    pub predecessor: String,
}

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
pub struct Snapshot {
    #[serde(default)]
    pub values: Vec<SnapshotValue>,
    #[serde(default)]
    pub tombstones: Vec<String>,
}

#[derive(Clone, Debug, Default, Deserialize, Serialize)]
pub struct Delta {
    pub values: Option<Vec<SnapshotValue>>,
    pub tombstones: Option<Vec<String>>,
}

pub type Change = BTreeMap<usize, Option<Value>>;

impl From<&Entry> for SnapshotValue {
    fn from(entry: &Entry) -> Self {
        Self {
            uuidv7: entry.uuidv7.clone(),
            value: entry.value.clone(),
            predecessor: entry.predecessor.clone(),
        }
    }
}
